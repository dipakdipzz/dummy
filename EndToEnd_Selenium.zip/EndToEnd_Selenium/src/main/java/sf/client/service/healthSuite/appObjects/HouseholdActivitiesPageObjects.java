package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.Span;

/**
 * This class contains all the page objects related to Household Activities
 */
public class HouseholdActivitiesPageObjects {
	
	private static final String LINK_MEMBER_ACTION = "innerText=Member Actions";
	private static final String SPAN_IS_HOUSEHOLD_ACTIVITIES = "text=Household Activities";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final Link LINK_MEMBER_ACTIONS = new Link(LINK_MEMBER_ACTION);
		public static final Span  SPAN_HOUSEHOLD_ACTIVITIES = new Span(SPAN_IS_HOUSEHOLD_ACTIVITIES);
	}
	
}