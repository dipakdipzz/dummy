package sf.client.service.healthSuite.appObjects;

import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;
import statefarm.widget.automater.WidgetIDs;


public class CreateIndividualCustomer {
	/*public static final ListBox LIST_AGENT = new ListBox("id=stAgtCode");
	public static final TextField TEXT_FIRSTNAME = new TextField(
			"id=person.bestName.firstName");
	public static final TextField TEXT_LASTNAME = new TextField(
			"id=person.bestName.lastName");
	public static final TextField MAILING_TEXT_PROVINCE = new TextField(
			"id=provinceLabel[0]");
	public static final TextField MAILING_TEXT_STATE = new TextField(
			"id=stateLabel[0]");
	public static final RadioButton MAILING_RADIO_CANADA = new RadioButton(
			"id=person.addresses[0].typeCanada");
	public static final TextField MAILING_TEXT_CITY = new TextField(
			"id=person.addresses[0].city");
	public static final TextField MAILING_TEXT_STREET = new TextField(
			"id=person.addresses[0].street1");
	public static final TextField MAILING_TEXT_ZIP = new TextField(
			"id=person.addresses[0].zipPostalCode");
	public static final RadioButton RADIO_US = new RadioButton(
			"id=person.addresses[0].typeUS");
	public static final RadioButton RADIO_ORG_US = new RadioButton(
			"id=organization.addresses[0].typeUS");
	public static final TextField TEXT_HOMEPHONE = new TextField(
			"id=person.phones[1].number");
	public static final ListBox LIST_CALLINGPREFERENCEDAYMOBILE = new ListBox(
			"name=person.phones[0].phoneAvailability");
	public static final ListBox LIST_FROMTIMEMOBILE = new ListBox(
			"name=person.phones[0].availabilityStartTime");
	public static final ListBox LIST_TOTIMEMOBILE = new ListBox(
			"name=person.phones[0].availabilityEndTime");
	public static final ListBox LIST_CALLINGPREFERENCEDAYHOME = new ListBox(
			"name=person.phones[1].phoneAvailability");
	public static final ListBox LIST_CALLINGPREFERENCEDAYADDTl = new ListBox(
			"name=person.phones[3].phoneAvailability");
	public static final ListBox LIST_FROMTIMEADDTl = new ListBox(
			"name=person.phones[3].availabilityStartTime");
	public static final ListBox LIST_TOTIMEADDTl = new ListBox(
			"name=person.phones[3].availabilityEndTime");
	public static final TextField TEXT_INDEMAILADDRESS = new TextField(
			"id=person.emails[0].address");
	public static final RadioButton RADIO_PUBLISHEMAIL = new RadioButton(
			"id=person.emails[0].marketingIndicatorYes");
	public static final TextField TEXT_SSNSIN = new TextField(
			"name=person.tin.number");
	public static final TextField TEXT_HEARABOUTOFFICECODE = new TextField(
			"id=person.agent.hearAboutOfficeCode");
	public static final TextField TEXT_IMPORTANCEFACTORCODE = new TextField(
			"id=person.agent.agentMarketingInfo.importanceFactorCode");
	public static final Button BUTTON_CREATECUSTOMER = new Button("id=save");
	public static final Button BUTTON__OK = new Button("id=ok");
	public static final Button BUTTON_OK_ADDRESSSTANDARDIZATION = new Button(
			"text=OK");
	public static final CheckBox CheckBox_KEEPNOT_STANDARD = new CheckBox(
			"id=keepNonStandard");
	public static final Link LINK_qb_createIndividualCustomer = new Link(
			"text=Create individual customer");
	public static final Link link_basicInfoTab_org = new Link(
			"id=pageBodyPartyManagement");
	public static final Link LINK_basicInfoTab = new Link(
			"id=tcDoLayout_tablist_basicInfo");
	public static final Link LINK_emailTab = new Link(
			"id=phone_emailContainer_tablist_emailTab");
	public static final Span SPAN_PROCEEDWITHCANCEL = new Span(
			"id=yesButton_label");
	public static final Link LINK_MOBILE_CALLING_PREFERENCE = new Link(
			"onclick=showPhoneCallingPreferences(*mobileCallingPrefDiv*);");
	public static final Link LINK_HOME_CALLING_PREFERENCE = new Link(
			"onclick=showPhoneCallingPreferences(*homeCallingPrefDiv*);");
	public static final Link LINK_ADDLTYPE_CALLING_PREFERENCE = new Link(
			"onclick=showPhoneCallingPreferences(*additionalCallingPrefDiv*);");
	public static final TextField TEXT_ADDITIONALPHONENUMBER = new TextField(
			"id=person.phones[3].number");
	public static final ListBox LIST_ADDITIONALTYPE = new ListBox(
			"id=person.phones[3].phonePurpose");
	public static final Link LINK_PHONETAB = new Link(
			"id=phone_emailContainer_tablist_phoneTab");
	public static final Link LINK_EMAILTAB = new Link(
			"id=phone_emailContainer_tablist_emailTab");
	public static final RadioButton RADIOBUTTON_PERMISSION_YES = new RadioButton(
			"value=Y");
	public static final RadioButton RADIOBUTTON_PERMISSION_NO = new RadioButton(
			"value=N");
	public static final RadioButton RADIOBUTTON_PERMISSION_DIDNOTASK = new RadioButton(
			"value=U");
	public static final Link LINK_ABSCREATE_INDIVIDUAL = new Link(
			"text=Create individual customer");
	public static final TextField TEXT_CELLPHONE_Cpp = new TextField(
			"id=person.phones[0].number");
	public static final ListBox LIST_FROMTIMEHOME_Cpp = new ListBox(
			"name=person.phones[1].availabilityStartTime");
	public static final ListBox LIST_TOTIMEHOME_Cpp = new ListBox(
			"name=person.phones[1].availabilityEndTime");
	public static final Link LINK_CREATE_INDIVIDUAL = new Link(
			"text=Create Individual");
	public static final Button BUTTON_CANCEL = new Button("id=cancel");
	public static final Div SEARCH_BOOK = new Div(
			"id=PC_7_DUGDR5C3289L40IQ8K9K493002_bookSearched");
	public static final Div DIV_PHONETOOLTIPCONTAINER = new Div(
			"class=dijitTooltipContainer dijitTooltipContents");
	public static final Button AHQB = new Button("id=CRC_Launcher_launch");
	public static final Button GREETING_OK = new Button("id=okB");*/
	
	//WidgetInfo class related constants
	public static final String LISTBOX_STATE_AGENTCODE="id=stAgtCode";
	public static final String TEXTFIELD_PERSON_FIRSTNAME="id=person.bestName.firstName";
	public static final String TEXTFIELD_PERSON_LASTNAME="id=person.bestName.lastName";
	public static final String TEXTFIELD_MAILINGTEXT_PROVINCELABEL="id=provinceLabel[0]";
	public static final String TEXTFIELD_MAILINGTEXT_STATELABEL="id=stateLabel[0]";
	public static final String RADIOBUTTON_PERSON_CANADAADDRESS="id=person.addresses[0].typeCanada";
	public static final String TEXTFIELD_PERSON_CITYADDRESS ="id=person.addresses[0].city";
	public static final String TEXTFIELD_PERSON_STREETADDRESS ="id=person.addresses[0].street1";
	public static final String TEXTFIELD_PERSON_POSTALADDRESS="id=person.addresses[0].zipPostalCode";
	public static final String RADIOBUTTON_PERSON_USADDRESS="id=person.addresses[0].typeUS";
	public static final String RADIOBUTTON_ORGANIZATION_USADDRESS="id=organization.addresses[0].typeUS";
	public static final String TEXT_PERSON_PHONENUMBER="id=person.phones[1].number";
	public static final String LISTBOX_PERSON_FIRSTPHONEAVAILABILITY="name=person.phones[0].phoneAvailability";
	public static final String LISTBOX_PERSON_FIRSTAVAILABILITYSTARTTIME="name=person.phones[0].availabilityStartTime";
	public static final String LISTBOX_PERSON_FIRSTAVAILABILITYENDTIME="name=person.phones[0].availabilityEndTime";
	public static final String LISTBOX_PERSON_SECONDPHONEAVAILABILITYE="name=person.phones[1].phoneAvailability";
	public static final String LISTBOX_PERSON_FOURTHPHONEAVAILABILITYE="name=person.phones[3].phoneAvailability";
	public static final String LISTBOX_PERSON_FOURTHAVAILABILITYSTARTTIME="name=person.phones[3].availabilityStartTime";
	public static final String LISTBOX_PERSON_FOURTHAVAILABILITYENDTIME="name=person.phones[3].availabilityEndTime";
	public static final String TEXTFIELD_PERSON_EMAILADDRESS ="id=person.emails[0].address";
	public static final String RADIOBUTTON_PERSON_MARKETINGINDICATOR="id=person.emails[0].marketingIndicatorYes";
	public static final String TEXTFIELD_PERSON_TINNUMBER ="name=person.tin.number";
	public static final String TEXTFIELD_HEARAGENTOFFICECODE="id=person.agent.hearAboutOfficeCode";
	public static final String TEXTFIELD_IMPORTANCEFACTORCODE="id=person.agent.agentMarketingInfo.importanceFactorCode";
	public static final String BUTTON_SAVE="id=save";
	public static final String BUTTON_OK="id=ok";
	public static final String BUTTON_TEXTOK="text=OK";
	public static final String CHECKBOX_KEEPNONSTANDARD="id=keepNonStandard";
	public static final String LINK_CREATEINDIVIDUALCUSTOMER="text=Create individual customer";
	public static final String LINK_LAUNCHAHQB="text=Launch AHQB Online";
	public static final String LINK_BODYPARTYMANAGEMENT="id=pageBodyPartyManagement";
	public static final String LINK_BASICINFO="id=tcDoLayout_tablist_basicInfo";
	public static final String LINK_EMAILTAB_ID="id=phone_emailContainer_tablist_emailTab";
	public static final String SPAN_YESBUTTON="id=yesButton_label";
	public static final String LINK_MOBILECALLING_METHOD="id=mobileCallingPrefLabelDiv";
	public static final String LINK_HOMECALLING_METHOD="id=homeCallingPrefLabelDiv";
	public static final String LINK_ADDITIONALCALLING_METHOD="id=additionalCallingPrefLabelDiv";
	public static final String TEXTFIELD_PERSON_FOURTHPHONENUMBER="id=person.phones[3].number";
	public static final String TEXTFIELD_PERSON_FOURTHPHONEPURPOSE="id=person.phones[3].phonePurpose";
	public static final String LINK_PHONETAB_ID="id=phone_emailContainer_tablist_phoneTab";
	public static final String LINK_EMAILTAB="id=phone_emailContainer_tablist_emailTab";
	public static final String RADIOBUTTON_PERMISSION_Y="value=Y";
	public static final String RADIOBUTTON_PERMISSION_N="value=N";
	public static final String RADIOBUTTON_PERMISSION_U="value=U";
	public static final String LINK_INDIVIDUAL_CUSTOMER="text=Create individual customer";
	public static final String TEXTFIELD_PERSON_FIRSTPHONENUMBER="id=person.phones[0].number";
	public static final String LISTBOX_PERSON_SECONDAVAILABILITYSTARTTIME="name=person.phones[1].availabilityStartTime";
	public static final String LISTBOX_PERSON_SECONDAVAILABILITYENDTIME="name=person.phones[1].availabilityEndTime";
	public static final String LINK_CREATE_INDIVIDUAL_TEXT="text=Create Individual";
	public static final String BUTTON_CANCEL_ID="id=cancel";
	public static final String DIV_BOOK_SEARCH="id=PC_7_DUGDR5C3289L40IQ8K9K493002_bookSearched";
	public static final String DIV_TOOLTIPCONTENT="class=dijitTooltipContainer dijitTooltipContents";
	public static final String BUTTON_CRC_LAUNCH="id=CRC_Launcher_launch";
	public static final String BUTTON_GREETING="id=okB";
	public static final String LAUNCHAHQB="text=Launch AHQB Online";
	
	
	@WidgetIDs
	public static class WidgetInfos {

		public static final ListBox LIST_AGENT = new ListBox(LISTBOX_STATE_AGENTCODE);
		public static final TextField TEXT_FIRSTNAME = new TextField(TEXTFIELD_PERSON_FIRSTNAME);
		public static final TextField TEXT_LASTNAME = new TextField(TEXTFIELD_PERSON_LASTNAME);
		public static final TextField TEXT_MAILING_PROVINCE = new TextField(TEXTFIELD_MAILINGTEXT_PROVINCELABEL);
		public static final TextField TEXT_MAILING_STATE = new TextField(TEXTFIELD_MAILINGTEXT_STATELABEL);
		public static final RadioButton RADIOBUTTON_MAILING_CANADA = new RadioButton(RADIOBUTTON_PERSON_CANADAADDRESS);
		public static final TextField TEXT_MAILING_CITY = new TextField(TEXTFIELD_PERSON_CITYADDRESS);
		public static final TextField TEXT_MAILING_STREET = new TextField(TEXTFIELD_PERSON_STREETADDRESS);
		public static final TextField TEXT_MAILING_ZIP = new TextField(TEXTFIELD_PERSON_POSTALADDRESS);
		public static final RadioButton RADIOBUTTON_PERSON_US = new RadioButton(RADIOBUTTON_PERSON_USADDRESS);
		public static final RadioButton RADIOBUTTON_ORGANIZATION_US = new RadioButton(RADIOBUTTON_ORGANIZATION_USADDRESS);
		public static final TextField TEXT_PERSON_PHONE = new TextField(TEXT_PERSON_PHONENUMBER);
		public static final ListBox LIST_CALLINGPREFERENCEDAYMOBILE = new ListBox(LISTBOX_PERSON_FIRSTPHONEAVAILABILITY);
		public static final ListBox LIST_FROMTIMEMOBILE = new ListBox(LISTBOX_PERSON_FIRSTAVAILABILITYSTARTTIME);
		public static final ListBox LIST_TOTIMEMOBILE = new ListBox(LISTBOX_PERSON_FIRSTAVAILABILITYENDTIME);
		public static final ListBox LIST_CALLINGPREFERENCEDAYHOME = new ListBox(LISTBOX_PERSON_SECONDPHONEAVAILABILITYE);
		public static final ListBox LIST_CALLINGPREFERENCEDAYADDTl = new ListBox(LISTBOX_PERSON_FOURTHPHONEAVAILABILITYE);
		public static final ListBox LIST_FROMTIMEADDTl = new ListBox(LISTBOX_PERSON_FOURTHAVAILABILITYSTARTTIME);
		public static final ListBox LIST_TOTIMEADDTl = new ListBox(LISTBOX_PERSON_FOURTHAVAILABILITYENDTIME);
		public static final TextField TEXT_INDEMAILADDRESS = new TextField(TEXTFIELD_PERSON_EMAILADDRESS);
		public static final RadioButton RADIO_PUBLISHEMAIL = new RadioButton(RADIOBUTTON_PERSON_MARKETINGINDICATOR);
		public static final TextField TEXT_SSNSIN = new TextField(TEXTFIELD_PERSON_TINNUMBER);
		public static final TextField TEXT_HEARABOUTOFFICECODE = new TextField(TEXTFIELD_HEARAGENTOFFICECODE);
		public static final TextField TEXT_IMPORTANCEFACTORCODE = new TextField(TEXTFIELD_IMPORTANCEFACTORCODE);
		public static final Button BUTTON_CREATECUSTOMER = new Button(BUTTON_SAVE);
		public static final Button BUTTON__OK = new Button(BUTTON_OK);
		public static final Button BUTTON_OK_ADDRESSSTANDARDIZATION = new Button(BUTTON_TEXTOK);
		public static final CheckBox CheckBox_KEEPNOT_STANDARD = new CheckBox(CHECKBOX_KEEPNONSTANDARD);
		
		public static final Link LINK_BASICINFOTAB_ORG = new Link(LINK_BODYPARTYMANAGEMENT);
		public static final Link LINK_BASICINFOTAB = new Link(LINK_BASICINFO);
		public static final Link LINK_emailTab = new Link(LINK_EMAILTAB_ID);
		public static final Span SPAN_PROCEEDWITHCANCEL = new Span(SPAN_YESBUTTON);
		public static final Link LINK_MOBILE_CALLING_PREFERENCE = new Link(LINK_MOBILECALLING_METHOD);
		public static final Link LINK_HOME_CALLING_PREFERENCE = new Link(
				LINK_HOMECALLING_METHOD);
		public static final Link LINK_ADDLTYPE_CALLING_PREFERENCE = new Link(
				LINK_ADDITIONALCALLING_METHOD);
		public static final TextField TEXT_ADDITIONALPHONENUMBER = new TextField(
				TEXTFIELD_PERSON_FOURTHPHONENUMBER);
		public static final ListBox LIST_ADDITIONALTYPE = new ListBox(
				TEXTFIELD_PERSON_FOURTHPHONEPURPOSE);
		public static final Link LINK_PHONETAB = new Link(LINK_PHONETAB_ID );
		//Need to check the below one it's already exist with the name of LINK_emailTab
		public static final Link LINK_EMAILTAB = new Link(
				"id=phone_emailContainer_tablist_emailTab");
		public static final RadioButton RADIOBUTTON_PERMISSION_YES = new RadioButton(
				RADIOBUTTON_PERMISSION_Y);
		public static final RadioButton RADIOBUTTON_PERMISSION_NO = new RadioButton(
				RADIOBUTTON_PERMISSION_N);
		public static final RadioButton RADIOBUTTON_PERMISSION_DIDNOTASK = new RadioButton(
				RADIOBUTTON_PERMISSION_U);
		public static final Link LINK_ABSCREATE_INDIVIDUAL = new Link(
				LINK_INDIVIDUAL_CUSTOMER);
		public static final TextField TEXT_CELLPHONE_Cpp = new TextField(
		TEXTFIELD_PERSON_FIRSTPHONENUMBER);
		public static final ListBox LIST_FROMTIMEHOME_Cpp = new ListBox(
				LISTBOX_PERSON_SECONDAVAILABILITYSTARTTIME);
		public static final ListBox LIST_TOTIMEHOME_CPP = new ListBox(
				LISTBOX_PERSON_SECONDAVAILABILITYENDTIME);
		public static final Link LINK_CREATE_INDIVIDUAL = new Link(
				LINK_CREATE_INDIVIDUAL_TEXT);
		public static final Button BUTTON_CANCEL = new Button(BUTTON_CANCEL_ID);
		public static final Div DIV_SEARCH_BOOK = new Div(
				DIV_BOOK_SEARCH);
		public static final Div DIV_PHONETOOLTIPCONTAINER = new Div(
				DIV_TOOLTIPCONTENT);
		public static final Button AHQB = new Button(BUTTON_CRC_LAUNCH);
		public static final Button GREETING_OK = new Button(BUTTON_GREETING);
		
		public static final Link LINK_QB_CREATEINDIVIDUALCUSTOMER = new Link(LINK_CREATEINDIVIDUALCUSTOMER);
		public static final Link LINK_LAUNCHAHQB = new Link(LAUNCHAHQB);
		
	}
}
