package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.WatUtility;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class CRC_CreateIndCust_Scenario27 extends BaseScript {
	int count = 0;
	String query = "select * from CRC_CreateIndCust_Scenario27";
	WatUtility watUtility = new WatUtility();

	public void executeScript() throws Exception {
		
		scenarioTasks.clickLaunchContactCenterOnlineForQBRole();
		
		/**
		 * Verifying the links in the search page
		 */
		scenarioTasks.verifyCreateIndOrgConnectEnterpriseviewLinksExists();
		
		/**
		 * Create an individual customer
		 */
		createCustTasks.clickCreateIndividualCustomerCRC();
		createCustTasks.createIndividualCustomerWithPhoneEmailData_CRC();
		scenarioTasks.clickCRCOnlineTabtoNavigatetoSearchPagefromHHpage();
		
		/**
		 * Launching HH Page
		 */
		scenarioTasks.launchHHPageFromCRCAHQBCustSearchPage();

		/** Navigate to Customer Info Page */
		scenarioTasks.launchCustInfoPageFromHHPage();
	
		/**
		 * Add an Alias - Name (Regular Characters). Also Add Preferred Name
		 * Update this Alias - Name with International Characters including � &
		 * �
		 */
		updateTasks.addUpdateAliasCRC();
		scenarioTasks.removeIndUpdateName();

		/**
		 * Change Address
		 */
		scenarioTasks.launchCRCAddAddressInCOA();

		/**
		 * Add,Update,Remove Email with Regular characters & International
		 * characters
		 */
		updateTasks.addEmailCustomerInfo_CRC();
		updateTasks.updateEmail_CRC();
		updateTasks.removeEmail_CRC();
		
		/**
		 * Remove all the phone numbers if any
		 */
		updateTasks.removeAllPhonesFromCustomerInfo_CRC();
		
		/**
		 * Add Mobile phone
		 */
		updateTasks.addMobilePhoneWithDidNotAskPermissionCustomerInfo();
		updateTasks.setCRCDefaultFrame();
		
		/**
		 * Add Work phone number
		 */
		updateTasks.addWorkPhoneCustomerInfo_CRC();

		/**
		 * Update Personal Information
		 */
		updateTasks.updatePersonalInfoCustomerInfo_CRC();
		
		hhNavigationTasks.selectCustomerNameLinkABS();

		updateTasks.setCRCDefaultFrame();
		
		scenarioTasks.clickContinueButtonIfExists();
		
		hhRelationshipTasks
				.verifyAHQBAddHouseholdAndNonHouseholdIndInRelationshipPage();

		/**
		 * Launch the policies from HH page
		 */
		//hhNavigationTasks.validateAutoPolicyInHHPage();
		//scenarioTasks.launchFireAppfromHHPage();
		//scenarioTasks.launchHealthAppfromHHPage();

		/**
		 * Launch Update Personal Information
		 */
		scenarioTasks.clickCRCActionsUpdatePersonalInformation();
		scenarioTasks.isInternetEnabledColumnDisplayedforHTMLHHpage();
		scenarioTasks.verifyInternetEnabledColumnWithYAndN();

		scenarioTasks.clickCRCOnlineTabtoNavigatetoSearchPagefromHHpage();

		/**
		 * Create an Organization customer
		 */
		createCustTasks.clickCreateOrganizationCustomer_CRC();
		createCustTasks.createOrgCustWithMobileWorkAdditionalEmailData_CRC();
		scenarioTasks.clickCRCOnlineTabtoNavigatetoSearchPagefromHHpage();
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil
						.loadTestDataCRCCreateIndCustScenario27(dbresultSet,
								clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);

				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());

				scenarioTasks
						.createResultsFile(resultsFileName(), scriptName());

				executeScript();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}