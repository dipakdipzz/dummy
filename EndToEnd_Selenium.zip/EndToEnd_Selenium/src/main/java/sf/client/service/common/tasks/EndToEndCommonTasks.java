package sf.client.service.common.tasks;

import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.common.appObjects.ABSPortalTestObjects;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.common.helpers.WatUtility;
import sf.client.service.healthSuite.appObjects.CWNonAgentCSObjects;
import sf.client.service.healthSuite.appObjects.CustomerInfoObjects;
import sf.client.service.healthSuite.appObjects.CustomerMaintenanceAppObj;
import sf.client.service.healthSuite.appObjects.HouseHoldMove_PageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.Update_IND_CustomerInfo_PageObjects;
import sf.client.service.healthSuite.appObjects.Update_Misc_Objects;
import sf.client.service.healthSuite.helpers.DatabaseUtil;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import statefarm.wat.util.KeyboardUtility;
import statefarm.widget.gui.Link;
import statefarm.widget.manager.Verify;

import com.thoughtworks.selenium.Selenium;

public class EndToEndCommonTasks extends WatUtility {

	public DatabaseUtil databaseUtil = new DatabaseUtil();
	public ClientE2ETO clientE2ETO = null;
	public LaunchApplication launcher;
	protected Selenium selenium;

	// OOBIndividualTasks oob = new OOBIndividualTasks();
	// CreateCustomersTasks createCustomersTasks = new CreateCustomersTasks();
	// ScenarioTasks scenarioTasks = new ScenarioTasks();
	/**
	 * Empty Constructor
	 */
	public EndToEndCommonTasks() {
	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param clientE2ETO
	 */
	public EndToEndCommonTasks(ClientE2ETO clientE2ETO) {
		this.clientE2ETO = clientE2ETO;
	}

	/**
	 * Launch Customer Info page from HH Page
	 */
	public void launchCustInfoPageFromHHPage() {

		if (isHHPageLaunched()) {
			clickMenuBar(HouseHoldTestObjects.WidgetInfos.CUSTOMER_LINK,
					HouseHoldTestObjects.WidgetInfos.LINK_HHCUSTOMERINFO);
			waitForPageLoad(CustomerInfoObjects.WidgetInfos.BTN_CUST_PRO_PRT,
					10);
		} else {
			Verify.verifyTrue(false,
					"Customer Information page is not launched as expected");
		}
	}

	/**
	 * Verify US SSN is Masked
	 * 
	 * @param custType
	 * @throws ScriptException
	 */
	public void verifyUSSSNMaskedForAgent(String custType)
			throws ScriptException {
		waitForPageLoad(CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN, 20);
		if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN.exists()) {
			try {
				String usSSN = CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN
						.getText();
				if (usSSN != null && !usSSN.isEmpty()) {

					if (isSSNMasked(usSSN)) {
						Verify.verifyTrue(true, custType + " US SSN Number "
								+ usSSN + " is Masked as expected");

					} else {
						Verify.verifyTrue(false, custType + " US SSN Number "
								+ usSSN + " is NOT Masked");

					}
				} else {
					Verify.verifyTrue(
							false,
							custType
									+ " Cannot Validate US SSN Number is Masked/UnMasked as US SSN Number is empty");
				}
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		} else if (CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN.exists()) {
			String usSSN = CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN
					.getText();
			if (usSSN != null & !usSSN.isEmpty()) {
				Verify.verifyTrue(false, custType + " US SSN Number " + usSSN
						+ " Unmasked not as Expected");
			} else {
				Verify.verifyTrue(
						false,
						custType
								+ " Cannot Validate US SSN Number is Masked/UnMasked as US SSN Number is empty");
			}
		} else {

			Verify.verifyTrue(false, custType
					+ " US SSN Number widget NOT displayed");
		}
	}

	/**
	 * Verify Canada SIN is Masked
	 * 
	 * @param String
	 *            custType
	 * @throws ScriptException
	 */
	public void verifyCanadaSINMaskedForAgent(String custType)
			throws ScriptException {
		waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL, 15);
		if (Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL,
					"Update Personal Inforamtion clicked");
			waitForPageLoad(CustomerInfoObjects.WidgetInfos.TXT_MASKED_CNSIN,
					20);
			setIFrame();
			if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_CNSIN.exists()) {
				try {
					String canadaSIN = CustomerInfoObjects.WidgetInfos.TXT_MASKED_CNSIN
							.getText();
					if (canadaSIN != null && !canadaSIN.trim().isEmpty()) {

						if (isSSNMasked(canadaSIN)) {
							Verify.verifyTrue(true, custType
									+ " Canada SIN Number " + canadaSIN
									+ " is Masked as expected");
						} else {
							Verify.verifyTrue(false, custType
									+ " Canada SIN Number " + canadaSIN
									+ " is NOT Masked");

						}
					} else {
						Verify.verifyTrue(
								false,
								custType
										+ " Cannot Validate Canada SIN Number is Masked/UnMasked as Canada SIN Number is empty");
					}
				} catch (Exception e) {
					Verify.verifyTrue(false, e.getMessage());
				}
			} else if (CustomerInfoObjects.WidgetInfos.TXT_CNSIN.exists()) {
				String canadaSIN = CustomerInfoObjects.WidgetInfos.TXT_CNSIN
						.getText();
				if (canadaSIN != null && !canadaSIN.isEmpty()) {
					Verify.verifyTrue(false, custType + " Canada SIN Number "
							+ canadaSIN + " is NOT Masked as expected");
				} else {
					Verify.verifyTrue(
							false,
							custType
									+ " Cannot Validate Canada SIN Number is Masked/UnMasked as Canada SIN Number is empty");
				}
			} else {
				Verify.verifyTrue(false, custType
						+ " Canada SIN Number widget NOT displayed");
			}
		}
	}

	/**
	 * Verify Driver's License Number is Masked
	 * 
	 * @param custType
	 * @throws ScriptException
	 */
	public void verifyDriLicNumMaskedInAgent(String custType)
			throws ScriptException {
		waitForPageLoad(CustomerInfoObjects.WidgetInfos.TXT_MASKED_DRI_LIC, 20);
		if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_DRI_LIC.exists()) {
			try {
				String driLic = CustomerInfoObjects.WidgetInfos.TXT_MASKED_DRI_LIC
						.getText();
				if (driLic != null && !driLic.isEmpty()) {
					if (isDriversLicenseMasked(driLic, custType)) {
						Verify.verifyTrue(true, custType
								+ " Driver's License Number " + driLic
								+ " is Masked as expected");
					} else {
						Verify.verifyTrue(false, custType
								+ " Driver's License Number " + driLic
								+ " is NOT Masked");
					}
				} else {
					Verify.verifyTrue(
							false,
							custType
									+ " Cannot Validate Driving License Number is Masked/UnMasked as Driving License Number is empty");
				}
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		} else if (CustomerInfoObjects.WidgetInfos.TXT_DRI_LIC.exists()) {
			String driLic = CustomerInfoObjects.WidgetInfos.TXT_DRI_LIC
					.getText();
			if (driLic != null && !driLic.isEmpty()) {
				Verify.verifyTrue(false, custType + " Driver's License Number "
						+ driLic + " is Unmasked NOT as Expected");
			} else {
				Verify.verifyTrue(
						false,
						custType
								+ " Cannot Validate Driving License Number is Masked/UnMasked as Driving License Number is empty");
			}
		} else {
			Verify.verifyTrue(false, custType
					+ " Driver's License Number widget NOT displayed");
		}
	}

	/**
	 * Verify TIN is Masked
	 * 
	 * @param custType
	 * @throws ScriptException
	 */
	public void verifyTINMaskedInAgent(String custType) throws Exception {
		if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN.exists()) {
			try {
				String tin = CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN
						.getText();
				if (!tin.isEmpty()) {
					String pattern = "^[X]{2}-{1}[X]{3}[0-9]{4}$";
					if (Pattern.matches(pattern, tin)) {
						Verify.verifyTrue(true, custType
								+ " TIN Number is Masked as expected");

					} else {
						Verify.verifyTrue(false, custType + " TIN Number "
								+ tin + " is UnMasked NOT as expected");

					}
				} else {
					Verify.verifyTrue(false, "Cannot Validate Tin Number "
							+ tin
							+ " is Masked/UnMasked as Tin Number is empty");
				}
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		} else
			Verify.verifyTrue(false, custType
					+ " TIN Number widget NOT displayed");
	}

	/**
	 * Verify US SSN is UnMasked
	 * 
	 * @param custType
	 * @throws ScriptException
	 */
	public void verifyUSSSNUnMaskedInAgent(String custType)
			throws ScriptException {
		waitForPageLoad(CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN, 20);
		if (CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN.exists()) {
			try {
				String usSSN = CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN
						.getText();
				if (usSSN != null && !usSSN.isEmpty()) {

					if (!isSSNMasked(usSSN)) {
						Verify.verifyTrue(true, custType + " US SSN Number "
								+ usSSN + " is UnMasked as expected");

					} else {
						Verify.verifyTrue(false, custType + " US SSN Number "
								+ usSSN + " is NOT UnMasked");

					}
				} else {
					Verify.verifyTrue(
							false,
							custType
									+ " Cannot Validate US SSN Number is Masked/UnMasked as US SSN Number is empty");
				}
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		} else if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN.exists()) {
			String usSSN = CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN
					.getText();
			if (usSSN != null && !usSSN.isEmpty()) {
				Verify.verifyTrue(false, custType + " US SSN Number " + usSSN
						+ " is Masked NOT As expected");
			} else {
				Verify.verifyTrue(
						false,
						custType
								+ " Cannot Validate US SSN Number is Masked/UnMasked as US SSN Number is empty");
			}
		} else {
			Verify.verifyTrue(false, custType
					+ " US SSN Number widget NOT displayed");
		}
	}

	/**
	 * Verify Canada SIN is UnMasked
	 * 
	 * @param custType
	 * @throws ScriptException
	 */
	public void verifyCanadaSINUnMaskedInAgent(String custType)
			throws ScriptException {

		waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL, 15);
		if (Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL,
					"Update Personal Inforamtion clicked");
			waitForPageLoad(CustomerInfoObjects.WidgetInfos.TXT_CNSIN, 20);
			if (CustomerInfoObjects.WidgetInfos.TXT_CNSIN.exists()) {
				try {
					String canadaSIN = CustomerInfoObjects.WidgetInfos.TXT_CNSIN
							.getText();
					if (canadaSIN != null && !canadaSIN.isEmpty()) {
						if (!isSSNMasked(canadaSIN)) {
							Verify.verifyTrue(true, custType
									+ " Canada SIN Number " + canadaSIN
									+ " is UnMasked as expected");

						} else {
							Verify.verifyTrue(false, custType
									+ " Canada SIN Number " + canadaSIN
									+ " is NOT UnMasked");

						}
					} else {
						Verify.verifyTrue(
								false,
								custType
										+ " Cannot Validate Canada SIN Number is Masked/UnMasked as Canada SIN Number is empty");
					}
				} catch (Exception e) {
					Verify.verifyTrue(false, e.getMessage());
				}
			} else if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_CNSIN
					.exists()) {
				String canadaSIN = CustomerInfoObjects.WidgetInfos.TXT_MASKED_CNSIN
						.getText();
				if (canadaSIN != null && !canadaSIN.isEmpty()) {
					Verify.verifyTrue(false, custType + " Canada SIN Number "
							+ canadaSIN + " is Masked NOT as expected");
				} else {
					Verify.verifyTrue(
							false,
							custType
									+ " Cannot Validate Canada SIN Number is Masked/UnMasked as Canada SIN Number is empty");
				}
			} else {
				Verify.verifyTrue(false, custType
						+ " Canada SIN Number is NOT UnMasked");
			}
		}
	}

	/**
	 * Verify Driver's License Number is UnMasked
	 * 
	 * @param custType
	 * @throws ScriptException
	 */
	public void verifyDriLicNumUnMaskedInAgent(String custType)
			throws ScriptException {
		waitForPageLoad(CustomerInfoObjects.WidgetInfos.TXT_DRI_LIC, 20);
		if (CustomerInfoObjects.WidgetInfos.TXT_DRI_LIC.exists()) {
			try {
				String driLic = CustomerInfoObjects.WidgetInfos.TXT_DRI_LIC
						.getText();

				if (driLic != null && !driLic.isEmpty()) {
					if (!isDriversLicenseMasked(driLic, custType)) {
						Verify.verifyTrue(true, custType
								+ " Driver's License Number " + driLic
								+ " is UnMasked as expected");

					} else {
						Verify.verifyTrue(false, custType
								+ " Driver's License Number " + driLic
								+ " is NOT UnMasked");
					}
				} else {
					Verify.verifyTrue(
							false,
							custType
									+ " Cannot Validate Driving License Number is Masked/UnMasked as Driving License Number is empty");
				}
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		} else if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_DRI_LIC.exists()) {
			String driLic = CustomerInfoObjects.WidgetInfos.TXT_MASKED_DRI_LIC
					.getText();
			if (driLic != null && !driLic.isEmpty()) {
				Verify.verifyTrue(false, custType + " Driver's License Number "
						+ driLic + " is Masked NOT as expected");
			} else {
				Verify.verifyTrue(
						false,
						custType
								+ " Cannot Validate Driving License Number is Masked/UnMasked as Driving License Number is empty");
			}
		} else {

			Verify.verifyTrue(false, custType
					+ " Driver's License Number widget NOT displayed");
		}
	}

	/**
	 * Update TIN to null
	 * 
	 * @param Tin
	 */
	public void updateTinNumToNull(String Tin) {
		try {
			clickUpdateOrgPersonalInfo();
			if (isUpdateOrgInfoLaunched()) {
				waitForPageLoad(CustomerInfoObjects.WidgetInfos.TXT_MASKED_TIN,
						5);
				if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_TIN.exists()) {
					CustomerInfoObjects.WidgetInfos.TXT_MASKED_TIN.clearText();
					Verify.verifyTrue(true,
							"Tin number is cleared to null successfully");
					clickSaveButton();
					setTopFrame();
					verifyTinInOrgCustInfo("updateTINToNull");
				}
				if (CustomerInfoObjects.WidgetInfos.TXT_TIN.exists()) {
					CustomerInfoObjects.WidgetInfos.TXT_TIN.clearText();
					Verify.verifyTrue(true,
							"Tin number is cleared to null successfully");
					clickSaveButton();
					setTopFrame();
					verifyTinInOrgCustInfo("updateTINToNull");
				} else {
					Verify.verifyTrue(false,
							"Tin number is not cleared to null");
				}
			} else {
				Verify.verifyTrue(false,
						"Unable to clear Tin, Organization Info page not launched");
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * verify Update Organization Info page launched
	 * 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isUpdateOrgInfoLaunched() throws ScriptException {
		waitForTime(4);
		if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_TIN.exists()
				|| CustomerInfoObjects.WidgetInfos.TXT_TIN.exists()) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Update TIN number in Organization Info Page
	 * 
	 * @param ab
	 */

	public void updateTINNumInOrganizationInfoPage(String ab) {
		try {
			if (isCustomerInfoPageExists()) {
				clickUpdateOrgPersonalInfo();
				if (isUpdateOrgInfoLaunched()) {
					addTinNumber();
					clickSaveButton();
					setTopFrame();
					verifyTinInOrgCustInfo(ab);
				} else {
					Verify.verifyTrue(false,
							"Unable to proceed, Update Organization Info Page not Launched");
				}
			} else {
				Verify.verifyTrue(false,
						"Unable to proceed, Organization customer Info not launched");
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Clicking the Update link in Customer Info page.
	 */
	public void clickUpdateOrgPersonalInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(
						Update_Misc_Objects.WidgetInfos.LINK_UPDATEORGANIZATIONINFO,
						10);
				if ((Update_Misc_Objects.WidgetInfos.LINK_UPDATEORGANIZATIONINFO)
						.exists()) {
					click(Update_Misc_Objects.WidgetInfos.LINK_UPDATEORGANIZATIONINFO,
							"Update Org Personal Info link clicked as expected");
					setIFrame();
				} else {
					Verify.verifyTrue(false,
							"Update Personal link is not found");
				}
			} else {
				Verify.verifyTrue(
						false,
						"Cannot proceed with Update Personal Info as the Customer Information Page is not Launched");
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Verifying Tin number in Customer info page and Update Personal info page.
	 * 
	 * @param tax
	 */
	public void verifyTinInOrgCustInfo(String tax) {
		try {
			waitForTime(3);
			setTopFramewithDefaultContent();
			waitForTime(3);
			if (tax.equalsIgnoreCase("updateTIN")
					|| tax.equalsIgnoreCase("verifyTIN")
					|| tax.equalsIgnoreCase("updateNullToTIN")) {
				if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN.exists()) {
					String tinValue = CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN
							.getText().substring(7);
					String mdbValue = clientE2ETO.getTaxIdNumber().substring(6);
					if (tinValue.equalsIgnoreCase(mdbValue)) {
						Verify.verifyTrue(true,
								"TIN value" + clientE2ETO.getTaxIdNumber()
										+ "entered successfully");
					} else {
						Verify.verifyTrue(false,
								"TIN value" + clientE2ETO.getTaxIdNumber()
										+ "is not entered ");
					}
				}
				if (CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN.exists()) {
					String tinValue = CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN
							.getText().substring(7);
					String mdbValue = clientE2ETO.getTaxIdNumber().substring(6);
					if (tinValue.equalsIgnoreCase(mdbValue)) {
						Verify.verifyTrue(true,
								"TIN value" + clientE2ETO.getTaxIdNumber()
										+ "entered successfully");
					} else {
						Verify.verifyTrue(false,
								"TIN value" + clientE2ETO.getTaxIdNumber()
										+ "is not entered ");
					}
				} else {
					Verify.verifyTrue(false,
							"Unable to proceed, tin value not found in Organization Information page");
				}
			}

			if (tax.equalsIgnoreCase("updateTINToNull")) {
				if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN.exists()) {
					String tinValue = CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN
							.getText().trim();
					if (tinValue.equalsIgnoreCase("")) {
						Verify.verifyTrue(true,
								"TIN value null is entered successfully");
					} else {
						Verify.verifyTrue(false,
								"TIN value null is not entered");
					}
				}
				if (CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN.exists()) {
					String tinValue = CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN
							.getText().trim();
					if (tinValue.equalsIgnoreCase("")) {
						Verify.verifyTrue(true,
								"TIN value null is entered successfully");
					} else {
						Verify.verifyTrue(false,
								"TIN value null is not entered");
					}
				} else {
					Verify.verifyTrue(false,
							"Unable to proceed, tin value not found in Organization Information page");
				}
			}

			if (tax.equalsIgnoreCase("partiallyMasked")) {
				if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN.exists()) {
					String tinValue = CustomerInfoObjects.WidgetInfos.TXT_MASKED_SSN_SIN
							.getText();
					String mdbValue = clientE2ETO.getTaxIdNumber().substring(5);
					if (tinValue.equalsIgnoreCase("XX-XXX" + mdbValue)) {
						Verify.verifyTrue(true, "TIN value is Partially masked");
					} else {
						Verify.verifyTrue(false,
								"TIN value is not Partially masked");
					}
				}
				if (CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN.exists()) {
					String tinValue = CustomerInfoObjects.WidgetInfos.TXT_SSN_SIN
							.getText().substring(6);
					String mdbValue = clientE2ETO.getTaxIdNumber().substring(5);
					if (tinValue.equalsIgnoreCase(mdbValue)) {
						Verify.verifyTrue(true, "TIN value is entered");
					} else {
						Verify.verifyTrue(false, "TIN value is not entered");
					}
				} else {
					Verify.verifyTrue(false,
							"Unable to proceed, tin value not found in Organization Information page");
				}
			}

		} catch (ScriptException e) {
			scriptError(e);
		}

	}

	/**
	 * Launch Household information page from Customer Information page.
	 * 
	 * @throws Exception
	 */
	public void launchHHPageFromCustInfo() throws Exception {
		waitForTime(3);
		clickHHPageCustomer();
		handleCimsVersion();
		verifyHouseholdPageLaunched();
	}

	/**
	 * Click on the customer name link in the search result.so that page
	 * navigates to the HH Page.
	 */
	public void launchPortalHHPage() {
		try {
			if (selectExistedCustomerFromSearch()) {
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 30, 2);
				setTopFrame();
				verifyHouseholdPageLaunched();
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Click on the customer name link in the search result.so that page
	 * navigates to the HH Page.
	 */
	public void launchNewCustomerHHPage() {
		try {
			if (selectNewCustomerFromSearch()) {
				//setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 30, 2);
				//setTopFrame();
				//verifyHouseholdPageLaunched();
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Click on the existed customer name link in the search result.so that page
	 * navigates to the HH Page.
	 */
	public void launchExistedCustomerHHPage() {
		try {
			if (selectExistedCustomerFromSearch()) {
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 30, 2);
				setTopFrame();
				verifyHouseholdPageLaunched();
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	public void launchPortalHHPage2() {
		try {
			if (selectPortalCustomerFromSearch2()) {
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 30, 2);
				setTopFrame();
				verifyHouseholdPageLaunched();
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Search for the particular name link and if it exists click on it.
	 * 
	 * @return
	 */
	public boolean selectPortalCustomerFromSearch() {
		Link LINK_CUST = new Link("text="
				+ clientE2ETO.getCustomerOneData().toUpperCase());
		System.out.println("Praveen:"+LINK_CUST);
		waitForPageLoad(LINK_CUST, 30);
		if (LINK_CUST.exists()) {
			click(LINK_CUST, "Customer link clicked from Search results table");
			return true;
		} else {
			Verify.verifyTrue(false,
					"Given Customer data is not found in the Customer Search Results");
			return false;
		}
	}
	
	/**
	 * Search for the newly created customer name link and if it exists click on it.
	 * 
	 * @return
	 */
	public boolean selectNewCustomerFromSearch() {
		Link LINK_CUST = new Link("text="
				+ clientE2ETO.getLastName().toUpperCase()+", "+clientE2ETO.getFirstName().toUpperCase());
		waitForPageLoad(LINK_CUST, 30);
		if (LINK_CUST.exists()) {
			//click(LINK_CUST, "Customer link clicked from Search results table");
			Verify.verifyTrue(true,
			"Given Customer data is found in the Customer Search Results");
			return true;
		} else {
			Verify.verifyTrue(false,
					"Given Customer data is not found in the Customer Search Results");
			return false;
		}
	}
	
	/**
	 * Search for the existed customer name link and if it exists click on it.
	 * 
	 * @return
	 */
	public boolean selectExistedCustomerFromSearch() {
		Link LINK_CUST = new Link("text="
				+ clientE2ETO.getCsLastName().toUpperCase()+", "+clientE2ETO.getCsFirstName().toUpperCase());
		waitForPageLoad(LINK_CUST, 30);
		if (LINK_CUST.exists()) {
			click(LINK_CUST, "Customer link clicked from Search results table");
			Verify.verifyTrue(true,
			"Given Customer data found in the Customer Search Results");
			return true;
		} else {
			Verify.verifyTrue(false,
					"Given Customer data is not found in the Customer Search Results");
			return false;
		}
	}
	
	public boolean selectPortalCustomerFromSearch2() {
		Link LINK_CUST = new Link("text="
				+ clientE2ETO.getCustomerOneData2().toUpperCase());
		waitForPageLoad(LINK_CUST, 30);
		if (LINK_CUST.exists()) {
			click(LINK_CUST, "Customer link clicked from Search results table");
			return true;
		} else {
			Verify.verifyTrue(false,
					"Given Customer data is not found in the Customer Search Results");
			return false;
		}

	}

	/**
	 * Search for the Customer name link and if it exists click on it. this
	 * method supports launching HH page for SupportWrite Portal.
	 * 
	 * @throws ScriptException
	 */
	public void launchABSPortalHHPage() throws ScriptException {
		Link LINK_CUST = new Link("text=" + clientE2ETO.getCustomerOneData());
		waitForPageLoad(LINK_CUST, 30);
		if (LINK_CUST.exists()) {
			click(LINK_CUST, "Customer link clicked from Search results table");
			clickContinueButtonIfExists();
			setWindow("Select CIMS 2.0 Version", 30, 2);
			setTopFrame();
			handleCimsVersion();
			selectAgentSelection();
			verifyHouseholdPageLaunched();
		} else {
			Verify.verifyTrue(false,
					"Given Customer data is not found in the Customer Search Results");
		}
	}

	/**
	 * launch AHQB Household Page by clicking the name link after the Successful
	 * Search
	 */
	public void launchAHQBHHPage() {
		try {
			Link LINK_CUST = new Link("text="
					+ clientE2ETO.getCustomerOneData());
			if (LINK_CUST.exists()) {
				try {
					LINK_CUST.click();
				} catch (Exception e) {
					Verify.verifyTrue(false, "Customer link NOT found");
				}
				Verify.verifyTrue(true,
						"Customer link clicked from Search results table");
				setCRCDefaultFrame();
				clickContinueButtonIfExists();
				verifyHouseholdPageLaunched();
			} else {
				Verify.verifyTrue(false,
						"Given Customer data is not found in the Customer Search Results");
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * This method is to validate SSN, TIN, SIN, and drivers license numbers in
	 * Customer Information Page
	 * 
	 * @param custType
	 * @throws ScriptException
	 */
	public void verifyCustomersWithAppQuotes(String custType)
			throws ScriptException {
		if (isCustomerInfoPageLaunched()) {
			if (EndToEndConstants.PROSPECT_NO_APPQUOTES
					.equalsIgnoreCase(custType)
					|| EndToEndConstants.EXCUSTOMER_NO_APPQUOTES_GREATER_60
							.equalsIgnoreCase(custType)) {
				verifyUSSSNMaskedForAgent(custType);
				verifyDriLicNumMaskedInAgent(custType);
				verifyCanadaSINMaskedForAgent(custType);

			} else {
				verifyUSSSNUnMaskedInAgent(custType);
				verifyDriLicNumUnMaskedInAgent(custType);
				verifyCanadaSINUnMaskedInAgent(custType);

			}
		} else {
			Verify.verifyTrue(
					false,
					"Can not Validate SSN, TIN, SIN, and drivers license numbers as Customer Information notlaunched");
		}
	}

	/**
	 * Launch Household page From the Portal Customer Search page.
	 */
	public void launchHouseholdpageFromPortal() {
		try {
			KeyboardUtility.sendKeys("{ESC}");
			if (isAgentBusinessSystemExist()) {
				clickCustomer();
				launchPortalCustomerSearchPage();
				launchPortalHHPage();
			} else {
				Verify.verifyTrue(false,
						"Customer Search Page not exists to Launch HH page.");
			}
		} catch (NoSuchElementException e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * click Name Radio Button Search Page
	 * 
	 * @throws ScriptException
	 */
	public void clickNameRadioButtonSearchPage() {
		try {
			if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_AGENT_NAME_SERACH
					.exists()) {
				click(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_AGENT_NAME_SERACH,
						"Name radio button Clicked in Search Page");
			}
		} catch (Exception exception) {
			Verify.verifyTrue(false, exception.getMessage());
		}
	}

	/**
	 * returns true if the SSN is masked.
	 * 
	 * @param ssn
	 * @return
	 * @throws ScriptException
	 */
	public boolean isSSNMasked(String ssn) throws ScriptException {
		String pattern = "^[X]{3}-{1}[X]{2}-{1}[0-9]{4}$";
		if (Pattern.matches(pattern, ssn)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * returns true if the DriversLicense is masked.
	 * 
	 * @param driversLicense
	 * @param custType
	 * @return
	 * @throws ScriptException
	 */
	public boolean isDriversLicenseMasked(String driversLicense, String custType)
			throws ScriptException {
		String pattern1 = "^[X]{6}[0-9]{4}$";
		String pattern2 = "^[X]{8}[0-9]{4}$";

		if (Pattern.matches(pattern1, driversLicense)
				|| Pattern.matches(pattern2, driversLicense)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Launch Household Page From Customer Search Page for SupportWrite
	 */
	public void launchHHPageFromCustomerSearchPage() {
		try {
			if (isCustomerSearchPageExistsABS()) {
				clickClearButtonSearchPage();
				launchCustomerSearchPage();
				launchHHPageABS();
			} else {
				Verify.verifyTrue(false,
						"Cannot proceed to HH page as Customer Search Page not launhced");
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * To validate USSSN CNSIN Drivers License in Customer Information page
	 * 
	 * @param custType
	 */
	public void validateUSSSNCNSINDriversLicenseCustomerInfo(String custType) {
		try {
			launchCustInfoPageFromHHPage();
			verifyCustomersWithAppQuotes(custType);
			closeAllWindows();
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * verify whether the Household page is launched.
	 * 
	 * @return if Household widget exists this method will return true.
	 */

	public boolean isHHPageLaunched() {
		boolean flag = false;
		try {
			waitForPageLoad(HouseHoldTestObjects.WidgetInfos.MEMBERDRPDWN,10);
			waitForTime(4);
			if (HouseHoldTestObjects.WidgetInfos.MEMBERDRPDWN.exists()) {
				return true;
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception exception) {
		}
		return flag;
	}

	/**
	 * hover the menuItem1 then click on menuItem2.
	 * 
	 * @param menuItem1
	 * @param menuItem2
	 */
	public void clickMenuBar(String menuItem1, String menuItem2) {
		Link Menu = new Link(menuItem1);
		Link MenuChild = new Link(menuItem2);
		waitForPageLoad(Menu, 30);
		if (Menu.exists()) {

			Menu.click();
			waitForPageLoad(MenuChild, 30);
			if (MenuChild.exists()) {
				MenuChild.click();
			}
		}

	}

	/**
	 * Click on Save button if exists.
	 */
	public void clickSaveButton() {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
					.exists()) {
				click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
						"Save button clicked");
			} else {
				Verify.verifyTrue(false, "Save button is NOT displayed");
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * returns true if the Customer Info page launched.
	 * 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isCustomerInfoPageExists() throws ScriptException {
		waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS, 15);
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Enter TIN Number for the Organization Customer
	 * 
	 * @throws ScriptException
	 */
	public void addTinNumber() throws ScriptException {
		if (clientE2ETO.getTaxIdNumber() != null) {
			waitForPageLoad(CustomerInfoObjects.WidgetInfos.TXT_MASKED_TIN, 10);
			if (CustomerInfoObjects.WidgetInfos.TXT_MASKED_TIN.exists()) {
				setTextInTextbox(
						CustomerInfoObjects.WidgetInfos.TXT_MASKED_TIN,
						clientE2ETO.getTaxIdNumber(),
						clientE2ETO.getTaxIdNumber()
								+ " value entered in TIN Number Text box ");
			}
			if (CustomerInfoObjects.WidgetInfos.TXT_TIN.exists()) {
				setTextInTextbox(CustomerInfoObjects.WidgetInfos.TXT_TIN,
						clientE2ETO.getTaxIdNumber(),
						clientE2ETO.getTaxIdNumber()
								+ " value entered in TIN Number Text box ");
			} else {
				Verify.verifyTrue(false, "TIN Number Text box not found");
			}
		}
	}

	/**
	 * Click on Active Customer Bar link to navigate back to HH Page.
	 */
	public void clickHHPageCustomer() {

		try {
			getWebDriverInstance().switchTo().defaultContent();
			WebElement customerName = getWebDriverInstance()
					.findElement(
							By.xpath("//div[@id='divClientBar']/table/tbody/tr[1]/td[2]/a"));
			customerName.click();
			waitForTime(2);
			Verify.verifyTrue(true,
					"Customer name link is clicked successfully");
			
			setTopFrame();
			verifyHouseholdPageLaunched();
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * verify whether Household page launched and Appropriate message will be
	 * displayed
	 * 
	 * @throws ScriptException
	 */
	public void verifyHouseholdPageLaunched() throws ScriptException {
		if (isHHPageLaunched()) {
			Verify.verifyTrue(true, "HH page launched Successfully");
		} else {
			Verify.verifyTrue(false, "HH page NOT launched Successfully");
		}
	}

	/**
	 * Click on Agent selection Button if it exists.
	 */
	public void clickContinueButtonIfExists() {
		try {
			waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.BTN_CNT, 10);
			if (CWNonAgentCSObjects.WidgetInfos.BTN_CNT.exists()) {
				CWNonAgentCSObjects.WidgetInfos.BTN_CNT.click();
				Verify.verifyTrue(true, "Continue button clicked");
			}
		} catch (Exception exception) {
			Verify.verifyTrue(false, exception.getMessage());
		}
	}
	
	/**
	 * Click on Yes button in  Privacy Option Word Track.
	 */
	public void clickPrivacyOptionWordTrack() {
		try {
			waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.PRIVACY_OPTION_WORDTRACK_YES, 25);
			if (CWNonAgentCSObjects.WidgetInfos.PRIVACY_OPTION_WORDTRACK_YES.exists()) {
				CWNonAgentCSObjects.WidgetInfos.PRIVACY_OPTION_WORDTRACK_YES.click();
				Verify.verifyTrue(true, "Privacy option word track Yes button clicked");
			}
		} catch (Exception exception) {
			Verify.verifyTrue(false, exception.getMessage());
		}
	}

	/**
	 * verify whether Portal Search page launched.if it launched this method
	 * will return true.
	 * 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isPortalSearchPageExist() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 10);
		if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Verify whether Customer Information page launched.returns true,if it is
	 * launched.
	 * 
	 * @return
	 */
	public boolean isCustomerInfoPageLaunched() {
		waitForPageLoad(CustomerInfoObjects.WidgetInfos.BTN_CUST_PRO_PRT, 15);
		if (CustomerInfoObjects.WidgetInfos.BTN_CUST_PRO_PRT.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Verify whether Agent Business System launched.returns true,if it is
	 * launched.
	 * 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isAgentBusinessSystemExist() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.LINK_CUSTOMER, 10);
		if (ABSPortalTestObjects.WidgetInfos.LINK_CUSTOMER.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Click on Customer tab if exists.
	 */
	public void clickCustomer() {
		try {
			if (isAgentBusinessSystemExist()) {
				
				if ((ABSPortalTestObjects.WidgetInfos.LINK_CUSTOMER).exists()) {
					//ABSPortalTestObjects.WidgetInfos.LINK_CUSTOMER.click();
					click(ABSPortalTestObjects.WidgetInfos.LINK_CUSTOMER,
							"Customer Tab clicked successfully");
				} else {
					Verify.verifyTrue(false, "Customer Tab Not Found");
				}
			} else {
				Verify.verifyTrue(false,
						"Agent Business System Page Not Launched");
			}
		} catch (NoSuchElementException exception) {
			Verify.verifyTrue(false, exception.getMessage());
		}
	}

	/**
	 * Search for a Customer in Portal Search page
	 */
	public void launchPortalCustomerSearchPage() {
		try {
			if (isPortalSearchPageExist()) {
				enterPortalCSLastName();
				enterPortalCSFirstName();
				//eneterPortalCSZip();
				clickPortalSeacrhButton();
				waitForTime(10);
			} else {
				Verify.verifyTrue(false,
						"Agent Customer Search Page Not Launched");
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Search for a newly created customer in Portal Search page
	 */
	public void launchNewlyCreatedCustomerSearchPage() {
		try {
			if (isPortalSearchPageExist()) {
				enterPortalLastName();
				enterPortalFirstName();
				//eneterPortalZip();
				clickPortalSeacrhButton();
			} else {
				Verify.verifyTrue(false,
						"Agent Customer Search Page Not Launched");
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	public void launchPortalCustomerSearchPageScondCustomer() {
		try {
			if (isPortalSearchPageExist()) {
				enterPortalCSLastName2();
				enterPortalCSFirstName2();
				eneterPortalCSZip();
				clickPortalSeacrhButton();
			} else {
				Verify.verifyTrue(false,
						"Agent Customer Search Page Not Launched");
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter the last name in Customer Search page for Agent.
	 * 
	 * @throws ScriptException
	 */
	public void enterPortalCSLastName() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 30);
		
		if ((ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME).exists()) {
			if (clientE2ETO.getCsOrgName() != null) {
				setTextInTextbox(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME,
						clientE2ETO.getCsOrgName(),
						clientE2ETO.getCsOrgName()
								+ " Value Entered in Last Name text box  as expected");
			} else {
				enterMandatoryfieldtoEnablebutton(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME,
						clientE2ETO.getCsLastName());
			}
		} else {
			Verify.verifyTrue(false,
					"Last Name text box is not displayed as expected");
		}
	}
	
	/**
	 * Enter the newly created last name in Customer Search page for Agent.
	 * 
	 * @throws ScriptException
	 */
	public void enterPortalLastName() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 30);
		
		if ((ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME).exists()) {
			if (clientE2ETO.getLastName() != null) {
				setTextInTextbox(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME,
						clientE2ETO.getLastName(),
						clientE2ETO.getLastName()
								+ " Value Entered in Last Name text box  as expected");
			} else {
				enterMandatoryfieldtoEnablebutton(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME,
						clientE2ETO.getCsLastName());
			}
		} else {
			Verify.verifyTrue(false,
					"Last Name text box is not displayed as expected");
		}
	}
	
	public void enterPortalCSLastName2() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 30);
		
		if ((ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME).exists()) {
			if (clientE2ETO.getCsOrgName2() != null) {
				setTextInTextbox(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME,
						clientE2ETO.getCsOrgName2(),
						clientE2ETO.getCsOrgName2()
								+ " Value Entered in Last Name text box  as expected");
			} else {
				enterMandatoryfieldtoEnablebutton(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME,
						clientE2ETO.getCsLastName2());
			}
		} else {
			Verify.verifyTrue(false,
					"Last Name text box is not displayed as expected");
		}
	}


	/**
	 * Enter the First name in Customer Search page for Agent.
	 * 
	 * @throws ScriptException
	 */
	public void enterPortalCSFirstName() throws ScriptException {
		
		if (clientE2ETO.getCsFirstName() != null) {
			if ((ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME).exists()) {
				setTextInTextbox(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME,
						clientE2ETO.getCsFirstName(),
						clientE2ETO.getCsFirstName()
								+ "First Name text box is entered as expected");
			} else {
				Verify.verifyTrue(false,
						"First Name text box is not displayed as expected");
			}
		}
	}
	
	/**
	 * Enter the newly created First name in Customer Search page for Agent.
	 * 
	 * @throws ScriptException
	 */
	public void enterPortalFirstName() throws ScriptException {		
		if (clientE2ETO.getFirstName() != null) {
			if ((ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME).exists()) {
				setTextInTextbox(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME,
						clientE2ETO.getFirstName(),
						clientE2ETO.getFirstName()
								+ "First Name text box is entered as expected");
			} else {
				Verify.verifyTrue(false,
						"First Name text box is not displayed as expected");
			}
		}
	}
	
	public void enterPortalCSFirstName2() throws ScriptException {
		
		if (clientE2ETO.getCsFirstName2() != null) {
			if ((ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME).exists()) {
				setTextInTextbox(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME,
						clientE2ETO.getCsFirstName2(),
						clientE2ETO.getCsFirstName2()
								+ "First Name text box is entered as expected");
			} else {
				Verify.verifyTrue(false,
						"First Name text box is not displayed as expected");
			}
		}
	}


	/**
	 * Enter the Zip/Postal Code in Customer Search page for Agent.
	 * 
	 * @throws ScriptException
	 */
	public void eneterPortalCSZip() throws ScriptException {
		if (clientE2ETO.getCsZip() != null) {
			if ((ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POSTALCODE)
					.exists()) {

				setTextInTextbox(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POSTALCODE,
						clientE2ETO.getCsZip().trim(), clientE2ETO.getCsZip().trim()
								+ "Zip text box is entered as expected");
			} else {
				Verify.verifyTrue(false,
						"Zip text box is not displayed as expected");
			}
		}
	}
	
	/**
	 * Enter newly created Zip /Postal Code in Customer Search page for Agent.
	 * 
	 * @throws ScriptException
	 */
	public void eneterPortalZip() throws ScriptException {
		if (clientE2ETO.getMzip() != null) {
			if ((ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POSTALCODE)
					.exists()) {

				setTextInTextbox(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POSTALCODE,
						clientE2ETO.getMzip(), clientE2ETO.getMzip()
								+ "Zip text box is entered as expected");
			} else {
				Verify.verifyTrue(false,
						"Zip text box is not displayed as expected");
			}
		}
	}

	/**
	 * Click on Search Button after entering required details in Search page for
	 * agent.
	 * 
	 * @throws ScriptException
	 */
	public void clickPortalSeacrhButton() throws ScriptException {
		if ((ABSPortalTestObjects.WidgetInfos.BUTTON_SUBMITSEARCH).exists()) {
			click(ABSPortalTestObjects.WidgetInfos.BUTTON_SUBMITSEARCH,
					"Search Button is clicked as expected");
		} else {
			Verify.verifyTrue(false,
					"Search Button is not displayed as expected");
		}
	}

	/**
	 * hover the menuItem1 then click on menuItem2.
	 * 
	 * @param menuItem1
	 *            parent menu to be hover
	 * @param menuItem2
	 *            child menu to be clicked
	 */
	public void launchCMPageFromHHPage(String menuItem1, String menuItem2)
			throws ScriptException {
		waitForPageLoad(new Link(menuItem1), 10);
		Link Menu = new Link(menuItem1);
		Link MenuChild = new Link(menuItem2);
		if (Menu.exists()) {
			Menu.click();
			Verify.verifyTrue(true,
					"Customer Menu is displayed in the Household page. ");
			MenuChild.click();
		} else {
			Verify.verifyTrue(false, "Customer Menu is NOT Found");
		}
	}

	public void clickMenuBar(Link menuItem1, Link menuItem2) {

		if (menuItem1.exists()) {

			menuItem1.click();

			if (menuItem2.exists()) {

				menuItem2.click();

			}

		}

	}

	/**
	 * kkkk Checking for the Customer Maintenance page existence.
	 * 
	 * @return returns true if the Customer Maintenance page exists.
	 * @throws ScriptException
	 */
	public boolean isCustomerMaintanancePage() throws ScriptException {
		waitForTime(3);
		if (CustomerMaintenanceAppObj.WidgetInfos.LINK_COMBINECUSTOMERS
				.exists()
				|| CustomerMaintenanceAppObj.WidgetInfos.LINK_SEPARATECUSTOMER
						.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Checking for Customer Search Page existence
	 * 
	 * @return returns true if the Customer Search page exists.
	 * @throws ScriptException
	 */
	public boolean isCustomerSearchPageExistsABS() throws ScriptException {
		waitForPageLoad(
				ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME,
				20);
		if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME
				.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Click on the Clear button in the Search page.
	 * 
	 * @throws ScriptException
	 */
	public void clickClearButtonSearchPage() throws ScriptException {

		getWebDriverInstance().findElement(By.id("clearEnterpriseNameSearch"))
				.click();
		System.out.println("clicked");
		Verify.verifyTrue(true, "Clear button is clicked successfully");
	}
	
	public void clickPolicyClearButton() throws ScriptException {

		getWebDriverInstance().findElement(By.id("clearPolicySearch"))
				.click();
		System.out.println("Clear button is clicked successfully");
		Verify.verifyTrue(true, "Clear button is clicked successfully");
	}
	
	public void clickPhoneSearchButton() throws ScriptException {

		getWebDriverInstance().findElement(By.id("phoneSearch"))
				.click();
		System.out.println("Search button is clicked successfully");
		Verify.verifyTrue(true, "Search button is clicked successfully");
	}
	
	public void clickNameRadioButton() throws ScriptException {

		getWebDriverInstance().findElement(By.id("coWideName"))
				.click();
		System.out.println("clicked");
		Verify.verifyTrue(true, "Name radio button is clicked successfully");
	}

	/**
	 * Select the Customer name from the Search result.
	 * 
	 * @return returns true if Customer exists in search page.
	 * @throws ScriptException
	 */
	public boolean selectCustomerFromTable() throws ScriptException {
		return selectCustomerFromTable(clientE2ETO.getCustomerOneData());

	}

	/**
	 * click on Customer Search Page Link In EnterPriseView Page
	 * 
	 * @throws ScriptException
	 */
	public void clickCustomerSearchPageLinkInEnterPriseView()
			throws ScriptException {
		if (CWNonAgentCSObjects.WidgetInfos.LINK_CUSTOMER_SEARCH.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.LINK_CUSTOMER_SEARCH,
					"Link clicked successfully");
		}
	}

	/**
	 * This method is to enter first name, last name,postal code on the Search
	 * Page and Click on Search button.
	 * 
	 * @throws ScriptException
	 */
	public void launchCustomerSearchPage() throws ScriptException {
		if (isCustomerSearchPageExistsABS()) {
			enterLastNameSearchPage();
			enterFirstNameSearchPage();
			enterZipSearchPage();
			clickSearchButtonSeachPage();
		} else {
			Verify.verifyTrue(false, "Customer Search Page Not Launched");
		}
	}

	/**
	 * This method is to enter the first name in Customer Search page for
	 * SupportWrite.
	 * 
	 * @throws ScriptException
	 */
	public void enterFirstNameSearchPage() throws ScriptException {
		if (clientE2ETO.getCsFirstName() != null) {
			if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_FIRSTNAME
					.exists()) {
				setTextInTextbox(
						ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_FIRSTNAME,
						clientE2ETO.getCsFirstName(), " First Name : "
								+ clientE2ETO.getCsFirstName());
			}
		} /*else {
			Verify.verifyTrue(false, "First Name is blank in DB");
		}*/
	}

	/**
	 * This method is to enter the last name in Customer Search page for
	 * SupportWrite.
	 * 
	 * @throws ScriptException
	 */
	public void enterLastNameSearchPage() throws ScriptException {
		try {
			if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME
					.exists() && clientE2ETO.getCsLastName() != null) {
				Verify.verifyTrue(true, clientE2ETO.getCsLastName()
						+ " Last Name Entered in seach page text box found");
				enterMandatoryfieldtoEnablebutton(
						ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME,
						clientE2ETO.getCsLastName());
			} else {
				Verify.verifyTrue(false,
						"Last Name in seach page text box not found");
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * This method is to enter the Postal Code in Customer Search page for
	 * SupportWrite.
	 * 
	 * @throws ScriptException
	 */
	public void enterZipSearchPage() throws ScriptException {
		if (clientE2ETO.getCsZip() != null) {
			if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_ZIP
					.exists()) {
				Verify.verifyTrue(true,
						"ZIP/Postal Code : " + clientE2ETO.getCsZip());
				ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_ZIP
						.setText(clientE2ETO.getCsZip());
			} else {
				Verify.verifyTrue(false,
						"Mailing ZIP text box is NOT displayed");
			}
		}
	}

	/**
	 * This method is to Click on Search Button in the Customer Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void clickSearchButtonSeachPage() throws ScriptException {
		if (ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_SUBMIT.exists()) {
			ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_SUBMIT.click();
			Verify.verifyTrue(true, "Search submit button is clicked");
		} else {
			Verify.verifyTrue(false, "Search button is not found");
		}
	}

	/**
	 * This method is used to Select the Customer from the Search results for
	 * Support Write
	 * 
	 * @throws ScriptException
	 */
	public void launchHHPageABS() throws ScriptException {
		try {
			if (isCustomerSearchPageExistsABS()) {
				selectCustomerFromTable();
				clickHouseholdButtonSearchPage();
				setTopFramewithDefaultContent();
				handleCimsVersion();
				clickContinuetoHHifExists();
				isHosuseHoldPageLaunchedOrNot();
			} else {
				Verify.verifyTrue(false,
						"Customer Search Page Not Launched to Continue to HH Page");
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * This method is used to Click on View Household Info button in the
	 * Customer Search page for Support Write.
	 * 
	 * @throws ScriptException
	 */
	public void clickHouseholdButtonSearchPage() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.BUTTON_HOUSEHOLDBUTTONSEARCHPAGE
				.exists()) {
			click(Update_Misc_Objects.WidgetInfos.BUTTON_HOUSEHOLDBUTTONSEARCHPAGE,
					"Clicked Household button in search page");

		} else {
			Verify.verifyTrue(false, "HouseHold button is not found");
		}
	}

	/**
	 * This Method is used to identify whether the Household page is launched.
	 * <p>
	 * Write the appropriate message.
	 * 
	 * @throws ScriptException
	 */
	public void isHosuseHoldPageLaunchedOrNot() throws ScriptException {
		waitForPageLoad(HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD, 15);
		if (HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD.exists()) {
			Verify.verifyTrue(true, "HouseHold page is launched successfully");
		} else {
			Verify.verifyTrue(false, "HouseHold  page is NOT launched");
		}
	}

	/**
	 * This method is used to Click on the Agent Selection button if exists.
	 */
	public void clickContinuetoHHifExists() {
		try {
			waitForPageLoad(
					ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_CONTINUE_HOUSEHOLD,
					5);
			if (ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_CONTINUE_HOUSEHOLD
					.exists()) {
				ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_CONTINUE_HOUSEHOLD
						.click();
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	public void searchCustomerByPhone_Agent() throws ScriptException {

		clickOnPhone();
		enterPhoneNumber();
		clickPortalSeacrhButton();
		waitForTime(1);

	}

	public void searchCustomerByPhone_NonAgent() throws ScriptException {

		clickPhone();
		enterPhone();
		clickPhoneSearchButton();
		waitForTime(2);

	}

	public void clickOnPhone() throws ScriptException {

		if (ABSPortalTestObjects.WidgetInfos.RADIOBUTTON_PHONE.exists()) {
			click(ABSPortalTestObjects.WidgetInfos.RADIOBUTTON_PHONE,
					"The radio button Phone is clicked successfully");
			waitForTime(3);
		}
	}

	public void clickPhone() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_PHONE
				.exists()) {
			click(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_PHONE,
					"The radio button Phone is clicked successfully");
			waitForTime(3);
		}
	}

	public void enterPhoneNumber() throws ScriptException {

		// phone number - "905-536-9477"
		if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_PHONENUMBER.exists()) {
			setTextInTextbox(
					ABSPortalTestObjects.WidgetInfos.TEXTFIELD_PHONENUMBER,
					clientE2ETO.getPhoneNumber1(),
					"Phone number is entered successfully");

		}
	}

	public void enterPhone() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_PHONE.exists()) {
			setTextInTextbox(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_PHONE,
					clientE2ETO.getPhoneNumber(),
					"Phone number is entered successfully");

		}
	}

	public void searchCustomerByAccountPolicy() throws ScriptException {

		clickOnAcctPolicy_Agent();
		enterPolicyNumber_Agent();
		clickPortalSeacrhButton();
		waitForTime(1);

	}

	public void clickOnAcctPolicy_Agent() throws ScriptException {

		if (ABSPortalTestObjects.WidgetInfos.RADIOBUTTON_ACCTPOLICY.exists()) {
			click(ABSPortalTestObjects.WidgetInfos.RADIOBUTTON_ACCTPOLICY,
					"Account/Policy is clicked successfully in the customer search page");
			waitForTime(3);
		}
	}

	public void clickOnAcctPolicy_NonAgent() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ACCOUNTPOLICY
				.exists()) {
			click(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ACCOUNTPOLICY,
					"Account/Policy is clicked successfully in the customer search page");
			waitForTime(5);
		}
	}

	public void enterPolicyNumber_Agent() throws ScriptException {

		// policy number - "101 4753-D08-60C"
		if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POLICYNUMBER.exists())
			setTextInTextbox(
					ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POLICYNUMBER,
					clientE2ETO.getPolicyNumber(),
					"Policy number is entered successfully");
	}

	public void enterPolicyNumber_NonAgent() throws ScriptException {

		// policy number - "101 4753-D08-60C"
		if (ABSCustomerSearchTestObjects.WidgetInfos.TEXTFIELD_POLICYNUMBER
				.exists())
			setTextInTextbox(
					ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POLICYNUMBER,
					clientE2ETO.getPolicyNumber1(),
					"Policy number is entered successfully");
	}

	public void selectRegion() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.LISTBOX_REGION.exists()) {
			ABSCustomerSearchTestObjects.WidgetInfos.LISTBOX_REGION
					.selectItemAtIndex(2);
			Verify.verifyTrue(true, "Region is selected successfully");
		} else
			Verify.verifyTrue(false, "Region is not found");
	}

	public void clickBob() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_BOOKOFBUSINESS
				.exists())
			click(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_BOOKOFBUSINESS,
					"Book of Business is clicked successfully in the customer search page");
	}

	public void enterAgentCode() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.TEXTFIELD_AGENT_CODE
				.exists())
			setTextInTextbox(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXTFIELD_AGENT_CODE,
					clientE2ETO.getAgentCode(),
					"Agent code is entered successfully");
	}
	
	public void enterCanadaAgentCode() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.TEXTFIELD_AGENT_CODE
				.exists())
			setTextInTextbox(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXTFIELD_AGENT_CODE,
					clientE2ETO.getCanadaAgentCode(),
					"Agent code is entered successfully");
	}

	public void enterLastName() throws ScriptException {

		waitForTime(2);
		 if(ABSCustomerSearchTestObjects.WidgetInfos.TEXT_AGENT_SEARCH_LASTNAME.exists())
		 {
		    setTextInTextbox(ABSCustomerSearchTestObjects.WidgetInfos.TEXT_AGENT_SEARCH_LASTNAME,
		 "SMITH", "Last name is entered successfully");
		 }
	}

	public void clickSearchButton() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_AGENT_SEARCH_SUBMIT
				.exists())
			click(ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_AGENT_SEARCH_SUBMIT,
					"Search button is clicked successfully in the customer search page");
	}

	/**
	 * CMP Scenarios
	 * 
	 * @throws ScriptException
	 * @throws InterruptedException
	 */

	public void usAgentNotAbleToSearchOnCanadaName() throws ScriptException {

		launchPortalCustomerSearchPage();
		waitForTime(1);
		verifyErrorMessageForScenario3();

	}

	public void canadaAgentNotAbleToSearchOnUSName() throws ScriptException {

		launchPortalCustomerSearchPage();
		waitForTime(5);
		verifyErrorMessageForScenario3();

	}

	public void usAgentNotAbleToSearchOnCanadaPhone() throws ScriptException {

		searchCustomerByPhone_Agent();
		verifyErrorMessageForScenario3();

	}

	public void canadaAgentNotAbleToSearchOnUSPhone() throws ScriptException {

		searchCustomerByPhone_Agent();
		verifyErrorMessageForScenario3();

	}

	public void usAgentNotAbleToSearchOnCanadaAcctPolicy()
			throws ScriptException {

		searchCustomerByAccountPolicy();
		verifyErrorMessageForScenario3();

	}

	public void canadaAgentNotAbleToSearchOnUSAcctPolicy()
			throws ScriptException {

		searchCustomerByAccountPolicy();
		verifyErrorMessageForScenario3();

	}

	/*
	 * public void usAgentNotAbleToSearchOnCanadaOob() throws ScriptException {
	 * 
	 * oob.fetchOobData(); verifyErrorMessageForScenario3();
	 * 
	 * }
	 * 
	 * public void canadaAgentNotAbleToSearchOnUSOob() throws ScriptException {
	 * 
	 * oob.fetchOobData(); verifyErrorMessageForScenario3();
	 * 
	 * }
	 */

	public void verifyErrorMessageForScenario3() throws ScriptException {

		String errorMessage = getWebDriverInstance().findElement(
				By.xpath("//div[@id='absResultContainer']/div/div/div[2]"))
				.getText();
		if (errorMessage.equalsIgnoreCase(MessageUtility.ERRORMSG_Scenario3))
			Verify.verifyTrue(true, "The Error message"+ " " 
					+ MessageUtility.ERRORMSG_Scenario3
					+ "is displayed successfully");
		else
			Verify.verifyTrue(false, "The Error message"
					+ MessageUtility.ERRORMSG_Scenario3 + "is not displayed ");

	}

	public void verifyErrorMessageForScenario4() throws ScriptException {

		String errorMessage = getWebDriverInstance().findElement(
				By.xpath("//div[@id='messageSummary']/ul/li")).getText();
		if (errorMessage.equalsIgnoreCase(MessageUtility.ERRORMSG_Scenario4))
			Verify.verifyTrue(true, "The Error message"+ " " 
					+ MessageUtility.ERRORMSG_Scenario4
					+ "is displayed successfully");
		else
			Verify.verifyTrue(false, "The Error message"
					+ MessageUtility.ERRORMSG_Scenario4 + "is not displayed ");

	}

	public void verifyErrorMessageForCanadaScenario5() throws ScriptException {

		String errorMessage = getWebDriverInstance().findElement(
				By.xpath("//div[@id='searchResults']/span/b")).getText();
		if (errorMessage
				.equalsIgnoreCase(MessageUtility.ERRORMSG_CanadaScenario5))
			Verify.verifyTrue(true, "The Error message"+ " " 
					+ MessageUtility.ERRORMSG_CanadaScenario5
					+ "is displayed successfully");
		else
			Verify.verifyTrue(false, "The Error message"
					+ MessageUtility.ERRORMSG_CanadaScenario5
					+ "is not displayed ");

	}

	public void verifyNoResultFound() {
		try {
			String noResultMsg = "No results found!";
			WebElement noResult = getWebDriverInstance().findElement(
					By.xpath("//div[@id='searchResults']/span/b"));
			if (noResult.equals(noResultMsg)) {
				Verify.verifyTrue(true, noResult + "   is displayed ");
			} else {
				Verify.verifyTrue(false, "No results found! is Not Displayed");
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}

	private void launchCustomerPhone() {
		if (isCustomerSearchPageExistsABS()) {
			enterPhoneSearchPage();
			clickSearchButtonSeachPage();
		} else {
			Verify.verifyTrue(false, "Customer Search Page Not Launched");
		}

	}

	private void enterPhoneSearchPage() {
		if (clientE2ETO.getCanadaPhone() != null) {
			ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_PHONE.click();
			waitForTime(3);
			if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_PHONE.exists()) {
				Verify.verifyTrue(true,
						"Phone Number : " + clientE2ETO.getCanadaPhone());
				ABSCustomerSearchTestObjects.WidgetInfos.TEXT_PHONE
						.setText(clientE2ETO.getCanadaPhone());// need to add
																// the
																// field[canadaPhone]
																// in
																// database&&need
																// toSetValue()
			} else {
				Verify.verifyTrue(false, "Phone text box is NOT displayed");
			}
		}
	}

	private void enterCanadaZipSearchPage() {
		if (clientE2ETO.getCanadaZip() != null) {
			if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_ZIP
					.exists()) {
				Verify.verifyTrue(true,
						"ZIP/Postal Code : " + clientE2ETO.getCanadaZip());
				ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_ZIP
						.setText(clientE2ETO.getCanadaZip());// need to add the
																// field[canadaZip]
																// in database
			} else {
				Verify.verifyTrue(false,
						"Mailing ZIP text box is NOT displayed");
			}
		}
	}

	public void verifyErrorMessageForUSScenario8() throws ScriptException {

		String errorMessage = getWebDriverInstance().findElement(
				By.xpath("//form[@name='createPersonForm']/div[3]/div[1]"))
				.getText();
		if (errorMessage
				.equalsIgnoreCase(MessageUtility.ERRORMSG_CanadaScenario5))
			Verify.verifyTrue(true, "The Error message"
					+ MessageUtility.ERRORMSG_USScenario8
					+ "is displayed successfully");
		else
			Verify.verifyTrue(false, "The Error message"
					+ MessageUtility.ERRORMSG_USScenario8 + "is not displayed ");

	}

	public void verifyErrorMessageForUSScenario1() throws ScriptException {

		String errorMessage = getWebDriverInstance().findElement(
				By.xpath("//div[@id='P2QX9A00_errorMessages']/span")).getText();
		if (errorMessage.equalsIgnoreCase(MessageUtility.ERRORMSG_USScenario1))
			Verify.verifyTrue(true, "The Error message"
					+ MessageUtility.ERRORMSG_USScenario1
					+ "is displayed successfully");
		else
			Verify.verifyTrue(false, "The Error message"
					+ MessageUtility.ERRORMSG_USScenario1 + "is not displayed ");

	}
	
	public void verifyErrorMessageForCanadaScenario1() throws ScriptException {

		String errorMessage = getWebDriverInstance().findElement(
				By.xpath("//div[@id='P2QX9A00_errorMessages']/span")).getText();
		if (errorMessage.equalsIgnoreCase(MessageUtility.ERRORMSG_CanadaScenario1))
			Verify.verifyTrue(true, "The Error message"
					+ MessageUtility.ERRORMSG_CanadaScenario1
					+ "is displayed successfully");
		else
			Verify.verifyTrue(false, "The Error message"
					+ MessageUtility.ERRORMSG_CanadaScenario1 + "is not displayed ");

	}

	/** US SCENARIOS **/

	/**
	 * CMP - US Scenario 3
	 * 
	 * @throws ScriptException
	 */
	public void usAgentNotAbleToSearchOnCanadaData() throws ScriptException {

		usAgentNotAbleToSearchOnCanadaName();
		usAgentNotAbleToSearchOnCanadaPhone();
		usAgentNotAbleToSearchOnCanadaAcctPolicy();
		// usAgentNotAbleToSearchOnCanadaOob();

	}

	/**
	 * CMP - US Scenario 4
	 * 
	 * @throws ScriptException
	 */
	public void usNonAgentNotAbleToSearchOnCanadianBob() throws ScriptException {

		clickBob();
		waitForTime(3);
		enterLastNameSearchPage();
		enterCanadaAgentCode();
		clickSearchButton();
		waitForTime(1);
		verifyErrorMessageForScenario4();
	}

	/**
	 * CMP - US Scenario 5
	 * 
	 * @throws ScriptException
	 */
	public void usNonAgentNotAbleToSearchOnCanadianPolicy()
			throws ScriptException {

		clickOnAcctPolicy_NonAgent();
		enterPolicyNumber_NonAgent();
		selectRegion();
		clickPortalSeacrhButton();
		waitForTime(3);
		verifyErrorMessageForScenario4();
	}

	/**
	 * CMP - US Scenario 6
	 * 
	 * @throws ScriptException
	 */
	public void unabletoSearchCanadaUserWithUsNonAgent() {
		try {
			if (isCustomerSearchPageExistsABS()) {
				clickClearButtonSearchPage();
				launchCustomerSearchPage();
				waitForTime(3);
				verifyNoResultFound();

			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * CMP - US Scenario 7
	 * 
	 * @throws ScriptException
	 */
	public void unabletoSearchCanadaphoneWithUsNonAgent() {
		if (isCustomerSearchPageExistsABS()) {
			clickClearButtonSearchPage();
			launchCustomerPhone();
			verifyNoResultFound();
		}

	}

	/**
	 * CMP - Canada Scenario 3
	 * 
	 * @throws ScriptException
	 */
	public void canadaNonAgentNotAbleToSearchOnUSBob() throws ScriptException {

		clickBob();
		enterAgentCode();
		enterLastName();
		clickSearchButton();
		waitForTime(3);
		verifyErrorMessageForScenario4();
	}

	/**
	 * CMP - Canada Scenario 4
	 * 
	 * @throws ScriptException
	 */
	public void canadaNonAgentNotAbleToSearchOnUSPolicy()
			throws ScriptException {

		clickClearButtonSearchPage();
		searchCustomerByAccountPolicy();
		verifyErrorMessageForScenario4();
	}

	/**
	 * CMP - Canada Scenario 5
	 * 
	 * @throws ScriptException
	 */
	public void canadaNonAgentNotAbleToSearchUSName() throws ScriptException {

		clickNameRadioButton();
		launchCustomerSearchPage();
		verifyErrorMessageForCanadaScenario5();
	}

	/**
	 * CMP - Canada Scenario 6
	 * 
	 * @throws ScriptException
	 */
	public void canadaNonAgentNotAbleToSearchUSPhone() throws ScriptException {

		waitForTime(3);
		searchCustomerByPhone_NonAgent();
		verifyErrorMessageForCanadaScenario5();
	}
}