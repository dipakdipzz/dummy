package sf.client.service.healthSuite.baseScripts;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import sf.client.service.common.helpers.ITransferObject;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.TestDataObject;
import sf.client.service.common.tasks.EndToEndCommonTasks;
import sf.client.service.healthSuite.helpers.DatabaseUtil;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;
import sf.client.service.healthSuite.tasks.OOBOrgnizationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.wat.script.IScript;
import statefarm.wat.util.WATConfiguration;


public class BaseScript implements IScript {
	
	public ScenarioTasks scenarioTasks = null;
	public ProductTasks productTasks = null;
	public CreateCustomersTasks createCustTasks = null;
	public ITransferObject transferObject = new TestDataObject();
	public DatabaseUtil databaseUtil = new DatabaseUtil();
	public ClientE2ETO clientE2ETO = new ClientE2ETO();
	public UpdateCustomersTasks updateTasks = null;
	public HHnavigationTasks hhNavigationTasks = null;
	public HHRelationshipTasks hhRelationshipTasks = null;
	public SeparateCustomersTasks separateCustTasks = null;
	public ConnectCustomersTasks connectCustTasks = null;
	public CombineCustomersTasks combineTasks = null;
	public SSNSINTasks ssnSINTasks = null;
	public TestDataObject testDataObject = null;
	public LaunchApplication launcher = null;
	public ResultSet dbresultSet = null;
	public OOBIndividualTasks oobIndividualTasks = null;
	public OOBOrgnizationTasks oobOrgnizationTasks = null;
	public RemoveFromBookTasks removeFromBookTasks = null;
	public EndToEndCommonTasks endToEndTasks = null;
	
	@Override
	public void scriptMain() {
		// TODO Auto-generated method stub

	}
	
	public WATConfiguration getWATConfig(){
		return WATConfiguration.getInstance();
	}
	public String currentProject=System.getProperty("user.dir");
	public ITransferObject setTestDataObject(ITransferObject transferObject) {
		
		if(transferObject!=null&&transferObject.getDbFileName()==null){
			
		transferObject.setDbFileName(getMDBName(null)+".mdb");
		
		}
		if(transferObject!=null&&transferObject.getDbFilePath()==null){
			
			
			transferObject.setDbFilePath(currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\");
			}
		
		
		return transferObject;
	}
	
	public String getMDBName(String mdbKey){
		String value=null;

	File propfile = new File(currentProject+"\\src\\main\\java\\sf\\client\\service\\common\\data\\mdb"+".properties");
	try{
	if(propfile.exists()){
	  Properties pro = new Properties();
	  FileInputStream in = new FileInputStream(propfile);
	  pro.load(in);
	  if(mdbKey!=null)
	     value = pro.getProperty(mdbKey);
	  else{
		  value = pro.getProperty("mdb");
	  }
	  
		 System.out.println("MDB specified as : "+value);
	   if(value!=null){
		   value=pro.getProperty(value);
		   if(value==null){
			  System.err.println("Specified mdb does not have Corresponding MDB file");
			 }
		 }
		 else{
			 System.err.println("Specified mdb does not have Corresponding MDB file");
		 }

	}
	else{

	  System.out.println("properties File not found!");
	}
	}
	catch(FileNotFoundException ex){
		System.err.println("FileNotFoundException occured while loading properties file");
	}

	catch(IOException ex){
		System.err.println("IOException occured while loading properties file");
	}
	return value;
	}
	
	public String getTime() {
		
		SimpleDateFormat	simpleDateFormat	= new SimpleDateFormat("HH-mm-ss");
		return simpleDateFormat.format(new Date()).toString();
	}
	
	public String resultsFileName(){
		String filename = (this.getClass().getSimpleName())+"_"+getTime();		
		return filename;
	}
	
	public String scriptName(){
			return this.getClass().getCanonicalName();
	}

}
