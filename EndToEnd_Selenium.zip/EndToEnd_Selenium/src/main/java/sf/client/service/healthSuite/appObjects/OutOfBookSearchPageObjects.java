package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.TextField;

public class OutOfBookSearchPageObjects {

	public static final String OUTOFBOOKSEARCH_WP_LINK_CUSTOMERTAB = "text=Customer";
	public static final String OUTOFBOOKSEARCH_OOB_RADIOBUTTON = "id=P2QX9A00_oobSearchOption";
	public static final String OUTOFBOOKSEARCH_RADIOBUTTON_SELECTINDIVIDUAL = "id=P2QX9A00_indType"; // GuiTestObject
	public static final String OUTOFBOOKSEARCH_RADIOBUTTON_SELECTORGANIZATION ="id=P2QX9A00_orgType";
	public static final String OUTOFBOOKSEARCH_TEXT_LASTNAME = "id=P2QX9A00_oobLastName";
	public static final String OUTOFBOOKSEARCH_TEXT_ORGNAME = "id=P2QX9A00_oobLastName";// P2QX9A00_oobOrgName
	public static final String OUTOFBOOKSEARCH_TEXT_FIRSTNAME = "id=P2QX9A00_oobFirstName"; // TextGuiTestObject
	public static final String OUTOFBOOKSEARCH_TEXT_CITY = "id=P2QX9A00_oobCity"; // TextGuiTestObject
	public static final String OUTOFBOOKSEARCH_TEXT_POSTALCODE = "id=P2QX9A00_oobPostalCode"; // TextGuiTestObject
	public static final String OUTOFBOOKSEARCH_LIST_STATEPROV = "id=P2QX9A00_oobState"; // SelectGuiSubitemTestObject
	public static final String OUTOFBOOKSEARCH_LIST_VERIFICATIONLOB = "id=P2QX9A00_oobLineOfBusiness"; // SelectGuiSubitemTestObject
	public static final String OUTOFBOOKSEARCH_TEXT_ACCOUNTPOLICYNUMBER = "id=P2QX9A00_oobPolicyNumber"; // TextGuiTestObject
	public static final String OUTOFBOOKSEARCH_LIST_VERIFICATIONSTATEPROV = "name=oobStateIssued"; // SelectGuiSubitemTestObject
	public static final String OUTOFBOOKSEARCH_TEXT_OOBSSN = "id=P2QX9A00_oobSSN"; // TextGuiTestObject
	public static final String OUTOFBOOKSEARCH_TEXT_OOBPOSTALCODEMOVE = "id=P2QX9A00_oobPostalCodeMove"; // TextGuiTestObject
	public static final String OUTOFBOOKSEARCH_LIST_MOVINGTOSTATEPROV = "name=oobStateMove"; // SelectGuiSubitemTestObject
	public static final String OUTOFBOOKSEARCH_TEXT_OOBCITYMOVE = "id=P2QX9A00_oobCityMove"; // TextGuiTestObject
	public static final String OUTOFBOOKSEARCH_BUTTON_SEARCHSUBMIT = "id=P2QX9A00_submitSearch"; // GuiTestObject
	public static final String OUTOFBOOKSEARCH_BUTTON_CLEARSUBMIT = "id=P2QX9A00_submitClear"; // GuiTestObject
	
	@WidgetIDs
	public static class WidgetInfos{
		public static final Link WP_LINK_CUSTOMERTAB = new Link(OUTOFBOOKSEARCH_WP_LINK_CUSTOMERTAB);
		public static final RadioButton OOB_RADIOBUTTON = new RadioButton(OUTOFBOOKSEARCH_OOB_RADIOBUTTON);
		public static final RadioButton RADIOBUTTON_SELECTINDIVIDUAL = new RadioButton(OUTOFBOOKSEARCH_RADIOBUTTON_SELECTINDIVIDUAL); // GuiTestObject
		public static final RadioButton RADIOBUTTON_SELECTORGANIZATION = new RadioButton(OUTOFBOOKSEARCH_RADIOBUTTON_SELECTORGANIZATION);
		public static final TextField TEXT_LASTNAME = new TextField(OUTOFBOOKSEARCH_TEXT_LASTNAME);
		public static final TextField TEXT_ORGNAME = new TextField(OUTOFBOOKSEARCH_TEXT_ORGNAME);// PC_7_DUGDR5C3289L40IQ8K9K493002_oobOrgName
		public static final TextField TEXT_FIRSTNAME = new TextField(OUTOFBOOKSEARCH_TEXT_FIRSTNAME); // TextGuiTestObject
		public static final TextField TEXT_CITY = new TextField(OUTOFBOOKSEARCH_TEXT_CITY); // TextGuiTestObject
		public static final TextField TEXT_POSTALCODE = new TextField(OUTOFBOOKSEARCH_TEXT_POSTALCODE); // TextGuiTestObject
		public static final ListBox LIST_STATEPROV = new ListBox(OUTOFBOOKSEARCH_LIST_STATEPROV); // SelectGuiSubitemTestObject
		public static final ListBox LIST_VERIFICATIONLOB = new ListBox(OUTOFBOOKSEARCH_LIST_VERIFICATIONLOB); // SelectGuiSubitemTestObject
		public static final TextField TEXT_ACCOUNTPOLICYNUMBER = new TextField(OUTOFBOOKSEARCH_TEXT_ACCOUNTPOLICYNUMBER); // TextGuiTestObject
		public static final ListBox LIST_VERIFICATIONSTATEPROV = new ListBox(OUTOFBOOKSEARCH_LIST_VERIFICATIONSTATEPROV); // SelectGuiSubitemTestObject
		public static final TextField TEXT_OOBSSN = new TextField(OUTOFBOOKSEARCH_TEXT_OOBSSN); // TextGuiTestObject
		public static final TextField TEXT_OOBPOSTALCODEMOVE = new TextField(OUTOFBOOKSEARCH_TEXT_OOBPOSTALCODEMOVE); // TextGuiTestObject
		public static final ListBox LIST_MOVINGTOSTATEPROV = new ListBox(OUTOFBOOKSEARCH_LIST_MOVINGTOSTATEPROV); // SelectGuiSubitemTestObject
		public static final TextField TEXT_OOBCITYMOVE = new TextField(OUTOFBOOKSEARCH_TEXT_OOBCITYMOVE); // TextGuiTestObject
		public static final Button BUTTON_SEARCHSUBMIT = new Button(OUTOFBOOKSEARCH_BUTTON_SEARCHSUBMIT); // GuiTestObject
		public static final Button BUTTON_CLEARSUBMIT = new Button(OUTOFBOOKSEARCH_BUTTON_CLEARSUBMIT); // GuiTestObject
	}
	
	
}
