package sf.client.service.healthSuite.tasks;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.CWNonAgentCSObjects;
import sf.client.service.healthSuite.appObjects.EnterpriseClientViewPageObjects;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.gui.TableEx;
import statefarm.widget.manager.Verify;

public class ConnectCustomersTasks extends HouseHoldTasks {

	/**
	 * Empty Constructor
	 */
	public ConnectCustomersTasks() {
	}
	/**
	 * Parameterized Constructor
	 * 
	 * @param clientE2ETO
	 */
	public ConnectCustomersTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}
	/**
	 * Search and Select First customer From Search and Select Two Customers page. 
	 * @throws ScriptException
	 */
	public void accessSS2CPageFirstCustomer() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.BUTTON_CLEAR, 10);
		click(CWNonAgentCSObjects.WidgetInfos.BUTTON_CLEAR,
				MessageUtility.BUTTON_CLEAR);
		if (clientE2ETO.getOrgNameSearchpage() != null) {
			waitForPageLoad(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA, 5);
			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA,
					"Name Radio Button Selected Successfully");
			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_ENTERPRISE_NAME_SEARCH_ORG,
					"Radio Button Selected Successfully");
			setTextInTextbox(
					CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_ORG,
					clientE2ETO.getOrgNameSearchpage(),
					"Organization name entered successfully");
			enterMandatoryfieldtoEnablebutton(
					CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_ORG,
					clientE2ETO.getOrgNameSearchpage());

			if (clientE2ETO.getZipSearchPage() != null)

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_ZIP,
						clientE2ETO.getZipSearchPage(),
						"Zip entered successfully");

			if (clientE2ETO.getStateSearchPage() != null)

				selectFromListbox(
						CWNonAgentCSObjects.WidgetInfos.LIST_ENTERPRISENAMESEARCHCRIT_STATE,
						clientE2ETO.getStateSearchPage(),
						"State entered successfully");

			if (clientE2ETO.getrCity() != null)

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_CITY,
						clientE2ETO.getrCity(), "City entered successfully");

			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_SEARCH,
					"Button clicked Successfully");

		}

		if (clientE2ETO.getOrgNameSearchpage() == null) {

			waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA);

			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA,
					"RadioButton clicked Successfully");
			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_ENTERPRISE_NAME_SEARCH_IND,
					"RadioButton clicked Successfully");

			if (clientE2ETO.getLastNameSearchpage() != null)

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_LASTNAME,
						clientE2ETO.getLastNameSearchpage(),
						"LastName entered successfully");
			enterMandatoryfieldtoEnablebutton(
					CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_LASTNAME,
					clientE2ETO.getLastNameSearchpage());

			if (clientE2ETO.getFirstNameSearchpage() != null) {

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_FIRSTNAME,
						clientE2ETO.getFirstNameSearchpage(),
						"FirstName entered successfully");

			}
			if (clientE2ETO.getMiddleName() != null)

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_MIDDLENAME,
						clientE2ETO.getMiddleName(),
						"MiddleName entered successfully");

			if (clientE2ETO.getZipSearchPage() != null) {

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_ZIP,
						clientE2ETO.getZipSearchPage(),
						"Zip entered successfully");
			} else {

				if (clientE2ETO.getStateSearchPage() != null)

					selectFromListbox(
							CWNonAgentCSObjects.WidgetInfos.LIST_ENTERPRISENAMESEARCHCRIT_STATE,
							clientE2ETO.getStateSearchPage(),
							"State entered successfully");
				if (clientE2ETO.getrCity() != null)

					setTextInTextbox(
							CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_CITY,
							clientE2ETO.getrCity(),
							"City  entered successfully");

			}

			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_SEARCH,
					"Button clicked successfully");

		}

	}
	/**
	 * Select and add First customer From Search and Select Two Customers page. 
	 *  @throws ScriptException
	 */
	public void selectAndAddCustomerFromSearchResultsMCLBFirstCustomer()
			throws ScriptException {

		boolean selected = selectCustomerFromTable(clientE2ETO
				.getSs2cFirstCustomer());

		if (!selected) {

			if (CWNonAgentCSObjects.WidgetInfos.DIV_HTML_ERRORMSG.exists()) {
				Verify.verifyTrue(false,
						"Unable to find " + clientE2ETO.getSs2cFirstCustomer()
								+ " in  Search Results MCLB");

			} else {
				Verify.verifyTrue(false,
						"Error occured while searching and the error message is :"
								+ (CWNonAgentCSObjects.WidgetInfos.DIV_HTML_ERRORMSG).getText()
										.substring(30));
			}
		} else {

			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_ADD,
					"Button clicked successfully");
		}

	}
	/**
	 * Search and Select Second customer From Search and Select Two Customers page. 
	 *  @throws ScriptException
	 */
	public void accessSS2CPageSecondCustomer() throws ScriptException {

		if (CWNonAgentCSObjects.WidgetInfos.BUTTON_CLEAR.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_CLEAR,
					"Button clicked successfully");
		}
		if (clientE2ETO.getOrgName2() != null) {

			waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA);
			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA,
					"RadioButton clicked successfully");

			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_ENTERPRISE_NAME_SEARCH_ORG,
					"RadioButton clicked successfully");

			setTextInTextbox(
					CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_ORG,
					clientE2ETO.getOrgName2(), "OrgName entered successfully");
			enterMandatoryfieldtoEnablebutton(
					CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_ORG,
					clientE2ETO.getOrgName2());

			if (clientE2ETO.getZip2() != null)

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_LASTNAME,
						clientE2ETO.getZip2(), "Zip entered successfully");

			if (clientE2ETO.getState2() != null)

				selectFromListbox(
						CWNonAgentCSObjects.WidgetInfos.LIST_ENTERPRISENAMESEARCHCRIT_STATE,
						clientE2ETO.getState2(), "State");
			if (clientE2ETO.getCity2() != null)

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_CITY,
						clientE2ETO.getCity2(), "City entered successfully");

			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_SEARCH,
					"Button clicked successfully");

		}

		if (clientE2ETO.getOrgName2() == null) {

			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA,
					"RadioButton clicked successfully");

			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_ENTERPRISE_NAME_SEARCH_IND,
					"RadioButton clicked successfully");

			if (clientE2ETO.getLastName2() != null)
				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_LASTNAME,
						clientE2ETO.getLastName2(), "Name entered successfully");
			enterMandatoryfieldtoEnablebutton(
					CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_LASTNAME,
					clientE2ETO.getLastName2());

			if (clientE2ETO.getFirstName2() != null) {

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_FIRSTNAME,
						clientE2ETO.getFirstName2(),
						"Name entered successfully");
			}
			if (clientE2ETO.getMiddleName2() != null)

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_MIDDLENAME,
						clientE2ETO.getMiddleName2(),
						"Name entered successfully");

			if (clientE2ETO.getZip2() != null) {

				setTextInTextbox(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_ZIP,
						clientE2ETO.getZip2(), "Zip entered successfully");

			} else {

				if (clientE2ETO.getState2() != null)

					selectFromListbox(
							CWNonAgentCSObjects.WidgetInfos.LIST_ENTERPRISENAMESEARCHCRIT_STATE,
							clientE2ETO.getState2(),
							"State selected successfully");

				if (clientE2ETO.getCity2() != null)

					setTextInTextbox(
							CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_CITY,
							clientE2ETO.getCity2(), "City entered successfully");
			}

			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_SEARCH,
					"Button Clicked Successfully");

		}

	}
	/**
	 * Select and add Second customer From Search and Select Two Customers page. 
	 *  @throws ScriptException
	 */
	public void selectAndAddCustomerFromSearchResultsMCLBSecondCustomer()
			throws ScriptException {

		boolean selected = selectCustomerFromTable(clientE2ETO
				.getSs2cSecondCustomer());

		if (!selected) {

			if (CWNonAgentCSObjects.WidgetInfos.DIV_HTML_ERRORMSG.exists()) {
				Verify.verifyTrue(false,
						"Unable to find " + clientE2ETO.getSs2cSecondCustomer()
								+ " in  Search Results MCLB");

			} else {
				Verify.verifyTrue(false,
						"Error occured while searching and the error message is :"
								+ (CWNonAgentCSObjects.WidgetInfos.DIV_HTML_ERRORMSG).getText()
										.substring(30));
			}
		} else {

			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_ADD,
					"Button clicked successfully");
		}

	}
	/**
	 * 	verify Search Page Launched Or Not. 
	 *  @throws ScriptException
	 *  @return
	 */
	public void isSearchPageLaunchedOrNot() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.LINK_CUSTOMERSEARCH.exists()) {

			Verify.verifyTrue(true, "Search page launched Successfully");

		}

		else {
			Verify.verifyTrue(false, " Search page NOT launched .");

		}
	}
	/**
	 * 	launch Verify info Page. 
	 *  @throws ScriptException
	 */

	public void launchVerifyPage() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.LINK_NEXT, 25);

		if (CWNonAgentCSObjects.WidgetInfos.LINK_NEXT.exists()) {

			click(CWNonAgentCSObjects.WidgetInfos.LINK_NEXT, "Link clicked successfully");
		}

	}
	/**
	 * 	Select Birth date radio button from Conflicting Customer Information page. 
	 *  @throws ScriptException
	 */

	public void conflictInfoBirthDateSelection(int selection)
			throws ScriptException {

		switch (selection) {

		case 1: {
			waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_CLIENT1,
					25);
			if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_CLIENT1.exists()) {

				selectRadioButton(
						CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_CLIENT1,
						"RadioButton clicked successfully");

			} else {

				if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NKNOWN.exists()) {

					selectRadioButton(
							CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NKNOWN,
							"RadioButton clicked successfully");

				} else {
					Verify.verifyTrue(false,
							"No Value Date of birth radio widget not found");
				}
			}
			break;
		}
		case 2: {
			if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_CLIENT2.exists()) {
				selectRadioButton(
						CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_CLIENT2,
						"RadioButton clicked successfully");

			} else {

				if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NKNOWN.exists()) {

					selectRadioButton(
							CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NKNOWN,
							"RadioButton clicked successfully");

				} else {
					Verify.verifyTrue(false,
							"No Value Date of birth radio widget not found");
				}
			}
			break;
		}
		case 3: {

			if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NEWDATA.exists()) {

				selectRadioButton(
						CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NEWDATA,
						"RadioButton clicked successfully");
				if (clientE2ETO.getDeathDate() != null)

					setTextInTextbox(CWNonAgentCSObjects.WidgetInfos.TEXT_BIRTHDATE,
							clientE2ETO.getDeathDate(),
							" Text entered successfully");

			} else {
				if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NKNOWN.exists()) {

					selectRadioButton(
							CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NKNOWN,
							"RadioButton clicked successfully");

				} else {
					Verify.verifyTrue(false,
							"No Value Date of birth radio widget not found");
				}
			}
			break;

		}
		case 4: {
			if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NKNOWN.exists()) {

				selectRadioButton(
						CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_BIRTHDATE_NKNOWN,
						"RadioButton clicked successfully");

			} else {
				Verify.verifyTrue(false,
						"No Value Date of birth radio widget not found");
			}
			break;
		}
		}
	}
	/**
	 * 	Select SSN radio button from Conflicting Customer Information page. 
	 *  @throws ScriptException
	 */
	public void conflictInfoSSNSelection(int selection) throws ScriptException {
		switch (selection) {
		case 1: {

			if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_CLIENT1.exists()) {

				selectRadioButton(CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_CLIENT1,
						"RadioButton clicked successfully");

			} else {

				if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_UNKNOWN.exists()) {

					selectRadioButton(
							CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_UNKNOWN,
							"RadioButton clicked successfully");

				} else {
					Verify.verifyTrue(false,
							"No Value SSN radio widget not found");
				}
			}
			break;
		}
		case 2: {

			if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_CLIENT2.exists()) {

				selectRadioButton(CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_CLIENT2,
						"RadioButton clicked successfully");

			} else {

				if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_UNKNOWN.exists()) {

					selectRadioButton(
							CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_UNKNOWN,
							"RadioButton clicked successfully");

				} else {
					Verify.verifyTrue(false,
							"No Value SSN radio widget not found");
				}
			}
			break;
		}
		case 3: {

			if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_NEWDATA.exists()) {

				if (clientE2ETO.getSsn() != null)

					setTextInTextbox(CWNonAgentCSObjects.WidgetInfos.TEXT_SSN,
							clientE2ETO.getSsn(), "SSN");

			} else {

				if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_UNKNOWN.exists()) {

					selectRadioButton(
							CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_UNKNOWN,
							"RadioButton clicked successfully");

				} else {
					Verify.verifyTrue(false,
							"No Value SSN radio widget not found");
				}
			}
			break;
		}
		case 4: {
			if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_UNKNOWN.exists()) {

				selectRadioButton(CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SSN_UNKNOWN,
						"RadioButton clicked successfully");

			} else {
				Verify.verifyTrue(false, "No Value SSN radio widget not found");
			}
			break;
		}
		}
	}
	/**
	 * 	Validate policy info from Enterprise View  page. 
	 *  @throws ScriptException
	 */
	public void validateViewPagePolicyInfo() throws ScriptException {

		try {
			for (int j = 0; j <= Integer.parseInt(clientE2ETO
					.getLinkedClients()); j++) {
				if (new TableEx(("id=regionalPolicyTable" + j)).exists()) {
					String cellsData = null;
					String header = "";
					String row = "";
					String formatter = "                                      || ";
					int rowCount = 0;
					int count = 1;
					int c = 1;
					while (true) {
						try {
							String str  = getWebDriverInstance().findElement(By.xpath("//div[@id='regionalPolicyTable"
											+ j
											+ "']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
											+ c + "]/td[1]")).getText();
							rowCount++;
							c++;
						} catch (Exception e) {
							break;
						}
					}
					String[] s = new String[] { "Name on Acct/Pol ", "Role",
							"Number", "Description" };

					if (rowCount >= 1) {
						for (int i = 0; i < s.length; i++) {
							if (s[i] != null)
								header += s[i]
										+ formatter.substring(s[i].length());
						}
						while (count <= rowCount) {
							for (int i = 1; i <= s.length; i++) {
								cellsData = getWebDriverInstance().findElement(By.xpath("//div[@id='regionalPolicyTable"
												+ j
												+ "']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
												+ count + "]/td[" + i + "]")).getText();
								if (cellsData.length() < (formatter.length() - 4)) {
									row += cellsData
											+ formatter.substring(cellsData
													.length());
								} else {
									row += cellsData.substring(0,
											formatter.length() - 3)
											+ "|| ";
								}
							}
							row = "";
							count += 1;
						}
						count = 0;

						Verify.verifyTrue(true,
								"ACCOUNTPOLICIES Table is displayed as expected .");
					}

					if (rowCount < 1) {
						Verify.verifyTrue(true, " =======    ACCOUNTPOLICIES Table is EMPTY  ====== ");
					}
					header = "";
					row = "";
				}
			}
		}  catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * 	launch Enterprise View Page from Customer Search page. 
	 *  @throws ScriptException
	 */
	public void launchConnectViewPage() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS, 10);
		if (CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS,
					"Enterprise View Link clicked successfully");
		}
	}
	/**
	 * 	launch And validate Enterprise View Page. 
	 *  @throws ScriptException
	 */
	public void launchEnterpriseViewPage() throws ScriptException {
		try {
			if (isCustomerSearchPageExistsABS()) {
				clickEnterpriseViewLink();
				setTopFramewithDefaultContent();
				searchClientDetailsByID();
				validateConnectViewPage();
				clickCustomerSearchPageLinkInEnterPriseView();
			} else {
				Verify.verifyTrue(false,
						"Cannot proceed to HH page as Customer Search Page not launhced");
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * 	launch Enterprise View Page by Giving ClientID. 
	 *  @throws ScriptException
	 */
	public void searchClientDetailsByID() throws ScriptException {
		waitForPageLoad(EnterpriseClientViewPageObjects.WidgetInfos.TEXT_CLIENTID, 10);
		if (EnterpriseClientViewPageObjects.WidgetInfos.TEXT_CLIENTID.exists()) {
			enterMandatoryfieldtoEnablebutton(
					EnterpriseClientViewPageObjects.WidgetInfos.TEXT_CLIENTID,
					clientE2ETO.getClientID());
			if (EnterpriseClientViewPageObjects.WidgetInfos.BUTTON_SEARCHSUBMIT.exists()) {
				click(EnterpriseClientViewPageObjects.WidgetInfos.BUTTON_SEARCHSUBMIT,
						"Button clicked successfully");
			} else {
				Verify.verifyTrue(false,
						"Enterprise ClientView Search Button  not found .");
			}
		} else {
			Verify.verifyTrue(false,
					"Enterprise ClientView Text field not found .");
		}
	}
	
	public boolean clickEnterpriseViewLink() throws ScriptException {

		if (CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS.exists()) {
			CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS.click();
			Verify.verifyTrue(true,
					"Enterprise view link is displayed successfully");
			waitForTime(3);
			return true;
		} else {

			Verify.verifyTrue(false,
					"Enterprise view link is NOT displayed successfully");
			return false;
		}

	}
	/**
	 * 	Validate Name section from Enterprise View Page. 
	 *  @throws ScriptException
	 */
	public void validateViewPageNameInfo() throws ScriptException {

		try {
			for (int j = 0; j <= Integer.parseInt(clientE2ETO
					.getLinkedClients()); j++) {
				if (new TableEx("id=regionalNameTable" + j).exists()) {
					String cellsData = null;
					String header = "";
					String row = "";
					String formatter = "                             || ";
					int rowCount = 0;
					int count = 1;
					if (new TableEx("id=regionalNameTable" + j).exists()) {
						int c = 1;
						while (true) {
							try {
								getWebDriverInstance().findElement(By.xpath("//div[@id='regionalNameTable"
										+ j
										+ "']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
										+ c + "]/td[1]")).getText();
								rowCount++;
								c++;
							} catch (Exception e) {
								break;
							}
						}
						if (rowCount >= 1 && rowCount < 30) {
							String[] s = new String[1];
							s[0] = "Names";
							for (int i = 0; i < s.length; i++) {

								if (s[i] != null)
									header += s[i].trim()
											+ formatter
													.substring(s[i].length());
							}

							String currentAddressRow = "";
							String previousAddressRow = "";
							while (count <= rowCount) {
								currentAddressRow = "";
								for (int i = 1; i <= s.length; i++) {
									cellsData = getWebDriverInstance().findElement(By.xpath("//div[@id='regionalNameTable"
													+ j
													+ "']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
													+ count + "]/td[" + i + "]")).getText();
									if (cellsData.length() < (formatter
											.length() - 4)) {
										row += cellsData
												+ formatter.substring(cellsData
														.length());
									} else {
										row += cellsData.substring(0,
												formatter.length() - 3)
												+ "|| ";
									}
									currentAddressRow = currentAddressRow
											+ cellsData;
								}

								if (!"".equalsIgnoreCase(previousAddressRow)
										&& !"".equalsIgnoreCase(currentAddressRow)
										&& previousAddressRow
												.equalsIgnoreCase(currentAddressRow)) {
									Verify.verifyTrue(false,
											"Repeated display of address which is not as expected");
								}
								previousAddressRow = currentAddressRow;
								row = "";
								count += 1;

							}

							count = 1;

							Verify.verifyTrue(true,
									"NAME table is displayed as expected .");
						}

						if (rowCount > 30) {

							Verify.verifyTrue(false,
									"More than 30 name versions are displayed which is not as expected");
						}
						if (rowCount < 1) {
							Verify.verifyTrue(true, " =======    NAME Table is EMPTY  ====== ");
							Verify.verifyTrue(false,
									"Minimum of one name version is not displayed which is not as expected");
						}
						header = "";
						row = "";
					}

				}

			}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * 	Validate Address section from Enterprise View Page. 
	 *  @throws ScriptException
	 */

	public void validateConnectViewPageAddressInfo() throws ScriptException {
		try {
			for (int j = 0; j <= Integer.parseInt(clientE2ETO
					.getLinkedClients()); j++) {
				waitForPageLoad(new TableEx(("id=regionalAddressTable" + j)),
						25);
				if (new TableEx(("id=regionalAddressTable" + j)).exists()) {
					String cellsData = null;
					String header = "";
					String row = "";
					String formatter = "                             || ";
					int rowCount = 0;
					int count = 1;
					if (new TableEx("id=regionalAddressTable" + j).exists()) {
						int c = 1;
						while (true) {
							try {
								String str = getWebDriverInstance().findElement(By.xpath("//div[@id='regionalAddressTable"
												+ j
												+ "']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
												+ c + "]/td[1]")).getText();
								rowCount++;
								c++;
							} catch (Exception e) {
								break;
							}
						}
						String[] s = { "Street,subdivision", "City,State",
								"  Zip/Postal" };
						if (rowCount >= 1) {
							for (int i = 0; i < s.length; i++) {
								if (s[i] != null)
									header += s[i]
											+ formatter
													.substring(s[i].length());
							}

							String currentAddressRow = "";
							String previousAddressRow = "";
							while (count <= rowCount) {
								currentAddressRow = "";
								for (int i = 1; i <= s.length; i++) {
									cellsData = getWebDriverInstance().findElement(By.xpath("//div[@id='regionalAddressTable"
													+ j
													+ "']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
													+ count + "]/td[" + i + "]")).getText();
									if (cellsData.length() < (formatter
											.length() - 4)) {
										row += cellsData
												+ formatter.substring(cellsData
														.length());
									} else {
										row += cellsData.substring(0,
												formatter.length() - 3)
												+ "|| ";
									}

									currentAddressRow = currentAddressRow
											+ cellsData;
								}
								if (!"".equalsIgnoreCase(previousAddressRow)
										&& !"".equalsIgnoreCase(currentAddressRow)
										&& previousAddressRow
												.equalsIgnoreCase(currentAddressRow)) {
									Verify.verifyTrue(false,
											"Repeated display of address which is not as expected");
								}
								previousAddressRow = currentAddressRow;
								row = "";
								count += 1;
							}
							count = 1;
							Verify.verifyTrue(true,
									"ADDRESS table is displayed as expected .");
						}
						if (rowCount < 1) {
							Verify.verifyTrue(true, " =======   * ADDRESS Table is EMPTY * ====== ");
						}
						header = "";
						row = "";
					}
				}
			}
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * 	launch And validate Enterprise View Page. 
	 *  @throws ScriptException
	 */
	public void validateConnectViewPage() throws ScriptException {
		try {
			validateViewPageNameInfo();
			validateConnectViewPageAddressInfo();
			validateViewPagePolicyInfo();
			validateClientPersonalInfo();
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}

	}
	/**
	 * 	validate Personal Info Section from Enterprise View Page. 
	 *  @throws ScriptException
	 *  @return 
	 */
	public boolean validateClientPersonalInfo() throws ScriptException {

		boolean status = false;
		try {
			waitForPageLoad(EnterpriseClientViewPageObjects.WidgetInfos.HTML_ENTEPRISEID,
					10);
			if (EnterpriseClientViewPageObjects.WidgetInfos.HTML_ENTEPRISEID.exists()) {
				status = true;
				Verify.verifyTrue(true,
						" EntepriseId   displayed as expected and the EntepriseId :"
								+ clientE2ETO.getClientID());

				if (EnterpriseClientViewPageObjects.WidgetInfos.HTML_DISPLAYNAMES.exists()) {
					for (int i = 0; i < 60; i++) {
						if (EnterpriseClientViewPageObjects.WidgetInfos
								.getWp_html_displayName(i).exists()) {
							Verify.verifyTrue(true,(i + 1)
									+ " name version is   : "
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getWp_html_displayName(i)
											.getText());
						} else {
							Verify.verifyTrue(true, "*** Total " + (i)
									+ " Client Names displayed ");
							break;
						}
					}
				} else {
					Verify.verifyTrue(false,
							"Client Names  Not Displayed as expected . ");
				}

				validateFirstClientPersonalInfo();

			} else {
				Verify.verifyTrue(false,
						"Enterprise ID   Not Displayed as expected . ");

			}
		}  catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}

		return status;

	}
	/**
	 * 	validate Personal Info Section from Enterprise View Page. 
	 *  @throws ScriptException
	 */
	private void validateFirstClientPersonalInfo() throws ScriptException {

		for (int i = 0; i < 1; i++) {

			if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
					.getWp_html_clientId(i))) {
				Verify.verifyTrue(true, "********************"
						+ (i + 1)
						+ " CLIENT INFORMATION ************************************************");

				Verify.verifyTrue(true, " ClientID  "
						+ (i + 1)
						+ " displayed as expected and the ClienID :"
						+ EnterpriseClientViewPageObjects.WidgetInfos
								.getWp_html_clientId(i).getText());

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getWp_html_birthDate(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " BirthDate   displayed as expected and the ClienID :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getWp_html_birthDate(i).getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " BirthDate   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getWp_html_languageOfChoice(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " languageOfChoice   displayed as expected and the languageOfChoice :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getWp_html_languageOfChoice(i)
											.getText());

				} else {
					Verify.verifyTrue(
							false,
							"Client  "
									+ (i + 1)
									+ " languageOfChoice   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getWp_html_SSN(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " Tin/SSN   displayed as expected and the Tin/SSN :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getWp_html_SSN(i).getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " Tin/SSN   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getWp_html_citizenship(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " citizenship   displayed as expected and the citizenship :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getWp_html_citizenship(i)
											.getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " citizenship   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getWp_html_gender(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " gender   displayed as expected and the gender :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getWp_html_gender(i).getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " gender   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getWp_html_maritalStatus(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " maritalStatus   displayed as expected and the maritalStatus :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getWp_html_maritalStatus(i)
											.getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " maritalStatus   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getwp_html_email(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " email   displayed as expected and the deathDate :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getwp_html_email(i).getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " email   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getwp_html_phoneNumber(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " phone   displayed as expected and the deathDate :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getwp_html_phoneNumber(i)
											.getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " phone   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getwp_html_driversLicense(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " driversLicense   displayed as expected and the deathDate :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getwp_html_driversLicense(i)
											.getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " driversLicense   Not Displayed as expected . ");
				}

				if (widgetExists(EnterpriseClientViewPageObjects.WidgetInfos
						.getWp_html_deathDate(i))) {

					Verify.verifyTrue(
							true,
							" Client  "
									+ (i + 1)
									+ " deathDate   displayed as expected and the deathDate :"
									+ EnterpriseClientViewPageObjects.WidgetInfos
											.getWp_html_deathDate(i).getText());

				} else {
					Verify.verifyTrue(false, "Client  " + (i + 1)
							+ " deathDate   Not Displayed as expected . ");
				}
			} else {

				break;
			}

		}
	}
	/**
	 * 	validate RO Code from Enterprise View Page. 
	 *  @throws ScriptException
	 */

	public void validateROCodeInEnterpriseScreen() throws ScriptException {
			try {

				String xpath = "//div[@class='resultsSection']";
				WebElement enterpriseData = getWebDriverInstance().findElement(By.xpath(xpath));
				if (!enterpriseData.getText().contains("R0"))
					Verify.verifyTrue(true,
							"RO code is NOT displayed in the screen content As Expected");
				else
					Verify.verifyTrue(false,
							"RO code is displayed in the screen content");
			} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
				}
			
		}
	
	/**
	 * 	validate Connect customer functionality from customer search page. 
	 */
	public void connectCustomers() {
		try {
			if (isConnectLinkEnabled()) {
				isConnectClientClickednewurl();
				if (isConnectPageExists()) {
					accessSS2CPageFirstCustomer();
					selectAndAddCustomerFromSearchResultsMCLBFirstCustomer();
					accessSS2CPageSecondCustomer();
					selectAndAddCustomerFromSearchResultsMCLBSecondCustomer();
					launchNextPage();
					conflictInfoBirthDateSelection(1);
					conflictInfoSSNSelection(1);
					launchVerifyPage();
					clickConnectButton();
					closeStikmanPage();
				} else {
					Verify.verifyTrue(false,
							"Cannot proceed with Connect Clients as it not launched");
				}
			} else {
				Verify.verifyTrue(false, "Connect Clients link not exists");
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());	
		} 
	}
	/**
	 * 	validate Connect Clients link from Customer search Page. 
	 *  @throws ScriptException
	 *  @return
	 */
	public boolean isConnectLinkEnabled() throws ScriptException {
		if (CWNonAgentCSObjects.WidgetInfos.LINK_CONNECT_CLIENTS.exists()) {
			Verify.verifyTrue(true, "Connect clients link is displayed");
			return true;
		} else {
			Verify.verifyTrue(false, "Connect clients link is not displayed");
			return false;
		}
	}
	/**
	 * 	validate Connect Clients page Launched or not. 
	 *  @throws ScriptException
	 *  @return
	 */
	public boolean isConnectPageExists() throws ScriptException {
		if (CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_MIDDLENAME
				.exists()) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * 	launch And validate Enterprise View Page. 
	 */
	public void launchAndValidateEnterPriseView() {
		try {
			if (isConnectViewPageExists()) {
				launchConnectViewPage();
				setTopFramewithDefaultContent();
				searchClientDetailsByID();
				validateConnectViewPage();
				validateROCodeInEnterpriseScreen();
				clickCustomerSearchPageLinkInEnterPriseView();
			} else {
				Verify.verifyTrue(false, "EnterPrise View link not exists");
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * 	validate Enterprise View link from Customer search Page. 
	 *  @throws ScriptException
	 *  @return
	 */
	public boolean isConnectViewPageExists() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS, 15);
		if (CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS.exists()) {
			return true;
		} else {
			return false;
		}
	}
}
