package sf.client.service.common.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.TextField;

/**
 * This class contains all the page objects related to ABS Customer Search page
 */
public class ABSCustomerSearchTestObjects {
	
	public static final String ABS_CUSTOMER_SEARCH = "title=Customer Search";
	private static final String TEXT_LASTNAME = "id=enterpriseNameSearchCriteria.lastName";
	private static final String TEXT_FIRSTNAME = "id=enterpriseNameSearchCriteria.firstName";
	private static final String TEXT_ORG_NAME = "id=enterpriseNameSearchCriteria.organizationName"; 
	private static final String TEXT_ZIP ="id=enterpriseNameSearchCriteria.zip";
	private static final String TEXT_CITY = "id=enterpriseNameSearchCriteria.city";
	private static final String TEXT_SEARCH_LASTNAME = "id=agentNameSearchCriteria.lastName";
	private static final String TEXT_SEARCH_FIRSTNAME = "id=agentNameSearchCriteria.firstName";
	private static final String TEXT_SEARCH_ZIP = "id=agentNameSearchCriteria.zip";
	private static final String TEXT_SEARCH_CITY = "id=agentNameSearchCriteria.city";
	private static final String LINK_CUSTOMER_SEARCH = "text=Customer Search";
	private static final String RADIO_BUTTON_ORG_SEARCH = "id=organizationPartyType";
	private static final String RADIO_BUTTON_IND_SEARCH ="id=individualPartyType";
	private static final String RADIO_BUTTON_NAME= "id=coWideName";
	private static final String RADIO_BUTTON_NAME_SEARCH = "id=PC_7_DUGDR5C3289L40IQ8K9K493002_nameSearchOption";
	private static final String LIST_SEARCH_STATE = "id=enterpriseNameSearchCriteria.state"; 
	private static final String LIST_AGENTSELECTION = "id=hhAgentSelection";
	private static final String BUTTON_SEARCH_SUBMIT = "id=enterpriseNameSearch";
	private static final String BUTTON_VIEW_HOUSEHOLD = "id=viewHouseholdInfo";
	private static final String BUTTON_CLEAR_NAME_SEARCH ="id=clearEnterpriseNameSearch";
	private static final String BUTTON_CUSTOMERINFO_SEARCHPAGE = "id=viewCustomerInfo";	
	private static final String BUTTON_AGENTINFO_SEARCHPAGE = "id=viewAgentInfo";	
	private static final String BUTTON_SEARCH_CLOSE = "class=buttonPadding";	
	private static final String BUTTON_HOUSEHOLD_SEARCHPAGE = "id=viewHouseholdInfo";	
	private static final String BUTTON_CONTINUE_HH = "id=agentSelectionButton"; 
	private static final String BUTTON_AGENT_SELECTION ="id=agentSelectionButton";	
	private static final String BUTTON_AGENT_SEARCHSUBMIT = "id=agentNameSearch";
	private static final String BUTTON_AGENT_CLEAR="id=clearAgentNameSearch";
	private static final String BUTTON_CRC_LAUNCH = "id=CRC_Launcher_launch";
	private static final String RADIO_BUTTON_BOB = "id=bob";
	private static final String TEXTFIELD_AGENTCODE = "id=agentNameSearchCriteria.agentCode";
	private static final String RADIO_BUTTON_ACCTPOLICY = "id=accountPolicy";
	private static final String TEXTFIELD_POLICYNO = "id=policySearchCriteria.policyNumber";
	private static final String LIST_REG = "id=policySearchCriteria.region";
	private static final String BUTTON_SEARCH = "id=policySearch";
	private static final String RADIOBUTTON_PHONE = "id=phone";
	private static final String TEXTFIELD_PHONE	 = "id=phoneSearchCriteria.phoneNumber";
	private static final String BUTTON_POLICY_CLEAR = "id=clearPolicySearch";

	
	@WidgetIDs
	public static class WidgetInfos {
		
		public static final Link LINK_CUSTOMERSEARCH = new Link(LINK_CUSTOMER_SEARCH);
		public static final TextField TEXT_ENTERPRISE_LASTNAME = new TextField(TEXT_LASTNAME);
		public static final TextField TEXT_ENTERPRISE_FIRSTNAME = new TextField(TEXT_FIRSTNAME);
		public static final TextField TEXT_ORGANIZTION_NAME = new TextField(TEXT_ORG_NAME); 
		public static final TextField TEXT_ENTERPRISE_SEARCH_ZIP = new TextField(TEXT_ZIP);
		public static final TextField TEXT_ENTERPRISE_SEARCH_CITY = new TextField(TEXT_CITY);
		public static final TextField TEXT_AGENT_SEARCH_LASTNAME = new TextField(TEXT_SEARCH_LASTNAME);
		public static final TextField TEXT_AGENT_SEARCH_FIRSTNAME = new TextField(TEXT_SEARCH_FIRSTNAME);
		public static final TextField TEXT_AGENT_SEARCH_ZIP = new TextField(TEXT_SEARCH_ZIP);
		public static final TextField TEXT_AGENT_SEARCH_CITY = new TextField(TEXT_SEARCH_CITY); 
		public static final RadioButton RADIO_BUTTON_ORGANIZATION_SEARCH = new RadioButton(RADIO_BUTTON_ORG_SEARCH);
		public static final RadioButton RADIO_BUTTON_INDIVIDUAL__SEARCH = new RadioButton(RADIO_BUTTON_IND_SEARCH);
		public static final RadioButton RADIO_BUTTON_AGENT_NAME_SERACH= new RadioButton(RADIO_BUTTON_NAME_SEARCH);
		public static final RadioButton RADIO_BUTTON_SEARCH_NAME= new RadioButton(RADIO_BUTTON_NAME);
		public static final ListBox LIST_STATE = new ListBox(LIST_SEARCH_STATE);
		public static final ListBox LIST_AGENT_SELECTION = new ListBox(LIST_AGENTSELECTION);
		public static final Button BUTTON_SUBMIT = new Button(BUTTON_SEARCH_SUBMIT);
		public static final Button BUTTON_VIEWHH= new Button(BUTTON_VIEW_HOUSEHOLD);
		public static final Button BUTTON_CLEAR=new Button(BUTTON_CLEAR_NAME_SEARCH);
		public static final Button BUTTON_CUSTOMERINFO_PAGE = new Button(BUTTON_CUSTOMERINFO_SEARCHPAGE);	
		public static final Button BUTTON_AGENTINFO_PAGE = new Button(BUTTON_AGENTINFO_SEARCHPAGE);	
		public static final Button BUTTON_CLOSE = new Button(BUTTON_SEARCH_CLOSE);	
		public static final Button BUTTON_HOUSEHOLD_PAGE = new Button(BUTTON_HOUSEHOLD_SEARCHPAGE);	
		public static final Button BUTTON_CONTINUE_HOUSEHOLD = new Button(BUTTON_CONTINUE_HH); 
		public static final Button BUTTON_AGENTSELECTION =new Button(BUTTON_AGENT_SELECTION);	
		public static final Button BUTTON_AGENT_SEARCH_SUBMIT = new Button(BUTTON_AGENT_SEARCHSUBMIT);
		public static final Button BUTON_AGENT_SEARCH_CLEAR=new Button(BUTTON_AGENT_CLEAR);
		public static final Button BUTTON_LAUNCH_CRC = new Button(BUTTON_CRC_LAUNCH);
		public static final RadioButton RADIO_BUTTON_BOOKOFBUSINESS = new RadioButton(RADIO_BUTTON_BOB);
		public static final TextField TEXTFIELD_AGENT_CODE = new TextField(TEXTFIELD_AGENTCODE);
		public static final RadioButton RADIO_BUTTON_ACCOUNTPOLICY = new RadioButton(RADIO_BUTTON_ACCTPOLICY);
		public static final TextField TEXTFIELD_POLICYNUMBER = new TextField(TEXTFIELD_POLICYNO);
		public static final ListBox LISTBOX_REGION = new ListBox(LIST_REG);
		public static final Button BUTTON_POLICYSEARCH = new Button(BUTTON_SEARCH);
		public static final RadioButton RADIO_BUTTON_PHONE = new RadioButton(RADIOBUTTON_PHONE);
		public static final TextField TEXT_PHONE = new TextField(TEXTFIELD_PHONE);
		public static final Button POLICY_CLEAR=new Button(BUTTON_POLICY_CLEAR);
	}
}
