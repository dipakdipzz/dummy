package sf.client.service.healthSuite.tasks;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.common.appObjects.ABSPortalTestObjects;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.AddressSO;
import sf.client.service.healthSuite.appObjects.CWNonAgentCSObjects;
import sf.client.service.healthSuite.appObjects.CreateIndividualCustomer;
import sf.client.service.healthSuite.appObjects.CreateOrganizationCustomerAppObj;
import sf.client.service.healthSuite.appObjects.CustomerInfoObjects;
import sf.client.service.healthSuite.appObjects.CustomerSeparateAppObj;
import sf.client.service.healthSuite.appObjects.HHRewriteObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.PresentationKitPopupObjects;
import sf.client.service.healthSuite.appObjects.Update_IND_CustomerInfo_PageObjects;
import sf.client.service.healthSuite.appObjects.Update_Misc_Objects;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.wat.util.KeyboardUtility;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Image;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.Span;
import statefarm.widget.manager.Verify;

public class ScenarioTasks extends HouseHoldTasks {
	public int count = 0;
	public int rowCount = 0;
	public String cellsData = null;
	int firePolicyCountI = 0;
	int firePolicyCountF = 0;
	int autoPolicyCountI = 0;
	int bankPolicyCountI = 0;
	int autoPolicyCountF = 0;
	int bankPolicyCountF = 0;

	/***
	 * Empty Constructor
	 */
	public ScenarioTasks() {
		super();
	}
	/**
	 * CMP - US Scenario 1
	 * @throws ScriptException
	 */
	public void usNonAgentCannotMimicCanadianAgent() throws ScriptException {
		
		enterCanadaAgentAliasinCustomerSearchPage();
		verifyErrorMessageForUSScenario1();
	}
	
	/**
	 * CMP - Canada Scenario 1
	 * @throws ScriptException
	 */
	public void canadaNonAgentCannotMimicUSAgent() throws ScriptException {
		
		enterAgentAliasinCustomerSearchPage();
		verifyErrorMessageForCanadaScenario1();
	}
	/**
	 * Parameterized constructor
	 * 
	 * @param clientE2ETO
	 */
	public ScenarioTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}

	/**
	 * Click on CRC launch button.
	 * 
	 * @throws ScriptException
	 */
	public void clickLaunchContactCenterOnlineForQBRole()
			throws ScriptException {

		waitForPageLoad(ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_LAUNCH_CRC, 20);
		if (ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_LAUNCH_CRC.exists()) {
			click(ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_LAUNCH_CRC,
					MessageUtility.BUTTON_LAUNCHCONTACTCENTERONLINE_CLICKED);
			waitForTime(3);

		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_LAUNCHCONTACTCENTERONLINE_NOTDISPLAYED);
		}
	}

	/**
	 * click on Greeting OK button
	 * 
	 * @throws ScriptException
	 */
	public void clickGreetingOk() throws ScriptException {

		waitForPageLoad(CreateIndividualCustomer.WidgetInfos.GREETING_OK, 20);
		if (CreateIndividualCustomer.WidgetInfos.GREETING_OK.exists()) {
			click(CreateIndividualCustomer.WidgetInfos.GREETING_OK,
					MessageUtility.BUTTON_GREETINGOK);

		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_GREETINGOK_NOTDISPLAYED);
		}
	}

	/**
	 * Validate the Create Individual link
	 * 
	 * @throws ScriptException
	 */
	public void validateCreateIndividualLinkDisplayedforQB()
			throws ScriptException {
		
		waitForTime(3);
		if (CreateIndividualCustomer.WidgetInfos.LINK_QB_CREATEINDIVIDUALCUSTOMER.exists()) {

			Verify.verifyTrue(true, MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_CLICKED);

		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_NOTFOUND);
		}
	}

	/**
	 * Click on Launch AHQB online button.
	 * 
	 * @throws ScriptException
	 */
	public void clickLaunchAHQBOnline() throws ScriptException {
		waitForPageLoad(CreateIndividualCustomer.WidgetInfos.AHQB, 20);
		if (CreateIndividualCustomer.WidgetInfos.AHQB.exists()) {
			click(CreateIndividualCustomer.WidgetInfos.AHQB,
					MessageUtility.LINK_LAUNCHAHQB);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_LAUNCHAHQB_NOTDISPLAYED);
		}
	}

	/**
	 * validate create Organization Customer link displayed
	 * 
	 * @throws ScriptException
	 */
	public void validateCreateOrganizationLinkDisplayedforQB()
			throws ScriptException {
		waitForTime(3);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGANIZATIONCUSTOMER
				.exists()) {

			Verify.verifyTrue(true,
					MessageUtility.LINK_CREATEORGANIZATION_FOUND);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_CREATEORGANIZATION_NOTFOUND);
		}
	}

	/**
	 * Validate the Connect link is not displayed for agent.
	 * 
	 * @throws ScriptException
	 */
	public void validateConnectLinkNotDisplayedforAgent()
			throws ScriptException {

		if (!CWNonAgentCSObjects.WidgetInfos.LINK_CONNECT_CLIENTS.exists()) {
			Verify.verifyTrue(true, MessageUtility.LINK_CONNECT_NOTDISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_CONNECT_DISPLAYED);
		}
	}

	/**
	 * validate the Enterprise view link not displayed for agent.
	 * 
	 * @throws ScriptException
	 */
	public void validateEnterpriseViewLinkNotDisplayedforAgent()
			throws ScriptException {
		if (!CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_ENTERPRISEVIEW_NOTDISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ENTERPRISEVIEW_DISPLAYED);
		}
	}

	/**
	 * validate the Create individual link is displayed for Agent
	 * 
	 * @throws ScriptException
	 */
	public void validateCreateIndividualLinkDisplayedforAgent()
			throws ScriptException {

		if (CreateIndividualCustomer.WidgetInfos.LINK_CREATE_INDIVIDUAL.exists()) {
			Verify.verifyTrue(true, MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_FOUND);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_NOTFOUND);
		}
	}

	/**
	 * validate the Create Organization link displayed
	 * 
	 * @throws ScriptException
	 */
	public void validateCreateOrganizationLinkDisplayedforAgent()
			throws ScriptException {

		if (CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGANIZATION.exists()) {

			Verify.verifyTrue(true,
					MessageUtility.LINK_CREATEORGANIZATION_FOUND);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_CREATEORGANIZATION_NOTFOUND);

		}
	}

	/**
	 * Click on Cancel button in Change Address Page.
	 * 
	 * @throws ScriptException
	 */

	public void clickCancelChangeAddress() throws ScriptException {
			if (AddressSO.WidgetInfos.TEXT_STREET1.exists())
			{
				Verify.verifyTrue(true,
						MessageUtility.CHANGEOFADDRESSPAGE);
				AddressSO.WidgetInfos.BUTTON_CLOSE.click();
				Verify.verifyTrue(true,
						MessageUtility.BUTTON_CLOSE);
				waitForTime(2);
				KeyboardUtility.sendKeys("{ENTER}");
				setWindow("Contact Center Online",5,2);
				waitForTime(6);
				
			} else {
				Verify.verifyTrue(false,
						MessageUtility.BUTTON_CANCEL_NOTDISPLAYED);
			}
			if (isErrorPage("Cancel in Change of Address")) {
				closeCurrentPage();
			}
	}
	
	
	
		

	/**
	 * Validate Add Individual link(through Member Actions dropdown) is
	 * displayed in HH Page
	 * 
	 * @throws ScriptException
	 */
	public void validateAddIndividuallink() throws ScriptException {
		HouseHoldTestObjects.WidgetInfos.MEMBERDRPDWN.click();
		if ((HouseHoldPageObjects.WidgetInfos.LINK_ADDINDIVIDUAL).exists()) {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ADDINDIVIDUAL_DISPLAYED);
		} else {
			Verify.verifyTrue(true,
					MessageUtility.LINK_ADDINDIVIDUAL_NOTFOUND);

		}
	}

	/**
	 * Validate Add Organization link(through Member Actions dropdown) is
	 * displayed in HH Page
	 * 
	 * @throws ScriptException
	 */
	public void validateAddOrganizationlink() throws ScriptException {
		HouseHoldTestObjects.WidgetInfos.MEMBERDRPDWN.click();
		if ((HouseHoldPageObjects.WidgetInfos.LINK_ADDORGANIZATION).exists()) {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ADDORGANIZATION_DISPLAYED);
		} else {
			Verify.verifyTrue(true,
					MessageUtility.LINK_ADDORGANIZATION_NOTFOUND);
		}
	}

	/**
	 * Click on Add individual link through Member Actions dropdown in HH Page.
	 * 
	 * @throws ScriptException
	 */
	public void clickMemberActionsAddIndPage() throws ScriptException {

		Div memberActionsDropDown = new Div("id=hhMembersTitleDropdown");
		memberActionsDropDown.click();
		Link addIndividual = new Link("id=hh_members_title_action1");
		addIndividual.click();
		waitForTime(5);
		Verify.verifyTrue(true,MessageUtility.LINK_ADDINDIVIDUAL);
	}

	/** Launch Fire Policies from the Household Info section */
	public void launchFireAppfromHHPage() {
		try {
			int divCount = 1;
			Div policies = new Div("id=gridInsurance");
			if (policies.exists()) {
			while(true)
			{		
				WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[1]/td[1]/span"));
				if (policyType.getText().equalsIgnoreCase("Fire")) {
					divCount++;
					WebElement firePolicy = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
							"div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
					if(firePolicy.isDisplayed())
					{
						firePolicy.click();
						waitForTime(10);
						Verify.verifyTrue(true,MessageUtility.FIREPOLICY_CLICKED);
						isFirePoliciesPageLaunched();
						clickHHPageCustomer();
						setTopFrame();
						break;
					}
					else
						Verify.verifyTrue(false,MessageUtility.FIREPOLICY_NOTFOUND);	
				}
			divCount++;
		}
			}
		}
		 catch (NoSuchElementException e) {
			 Verify.verifyTrue(false,"Fire policy is not found");
		}
	}

	/** Launch Health Policies from the Household Info section */
	public void launchHealthAppfromHHPage() {
		try {
			int divCount = 1;
			Div policies = new Div("id=gridInsurance");
			if (policies.exists()) {
			while(true)
			{		
				WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[1]/td[1]/span"));
				if (policyType.getText().equalsIgnoreCase("Health")) {
				divCount++;
				WebElement healthPolicy = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
				if(healthPolicy.isDisplayed())
				{
					healthPolicy.click();
					waitForTime(10);
					Verify.verifyTrue(true,MessageUtility.HEALTHPOLICY_CLICKED);
					clickHHPageCustomer();
					setTopFrame();
					break;
				}
				else
					Verify.verifyTrue(false, MessageUtility.HEALTHPOLICY_NOTFOUND);	
						
			}
			divCount++;
		}
			}
		}catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}
	}
	/**
	 * Launch Mutual Fund policy from HH page
	 */
	public void launchMutualAppfromHHPage() {

		try {
			if (isHHPageLaunched()) {
				if (HHRewriteObjects.WidgetInfos.MUTUALFUNDTAB.exists()) {
					HHRewriteObjects.WidgetInfos.MUTUALFUNDTAB.click();
					waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.MUTUALFUNDSPOLICY, 6);
					if (CWNonAgentCSObjects.WidgetInfos.MUTUALFUNDSPOLICY.exists()) {
						click(CWNonAgentCSObjects.WidgetInfos.MUTUALFUNDSPOLICY,
								MessageUtility.LINK_MUTUALFUNDSPOLICY_CLICKED);
						closeMutualAppScreen();
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.LINK_MUTUALFUNDSPOLICY_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}

	}

	/**
	 * Launch SFPP policy from HH Page.
	 */
	public void launchSFPPAppfromHHPage() {
		try {
			if (isHHPageLaunched()) {
				Div sfppPolicy = new Div(
						"id=policyTabContainer_tablist_tempSfppGrid");
				if (sfppPolicy.exists()) {
					sfppPolicy.click();
					String xpath = "//div[@id='gridSfpp']/div/div/div/div/div/div/table/tbody/tr[1]/td[2]/a";
					getWebDriverInstance().findElement(By.xpath(xpath)).click();
					Verify.verifyTrue(true, MessageUtility.SFPPPOLICY_CLICKED);
					validateSFPPPage();
					clickHHPageCustomer();
					setTopFrame();
					
				} else {
					Verify.verifyTrue(false,
							MessageUtility.SFPPPOLICY_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}
	}

	public void validateSFPPPage()
	{
		try
		{
			Link helpLink = new Link("text=help on this page");
			waitForPageLoad(helpLink,10);
			if(helpLink.exists())
				Verify.verifyTrue(true, MessageUtility.SFPPPAGE_LAUNCHED);
			else
				Verify.verifyTrue(false, MessageUtility.SFPPPAGE_NOTLAUNCHED);
			/*Button closeButton = new Button("value=Close");
			closeButton.click();
			Verify.verifyTrue(true,"Close Button in SFPP Page is clicked successfully");*/
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * Close the Life policy Screen if exists
	 */
	public void closeLifeAppScreen() {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE, 15);
		try {
			if (CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE.exists()) {
				CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE.click();
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, MessageUtility.LIFEPOLICY_NOTLAUNCHED);

		} finally {
			clickHHPageCustomer();
		}
	}

	/**
	 * Close Mutual Application screen if exists
	 * 
	 * @throws ScriptException
	 */
	public void closeMutualAppScreen() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE, 10);
		try {
			if (widgetExists(CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE)) {
				CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE.click();
			} else {
				clickHHPageCustomer();
			}
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}
	}

	/**
	 * Click on Life policy number in Household page.
	 */
	public void launchLifeAppfromProductsInactivePage() {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(new Div("id=dojox_grid__View_3"), 15);
				String customerData = null;
				String policyInformation = "";
				if (new Div("id=dojox_grid__View_3").exists()) {
					customerData = getTableXPathFromDivId("dojox_grid__View_3");
					if (customerData != null) {
						if (customerData.contains("LF-")) {
							policyInformation = customerData
									.substring(customerData.indexOf("LF-"));
							String[] lifePolicyInfo = policyInformation
									.split(" ");

							String lifePolicyNum = lifePolicyInfo[0];

							if (new Link(lifePolicyNum).exists()) {
								click(new Link(lifePolicyNum),
										MessageUtility.LIFEPOLICY_CLICKED);
								closeLifeAppScreen();
							}
						} else {
							Verify.verifyTrue(false,
									MessageUtility.LIFEPOLICY_NOTFOUND);
						}
					} else {
						Verify.verifyTrue(false,
								MessageUtility.LIFEPOLICY_NOTFOUND);
					}
				}
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}
	}

	/**
	 * Add an Employment in the Customer Info page
	 */
	public void updateEmploymentAddEmployment() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddEmployment();
				enterEmployerName();
				selectOccupation();
				selectOccupationStatus();
				selectJobTitle();
				enterAsOfDate();
				clickSaveButton();
				isErrorPage("Add Employment");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}
	}

	/**
	 * Click on Add Employment link in HH page
	 * 
	 * @throws ScriptException
	 */
	public void clickAddEmployment() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDEMPLOYMENT.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_ADDEMPLOYMENT,
					MessageUtility.LINK_ADDEMPLOYMENT);
			setIFrame();
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_ADDEMPLOYMENT_NOTFOUND);
		}
	}

	/**
	 * Enter the Employer name in the Employment page
	 * 
	 * @throws ScriptException
	 */
	public void enterEmployerName() throws ScriptException {
		if (clientE2ETO.getEmployerName() != null) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMPLOYERNAME,
					clientE2ETO.getEmployerName(),
					MessageUtility.EMPLOYERNAME_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.EMPLOYERNAME_NOTDISPLAYED);
		}
	}

	/**
	 * Select the occupation from Occupation list
	 * 
	 * @throws ScriptException
	 */
	public void selectOccupation() throws ScriptException {
		if (clientE2ETO.getOccupation() != null) {
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATION,
					clientE2ETO.getOccupation(),
					MessageUtility.OCCUPATION_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.OCCUPATION_NOTDISPLAYED);
		}
	}

	/**
	 * Select the Occupation status in the Employment page
	 * 
	 * @throws ScriptException
	 */
	public void selectOccupationStatus() throws ScriptException {
		if (clientE2ETO.getOccupationStatus() != null) {
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATIONSTATUS,
					clientE2ETO.getOccupationStatus(),
					MessageUtility.OCCUPATIONSTATUS_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.OCCUPATIONSTATUS_NOTDISPLAYED);
		}
	}

	/**
	 * Select the Job title from the Employment page
	 * 
	 * @throws ScriptException
	 */
	public void selectJobTitle() throws ScriptException {
		if (clientE2ETO.getJobTitle() != null) {
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_JOBTITLE,
					clientE2ETO.getJobTitle(),
					MessageUtility.JOBTITLE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.JOBTITLE_NOTDISPLAYED);
		}
	}

	/**
	 * Enter As of Date in the Employment page
	 * 
	 * @throws ScriptException
	 */
	public void enterAsOfDate() throws ScriptException {
		if (clientE2ETO.getEmploymentAsOfDate() != null) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_ASOFDATE_EMP,
					clientE2ETO.getEmploymentAsOfDate(),
					MessageUtility.ASOFDATE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.ASOFDATE_NOTDISPLAYED);
		}
	}

	/**
	 * Click on Change Address link in the HH Page
	 * 
	 * @throws ScriptException
	 */
	public void clickChageAddress() throws ScriptException {
		waitForPageLoad(CustomerInfoObjects.WidgetInfos.LINK_COA, 10);
		if (CustomerInfoObjects.WidgetInfos.LINK_COA.exists()) {
			click(CustomerInfoObjects.WidgetInfos.LINK_COA,
					MessageUtility.LINK_CHANGEOFADDRESS);
			setWindow("Change Address", 30, 2);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_CHANGEOFADDRESS_NOTDISPLAYED);

		}

	}

	public void removeIndUpdateName() {
		try {
			if (isCustomerInfoPageExists()) {
				String deleteAlias = clientE2ETO.getAliasFirstName() + " "
						+ clientE2ETO.getUpdateLastName();
				Link LINK_UPDATE = new Link("text=" + deleteAlias.toUpperCase());
				waitForPageLoad(LINK_UPDATE, 10);
				
				if (LINK_UPDATE.exists()) {
					List<WebElement> nameLinkTextElements = getWebDriverInstance().findElements(By.xpath("//div[@id='tempNamesGrid']//table[@class='dojoxGridRowTable']/tbody/tr/td[1]/a"));
					List<WebElement> nameLinkTextRemoveImage = getWebDriverInstance().findElements(By.xpath("//div[@id='tempNamesGrid']//table[@class='dojoxGridRowTable']/tbody/tr/td[3]/a/img"));
					for(int i=0;i<nameLinkTextElements.size();i++){
						if(nameLinkTextElements.get(i).getText().equalsIgnoreCase(deleteAlias)){
							nameLinkTextRemoveImage.get(i).click();
							waitForTime(5);
							break;
						}
					}
					clickConfirmRemoveButton();
					waitForTime(8);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.LINK_UPDATEALIAS_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}
	}

	/**
	 * Click on Confirm Remove button if exists
	 * 
	 * @throws ScriptException
	 */
	public void clickConfirmRemoveButton() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.BUTTON_REMOVEEVENTCONTINUE.exists()) {
			Update_Misc_Objects.WidgetInfos.BUTTON_REMOVEEVENTCONTINUE.click();
			Verify.verifyTrue(true,
					MessageUtility.BUTTON_REMOVE_CLICKED);
		} else
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_REMOVE_NOTDISPLAYED);
	}

	/**
	 * Add alias in the Customer info screen if Add Alias link exists
	 * 
	 * @throws ScriptException
	 */
	public void accessSecondAddAliasPageUpdate() throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_TITLE);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_TITLE.exists())
			selectFromListbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_TITLE,
					"Mr", MessageUtility.TITLE);
		else
			Verify.verifyTrue(false, MessageUtility.TITLE_NOTFOUND);

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME.exists())
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME,
					"Update Alias FirstName", MessageUtility.FIRSTNAME_VALUE);
		else
			Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME.exists())
			setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
					"Update Alias LastName", MessageUtility.LASTNAME_VALUE);
		else
			Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);

		click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
				MessageUtility.BUTTON_SAVE);

		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE, 15);

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE.exists())
			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
					MessageUtility.BUTTON_CONTINUE);
		else
			Verify.verifyTrue(false, MessageUtility.BUTTON_CONTINUE_NOTFOUND);
	}

	/**
	 * Verify whether Connect link is enabled
	 * 
	 * @return Verify whether Connect link is enabled
	 * @throws ScriptException
	 */
	public boolean isConnectLinkEnabled() throws ScriptException {

		if (CWNonAgentCSObjects.WidgetInfos.LINK_CONNECT_CLIENTS.exists()) {

			Verify.verifyTrue(true,
					MessageUtility.LINK_CONNECTCLIENTS_DISPLAYED);
			return true;
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_CONNECTCLIENTS_NOTDISPLAYED);
			return false;

		}

	}

	/**
	 * Verify whether Enterprise View link is enabled
	 * 
	 * @return Verify whether Enterprise View link is enabled
	 * @throws ScriptException
	 */
	public boolean isEnterpriseViewLinkEnabled() throws ScriptException {

		if (CWNonAgentCSObjects.WidgetInfos.LINK_CONNECTVIEWCLIENTS.exists()) {

			Verify.verifyTrue(true,
					MessageUtility.LINK_ENTERPRISEVIEW_DISPLAYED);
			return true;
		} else {

			Verify.verifyTrue(false,
					MessageUtility.LINK_ENTERPRISEVIEW_NOTDISPLAYED);
			return false;
		}

	}

	
	/**
	 * verify the Internet enabled in HH Page
	 */
	
	public void verifyInternetEnabledColumnWithYAndN() {
		try {
			
			for (int i = 1; i < 3; i = i + 1) {
				WebElement elementEnabledValue = getWebDriverInstance().findElement(By.xpath("//div[@id='gridHHMembers']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
						+ i + "]/table[@class='dojoxGridRowTable']/tbody/tr[1]/td[8]"));
				if (!elementEnabledValue.isDisplayed()) {
					break;
				}
				String InternetEnabledValue = elementEnabledValue.getText();
				if (InternetEnabledValue.contains("Y")
						|| InternetEnabledValue.contains("N")) {
					Verify.verifyTrue(true, "Internet enabled value at Row  " + i
							+ "is  " + InternetEnabledValue);
				} else {
					Verify.verifyTrue(true, MessageUtility.INTERNETENABLEDCOLUMN
							+ i);
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}



	/**
	 * verify the Customer Interest link link is available in Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void validateCustomerInterestLink() throws ScriptException {
		if (isCustomerInfoPageExists()) {
			if (!Update_Misc_Objects.WidgetInfos.LINK_ADDINTEREST.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_ADDINTEREST_NOTDISPLAYED);

			} else {
				Verify.verifyTrue(true, MessageUtility.LINK_ADDINTEREST_DISPLAYED);
			}
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * Validate the Mailing link in Customer info page
	 * 
	 * @throws ScriptException
	 */
	public void validateMaillingLink() throws ScriptException {
		if (isCustomerInfoPageExists()) {
			if (!Update_Misc_Objects.WidgetInfos.LINK_MAILING.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_MAILING_NOTDISPLAYED);

			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_MAILING_DISPLAYED);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * Validate notes link in Customer info page
	 * 
	 * @throws ScriptException
	 */
	public void validateNotesLink() throws ScriptException {
		if (isCustomerInfoPageExists()) {
			if (!Update_Misc_Objects.WidgetInfos.LINK__NO.exists()) {
				Verify.verifyTrue(false,
						MessageUtility.LINK_NOTES_NOTDISPLAYED);

			} else {
				Verify.verifyTrue(true, MessageUtility.LINK_NOTES_DISPLAYED);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * Add an Event to the Household through Customer info page
	 */
	public void lifeEventsAddEventSC1_CRC() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddEvent();
				selectEvent();
				enterlifeEventsAsofdate();
				clickSaveButton();
				isErrorPage("Add Event");
				setCRCDefaultFrame();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	public void lifeEventsAddEventSC1() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddEvent();
				selectEvent();
				enterlifeEventsAsofdate();
				clickSaveButton();
				isErrorPage("Add Event");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on Add event page
	 * 
	 * @throws ScriptException
	 */
	public void clickAddEvent() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDEVENT.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_ADDEVENT,
					MessageUtility.LINK_ADDEVENT);
			setIFrame();
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_ADDEVENT_NOTFOUND);
		}
	}

	/**
	 * Select an event from the ListBox in Customer info page.
	 * 
	 * @throws ScriptException
	 */
	public void selectEvent() throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIFEEVENT1, 20);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIFEEVENT1.exists()) {
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIFEEVENT1,
					clientE2ETO.getLifeEvent(),
					clientE2ETO.getLifeEvent()
							+ MessageUtility.LISTBOX_EVENT);
			
		} else {
			Verify.verifyTrue(false, MessageUtility.LISTBOX_EVENT_NOTFOUND);
		}
	}

	/**
	 * Enter As of Date in Life Event page.
	 * 
	 * @throws ScriptException
	 */
	public void enterlifeEventsAsofdate() throws ScriptException {
		if (clientE2ETO.getLifeEvent2AsOfDate() != null) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EVENTDATE1,
					clientE2ETO.getLifeEvent2AsOfDate(),
					MessageUtility.ASOFDATE);
		} else {
			Verify.verifyTrue(false, MessageUtility.ASOFDATE_NOTFOUND);
		}

	}

	/**
	 * Click on Products Inactive tab if it exists
	 * 
	 * @throws ScriptException
	 */
	public void clickProductsInactive() throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.PRODUCTS_INACTIVE_TAB, 10);
				if (CWNonAgentCSObjects.WidgetInfos.PRODUCTS_INACTIVE_TAB.exists()) {
					CWNonAgentCSObjects.WidgetInfos.PRODUCTS_INACTIVE_TAB.click();
					Verify.verifyTrue(true,
							MessageUtility.INACTIVEPOLICIES_CLICKED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.INACTIVEPOLICIES_NOTFOUND);
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Click on Payment/Bill History link.
	 * 
	 * @throws ScriptException
	 */
	
	public void clickPaymentBillingHistory() throws ScriptException {

		Set<String> oldHandle = getWebDriverInstance().getWindowHandles();
		clickMenuBar(HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD,
				CWNonAgentCSObjects.WidgetInfos.PAYMENT_BILLINGHISTORY);
		Verify.verifyTrue(true,
				MessageUtility.LINK_PAYMENTBILLHISTORY);
		
		waitForTime(5);
		
		Set<String> handles = getWebDriverInstance().getWindowHandles();
        handles.removeAll(oldHandle);
        Iterator<String> iterator = handles.iterator();
        while (iterator.hasNext()) {
           String paymentBill = iterator.next().toString();
           getWebDriverInstance().switchTo().window(paymentBill);
        }
		
		//setWindow("billingonlinesystem", 5, 2);
		waitForTime(5);
		Link referLink = new Link(
				"text=New business application reference # search");
		if (referLink.exists())
		{
			Verify.verifyTrue(true,
					MessageUtility.LINK_PAYMENTBILLHISTORY_LAUNCHED);
		}
		getWebDriverInstance().close();
		waitForTime(5);
		setWindow("Household Information", 5, 2);
		//setTopFramewithDefaultContent();
	}


	/**
	 * Validate the Active Customer bar
	 */
	public void validateActiveCustomerBar() {
		try {
			getWebDriverInstance().switchTo().defaultContent();
			if (HouseHoldPageObjects.WidgetInfos.ACTIVECUSTOMERBAR.exists()) {
				String activeCustomerBarText = HouseHoldPageObjects.WidgetInfos.ACTIVECUSTOMERBAR
						.getText();
				Verify.verifyTrue(true,"---------------------------------------------------------------------------");
				Verify.verifyTrue(true,activeCustomerBarText);
				Verify.verifyTrue(true,"---------------------------------------------------------------------------");
			} else if (HouseHoldPageObjects.WidgetInfos.HH_ACTIVE_CUSTOMER_BAR.exists()) {
				String activeCustomerBarText = HouseHoldPageObjects.WidgetInfos.HH_ACTIVE_CUSTOMER_BAR
						.getText();
				Verify.verifyTrue(true,"---------------------------------------------------------------------------");
				Verify.verifyTrue(true,activeCustomerBarText);
				Verify.verifyTrue(true,"---------------------------------------------------------------------------");
			} else
				Verify.verifyTrue(false,
					MessageUtility.ACTIVECUSTOMERBARNAME_NOTFOUND);
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, "Exception Occured in validateActiveCustomerBar(); "
					+ e.getMessage());
		}
	}

	/**
	 * Add Comments to the Household.
	 * 
	 * @throws ScriptException
	 */
	public void launchAddUpdateComments() throws ScriptException {
		if (HouseHoldPageObjects.WidgetInfos.TEXTFIELD_ADDUPDATECOMMENTS.exists()) {
			HouseHoldPageObjects.WidgetInfos.TEXTFIELD_ADDUPDATECOMMENTS.click();
		} else {
			Verify.verifyTrue(false, MessageUtility.COMMENTSSECTION_NOTLAUNCHED);
		}
	}

	/**
	 * Enter the Comments in textfield
	 * 
	 * @throws ScriptException
	 */
	public void accessAddUpdateComments() throws ScriptException {
		if (HouseHoldPageObjects.WidgetInfos.TEXTAREA_HHCOMMENTS_LATEST.exists()) {
			setTextInTextbox(HouseHoldPageObjects.WidgetInfos.TEXTAREA_HHCOMMENTS_LATEST,
					"ABCDEFW�Y�PTsssssssssssssssssssssssss",
					MessageUtility.COMMENTS);
		}
		if (HouseHoldPageObjects.WidgetInfos.BUTTON_HHCOMMENTSAVE_LABEL.exists()) {
			click(HouseHoldPageObjects.WidgetInfos.BUTTON_HHCOMMENTSAVE_LABEL,
					MessageUtility.BUTTON_SAVE);
		}
	}

	/**
	 * Click on Bank policy link if it exists
	 */
	public void clickBankPolicies() {
		try {
			if (isHHPageLaunched()) {
				Div bankPolicies = new Div(
						"id=policyTabContainer_tablist_tempBankGrid");
				waitForPageLoad(bankPolicies, 5);
				if (bankPolicies.exists()) {
					bankPolicies.click();
					Verify.verifyTrue(true,
							MessageUtility.BANKPOLICY_CLICKED);
				} else {
					Verify.verifyTrue(false, MessageUtility.BANKPOLICY_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, "Exception Occured in clickBankPolicies(); "
					+ e.getMessage());
		}
	}

	/**
	 * Click on Mutual Fund Policies link
	 */
	public void clickMutualFundsPolicies() {
		try {
			if (isHHPageLaunched()) {
				Div mutualFundsPolicies = new Div(
						"id=policyTabContainer_tablist_tempMutualFundGrid");
				waitForPageLoad(mutualFundsPolicies, 5);
				if (mutualFundsPolicies.exists()) {
					mutualFundsPolicies.click();
					Verify.verifyTrue(true,
							MessageUtility.MUTUALFUNDSTAB_CLICKED);
				} else {
					Verify.verifyTrue(false, MessageUtility.MUTUALFUNDSTAB_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on SFPP policies link
	 */
	public void clickSfppPolicies() {
		try {
			if (isHHPageLaunched()) {
				Div sfppPolicies = new Div(
						"id=policyTabContainer_tablist_tempSfppGrid");
				waitForPageLoad(sfppPolicies, 5);
				if (sfppPolicies.exists()) {
					sfppPolicies.click();
					Verify.verifyTrue(true,
							MessageUtility.SFPPPOLICY_CLICKED);
				} else {
					Verify.verifyTrue(false, MessageUtility.SFPPPOLICY_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, "Exception Occured in clickSfppPolicies(); "
					+ e.getMessage());
		}
	}

	/**
	 * Display the Content of Bank Policy in the HH Page
	 */
	public void displayBankPolicies() {
		try {
			if (isHHPageLaunched()) {
				Div bankPoliciesInfo = new Div("id=gridBank");
				if (bankPoliciesInfo.exists()) {
					Verify.verifyTrue(true, "Bank Policies \n");
					Verify.verifyTrue(true, bankPoliciesInfo.getText());
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Display the Content of Mutual Fund Policy in the HH Page
	 */
	public void displayMutualFundPolicies() {
		try {
			if (isHHPageLaunched()) {
				Div mutualFundsPoliciesInfo = new Div("id=gridMutualFund");
				if (mutualFundsPoliciesInfo.exists()) {
					Verify.verifyTrue(true, "Mutual Funds \n");
					Verify.verifyTrue(true, mutualFundsPoliciesInfo.getText());
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}

	/**
	 * Display the Content of SFPP Policy in the HH Page
	 */
	public void displaySfppPolicies() {
		try {
			if (isHHPageLaunched()) {
				Div sfppPoliciesInfo = new Div("id=gridSfpp");
				if (sfppPoliciesInfo.exists()) {
					Verify.verifyTrue(true, "SFPP Policies \n");
					Verify.verifyTrue(true, sfppPoliciesInfo.getText());
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/** Launch Update Personal Information */

	public void clickActionsUpdatePersonalInformation() {
		try {
			if (isHHPageLaunched()) {
				String xpath = "//div[@id='gridHHMembers']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div/table/" +
						"tbody/tr/td[2]/span/span/span";
				getWebDriverInstance().findElement(By.xpath(xpath)).click();
				WebElement itemName = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
				if(itemName.getText().contains("Update Personal Information"))
				{
					getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[1]/td[2]")).click();
					setWindow("Update Personal Information",5,2);
					Verify.verifyTrue(true, MessageUtility.UPDATEPERSONALINFO_CLICKED);
					CWNonAgentCSObjects.WidgetInfos.BUTTON_CANCEL.click();
					
				}
				else
					Verify.verifyTrue(false, MessageUtility.UPDATEPERSONALINFO_NOTDISPLAYED);
				}
			
			else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
						
			}
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION,5,2);
			setTopFramewithDefaultContent();
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Click on N hyper link(Internet Enabled) and verify whether that screen is
	 * launched
	 */
	public void clickIsInternetEnabledNOption() {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD, 10);
				Link nLink = new Link("text=N");
					if (nLink.exists()) {
						nLink.click();
					Verify.verifyTrue(true,
							MessageUtility.LINK_INTERNETENABLED);
					setWindow("User ID and Password - Registration - State Farm�", 10, 2);
					
					if (HouseHoldPageObjects.WidgetInfos.USER_ID_TEXTFIELD.exists()) {
						Verify.verifyTrue(true,
								MessageUtility.CIMSREGISTRATIONPAGE_LAUNCHED);
						getWebDriverInstance().close();
						Verify.verifyTrue(true,
								MessageUtility.CIMSREGISTRATIONPAGE_CLOSED);
						setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 5, 2);
						setTopFramewithDefaultContent();
					} else {
						Verify.verifyTrue(true,
								MessageUtility.CIMSREGISTRATIONPAGE_CLOSED);
					}
					/*waitForPageLoad(HouseHoldPageObjects.WidgetInfos.ICSSPAGE, 5);
					if (HouseHoldPageObjects.WidgetInfos.ICSSPAGE_CLOSE_BUTTON.exists()) {
						Verify.verifyTrue(true,
								MessageUtility.CIMSREGISTRATIONPAGE_LAUNCHED);
						HouseHoldPageObjects.WidgetInfos.ICSSPAGE_CLOSE_BUTTON.click();
						Verify.verifyTrue(true,
								MessageUtility.CIMSREGISTRATIONPAGE_CLOSED);
						setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 5, 2);
						setTopFramewithDefaultContent();
					} else {
						Verify.verifyTrue(true,
								MessageUtility.CIMSREGISTRATIONPAGE_CLOSED);
					}*/
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} 
	}

	/**
	 * Add the Address in Change Address Page and set the Window back to
	 * Customer Information page
	 * 
	 * @param Window
	 */
	public void addAddressChangeOfAddressABS(int Window) {
		addAddressChangeOfAddressCRC(Window);
		setWindow("Customer Information", 15, 2);
		setTopFramewithDefaultContent();
	}

	/**
	 * Add the Address in Change Address page
	 * 
	 * @param Window
	 */
	public void addAddressChangeOfAddressCRC(int Window) {
		try {
			if (AddressSO.WidgetInfos.TEXT_STREET1.exists()) {
				setTextInTextbox(AddressSO.WidgetInfos.TEXT_STREET1, clientE2ETO.getHhStreet(),
						clientE2ETO.getHhStreet() + MessageUtility.STREET_VALUE);
				setTextInTextbox(AddressSO.WidgetInfos.TEXT_CITY, clientE2ETO.getHhCity(),
						MessageUtility.CITY);
				selectFromListbox(AddressSO.WidgetInfos.LIST_STATE, clientE2ETO.getHhState(),
						MessageUtility.STATE);
				setTextInTextbox(AddressSO.WidgetInfos.TEXT_ZIP, clientE2ETO.getHhZip(),
						MessageUtility.ZIP);
				waitForPageLoad(AddressSO.WidgetInfos.BUTTON_SAVE, 5);
				if (AddressSO.WidgetInfos.BUTTON_SAVE.exists()) {
					click(AddressSO.WidgetInfos.BUTTON_SAVE,
							MessageUtility.BUTTON_SAVE);
					if (!isErrorPage("Change of Address")) {
						if (AddressSO.WidgetInfos.BUTTON_OK_ADDRESSSTANDARDIZATION.exists()) {
							click(AddressSO.WidgetInfos.BUTTON_OK_ADDRESSSTANDARDIZATION,
									MessageUtility.BUTTON_OK);
						}setWindow("Customer Expectations", 5, 2);
						if (AddressSO.WidgetInfos.BUTTON_FINISH_ADDRESSSTANDARDIZATION.exists()) {
							click(AddressSO.WidgetInfos.BUTTON_FINISH_ADDRESSSTANDARDIZATION,
									MessageUtility.BUTTON_FINISH);
						}
					} else {
						closeCurrentPage();
					}
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on View CustomerInformation Option from the Action dropdown in
	 * Household page
	 */
	public void clickActionsViewCustomerInfo() {
		try {
			if (isHHPageLaunched()) {
				String xpath = "//span[text()='Action']";
				getWebDriverInstance().findElement(By.xpath(xpath)).click();
				Image image = new Image(
						"class=dijitIcon dijitMenuItemIcon icon_ViewCustInfo");
				image.click();
				Verify.verifyTrue(true,
						MessageUtility.VIEWCUSTOMERINFO_CLICKED);
				verifyViewCustomerInfo();
			} else
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * verify whether Customer Information page is launched
	 */
	public void verifyViewCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				Verify.verifyTrue(true,
						MessageUtility.CUSTINFOPAGE_LAUNCHED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			setWindow("Household Information", 30, 10);
		}
	}

	/**
	 * Click on View CustomerInformation Option from the Action dropdown in
	 * Household page
	 */
	public void clickActionsViewCustomerInfoABS() {
		try {
			if (isHHPageLaunched()) {
				String xpath = "//div[@id='gridHHMembers']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div/table/" +
						"tbody/tr/td[2]/span/span/span";
				getWebDriverInstance().findElement(By.xpath(xpath)).click();
				WebElement itemName = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
				if(itemName.getText().contains("View Customer Information"))
				{
					getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[2]/td[2]")).click();
					Verify.verifyTrue(true, MessageUtility.VIEWCUSTOMERINFO_CLICKED);
					
				}
				else
					Verify.verifyTrue(false, MessageUtility.VIEWCUSTOMERINFO_NOTDISPLAYED);

				setWindow("Customer Information",5,2);
				getWebDriverInstance().close();
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION,5,2);
				setTopFramewithDefaultContent();
				}
			
			else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
						
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}			
	}


	/**
	 * verify whether Customer Information page is launched
	 */
	public void verifyViewCustomerInfoABS() {
		try {
			if (isCustomerInfoPageExists()) {
				Verify.verifyTrue(true,
						MessageUtility.CUSTINFOPAGE_LAUNCHED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} finally {
			setWindow("Household Information", 30, 10);
		}
	}

	/**
	 * Print the Accounts and policies from the Customer Info
	 * 
	 * @throws ScriptException
	 */
	public void printAccountsAndPolicesFromCustomerInfoPage()
			throws ScriptException {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.ACCOUNT_POLICIES,
						20);
				String AccountInfo = Update_IND_CustomerInfo_PageObjects.WidgetInfos.ACCOUNT_POLICIES
						.getText();
				Verify.verifyTrue(true,
						MessageUtility.ACCOUNTSANDPOLICIES
								+ AccountInfo);
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on Submit button after entered the Alias
	 * 
	 * @throws ScriptException
	 */
	public void clickAgentAliasSearchButton() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.BUTTON_AGENTSEARCH, 10);
		if (ABSPortalTestObjects.WidgetInfos.BUTTON_AGENTSEARCH.exists()) {
			click(ABSPortalTestObjects.WidgetInfos.BUTTON_AGENTSEARCH,
					MessageUtility.BUTTON_SEARCH);
			Verify.verifyTrue(true, MessageUtility.BUTTON_SEARCH);
		} else
			Verify.verifyTrue(true, MessageUtility.BUTTON_SEARCH_NOTFOUND);
	}

	 /**
     * verify PresentationKit Page
     * @throws ScriptException
     */
	public void verifyPresentationKitPage() throws ScriptException {

		try
		{
		waitForPageLoad(PresentationKitPopupObjects.BUTTON_VIEW, 20);
		if ((HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_HELPONTHISPAGE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_HELPONTHISPAGE_NOTDISPLAYED);
		}

		if ((PresentationKitPopupObjects.BUTTON_VIEW).exists()) {
			Verify.verifyTrue(true, MessageUtility.BUTTON_VIEW_DISPLAYED);

		} else {
					Verify.verifyTrue(false, MessageUtility.BUTTON_VIEW_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.BUTTON_CLOSE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.BUTTON_CLOSE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_CLOSE_NOTFOUND);
		}
		if ((PresentationKitPopupObjects.link_agentonlinecatalog).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_AGENTONLINE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_AGENTONLINE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.link_backroomtechnician).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_BACKROOMTECHNICIAN_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_BACKROOMTECHNICIAN_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.link_environmenturl).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_ENVIRONMENTURL_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ENVIRONMENTURL_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.link_vitalsigns).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_VITALSIGNS_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_VITALSIGNS_NOTDISPLAYED);
		}
		verifyNondisclosure();
		/**
		 * verify check boxes
		 */
		if ((PresentationKitPopupObjects.CHECKBOX_CSON).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.SELECTITEMS);

			Verify.verifyTrue(true,
					MessageUtility.CUSTOMERPROFILE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTOMERPROFILE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CSON_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.POLICYLISTINGPRINT_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.POLICYLISTINGPRINT_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CSON_2).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.HOUSEHOLDOPPORTUNITIES_DISPLAYED);

		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.HOUSEHOLDOPPORTUNITIES_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_FTON_6).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.FACTFINDERHEADER_DISPLAYED);

			Verify.verifyTrue(true,
					MessageUtility.LIFEFACTFINDER_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LIFEFACTFINDER_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_FTON_4).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.EDUCATIONSAVINGSFACTFINDER_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.EDUCATIONSAVINGSFACTFINDER_NOTDISPLAYED);
		}

		if ((PresentationKitPopupObjects.CHECKBOX_FTON_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.RETIREMENYFACTFINDER_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RETIREMENYFACTFINDER_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CGON_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CONVERSATIONGUIDESHEADER);

			Verify.verifyTrue(true,
					MessageUtility.QUICKNAQ_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.QUICKNAQ_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CGON_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.SALESCONVERSATIONMODEL_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.SALESCONVERSATIONMODEL_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CGON_5).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.PYRAMIDOFNEEDS_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.PYRAMIDOFNEEDS_NOTDISPLAYED);
		}

		if ((PresentationKitPopupObjects.checkBox_trOn_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.BACKROOMTECHNICIANREPORTSHEADER);

			Verify.verifyTrue(
					true,
					MessageUtility.CONSIDERATIONSINPURCHASEOFLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.CONSIDERATIONSINPURCHASEOFLIFEINSURANCE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.GENERALPURPOSESOFLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.GENERALPURPOSESOFLIFEINSURANCE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn_2).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.UNIVERSALLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.UNIVERSALLIFEINSURANCE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn_4).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LONGTERMCARE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LONGTERMCARE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.NEEDFORRESPONSIBLEPLANNING_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.NEEDFORRESPONSIBLEPLANNING_NOTDISPLAYED);
		}

	} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Validate the Added Organization Customer in Household page
	 */
	public void validateAddedHouseHoldMemberCustOrg() {
		try {
			if (clientE2ETO.getOrganizationName() != null
					&& CWNonAgentCSObjects.WidgetInfos.DIV_HHMEMBERSTITLE.exists()) {
				String membersSection = CWNonAgentCSObjects.WidgetInfos.DIV_HHMEMBERSTITLE
						.getText();
				if (membersSection.indexOf(clientE2ETO.getOrganizationName()) >= 0) {
					Verify.verifyTrue(true,
							MessageUtility.ORGANIZATIONMEMBER_ADDED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.ORGANIZATIONMEMBER_NOTADDED);
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Validate that the Internet Enabled column is displayed in the Household
	 * members section with its field values ('Y' & 'N')
	 */
	public boolean isInternetEnabledColumnDisplayedforHTMLHHpage() {
		boolean flag = false;
		try {
			String internetEnabled = null;
			if (CWNonAgentCSObjects.WidgetInfos.DIV_HHMEMBERSTITLE.exists()) {
				internetEnabled = CWNonAgentCSObjects.WidgetInfos.DIV_HHMEMBERSTITLE
						.getText();
				if (internetEnabled != null
						&& internetEnabled.indexOf("Internet Enabled") >= 0) {
					Verify.verifyTrue(true,
							MessageUtility.INTERNETENABLEDCOLUMN_DISPLAYED);
					flag = true;

				} else {
					Verify.verifyTrue(false,
							MessageUtility.INTERNETENABLEDCOLUMN_NOTDISPLAYED);
				}
			}

		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
		return flag;
	}

	/**
	 * Click on Action drop down in the Customer search page
	 * <p>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript.
	 * 
	 * @throws ScriptException
	 */

	public void clickActionsSearchPage() {
			
		waitForTime(4);
			WebElement actionDropDown = getWebDriverInstance().findElement(By.xpath("//div[@id='gridNode']/div/div/div/div/div/div/table/tbody/tr/td[10]/span/span"));
			if (actionDropDown.isDisplayed()) {
				actionDropDown.click();
				waitForTime(5);
			}
		}

	/**
	 * Click on New App/Quote from the Actions dropdown in the Customer Search
	 * page
	 * <p>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript.
	 * 
	 * @throws ScriptException
	 */
	
	public void clickActionsNewAppQuote() {
		try {
			
			WebElement newAppQuote = getWebDriverInstance().findElement(By.xpath(EndToEndConstants.xpath+"tr[1]/td[2]"));
			newAppQuote.click();
			Verify.verifyTrue(true, MessageUtility.LINK_NEWAPPQUOTE);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on Production Manager from the Actions dropdown in the Customer
	 * Search page
	 * <P>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript.
	 * 
	 * @throws ScriptException
	 */

	public void clickActionsProdManager() {
		try {

			WebElement productionManager = getWebDriverInstance().findElement(By.xpath(EndToEndConstants.xpath+"tr[2]/td[2]"));
			productionManager.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_PRODUCTIONMANAGER_CLICKED);

		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on Customer Profile Print from the Actions dropdown in the Customer
	 * Search page
	 * <P>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript.
	 * 
	 * @throws ScriptException
	 */

	public void clickCustomerProfilePrintFromActionsDropdown() {
		try {
			if (isHHPageLaunched()) {
				
				String xpath = "//div[@id='gridHHMembers']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div/table/" +
				"tbody/tr/td[2]/span/span/span";
		getWebDriverInstance().findElement(By.xpath(xpath)).click();
		WebElement itemName = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
		if(itemName.getText().contains("Customer Profile Print"))
		{
			getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[3]/td[2]")).click();
			setWindow("statefarm.org", 5, 2);
			Verify.verifyTrue(true, MessageUtility.CUSTOMERPROFILE_CLICKED);
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 5, 2);
			setTopFramewithDefaultContent();
			
		}
		else
			Verify.verifyTrue(false, MessageUtility.CUSTOMERPROFILE_NOTDISPLAYED);
		}
	}catch(Exception e)
		{
		}
	}

	/**
	 * Click the Customer Profile Print from Action Dropdown in Customer Search
	 * Page
	 */
	public void clickCustomerProfilePrintFromActionsDropdownInSearchPage() {
		try {
			selenium = sel.getCurrentDomain();
			if (isActionDropdownExists()) {
				String xpath = "xpath=//span[text()='Action']";
				selenium.mouseDown(xpath);
				if (isActionDropdownExists()) {
					String custProfPrint = "css=table#dijit_Menu_0>tbody>tr:nth-child(3)";
					selenium.click(custProfPrint);
					validateCustomerProfilePrint(3);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 5, 2);
		}
	}

	/**
	 * Click on Activitity List from the Actions dropdown in the Customer Search
	 * page
	 * <P>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * @throws ScriptException
	 */

	public void clickActionsActivitityList() {
		try {

			WebElement activityList = getWebDriverInstance().findElement(By.xpath(EndToEndConstants.xpath+"tr[5]/td[2]"));
			activityList.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_ACTIVITYLIST);

		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on Create Follow Up from the Actions dropdown in the Customer
	 * Search page..
	 * <P>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * @throws ScriptException
	 */

	public void clickActionsCreateFollowUp() {
		try {

			WebElement createFollowUp = getWebDriverInstance().findElement(By.xpath(EndToEndConstants.xpath+"tr[6]/td[2]"));
			createFollowUp.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_CREATEFOLLOWUP);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on Create Note Up from the Actions dropdown in the Customer Search
	 * page..
	 * <P>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * @throws ScriptException
	 */

	public void clickActionsCreateNote() {
			try {
				WebElement createNote = getWebDriverInstance().findElement(By.xpath(EndToEndConstants.xpath+"tr[7]/td[2]"));
				createNote.click();
				Verify.verifyTrue(true, MessageUtility.LINK_CREATENOTE);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}

	/**
	 * Click on Direct Mail History Up from the Actions dropdown in the Customer
	 * Search page..
	 * <P>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript.
	 * 
	 * @throws ScriptException
	 */

	public void clickActionsDirectMailHistory() {
		try {
			WebElement directMail = getWebDriverInstance().findElement(By.xpath(EndToEndConstants.xpath+"tr[9]/td[2]"));
			directMail.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_DIRECTMAIL);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
//Need to Modify
	/**
	 * Click on Marketing Oppurtunities Up from the Actions dropdown in the
	 * Customer Search page..
	 * <p>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * @throws ScriptException
	 */
	public void clickActionsMarketingOppurtunities() {
		try {
			WebElement marketingOpportunities = getWebDriverInstance().findElement(By.xpath(EndToEndConstants.xpath+"tr[10]/td[2]"));
			marketingOpportunities.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_MARKETINGOPPORTUNITIES);

		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}


	/**
	 * Click on MR Icon in the HH Page
	 * 
	 * @throws Exception
	 */
	public void clickMRIcon() throws Exception {
		try {
			Span span = new Span("class=icon_MasterRecord");
			if (span.exists()) {
				span.click();
			} else {
				Verify.verifyTrue(false, MessageUtility.MRICON_NOTFOUND);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Update the alias in the Customer info page
	 */
	public void selectNameVersionAndUpdate() {
		try {
			String alias = clientE2ETO.getAliasFirstName() + " "
					+ clientE2ETO.getAliasLastName();
			Link LINK_UPDATE = new Link("text=" + alias.toUpperCase());
			waitForPageLoad(LINK_UPDATE, 10);
			if (LINK_UPDATE.exists()) {
				click(LINK_UPDATE, MessageUtility.LINK_UPDATENAME);
			}
			setIFrame();
			waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
					10);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME.exists()
					&& clientE2ETO.getUpdateLastName() != null) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
						clientE2ETO.getUpdateLastName(),
						clientE2ETO.getUpdateLastName() + " Lastname");
				if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.exists()) {
					click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
							MessageUtility.BUTTON_SAVE);
				}
				waitForPageLoad(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE, 3);
				if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE)
						.exists()) {
					click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
							MessageUtility.BUTTON_CONTINUE);
				}
				isErrorPage("Update Alias");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_UPDATEALIAS_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * verify the Add address link is not displayed for QB
	 * 
	 * @throws ScriptException
	 */
	public void validateAddAddressLinkNotDisplayedForQB()
	throws ScriptException {
		setCRCDefaultFrame();
		if (isCustomerInfoPageExists()) {
			if (!Update_Misc_Objects.WidgetInfos.LINK_ADDADDRESS.exists()) {
				Verify.verifyTrue(true,
					MessageUtility.LINK_ADDADDRESS_NOTDISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_ADDADDRESS_DISPLAYED);
			}
		} else {
			Verify.verifyTrue(false,
				MessageUtility.CUSTINFOPAGE_LAUNCHED);
}
}

	/**
	 * verify whether the Update link is displayed in Customer info page
	 * 
	 * @throws Exception
	 */
	public void validatePersonalInfoUpdateBtnDisplayed() throws Exception {
		try {
		Link update_link = new Link("text=Update");
			if (update_link.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_UPDATE_DISPLAYED);
			}
			Verify.verifyTrue(true,
					MessageUtility.LINK_UPDATE_NOTDISPLAYED);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter the Agent alias
	 * 
	 * @throws ScriptException
	 */
	public void enterAgentAlias() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_AGENTALIAS, 15);
		if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_AGENTALIAS.exists()) {
			enterMandatoryfieldtoEnablebutton(
					ABSPortalTestObjects.WidgetInfos.TEXTFIELD_AGENTALIAS,
					clientE2ETO.getAgentAlias());
		}
	}
		
			
	public void enterCanadaAgentAlias() throws ScriptException {
				waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_AGENTALIAS, 15);
				if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_AGENTALIAS.exists()) {
					enterMandatoryfieldtoEnablebutton(
							ABSPortalTestObjects.WidgetInfos.TEXTFIELD_AGENTALIAS,
							clientE2ETO.getAgentAlias1());

		} else
			Verify.verifyTrue(false, MessageUtility.AGENTALIAS);
	}

	/** Navigate back to Customer Search */
	public void clickCRCOnlineTabtoNavigatetoSearchPagefromHHpage()
	throws ScriptException {
		getWebDriverInstance().switchTo().defaultContent();
		getWebDriverInstance().switchTo().frame("TopFrame");
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.CUSTOMERSEARCHPAGEFROMHHPAGE, 20);
		if (CWNonAgentCSObjects.WidgetInfos.CUSTOMERSEARCHPAGEFROMHHPAGE.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.CUSTOMERSEARCHPAGEFROMHHPAGE,
			MessageUtility.CRCTAB_CLICKED);
		getWebDriverInstance().switchTo().defaultContent();
		setCRCTopFrame();
} else {
	Verify.verifyTrue(false, MessageUtility.CRCTAB_NOTLAUCNHED);
}
if (isABSCustomerSearchPageExist()) {
	Verify.verifyTrue(true, MessageUtility.CUSTOMERSEARCHPAGE);
} else {
	Verify.verifyTrue(false, MessageUtility.CUSTOMERSEARCHPAGE_NOTLAUNCHED);
}
}
	

	public void clickCRCOnlineTabtoNavigatetoSearchPagefromHHpageCRC()
				throws ScriptException {
			setCRCFrame();
			waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.CUSTOMERSEARCHPAGEFROMHHPAGE, 20);
			if (CWNonAgentCSObjects.WidgetInfos.CUSTOMERSEARCHPAGEFROMHHPAGE.exists()) {
				click(CWNonAgentCSObjects.WidgetInfos.CUSTOMERSEARCHPAGEFROMHHPAGE,
						MessageUtility.CRCTAB_CLICKED);
			} else {
				Verify.verifyTrue(false, MessageUtility.CRCTAB_NOTLAUCNHED);
			}
			if (isABSCustomerSearchPageExist()) {
				Verify.verifyTrue(true, MessageUtility.CUSTOMERSEARCHPAGE);
			} else {
				Verify.verifyTrue(false, MessageUtility.CUSTOMERSEARCHPAGE_NOTLAUNCHED);
			}
		}

	/**
	 * Click on Member Actions Add Organization link
	 * 
	 * @throws ScriptException
	 */
	public void clickMemberActionsAddOrgPage() throws ScriptException {
		Div memberActionsDropDown = new Div("id=hhMembersTitleDropdown");
		memberActionsDropDown.click();
		Link addOrganization = new Link("id=hh_members_title_action2");
		addOrganization.click();
		Verify.verifyTrue(true, MessageUtility.LINK_ADDORGANIZATION_CLICKED);
	}

	/**
	 * Verify the Internet enabled column is displayed with its Y and N values
	 */
	public void verifyInternetEnabledColumnWithN() {
		try {
			if (isHHPageLaunched()) {
				int i = 1;
				while (true) {
					try {
						WebElement elementInternetEnabled = getWebDriverInstance().findElement(By.xpath("//div[@id='gridHHMembers']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
								+ i+ "]/table[@class='dojoxGridRowTable']/tbody/tr[1]/td[7]"));
						String InternetEnabledValue = elementInternetEnabled.getText();
						if (InternetEnabledValue.contains("N")) {
							Verify.verifyTrue(true,
									"Internet enabled value at Row  " + i 
											+ "is  " + InternetEnabledValue);
						}
						if (InternetEnabledValue.isEmpty()) {
							WebElement elementInternetEnabled1 = getWebDriverInstance().findElement(By.xpath("//div[@id='gridHHMembers']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
									+ i + "']/table[@class='dojoxGridRowTable']/tbody/tr[1]/td[4]"));
							String InternetEnabledValue1 = elementInternetEnabled1.getText();
							if (InternetEnabledValue1.isEmpty())
								Verify.verifyTrue(
										true,
										MessageUtility.INTERNETENABLEDCOLUMN_FIELDVALUESDISPLAYED);
							else
								Verify.verifyTrue(
										false,
										MessageUtility.INTERNETENABLEDCOLUMN_FIELDVALUESNOTDISPLAYED);

						}
						i++;

					} catch (Exception e) {
						break;

					}
				}
			} else
				Verify.verifyTrue(
						false,
						"Cannot proceed with Internet Enabled Column With N as Household page is not launched");
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Add Comments to Household
	 */
	public void validateCommentsSectionfromHHPage() {
		try {
			if (isHHPageLaunched()) {
				launchAddUpdateComments();
				accessAddUpdateComments();
				refreshHHPage();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Launch New App/Quote From Action Dropdown in Customer SearchPage
	 */
	public void launchNewAppQuoteFromActionDropdownSearchPage() {
		try {
				clickActionsSearchPage();
				clickActionsNewAppQuote();
				waitForTime(4);
				setWindow(EndToEndConstants.PRODUCT_SELECTION, 5, 2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 3, 2);
			} 
		catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Launch Production Manager From Action Dropdown in Customer SearchPage
	 */

	public void launchProductionManagerFromActionDropdownSearchPage() {
		try {
				clickActionsSearchPage();
				clickActionsProdManager();
				waitForTime(4);
				setWindow(EndToEndConstants.PRODUCTION_MANAGER, 5, 2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 3, 2);
			
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	
	public void launchCustomerProfilePrintFromActionDropdownSearchPage() {
		try {
				clickActionsSearchPage();
				clickActionsCustomerProfilePrint();
				waitForTime(4);
				/*setWindow(EndToEndConstants.PRODUCTION_MANAGER, 5, 2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 5, 2);*/
			
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	public void clickActionsCustomerProfilePrint() {

		try {

		WebElement customerProfilePrint = getWebDriverInstance().findElement(By.xpath(EndToEndConstants.xpath+"tr[3]/td[2]"));

		customerProfilePrint.click();

		Verify.verifyTrue(true,

		MessageUtility.CUSTOMERPROFILE_CLICKED);

		} catch (Exception e) {

		Verify.verifyTrue(false, e.getMessage());

		}

		}

	/**
	 * Launch New Activity From Action Dropdown in Customer SearchPage
	 */
	public void launchNewActivityFromActionDropdownSearchPage() {
		try {
				clickActionsSearchPage();
				clickActionsActivitityList();
				waitForTime(4);
				setWindow(EndToEndConstants.ACTIVITY_LIST, 5, 2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 3, 2);
			
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Launch Create FollowUp From Action Dropdown in Customer SearchPage
	 */
	public void launchNewCreateFollowUpFromActionDropdownSearchPage() {
		try {
				clickActionsSearchPage();
				clickActionsCreateFollowUp();
				waitForTime(4);
				setWindow(EndToEndConstants.CREATE_FOLLOW_UP, 5, 2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 3, 2);
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Launch Create Note From Action Dropdown in Customer SearchPage
	 */

	public void launchNewCreateNoteFromActionDropdownSearchPage() {
			try {
					clickActionsSearchPage();
					clickActionsCreateNote();
					waitForTime(4);
					setWindow(EndToEndConstants.CREATE_NOTE, 5, 2);
					getWebDriverInstance().close();
					waitForTime(2);
					setWindow(EndToEndConstants.CUSTOMER_SEARCH, 3, 2);
				
			} catch (ScriptException scriptException) {
				scriptError(scriptException);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}

	/**
	 * Launch Direct Mail History From Action Dropdown in Customer SearchPage
	 */
	public void launchDirectMailHistoryFromActionDropdownSearchPage() {
		try {
				clickActionsSearchPage();
				clickActionsDirectMailHistory();
				waitForTime(4);
				setWindow(clientE2ETO.getCustomerOneData().toUpperCase()+"  - ", 5, 2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 3, 2);
			
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Launch Marketing Opportunities History From Action Dropdown in Customer
	 * SearchPage
	 */

	public void launchMktngOpprFromActionDropdownSearchPage() {
			try {
				clickActionsSearchPage();
				clickActionsMarketingOppurtunities();
				waitForTime(4);
				/*setWindow(EndToEndConstants.DIRECT_MAIL, 5, 2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 3, 2);*/
			} catch (ScriptException scriptException) {
				scriptError(scriptException);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}

	/**
	 * verify whether Action dropdown is exists
	 */
	public boolean isActionDropdownExists() throws ScriptException {
		waitForPageLoad(CustomerSeparateAppObj.WidgetInfos.ACTION_DROPDOWN, 15);
		if (CustomerSeparateAppObj.WidgetInfos.ACTION_DROPDOWN.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Add Household comments
	 */
	public void validateCommentsSectionHHPage() {
		try {
			if (isHHPageLaunched()) {
				launchAddUpdateComments();
				accessAddUpdateComments();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Validate Create Individual Customer & Create Organization Customer link
	 * Exists in Customer Search page. Validate Enterprise connect & Enterprise
	 * View link does not Exists in Customer Search page.
	 */

	public void verifyCreateIndOrgConnectEnterpriseviewLinksExists() {
		try {
			setCRCTopFrame();
			clickNameRadioButtonSearchPage();
			if (isABSCustomerSearchPageExist()) {
				validateCreateIndividualLinkDisplayedforQB();
				validateCreateOrganizationLinkDisplayedforQB();
				validateConnectLinkNotDisplayedforAgent();
				validateEnterpriseViewLinkNotDisplayedforAgent();
				waitForTime(6);
				setWindow("Customer Search", 5, 2);
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Click on AHQB Online logo
	 * 
	 * @throws ScriptException
	 */
	
	public void clickAHQBOnlineLogo() throws ScriptException {
		getWebDriverInstance().switchTo().defaultContent();
		getWebDriverInstance().switchTo().frame("TopFrame");
		waitForPageLoad(HouseHoldPageObjects.WidgetInfos.AHQBLOGO, 30);
		if (HouseHoldPageObjects.WidgetInfos.AHQBLOGO.exists()) {
			HouseHoldPageObjects.WidgetInfos.AHQBLOGO.click();
			waitForTime(5);
			KeyboardUtility.sendKeys("{ENTER}");
			Verify.verifyTrue(true, MessageUtility.AHQBLOGO_CLICKED);
		} else {
			Verify.verifyTrue(false, MessageUtility.AHQBLOGO_NOTDISPLAYED);
		}
		getWebDriverInstance().switchTo().defaultContent();
		setCRCTopFrame();
	}

	/**
	 * Validate the Create Individual,Organization,Connect and EnterpriseView
	 * link are displayed in Customer Search page
	 */
	public void validateLinksDisplayedInCustSearchPage() {
		try {
			if (isCustomerSearchPageExistsABS()) {
				validateCreateIndividualLinkDisplayedforQB();
				validateCreateOrganizationLinkDisplayedforQB();
				//isConnectLinkEnabled();
				isEnterpriseViewLinkEnabled();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on the Change Address hyper link next to the Add address link in
	 * the Address section and Add an Address and click SAVE
	 */
	public void launchAndAddAddressInCOA() {
		try {
			if (isCustomerInfoPageExists()) {
				clickChageAddress();
				addAddressChangeOfAddressABS(2);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on the Change Address hyper link next to the Add address link in
	 * the Address section and click on Cancel
	 */
	public void launchAndCancelInCOA() throws ScriptException {
		try {
			if (isCustomerInfoPageExists()) {
				clickChageAddress();
				clickCancelChangeAddress();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Add an individual to the Household through member actions page
	 */
	public void addIndividualinHouseholdPage() {
		try {
			if (isHHPageLaunched()) {
				clickMemberActionsAddIndPage();
				setWindow(EndToEndConstants.ADDMEMBERS,5,2);
				addIndividual();
				waitForTime(3);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
		setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 5, 2);
	}	
	

	/** Add an Organization */
	public void addOrganizationinHouseholdPage() {
		try {
			if (isHHPageLaunched()) {
				clickMemberActionsAddOrgPage();
				setWindow(EndToEndConstants.ADDMEMBERS, 30, 2);
				waitForTime(3);
				selectHHAddOrganization(0);
				setHHAddMemberDataOrganization();
				selectAddAddress();
				clickAddOrgCreateMember();
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 30, 2);
				setTopFramewithDefaultContent();
				refreshHHPage_SW();
				verifyHouseholdPageLaunched();
				
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/** Add an Organization With Tin */
	public void addOrganizationWithTininHouseholdPage() {
		try {
			if (isHHPageLaunched()) {
				clickMemberActionsAddOrgPage();
				setWindow(EndToEndConstants.ADDMEMBERS, 30, 2);
				selectHHOrganizationType(0);
				setHHAddMemberDataOrganization();
				selectAddAddress();
				addTinInAddOrgPage();
				clickCreateMember();
				clickContinueButtonIfExists();
				if (isErrorPage(EndToEndConstants.ADDMEMBERS)) {
					closeCurrentPage();
				}
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 30, 2);
				verifyHouseholdPageLaunched();
				refreshHHPage();
				handleCimsVersion();
				verifyAddedIndOrgCustomerInHHPage(clientE2ETO
						.getHhOrganizationName());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/** Add an Organization */
	public void addOrganizationinHouseholdPageForAHQB() {
		try {
			if (isHHPageLaunched()) {
				clickMemberActionsAddOrgPage();
				selectHHOrganizationType(0);
				setHHAddMemberDataOrganization();
				selectAddAddress();
				clickCreateMember();
				clickContinueButtonIfExists();
				verifyHouseholdPageLaunched();
				verifyAddedIndOrgCustomerInHHPage(clientE2ETO
						.getHhOrganizationName());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Verify the Create Individual/Organization links are displayed in
	 * Household page
	 */
	public void verifyCreateIndOrg() {
		try {
			if (isPortalSearchPageExist()) {
				validateCreateIndividualLinkDisplayedforAgent();
				validateCreateOrganizationLinkDisplayedforAgent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTSEARCH_PORTAL_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Verify the Create Individual/Organization links are displayed and
	 * ConnectLink,EnterpriseViewLink are not displayed in the Customer search
	 * page
	 */
	public void verifyCreateIndOrgConnectEnterpriseviewLinksPresent() {
		try {
			if (isPortalSearchPageExist()) {
				verifyCreateIndOrg();
				validateConnectLinkNotDisplayedforAgent();
				validateEnterpriseViewLinkNotDisplayedforAgent();
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTSEARCH_PORTAL_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter the US agent alias and click on Search button
	 */
	public void enterAgentAliasinCustomerSearchPage() {
		try {
			if (isAgentBusinessSystemExist()) {
				enterAgentAlias();
				clickAgentAliasSearchButton();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	
	/**
	 * Enter the Canada agent alias and click on Search button
	 */
	public void enterCanadaAgentAliasinCustomerSearchPage() {
		try {
			if (isAgentBusinessSystemExist()) {
				enterCanadaAgentAlias();
				clickAgentAliasSearchButton();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/** Launch CRC Update Personal Information */
	public void clickCRCActionsUpdatePersonalInformation() {
		try {
			if (isHHPageLaunched()) {
				String xpath = "//div[@id='tempHHMembersGrid']//span[@role='button']";
				String xpath1 = "//table[@id='dijit_Menu_0']/tbody/tr[2]/td/img";
				if (getWebDriverInstance().findElement(By.xpath(xpath)).isDisplayed()) {
					getWebDriverInstance().findElement(By.xpath(xpath)).click();
					waitForTime(2);
					getWebDriverInstance().findElement(By.xpath(xpath1)).click();
					Verify.verifyTrue(true,
							MessageUtility.LINK_UPDATEPERSONALINFO);
					waitForTime(5);
					waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.BUTTON_CANCEL, 10);
					if (CWNonAgentCSObjects.WidgetInfos.BUTTON_CANCEL.exists()) {
						click(CWNonAgentCSObjects.WidgetInfos.BUTTON_CANCEL,
								MessageUtility.BUTTON_CANCEL);

					}
					setCRCDefaultFrame();
				}
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on the Change Address hyper link next to the Add address link in
	 * the Address section and Add an Address and click SAVE for CRC Role
	 */
	public void launchCRCAddAddressInCOA() {
		try {
			if (isCustomerInfoPageExists()) {
				clickChageAddress();
				addAddressChangeOfAddressCRC(2);
				setWindow(EndToEndConstants.CUSTOMER_INFORMATION, 5, 2);
				setCRCDefaultFrame();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * validate Add Individual,Add Organization link displayed in the search
	 * page for CRC
	 */
	public void validateAddIndAndAddOrgLinksInHHPageCRC() {
		try {
			if (isHHPageLaunched()) {
				validateAddIndividuallink();
				validateAddIndividuallink();
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Add the TIN number in Add Organization page
	 * 
	 * @throws ScriptException
	 */
	public void addTinInAddOrgPage() throws ScriptException {
		try {
			waitForPageLoad(CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_SSN, 5);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_SSN.exists()) {
				setTextInTextbox(CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_SSN,
						clientE2ETO.getTaxIdNumber(),
						MessageUtility.TIN);
			} else {
				Verify.verifyTrue(false, MessageUtility.TIN_NOTFOUND);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Click on the Life policy number link from the Household page
	 * 
	 * @throws ScriptException
	 */
	public void launchLifeAppfromHHPage() throws ScriptException {
		String productType = null;
		int c = 1;
		while (true) {
			try {
				
				WebElement elementProdutType = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
						+ c
						+ "]/table[@class='dojoxGridRowTable']/tbody/tr[1]/td[1]"));
				productType = elementProdutType.getText(); 
				if (productType.equals("Life")) {
					c++;
					WebElement elementPolicyNumber = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='dojox_grid__View_1']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
							+ c
							+ "]/table[@class='dojoxGridRowTable']/tbody/tr[2]/td[3]/a"));
					elementPolicyNumber.click();
					Verify.verifyTrue(true, MessageUtility.LIFEPOLICY_CLICKED);

				}
				c++;
			} catch (Exception e) {

				break;
			}
		}
	}

	/**
	 * Launch the Life policy from the Household page.
	 * 
	 * @throws ScriptException
	 */
	public void launchLifePolicyfromHHPage() throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				launchLifeAppfromHHPage();

				if (verifyLifePolicyPage()) {
					closeLifeAppScreen();
				} else {
					Verify.verifyTrue(false, MessageUtility.LIFEPOLICY_NOTFOUND);
					clickHHPageCustomer();
				}
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Verify whether life policy page is launched.
	 * 
	 * @return returns true if the Life policy launched
	 * @throws ScriptException
	 */
	public boolean verifyLifePolicyPage() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.LIFE_POLICY_VIEW, 45);
		if (CWNonAgentCSObjects.WidgetInfos.LIFE_POLICY_VIEW.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Validate Policy Listing Print Page
	 * 
	 * @throws ScriptException
	 */
	public void validatePolicyListingPrintPortal() throws ScriptException {
		setWindow("Crystal Reports Viewer", 30, 2);
		if (HouseHoldTestObjects.WidgetInfos.POLICYLISTINGPRINT.exists()) {

			Verify.verifyTrue(true,
					MessageUtility.POLICYLISTINGPRINT_LAUNCHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.POLICYLISTINGPRINT_NOTLAUNCHED);

		}
	}

	/**
	 * Click on Policy Listing Page link from Household menu
	 * 
	 * @throws ScriptException
	 */
	public void validatePolicyListingPrintInHHpage() throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HHRewriteObjects.WidgetInfos.HHHOUSEHOLDTAB, HHRewriteObjects.WidgetInfos.HHHOUSEHOLDTAB_POLICYLISTING);
				validatePolicyListingPrintPortal();
				setWindow("Household Information", 30, 2);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Launch HH From CRC AHQB Customer Search page
	 */

public void launchHHPageFromCRCAHQBCustSearchPage() {
	try {
		clickNameRadioButtonSearchPage();
		if (isABSCustomerSearchPageExist()) {
			clickClearButtonSearchPage();
			clickIndividualRadioButtonSearchPage();
			enterLastNameSearchPage();
			enterFirstNameSearchPage();
			enterZipSearchPage();
			clickSearchButtonSeachPage();
			waitForTime(3);
			launchAHQBHHPage();
		} else {
			Verify.verifyTrue(false,
					MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
		}
	} catch (ScriptException e) {
		scriptError(e);
	}
}

/** Launch AHQB Update Personal Information */
public void clickAHQBActionsUpdatePersonalInformation() {
	try {
		if (isHHPageLaunched()) {
			String xpath = "//div[@id='tempHHMembersGrid']//span[@role='button']";
			String xpath1 = "//table[@id='dijit_Menu_0']/tbody/tr[2]/td/img";
			if (getWebDriverInstance().findElement(By.xpath(xpath)).isDisplayed()) {
				//getWebDriverInstance().findElement(By.xpath(xpath)).click();
				waitForTime(2);
				getWebDriverInstance().findElement(By.xpath(xpath1)).click();
				Verify.verifyTrue(true,
						MessageUtility.LINK_UPDATEPERSONALINFO);
				waitForTime(5);
				waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.BUTTON_CANCEL, 10);
				if (CWNonAgentCSObjects.WidgetInfos.BUTTON_CANCEL.exists()) {
					click(CWNonAgentCSObjects.WidgetInfos.BUTTON_CANCEL,
							MessageUtility.BUTTON_CANCEL);
					waitForTime(4);
					click(CWNonAgentCSObjects.WidgetInfos.BUTTON_CANCEL_WITH_PROCEED,
							MessageUtility.BUTTON_CANCELWITHPROCEED);
					waitForTime(4);
				}else{
					System.out.println("not navigated to add member screen");
				}
				setCRCDefaultFrame();
			}
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		}
	} catch (ScriptException scriptException) {
		scriptError(scriptException);
	} catch (Exception e) {
		Verify.verifyTrue(false, e.getMessage());
	}
}
}