package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class SupportWrite_Ind_Sear_Scenario4 extends BaseScript {
	String query = "select * from SupportWrite_Ind_Sear_Scenario4";
	public void executeScript(){
		
		createCustTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		createCustTasks.setCustomerSearchTopFrame();
				
		//  CMP Day 1 Scenario's
 		
	/*	*//**US Scenario 1 *//*
		scenarioTasks.usNonAgentCannotMimicCanadianAgent();
		
		*//**US Scenario 4 *//*
		createCustTasks.usNonAgentNotAbleToSearchOnCanadianBob();
		
		*//**US Scenario 5 *//*
		createCustTasks.usNonAgentNotAbleToSearchOnCanadianPolicy();
		
		*//**US Scenario 6 *//*
		createCustTasks.unabletoSearchCanadaUserWithUsNonAgent();
		
		*//**US Scenario 7 *//*
		createCustTasks.unabletoSearchCanadaphoneWithUsNonAgent();
		
		*//**US Scenario 8 *//*
		createCustTasks.canadaNonAgentUnableToCreateUSCustomers();
		
		*//**US Scenario 9 *//*
		createCustTasks.usNonAgentUnableToCreateCanadaCustomers();*/
		
		/**customer search*/
		productTasks.launchHHPageFromCustomerSearchPage();
		/**Verifying Accounts/Policies with Others*/
		productTasks.verifyAccountsPoliciesWithOthers();
		productTasks.setTopFramewithDefaultContent();
		/**Creating Auto,Bank Policy with Others*/
		productTasks.createAutoBankPolicesWithOthers();
		productTasks.setTopFramewithDefaultContent();
		/**Validate count of Auto and Bank Policy with Others*/
		productTasks.verifyCreatedAutoBankPolicies();
		/**Launching,Verifying and updating Auto Policy*/
		productTasks.updateAutoPoliciesWithOthers();
		/**Removing the Bank Policy*/
		productTasks.removeBankPoliciesWithOthers();
		/**Add New Individual*/
		createCustTasks.addAndVerifyIndCustFromMemberActions();
		/**Remove From Book*/
		removeFromBookTasks.validateRemoveFromBookPageLaunhed();
		/**Verify Active customer cannot be deleted via Remove From Book*/
		removeFromBookTasks.validateActiveCustomerRemoval();
		/**Validate Comments section*/
		scenarioTasks.validateCommentsSectionHHPage();
		/**Validate the Household Menu in the Household Page *//*
		*//**Launch and Validate Loss History*/
		
		// Modification 1
		updateTasks.launchAndValidateLossHistory();
		scenarioTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		/**Launch and Validate Policy Listing Print*/
		updateTasks.launchAndVerifyPolicyListingPrintPage();
		/**Launch and Validate Claim Status*/
		updateTasks.launchAndValidateClaimStatus();
		scenarioTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		/**Validate New App/Quote*/
		updateTasks.launchAndverifyNewAppQuotePage();
		scenarioTasks.handleCimsVersion();
		/**Validate New SFPP*/
		updateTasks.launchAndVerifyNewSFPPPage();
		scenarioTasks.handleCimsVersion();
		/**Launch and Validate Production Manager*/
		updateTasks.launchAndVerifyProdManager();
		scenarioTasks.handleCimsVersion();
		/**Validate the Activities Menu in the Household Page*//*
		*//**Launch and Verify Activity List*/
		updateTasks.launchAndVerifyActivityList();
		scenarioTasks.handleCimsVersion();
		/**Launch and Verify Create Follow up*/
		updateTasks.launchAndVerifyCreateFollowUp();
		scenarioTasks.handleCimsVersion();
		/**Launch and Verify Create Note*/
		updateTasks.launchAndVerifyCreateNote();
		scenarioTasks.handleCimsVersion();
		/**Launch and Validate SMP from the Activities.*/
		updateTasks.launchAndVerifySMP();
		scenarioTasks.handleCimsVersion();
		/** Validate the Marketing Menu in the Household Page*/
		updateTasks.launchAndVerifyIFRTools();
		scenarioTasks.handleCimsVersion();
		/**Launch and validate Action Plan*/
		updateTasks.launchAndVerifyActionPlan();
		scenarioTasks.handleCimsVersion();
		/**Launch and Verify NAQs*/
		updateTasks.launchAndVerifyNAQs();
		scenarioTasks.handleCimsVersion();
		/**Launch and Verify SMP from the Marketing menu*/
		updateTasks.launchAndVerifySMPFromMarketing();
		scenarioTasks.handleCimsVersion();
		/**Launch and Verify Marketing Opportunities.*/
		updateTasks.launchAndVerifyMarketingOpportunities();
		scenarioTasks.handleCimsVersion();
		/**Launch and Validate Direct Mail.*/
		updateTasks.launchAndVerifyDirectMail();
		scenarioTasks.handleCimsVersion();
		/**Validate the Assigned Staff�s link in the HH page */
		productTasks.verifyAssignedStaffLinkInHHPage();
		/**Validate the Production Manager link in the HH page */
		productTasks.launchAndVerifyProductionManagerLinkInHHPage();
		scenarioTasks.handleCimsVersion();
		/**Verifying Previous Review Date functionality*/
		productTasks.verifyPreviousReviewDateFunctionality();
		productTasks.setTopFramewithDefaultContent();
		productTasks.refreshHHPage_SW();
		/**Verifying Next Review Date functionality*/
		productTasks.verifyNextReviewDateFunctionality();
		productTasks.setTopFramewithDefaultContent();
		productTasks.refreshHHPage_SW();
		/**Launch and Verify Help On This Page*/
		productTasks.clickAddAccPoliciesWithOthersLink();
		productTasks.setWindow("Add Accounts/Policies With Others", 5, 2);
		productTasks.launchHelpOnthisPage_Household();
		productTasks.validateHelpOnthisPageInAddProductsWithOthers();
		/**Launch Presentation kit page*/
		productTasks.verifyPresentationKit();
	}

	public void scriptMain() {
		try {
				transferObject = setTestDataObject(transferObject);
				transferObject.setDbQuery(query);
				dbresultSet = databaseUtil.getCoreData(transferObject);
				while (dbresultSet.next()) {
					clientE2ETO = databaseUtil.loadTestDataSupportWrite_Ind_Sear_Scenario4(
									dbresultSet, clientE2ETO);
					productTasks = new ProductTasks(clientE2ETO);
					scenarioTasks = new ScenarioTasks(clientE2ETO);
					removeFromBookTasks = new RemoveFromBookTasks(clientE2ETO);
					createCustTasks = new CreateCustomersTasks(clientE2ETO);
					separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
					hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
					hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
					updateTasks = new UpdateCustomersTasks(clientE2ETO);
					launcher = new LaunchApplication(getWATConfig());
					launcher.launchUser(this.getClass().getSimpleName());
					productTasks.createResultsFile(resultsFileName(),
							scriptName());
					executeScript();
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
