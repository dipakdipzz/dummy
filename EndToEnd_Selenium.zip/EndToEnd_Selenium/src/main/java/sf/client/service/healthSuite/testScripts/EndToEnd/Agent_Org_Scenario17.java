package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class Agent_Org_Scenario17 extends BaseScript {
	int count = 0;
	String query = "select * from Agent_Org_Scenario17";

	public void executeScript() throws Exception {
		/**
		 * Validate Customer Search Page
		 */
		createCustTasks.launchCustomerSeachPage();
		/**
		 * validate Create Ind & Create Org link Exists in Customer Search page.
		 */
		scenarioTasks.verifyCreateIndOrg();

		/** Create Organization Customer With International Characters. */
		createCustTasks.clickCreateOrganization();
		createCustTasks.createOrgCustomerWithNameAddressData();

		/** Remove From Book */
		removeFromBookTasks.getHouseholdMembers();

		removeFromBookTasks.clickMenuBar("text=Customer",
				"text=Remove From Book");
		removeFromBookTasks.verifyHHMembersInRemoveFromBook();
		removeFromBookTasks.confirmmRemovalInRFBConfirm();
		removeFromBookTasks.verifyHHPageLaunchAfterConfirm();
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataAgentOrgScenario17(
						dbresultSet, clientE2ETO);
			
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				removeFromBookTasks = new RemoveFromBookTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				removeFromBookTasks
						.createResultsFile(resultsFileName(), scriptName());
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
