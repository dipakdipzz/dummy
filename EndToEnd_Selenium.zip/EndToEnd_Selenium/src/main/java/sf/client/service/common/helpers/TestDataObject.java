package sf.client.service.common.helpers;

import java.sql.ResultSet;

@SuppressWarnings("serial")
public class TestDataObject implements ITransferObject {

	private String userAlias = null;
	private String db2InfoTableName;
	private String coreDataQuery = null; 
	private String db2PortNumber;
	private String db2DatabaseName;
	private String db2User;
	private String db2Password;
	private String db2Query;
	private int failCount = 0;
	private int imageCount = 0;
	private String resultFileName = null;
	private String resultFilePath = null;
	private String dbFilePath = null;
	private String dbFileName = null;
	private String dbTableName = null;
	private String dbQuery = null;
	private ResultSet dbResultSet = null;
	private String domain = null;
	private String userID = null;
	private String password = null;
	private String url = null;
	private String bussinessRole = null;
	private String cimsRollout = null;
	private String cimsVersion = null;
	private String actualResult = null;
	private String testcaseName = null;
	
	public String getTestcaseName() {
		return testcaseName;
	}

	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}

	public String getActualResult() {
		return actualResult;
	}

	public void setActualResult(String actualResult) {
		this.actualResult = actualResult;
	}

	public boolean getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(boolean resultStatus) {
		this.resultStatus = resultStatus;
	}

	private boolean resultStatus = false;

	public String getCimsRollout() {
		return cimsRollout;
	}

	public void setCimsRollout(String cimsRollout) {
		this.cimsRollout = cimsRollout;
	}

	public String getCimsVersion() {
		return cimsVersion;
	}

	public void setCimsVersion(String cimsVersion) {
		this.cimsVersion = cimsVersion;
	}

	public String getDbFileName() {
		return dbFileName;
	}

	public void setDbFileName(String dbFileName) {
		this.dbFileName = dbFileName;
	}

	public String getDbFilePath() {
		return dbFilePath;
	}

	public void setDbFilePath(String dbFilePath) {
		this.dbFilePath = dbFilePath;
	}

	public String getDbQuery() {
		return dbQuery;
	}

	public void setDbQuery(String dbQuery) {
		this.dbQuery = dbQuery;
	}

	public String getDbTableName() {
		return dbTableName;
	}

	public void setDbTableName(String dbTableName) {
		this.dbTableName = dbTableName;
	}

	public ResultSet getDbResultSet() {
		return dbResultSet;
	}

	public void setDbResultSet(ResultSet dbResultSet) {
		this.dbResultSet = dbResultSet;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getBussinessRole() {
		return bussinessRole;
	}

	public void setBussinessRole(String bussinessRole) {
		this.bussinessRole = bussinessRole;
	}

	/**
	 * @return the resultFilePath
	 */
	public String getResultFilePath() {
		return resultFilePath;
	}

	/**
	 * @param resultFilePath
	 *            the resultFilePath to set
	 */
	public void setResultFilePath(String resultFilePath) {
		this.resultFilePath = resultFilePath;
	}

	/**
	 * @return the failCount
	 */
	public int getFailCount() {
		return failCount;
	}

	/**
	 * @param failCount
	 *            the failCount to set
	 */
	public void setFailCount(int failCount) {
		this.failCount = failCount;
	}

	/**
	 * @return the imageCount
	 */
	public int getImageCount() {
		return imageCount;
	}

	/**
	 * @param imageCount
	 *            the imageCount to set
	 */
	public void setImageCount(int imageCount) {
		this.imageCount = imageCount;
	}

	/**
	 * @return the resultFileName
	 */
	public String getResultFileName() {
		return resultFileName;
	}

	/**
	 * @param resultFileName
	 *            the resultFileName to set
	 */
	public void setResultFileName(String resultFileName) {
		this.resultFileName = resultFileName;
	}

	/**
	 * @return the db2DatabaseName
	 */
	public String getDb2DatabaseName() {
		return db2DatabaseName;
	}

	/**
	 * @param db2DatabaseName
	 *            the db2DatabaseName to set
	 */
	public void setDb2DatabaseName(String db2DatabaseName) {
		this.db2DatabaseName = db2DatabaseName;
	}

	/**
	 * @return the db2Password
	 */
	public String getDb2Password() {
		return db2Password;
	}

	/**
	 * @param db2Password
	 *            the db2Password to set
	 */
	public void setDb2Password(String db2Password) {
		this.db2Password = db2Password;
	}

	/**
	 * @return the db2PortNumber
	 */
	public String getDb2PortNumber() {
		return db2PortNumber;
	}

	/**
	 * @param db2PortNumber
	 *            the db2PortNumber to set
	 */
	public void setDb2PortNumber(String db2PortNumber) {
		this.db2PortNumber = db2PortNumber;
	}

	/**
	 * @return the db2User
	 */
	public String getDb2User() {
		return db2User;
	}

	/**
	 * @param db2User
	 *            the db2User to set
	 */
	public void setDb2User(String db2User) {
		this.db2User = db2User;
	}

	/**
	 * @return the db2Query
	 */
	public String getDb2Query() {
		return db2Query;
	}

	/**
	 * @param db2Query
	 *            the db2Query to set
	 */
	public void setDb2Query(String db2Query) {
		this.db2Query = db2Query;
	}

	/**
	 * @return the db2InfoTableName
	 */
	public String getDb2InfoTableName() {
		return db2InfoTableName;
	}

	/**
	 * @param db2InfoTableName
	 *            the db2InfoTableName to set
	 */
	public void setDb2InfoTableName(String db2InfoTableName) {
		this.db2InfoTableName = db2InfoTableName;
	}

	public String getUserAlias() {
		return userAlias;
	}

	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}

	public String getCoreDataQuery() {
		return coreDataQuery;
	}

	public void setCoreDataQuery(String coreDataQuery) {
		this.coreDataQuery = coreDataQuery;
	}

}
