package sf.client.service.healthSuite.tasks;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.common.appObjects.ABSPortalTestObjects;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.AddIndividualPageObjects;
import sf.client.service.healthSuite.appObjects.ConflictCustomerInfoAppObj;
import sf.client.service.healthSuite.appObjects.CreateIndividualCustomer;
import sf.client.service.healthSuite.appObjects.CreateOrganizationCustomerAppObj;
import sf.client.service.healthSuite.appObjects.CustomerSeparateAppObj;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.OutOfBookSearchPageObjects;
import sf.client.service.healthSuite.appObjects.SSNSINObjects;
import sf.client.service.healthSuite.appObjects.SearchSelectCustomerAppObj;
import sf.client.service.healthSuite.appObjects.Update_IND_CustomerInfo_PageObjects;
import sf.client.service.healthSuite.appObjects.Update_Misc_Objects;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.TextField;
import statefarm.widget.manager.Verify;

public class CreateCustomersTasks extends HouseHoldTasks {
	/**
	 * Empty Constructor
	 */
	public CreateCustomersTasks() {
		super();
	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param clientE2ETO
	 */
	public CreateCustomersTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}

	/**
	 * Verify Create Individual Customer page launched or not.
	 * 
	 * @throws ScriptException
	 */
	public void isCreateIndividualPageLaunched() throws ScriptException {
		setWindow(EndToEndConstants.CREATE_INDIVIDUAL_PORTAL, 30, 2);
		setTopFrame();
		if ((CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB_ORG)
				.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CREATEINDIVIDUALPAGE_LAUNCHED);
		} else if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB
				.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CREATEINDIVIDUALPAGE_LAUNCHED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * CMP - US Scenario 8
	 * 
	 * @throws ScriptException
	 */
	public void canadaNonAgentUnableToCreateUSCustomers()
			throws ScriptException {

		clickCreateIndividual();
		fillAgentCode();
		verifyErrorMessageForUSScenario8();
	}

	/**
	 * CMP - US Scenario 9
	 * 
	 * @throws ScriptException
	 */
	public void usNonAgentUnableToCreateCanadaCustomers()
			throws ScriptException {

		clickCreateIndividual();
		fillAgentCode();
		verifyErrorMessageForUSScenario8();
	}

	/** CANADA SCENARIOS **/

	/**
	 * CMP - Canada Scenario 2
	 * 
	 * @throws ScriptException
	 */
	public void canadaAgentNotAbleToSearchOnUSData() throws ScriptException {

		canadaAgentNotAbleToSearchOnUSName();
		canadaAgentNotAbleToSearchOnUSPhone();
		canadaAgentNotAbleToSearchOnUSAcctPolicy();
		//canadaAgentNotAbleToSearchOnUSOob();

	}

	/*public void canadaAgentNotAbleToSearchOnUSOob() throws ScriptException {
		 
		fetchOobData(); 
		  verifyErrorMessageForScenario3();
	}
	
	public void fetchOobData() {
		try {
			clickOutOfBookAndIndividualRadioButton();
			isOOBIndividualPageExists();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			clickSearch();
			waitForTime(5);
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}
	
	public void enterNameSectionInOOBIndividualPage() {
		try {
			if (isOOBIndividualPageExists()) {
				enterOOBLastName();
				enterOOBFirstName();
				enterZip(); 
				selectStateOrProvince(); 
				enterCity();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException e) {
			scriptError(e);
		}
	}
public void enterOOBLastName() throws ScriptException {
		
		if (OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT.click();
		}
		if (clientE2ETO.getLastName() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.setText(clientE2ETO
						.getLastName());
				Verify.verifyTrue(true,  clientE2ETO.getLastName() + MessageUtility.LASTNAME_VALUE);
						
			} else {
				Verify.verifyTrue(false,  MessageUtility.TEXT_LASTNAME);
			}
		}
	}

	*//**
	 * This Method is used to enter the First name in OOB Search Page.
	 * 
	 * @throws ScriptException
	 *//*
	public void enterOOBFirstName() throws ScriptException {
		if (clientE2ETO.getFirstName() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_FIRSTNAME.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_FIRSTNAME.setText(clientE2ETO
						.getFirstName());
				Verify.verifyTrue(true, "'" + clientE2ETO.getFirstName() + MessageUtility.FIRSTNAME_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);
			}
		}
	}
	
	public void clickOutOfBookAndIndividualRadioButton() {
		try {
			if (isPortalSearchPageExist()) {
				clickSearchOOB();
				clickSearchIndividaul();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}

	}
	
	public void clickSearchOOB() throws ScriptException,
	sf.client.service.common.helpers.ScriptException {
waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON, 15);
if (OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON.exists()) {
	OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON.click();
	Verify.verifyTrue(true,
			MessageUtility.RADIOBUTTON_OUTOFBOOK_CLICKED);
} else {
	Verify.verifyTrue(false,
			MessageUtility.RADIOBUTTON_OUTOFBOOK_NOTFOUND);
}
}
	
	public void clickSearchIndividaul() throws ScriptException {
		waitForPageLoad(
				OutOfBookSearchPageObjects.WidgetInfos.RADIOBUTTON_SELECTINDIVIDUAL, 15);
		if (OutOfBookSearchPageObjects.WidgetInfos.RADIOBUTTON_SELECTINDIVIDUAL.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.RADIOBUTTON_SELECTINDIVIDUAL.click();
			Verify.verifyTrue(true,
					MessageUtility.RADIOBUTTON_INDIVIDUAL);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_INDIVIDUAL_NOTFOUND);
		}
	}
	
public boolean isOOBIndividualPageExists() {
		
		waitForTime(5);
		if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.exists()) {
			return true;
		} else {
			return false;
		}
	}*/

	/**
	 * Launch Basic info page.
	 * 
	 * @throws ScriptException
	 */
	public void launchBasicInfo() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB).exists()) {
			click(CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB,
					MessageUtility.BASICINFOTAB);
		}
	}

	/**
	 * Verify Basic info page launched or not.
	 * 
	 * @throws ScriptException
	 */
	public void isBasicInfoPageLaunched() throws ScriptException {
		waitForPageLoad(CreateIndividualCustomer.WidgetInfos.TEXT_LASTNAME, 4);
		if ((CreateIndividualCustomer.WidgetInfos.TEXT_LASTNAME).exists()) {
			Verify.verifyTrue(true, MessageUtility.BASICINFOPAGE_LAUNCHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.BASICINFOPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * Enter First name in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterFirstName() throws ScriptException {
		if (clientE2ETO.getFirstName() != null) {
			if ((CreateIndividualCustomer.WidgetInfos.TEXT_FIRSTNAME).exists()) {

				setTextInTextbox(
						CreateIndividualCustomer.WidgetInfos.TEXT_FIRSTNAME,
						clientE2ETO.getFirstName(), clientE2ETO.getFirstName()
								+ MessageUtility.FIRSTNAME_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);
			}
		}
	}

	/**
	 * Enter Last name in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterLastName() throws ScriptException {
		if (clientE2ETO.getLastName() != null) {
			if ((CreateIndividualCustomer.WidgetInfos.TEXT_LASTNAME).exists()) {
				setTextInTextbox(
						CreateIndividualCustomer.WidgetInfos.TEXT_LASTNAME,
						clientE2ETO.getLastName(), clientE2ETO.getLastName()
								+ MessageUtility.LASTNAME_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);
			}
		}
	}

	/**
	 * Select Address type as us in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectUSType() throws ScriptException {

		if ((CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERSON_US)
				.exists()) {
			selectRadioButton(
					CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERSON_US,
					MessageUtility.RADIOBUTTON_US);
		} else {
			Verify.verifyTrue(false, MessageUtility.RADIOBUTTON_US_NOTDISPLAYED);

		}
	}

	/**
	 * Select Address type as us in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectUSOrgType() throws ScriptException {

		if ((CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_ORGANIZATION_US)
				.exists()) {
			selectRadioButton(
					CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_ORGANIZATION_US,
					MessageUtility.RADIOBUTTON_US);
		} else {
			Verify.verifyTrue(false, MessageUtility.RADIOBUTTON_US_NOTDISPLAYED);

		}
	}

	/**
	 * Enter Mailing Street in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMailingStreet() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_STREET).exists()) {
			setTextInTextbox(
					CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_STREET,
					clientE2ETO.getmStreet(), clientE2ETO.getmStreet()
							+ MessageUtility.STREET_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_STREET);

		}
	}

	/**
	 * Enter Mailing City in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMailingCity() throws ScriptException {

		if ((CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_CITY).exists()) {
			setTextInTextbox(
					CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_CITY,
					clientE2ETO.getmCity(), clientE2ETO.getmCity()
							+ MessageUtility.CITY_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_CITY);

		}
	}

	/**
	 * Enter Mailing State in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */

	public void selectMailingState() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_STATE).exists()) {
			setTextInTextbox(
					CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_STATE,
					clientE2ETO.getMstate(),
					MessageUtility.LISTBOX_MAILINGSTATE);
		} else {
			Verify.verifyTrue(false, MessageUtility.LISTBOX_STATE);
		}
	}

	/**
	 * Enter Mailing Zip in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMailingZip() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_ZIP).exists()) {
			setTextInTextbox(
					CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_ZIP,
					clientE2ETO.getMzip().trim(), clientE2ETO.getMzip().trim()
							+ MessageUtility.ZIP_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_ZIP);
		}
	}

	/**
	 * click Create Customer Button in Create Individual/Organization Customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void clickCreateCustomers() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.BUTTON_CREATECUSTOMER.exists()) {
			click(CreateIndividualCustomer.WidgetInfos.BUTTON_CREATECUSTOMER,
					MessageUtility.BUTTON_CREATECUSTOMERS);
		}
	}

	/**
	 * verify Household Page Launched Or Not.
	 * 
	 * @throws ScriptException
	 */
	public void isHouseholdPageLaunched() throws ScriptException {
		waitForPageLoad(HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE,
				10);
		if (HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE.exists()) {
			Verify.verifyTrue(true, MessageUtility.HOUSEHOLDPAGE_LAUNCHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * Enter First name in Add Member(s) Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterHHFirstName() throws ScriptException {
		waitForPageLoad(AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME, 30);
		if (clientE2ETO.getHhFirstName() != null) {
			if ((AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME).exists()) {
				enterMandatoryfieldtoEnablebutton(
						AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME,
						clientE2ETO.getHhFirstName());
				Verify.verifyTrue(true, clientE2ETO.getHhFirstName()
						+ MessageUtility.FIRSTNAME);

			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);
			}
		}
	}

	/**
	 * Enter Last name in Add Member(s) Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterHHLastName() throws ScriptException {
		if (clientE2ETO.getHhLastName() != null) {
			if ((AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME).exists()) {
				enterMandatoryfieldtoEnablebutton(
						AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME,
						clientE2ETO.getHhLastName());
				Verify.verifyTrue(true, clientE2ETO.getHhLastName()
						+ MessageUtility.LASTNAME);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);
			}
		}
	}

	/**
	 * Select Address type as Canada in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectCanadaTypeForMailing() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_MAILING_CANADA)
				.exists()) {
			selectRadioButton(
					CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_MAILING_CANADA,
					MessageUtility.RADIOBUTTON_CANADA_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_CANADA_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Mailing Province in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectMailingProvince() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_PROVINCE)
				.exists()) {
			selectProvinceCanada(clientE2ETO.getmProvince());
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LISTBOX_MAILINGPROVINCE_NOTDISPLAYED);
		}
	}

	/**
	 * Select Mailing Province in Create Individual Customer page.
	 */
	public void selectProvinceCanada(String stateToBeSelected) {
		try {
			selenium = sel.getCurrentDomain();
			selenium.clickAt("//div[@id='widget_provinceLabel[0]']/div", "");
			selenium.waitForCondition(
					"selenium.isElementPresent(\"provinceLabel[0]_popup8\")",
					"3000");
			int i = 0;
			while (true) {
				if (selenium.isElementPresent("provinceLabel[0]_popup" + i)) {
					String state = selenium.getText("provinceLabel[0]_popup"
							+ i);
					if (state.contains(clientE2ETO.getmProvince().trim())) {
						selenium.mouseOver("provinceLabel[0]_popup" + i);
						selenium.clickAt("provinceLabel[0]_popup" + i, "");
						break;
					}
				} else {
					break;
				}
				i++;
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter Home Phone Number in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterHomePhoneNumber() throws ScriptException {
		if (clientE2ETO.getHomePhoneNumber() != null) {
			if ((CreateIndividualCustomer.WidgetInfos.TEXT_PERSON_PHONE)
					.exists()) {

				setTextInTextbox(
						CreateIndividualCustomer.WidgetInfos.TEXT_PERSON_PHONE,
						clientE2ETO.getHomePhoneNumber(),
						"'" + clientE2ETO.getHomePhoneNumber()
								+ MessageUtility.HOMEPHONE_DISPLAYED);

			} else {
				Verify.verifyTrue(false, MessageUtility.HOMEPHONE_NOTDISPLAYED);

			}
		}
	}

	/**
	 * Enter Calling Preferences day in Create Individual Customer page for
	 * Mobile phone.
	 * 
	 * @throws ScriptException
	 */
	public void selectCallingPrefDayMobile() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LIST_CALLINGPREFERENCEDAYMOBILE)
				.exists()) {

			selectFromListbox(
					CreateIndividualCustomer.WidgetInfos.LIST_CALLINGPREFERENCEDAYMOBILE,
					clientE2ETO.getCallingPref(), "Mobile Calling preference"
							+ clientE2ETO.getCallingPref()
							+ "is displayed as expected");
			if (clientE2ETO.getCallingPref().equalsIgnoreCase("SPECIFIC")) {
				if (clientE2ETO.getSpecificDays().contains("SUNDAY")) {
					CheckBox specificSunday = new CheckBox(
							"id=person.phones[0].availableSun");
					specificSunday.click();
				} else if (clientE2ETO.getSpecificDays().contains("MONDAY")) {
					CheckBox specificMonday = new CheckBox(
							"id=person.phones[0].availableMon");
					specificMonday.click();
				} else if (clientE2ETO.getSpecificDays().contains("TUESDAY")) {
					CheckBox specificTuesday = new CheckBox(
							"id=person.phones[0].availableTue");
					specificTuesday.click();
				} else if (clientE2ETO.getSpecificDays().contains("WEDNESDAY")) {
					CheckBox specificWednesday = new CheckBox(
							"id=person.phones[0].availableWed");
					specificWednesday.click();
				} else if (clientE2ETO.getSpecificDays().contains("THURSDAY")) {
					CheckBox specificThursday = new CheckBox(
							"id=person.phones[0].availableThu");
					specificThursday.click();
				} else if (clientE2ETO.getSpecificDays().contains("FRIDAY")) {
					CheckBox specificFriday = new CheckBox(
							"id=person.phones[0].availableFri");
					specificFriday.click();
				} else if (clientE2ETO.getSpecificDays().contains("SATURDAY")) {
					CheckBox specificSaturday = new CheckBox(
							"id=person.phones[0].availableSat");
					specificSaturday.click();
				}
			}
			Verify.verifyTrue(true, " '" + clientE2ETO.getSpecificDays()
					+ "' is clicked");
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HOMECALLINGPREFERENCE_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Calling Preferences From Time in Create Individual Customer page
	 * for Mobile phone.
	 * 
	 * @throws ScriptException
	 */
	public void selectCallingPrefFromTimeMobile() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LIST_FROMTIMEMOBILE).exists()) {
			selectFromListbox(
					CreateIndividualCustomer.WidgetInfos.LIST_FROMTIMEMOBILE,
					clientE2ETO.getFromTime(),
					"Mobile Calling preference from time"
							+ clientE2ETO.getFromTime()
							+ "is displayed as expected");

		} else {
			Verify.verifyTrue(false,
					MessageUtility.MOBILECALLINGPREFERENCEFROMTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Calling Preferences To Time in Create Individual Customer page for
	 * Mobile phone.
	 * 
	 * @throws ScriptException
	 */
	public void selectCallingPrefToTimeMobile() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LIST_TOTIMEMOBILE).exists()) {

			selectFromListbox(
					CreateIndividualCustomer.WidgetInfos.LIST_TOTIMEMOBILE,
					clientE2ETO.getToTime(),
					"Mobile Calling preference to time"
							+ clientE2ETO.getToTime()
							+ "is displayed as expected");

		} else {
			Verify.verifyTrue(false,
					MessageUtility.MOBILECALLINGPREFERENCETOTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Calling Preferences Day in Create Individual Customer page for
	 * Mobile phone.
	 * 
	 * @throws ScriptException
	 */
	public void selectCallingPrefDayHome() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LIST_CALLINGPREFERENCEDAYHOME)
				.exists()) {
			/*selectFromListbox(
					CreateIndividualCustomer.WidgetInfos.LIST_CALLINGPREFERENCEDAYHOME,
					clientE2ETO.getCallingPrefDayHome(),
					"Home Calling preference Day list box is displayed as expected");*/
			selectFromListbox(
					CreateIndividualCustomer.WidgetInfos.LIST_CALLINGPREFERENCEDAYHOME,
					"Any Day",
					"Home Calling preference Day list box is displayed as expected");
			if (clientE2ETO.getCallingPrefDayHome()
					.equalsIgnoreCase("SPECIFIC")) {
				if (clientE2ETO.getSpecificDays().contains("SUNDAY")) {
					CheckBox specificSunday = new CheckBox(
							"id=person.phones[1].availableSun");
					specificSunday.click();
				} else if (clientE2ETO.getSpecificDays().contains("MONDAY")) {
					CheckBox specificMonday = new CheckBox(
							"id=person.phones[1].availableMon");
					specificMonday.click();
				} else if (clientE2ETO.getSpecificDays().contains("TUESDAY")) {
					CheckBox specificTuesday = new CheckBox(
							"id=person.phones[1].availableTue");
					specificTuesday.click();
				} else if (clientE2ETO.getSpecificDays().contains("WEDNESDAY")) {
					CheckBox specificWednesday = new CheckBox(
							"id=person.phones[1].availableWed");
					specificWednesday.click();
				} else if (clientE2ETO.getSpecificDays().contains("THURSDAY")) {
					CheckBox specificThursday = new CheckBox(
							"id=person.phones[1].availableThu");
					specificThursday.click();
				} else if (clientE2ETO.getSpecificDays().contains("FRIDAY")) {
					CheckBox specificFriday = new CheckBox(
							"id=person.phones[1].availableFri");
					specificFriday.click();
				} else if (clientE2ETO.getSpecificDays().contains("SATURDAY")) {
					CheckBox specificSaturday = new CheckBox(
							"id=person.phones[1].availableSat");
					specificSaturday.click();
				}
			}
			Verify.verifyTrue(true, "'" + clientE2ETO.getSpecificDays()
					+ "' is selected");
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HOMECALLINGPREFERENCE_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Calling Preferences Day in Create Organization Customer page .
	 * 
	 * @throws ScriptException
	 */
	public void selectCellCallingPrefDayOrg() {
		try {
			if (CreateOrganizationCustomerAppObj.WidgetInfos.LIST_CELLCALLINGPREFERENCEDAY
					.exists()) {
				selectFromListbox(
						CreateOrganizationCustomerAppObj.WidgetInfos.LIST_CELLCALLINGPREFERENCEDAY,
						clientE2ETO.getCallingPref(),
						" Calling preference Day list box is displayed as expected .");
			} else if (clientE2ETO.getCallingPref()
					.equalsIgnoreCase("SPECIFIC")) {
				if (clientE2ETO.getSpecificDays().contains("SUNDAY")) {
					CheckBox specificSunday = new CheckBox(
							"id=phone.availableSun");
					specificSunday.click();
				} else if (clientE2ETO.getSpecificDays().contains("MONDAY")) {
					CheckBox specificMonday = new CheckBox(
							"id=phone.availableMon");
					specificMonday.click();
				} else if (clientE2ETO.getSpecificDays().contains("TUESDAY")) {
					CheckBox specificTuesday = new CheckBox(
							"id=phone.availableTue");
					specificTuesday.click();
				} else if (clientE2ETO.getSpecificDays().contains("WEDNESDAY")) {
					CheckBox specificWednesday = new CheckBox(
							"id=phone.availableWed");
					specificWednesday.click();
				} else if (clientE2ETO.getSpecificDays().contains("THURSDAY")) {
					CheckBox specificThursday = new CheckBox(
							"id=phone.availableThu");
					specificThursday.click();
				} else if (clientE2ETO.getSpecificDays().contains("FRIDAY")) {
					CheckBox specificFriday = new CheckBox(
							"id=phone.availableFri");
					specificFriday.click();
				} else if (clientE2ETO.getSpecificDays().contains("SATURDAY")) {
					CheckBox specificSaturday = new CheckBox(
							"id=phone.availableSat");
					specificSaturday.click();
				}

			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter SSN number in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterSSN() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.TEXT_SSNSIN).exists()) {
			setTextInTextbox(CreateIndividualCustomer.WidgetInfos.TEXT_SSNSIN,
					clientE2ETO.getSsnNum(), clientE2ETO.getSsnNum()
							+ MessageUtility.SSN1);
		} else {
			Verify.verifyTrue(false, MessageUtility.SSN_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Email Address in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterEmailAddress() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.LINK_EMAILTAB.exists()) {
			clickEmailTab();
			if (AddIndividualPageObjects.WidgetInfos.TEXT_EMAILADDRESSES
					.exists()) {
				setTextInTextbox(
						AddIndividualPageObjects.WidgetInfos.TEXT_EMAILADDRESSES,
						clientE2ETO.getHhEmailAddress1(), MessageUtility.EMAIL);
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.EMAIL_NOTDISPLAYED);
		}
	}

	/**
	 * Click OK Button in Address Standardization page.
	 * 
	 * @throws ScriptException
	 */
	public void clickAddressStdzationOkbutton() throws ScriptException {
		waitForPageLoad(CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_OK,
				30);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_OK.exists()) {
			click(CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_OK,
					MessageUtility.BUTTON_OK);
		}

	}

	/**
	 * Enter Calling Preferences From Time in Create Organization Customer page
	 * .
	 * 
	 * @throws ScriptException
	 */
	public void selectCellCallingPrefFromTimeOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.LIST_CELLFROMTIME
				.exists()) {
			selectFromListbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.LIST_CELLFROMTIME,
					clientE2ETO.getFromTime(),
					MessageUtility.CALLINGPREFERENCEFROMTIME_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CALLINGPREFERENCEFROMTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Calling Preferences From Time in Create Organization Customer page
	 * .
	 * 
	 * @throws ScriptException
	 */
	public void selectCellCallingPrefToTimeOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.LIST_CELLTOTIME
				.exists()) {
			selectFromListbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.LIST_CELLTOTIME,
					clientE2ETO.getToTime(),
					MessageUtility.CALLINGPREFERENCETOTIME_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CALLINGPREFERENCETOTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Calling Preferences Day in Create Organization Customer page fro
	 * Additional type phone.
	 * 
	 * @throws ScriptException
	 */
	public void selectAdditionalCallingPrefDayOrg() throws ScriptException {
		if (clientE2ETO.getAdditionalCallingPref() != null) {
			if (CreateOrganizationCustomerAppObj.WidgetInfos.LIST_ADDITIONALCALLINGPREFERENCEDAY
					.exists()) {
				selectFromListbox(
						CreateOrganizationCustomerAppObj.WidgetInfos.LIST_ADDITIONALCALLINGPREFERENCEDAY,
						clientE2ETO.getAdditionalCallingPref(),
						MessageUtility.CALLINGPREFERENCEDAY_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CALLINGPREFERENCEDAY_NOTDISPLAYED);
			}
		}
	}

	/**
	 * Enter Calling Preferences From Time in Create Organization Customer page
	 * fro Additional type phone.
	 * 
	 * @throws ScriptException
	 */
	public void selectAdditionalCallingPrefFromTimeOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.LIST_ADDITIONALFROMTIME
				.exists()) {
			selectFromListbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.LIST_ADDITIONALFROMTIME,
					clientE2ETO.getAdditionalFromTime(),
					MessageUtility.CALLINGPREFERENCEFROMTIME_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CALLINGPREFERENCEFROMTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Calling Preferences To Time in Create Organization Customer page
	 * for Additional type phone.
	 * 
	 * @throws ScriptException
	 */
	public void selectAdditionalCallingPrefToTimeOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.LIST_ADDITIONALTOTIME
				.exists()) {
			selectFromListbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.LIST_ADDITIONALTOTIME,
					clientE2ETO.getAdditionalToTime(),
					MessageUtility.CALLINGPREFERENCETOTIME_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CALLINGPREFERENCETOTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Hear About Office in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectHearAboutOfficeOrg() throws ScriptException {
		if (clientE2ETO.getHearAboutOffice() != null) {
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HEARABOUTOFFICE
					.exists()) {
				setTextInTextbox(
						CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HEARABOUTOFFICE,
						clientE2ETO.getHearAboutOffice(),
						MessageUtility.HEARABOUTOFFICE_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HEARABOUTOFFICE_NOTDISPLAYED);

			}
		}
	}

	/**
	 * Enter Most important to you in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectMostimportanttoyouOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MOSTIMPORTANTTOYOU
				.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MOSTIMPORTANTTOYOU,
					clientE2ETO.getMostimportanttoyou(),
					MessageUtility.MOSTIMPORTANTTOYOU_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.MOSTIMPORTANTTOYOU_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Hear About Office in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectHearAboutOfficeInd() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.TEXT_HEARABOUTOFFICECODE
				.exists()) {
			setTextInTextbox(
					CreateIndividualCustomer.WidgetInfos.TEXT_HEARABOUTOFFICECODE,
					clientE2ETO.getHearAboutOffice(),
					MessageUtility.HEARABOUTOFFICE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HEARABOUTOFFICE_NOTDISPLAYED);

		}
	}

	/**
	 * Enter Most important to you in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectMostimportanttoyouInd() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.TEXT_IMPORTANCEFACTORCODE
				.exists()) {
			setTextInTextbox(
					CreateIndividualCustomer.WidgetInfos.TEXT_IMPORTANCEFACTORCODE,
					clientE2ETO.getMostimportanttoyou(),
					MessageUtility.MOSTIMPORTANTTOYOU_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.MOSTIMPORTANTTOYOU_NOTDISPLAYED);
		}
	}

	/**
	 * Select Address type as us in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectUSTypeOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.RADIOBUTTON_MUS
				.exists()) {
			CreateOrganizationCustomerAppObj.WidgetInfos.RADIOBUTTON_MUS
					.click();
			Verify.verifyTrue(true, MessageUtility.RADIOBUTTON_US);

		} else {
			Verify.verifyTrue(false, MessageUtility.RADIOBUTTON_US_NOTDISPLAYED);
		}
	}

	/**
	 * Click Add Additional Individual Button in Create Individual/Organization
	 * Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void clickAddAdditionalIndividual() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_ADDADDITIONALIND
				.exists()) {
			click(CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_ADDADDITIONALIND,
					MessageUtility.BUTTON_ADDADDITIONALINDIVIDUAL);
			count++;
		}
	}

	/**
	 * Click Add Additional Organization Tab in Add Member(s) page.
	 * 
	 * @throws ScriptException
	 */
	public void clickAddAdditionalOrganizationTab() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_TAB_ADDADDITIONALORG
				.exists()) {
			click(CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_TAB_ADDADDITIONALORG,
					MessageUtility.ADDADDITIONALORGANIZATION);
		}
	}

	/**
	 * Verify US SSN/CN SIN is displayed in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void verifySSNAddIndPage() throws ScriptException {
		WebElement text = getWebDriverInstance()
				.findElement(
						By.xpath("//div[@id='mainTabContainer']/div/div/fieldset[2]/table"));
		if (text.getText().contains("US SSN:")
				&& text.getText().contains("CN SIN:"))
			Verify.verifyTrue(true, MessageUtility.SSN_DISPLAY);
		else
			Verify.verifyTrue(false, MessageUtility.SSN_NOTDISPLAY);

	}

	/**
	 * Enter Mandatory Fields in Add Member(s) page for Additional Organization
	 * create.
	 * 
	 * @throws ScriptException
	 */

	public void addAdditionalOrganizationCreate() throws ScriptException {
		selectHHOrganizationType(1);
		enterMandatoryfieldtoEnablebutton(
				CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HHADDITIONALORGANIZATIONNAME,
				clientE2ETO.getAddAddlOrgName());
		selectAddAddress();
	}

	/**
	 * click Cancel button in Create Individual customer page.
	 * 
	 * @throws ScriptException
	 */
	public void clickCancelInCreateIndividual() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.BUTTON_CANCEL.exists())
			click(CreateIndividualCustomer.WidgetInfos.BUTTON_CANCEL,
					MessageUtility.CREATEINDIVIDUALCANCEL_CLICKED);
		else
			Verify.verifyTrue(false,
					MessageUtility.CREATEINDIVIDUALCANCEL_NOTDISPLAYED);
	}

	/**
	 * click Mobile Calling Preference in Create Individual/Organization
	 * customer page.
	 * 
	 * @throws ScriptException
	 */
	public void clickMobileCallingPreference() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LINK_MOBILE_CALLING_PREFERENCE)
				.exists()) {
			CreateIndividualCustomer.WidgetInfos.LINK_MOBILE_CALLING_PREFERENCE
					.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_MOBILECALLINGPREFERENCE_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_MOBILECALLINGPREFERENCE_NOTCLICKED);
		}
	}

	/**
	 * click Fax Calling Preference in Create Organization customer page.
	 * 
	 * @throws ScriptException
	 */
	public void clickFaxCallingPreferenceOrg() throws ScriptException {
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.LINK_FAX_CALLING_PREFERENCE)
				.exists()) {
			CreateOrganizationCustomerAppObj.WidgetInfos.LINK_FAX_CALLING_PREFERENCE
					.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_FAXCALLINGPREFERENCE_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_FAXCALLINGPREFERENCE_NOTCLICKED);
		}
	}

	/**
	 * click Phone Tab in Create Individual/Organization customer page.
	 * 
	 * @throws ScriptException
	 */
	public void clickPhoneTab() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.LINK_PHONETAB.exists()) {
			click(CreateIndividualCustomer.WidgetInfos.LINK_PHONETAB,
					MessageUtility.PHONETAB_CLICKED);
		} else {
			Verify.verifyTrue(false, MessageUtility.PHONETAB_NOTFOUND);
		}
	}

	/**
	 * Verify Permission To Text Option in Create Individual/Organization
	 * customer page.
	 * 
	 * @throws ScriptException
	 */
	public void verifyPermissionToTextOptions() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_YES
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.PERMISSIONTOTEXT_YES);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PERMISSIONTOTEXT_YES_NOTFOUND);
		}
		if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_NO
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.PERMISSIONTOTEXT_NO);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PERMISSIONTOTEXT_NO_NOTFOUND);
		}
		if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_DIDNOTASK
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.PERMISSIONTOTEXT_DIDNOTASK);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PERMISSIONTOTEXT_DIDNOTASK_NOTFOUND);
		}
	}

	/**
	 * Select Permission To Text Option in Create Individual/Organization
	 * customer page.
	 * 
	 * @throws ScriptException
	 */
	public void permissionToText() throws ScriptException {
		try {
			if (clientE2ETO.getPermissionText().equalsIgnoreCase("Yes")) {
				if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_YES
						.exists()) {
					selectRadioButton(
							CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_YES,
							MessageUtility.PERMISSIONTOTEXT_YES_CLICKED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.PERMISSIONTOTEXT_YES_NOTFOUND);
				}
			}
			if (clientE2ETO.getPermissionText().equalsIgnoreCase("No")) {
				if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_NO
						.exists()) {
					selectRadioButton(
							CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_NO,
							MessageUtility.PERMISSIONTOTEXT_NO_CLICKED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.PERMISSIONTOTEXT_NO_NOTFOUND);
				}
			}

			if (clientE2ETO.getPermissionText().equalsIgnoreCase("DidNotAsk")) {
				if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_DIDNOTASK
						.exists()) {
					selectRadioButton(
							CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_DIDNOTASK,
							MessageUtility.PERMISSIONTOTEXT_DIDNOTASK_CLICKED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.PERMISSIONTOTEXT_DIDNOTASK_NOTFOUND);
				}
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click Home Calling Preference in Create Individual customer page.
	 * 
	 * @throws ScriptException
	 */
	public void clickHomeCallingPreference() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LINK_HOME_CALLING_PREFERENCE)
				.exists()) {
			click(CreateIndividualCustomer.WidgetInfos.LINK_HOME_CALLING_PREFERENCE,
					MessageUtility.HOMECALLINGPREFERENCE_FOUND);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HOMECALLINGPREFERENCE_NOTFOUND);
		}
	}

	/**
	 * Select Home Calling Preferences From Time in Create Individual customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void selectCallingPrefFromTimeHomeInd() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LIST_FROMTIMEHOME_Cpp)
				.exists()) {
			selectFromListbox(
					CreateIndividualCustomer.WidgetInfos.LIST_FROMTIMEHOME_Cpp,
					clientE2ETO.getHomeFromTime(),
					clientE2ETO.getHomeFromTime()
							+ MessageUtility.HOMEFROMTIME_VALUE);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CALLINGPREFERENCEFROMTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Select Home Calling Preferences To Time in Create Individual customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void selectCallingPrefToTimeHomeInd() throws ScriptException {
		if ((CreateIndividualCustomer.WidgetInfos.LIST_TOTIMEHOME_CPP).exists()) {

			selectFromListbox(
					CreateIndividualCustomer.WidgetInfos.LIST_TOTIMEHOME_CPP,
					clientE2ETO.getHomeToTime(), clientE2ETO.getHomeToTime()
							+ MessageUtility.HOMETOTIME_VALUE);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CALLINGPREFERENCETOTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Select Additional Type phone in Create Individual/Organization customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void selectAdditionalType() throws ScriptException {
		if (clientE2ETO.getAdditionalType() != null) {
			if ((CreateIndividualCustomer.WidgetInfos.LIST_ADDITIONALTYPE)
					.exists()) {

				selectFromListbox(
						CreateIndividualCustomer.WidgetInfos.LIST_ADDITIONALTYPE,
						clientE2ETO.getAdditionalType(),
						clientE2ETO.getAdditionalType()
								+ MessageUtility.ADDITIONALTYPE_VALUE);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.ADDITIONALTYPE_VALUES_NOTDISPLAYED);

			}
		}
	}

	/**
	 * Enter Additional Type phone number in Create Individual/Organization
	 * customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterAdditionalPhoneNumber() throws ScriptException {
		if (clientE2ETO.getAdditionalPhoneNumber() != null) {
			if ((CreateIndividualCustomer.WidgetInfos.TEXT_ADDITIONALPHONENUMBER)
					.exists()) {
				setTextInTextbox(
						CreateIndividualCustomer.WidgetInfos.TEXT_ADDITIONALPHONENUMBER,
						clientE2ETO.getAdditionalPhoneNumber(),
						clientE2ETO.getAdditionalPhoneNumber()
								+ MessageUtility.ADDITIONALTYPEPHONENUMBER_VALUE);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ADDITIONALTYPEPHONENUMBER_NOTDISPLAYED);
			}
		}
	}

	/**
	 * Enter Additional Type Calling Preference in Create
	 * Individual/Organization customer page.
	 * 
	 * @throws ScriptException
	 */
	public void clickAdditionalCallingPreference() throws ScriptException {

		click(CreateIndividualCustomer.WidgetInfos.LINK_ADDLTYPE_CALLING_PREFERENCE,
				MessageUtility.LINK_ADDITIONALCALLINGPREFERENCE);
	}

	/**
	 * Click Email Tab in Create Individual/Organization customer page.
	 * 
	 * @throws ScriptException
	 */
	public void clickEmailTab() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.LINK_EMAILTAB.exists()) {
			CreateIndividualCustomer.WidgetInfos.LINK_EMAILTAB.click();
			Verify.verifyTrue(true, MessageUtility.EMAILTAB_CLICKED);
		} else {
			Verify.verifyTrue(false, MessageUtility.EMAILTAB_NOTFOUND);
		}
	}

	/**
	 * Enter Mailing Zip in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMailingStreetOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MSTREET1.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MSTREET1,
					clientE2ETO.getmStreet(), clientE2ETO.getmStreet()
							+ MessageUtility.STREET_VALUE);
		}
	}

	/**
	 * Enter organization Name in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void fillOrgName() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGNAME.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGNAME,
					clientE2ETO.getOrganizationName(),
					clientE2ETO.getOrganizationName()
							+ MessageUtility.ORGANIZATIONNAME_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_ORGNAME_NOTFOUND);
		}
	}

	/**
	 * Enter Mailing City in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMailingCityOrg() throws ScriptException {
		if (clientE2ETO.getmCity() != null) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MCITY,
					clientE2ETO.getmCity(), clientE2ETO.getmCity()
							+ MessageUtility.CITY_VALUE);

		} else {

			Verify.verifyTrue(false, MessageUtility.TEXT_CITY);
		}

	}

	/**
	 * Enter Mailing Zip in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMailingZipOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MZIPANDPOSTAL
				.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MZIPANDPOSTAL,
					clientE2ETO.getMzip(), clientE2ETO.getMzip()
							+ MessageUtility.ZIP_VALUE);
		} else {

			Verify.verifyTrue(false, MessageUtility.TEXT_ZIP);
		}
	}

	/**
	 * Enter Business Phone Number in Create Individual/Organization Customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void enterBusinessPhoneNum() throws ScriptException {
		if (clientE2ETO.getOrgBusinessPhoneNum() != null) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_BUSINESSPHONENUM,
					clientE2ETO.getOrgBusinessPhoneNum(),
					clientE2ETO.getOrgBusinessPhoneNum()
							+ MessageUtility.BUSINESSPHONE_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_BUSINESSPHONE);
		}
	}

	/**
	 * Enter Mobile Phone number in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMobilePhoneNumOrg() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MOBILEPHONENUM
				.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MOBILEPHONENUM,
					clientE2ETO.getCellPhoneNumber(),
					clientE2ETO.getCellPhoneNumber()
							+ MessageUtility.MOBILEPHONE_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_MOBILEPHONE);
		}
	}

	/**
	 * Click Mobile Phone Calling Preference in Create Organization Customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void clickMobileCallingPreferenceOrg() throws ScriptException {
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.LINK_MOBILE_CALLING_PREFERENCE)
				.exists()) {
			CreateOrganizationCustomerAppObj.WidgetInfos.LINK_MOBILE_CALLING_PREFERENCE
					.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_MOBILECALLINGPREFERENCE_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_MOBILECALLINGPREFERENCE_NOTCLICKED);
		}
	}

	/**
	 * Enter Fax Number in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterFaxPhoneNumberOrg() throws ScriptException {
		if (clientE2ETO.getFaxPhoneNumber() != null) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_FAXPHONENUM,
					clientE2ETO.getFaxPhoneNumber(),
					clientE2ETO.getFaxPhoneNumber()
							+ MessageUtility.FAXPHONENUMBER_VALUE);
		}
	}

	/**
	 * Enter Fax Calling Preferences day in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectFaxCallingPrefDayOrg() throws ScriptException {
		if (clientE2ETO.getFaxCallingPref() != null) {
			if (CreateOrganizationCustomerAppObj.WidgetInfos.LIST_FAXCALLINGPREFERENCEDAY
					.exists()) {
				selectFromListbox(
						CreateOrganizationCustomerAppObj.WidgetInfos.LIST_FAXCALLINGPREFERENCEDAY,
						clientE2ETO.getFaxCallingPref(),
						clientE2ETO.getFaxCallingPref()
								+ MessageUtility.LISTBOX_FAXCALLINGPREFERENCE);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LISTBOX_FAXCALLINGPREFERENCE_NOTSELECTED);
			}
		}
	}

	/**
	 * Enter Fax Calling Preferences From Time in Create Organization Customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void selectCallingPrefFromTimeFaxOrg() throws ScriptException {
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.LIST_FAXFROMTIME)
				.exists()) {
			selectFromListbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.LIST_FAXFROMTIME,
					clientE2ETO.getFaxFromTime(),
					clientE2ETO.getFaxFromTime()
							+ MessageUtility.CALLINGPREFERENCEFROMTIME_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CALLINGPREFERENCEFROMTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Fax Calling Preferences To Time in Create Organization Customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void selectCallingPrefToTimeFaxOrg() throws ScriptException {
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.LIST_FAXTOTIME)
				.exists()) {

			selectFromListbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.LIST_FAXTOTIME,
					clientE2ETO.getFaxToTime(), clientE2ETO.getFaxToTime()
							+ MessageUtility.CALLINGPREFERENCETOTIME_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CALLINGPREFERENCETOTIME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter Additional Phone Number in Create Organization Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterAdditionalPhoneNumberOrg() throws ScriptException {
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDITIONALPHONENUM)
				.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDITIONALPHONENUM,
					clientE2ETO.getAdditionalPhoneNumber(),
					clientE2ETO.getAdditionalPhoneNumber()
							+ MessageUtility.ADDITIONALTYPEPHONENUMBER_VALUE);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.ADDITIONALTYPEPHONENUMBER_NOTDISPLAYED);
		}
	}

	/**
	 * Click Additional Phone CallingPreference in Create Organization Customer
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void clickAdditionalCallingPreferenceOrg() throws ScriptException {
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.LINK_ADDLTYPE_CALLING_PREFERENCE)
				.exists()) {
			CreateOrganizationCustomerAppObj.WidgetInfos.LINK_ADDLTYPE_CALLING_PREFERENCE
					.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_ADDITIONALCALLINGPREFERENCE_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ADDITIONALCALLINGPREFERENCE_NOTCLICKED);
		}
	}

	/**
	 * Enter Email Address in Create Organization Customer page.
	 */
	public void fillEmailAddress() {
		try {
			if (CreateIndividualCustomer.WidgetInfos.LINK_EMAILTAB.exists()
					&& clientE2ETO.getOrgEmailAddress1() != null) {
				clickEmailTab();
				if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGEMAILADDRESS
						.exists()) {
					setTextInTextbox(
							CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGEMAILADDRESS,
							clientE2ETO.getOrgEmailAddress1(),
							clientE2ETO.getOrgEmailAddress1()
									+ MessageUtility.EMAIL);
				} else {
					Verify.verifyTrue(false, MessageUtility.EMAILTAB_NOTFOUND);
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}

	/**
	 * Select marketing Indicator as Yes for Email.
	 * 
	 * @throws ScriptException
	 */

	public void selectEmailAddressForMarketingYes() throws ScriptException {
		if (clientE2ETO.getEmailMarketing().equalsIgnoreCase("Yes")) {
			if (CreateOrganizationCustomerAppObj.WidgetInfos.RADIOBUTTON_PUBLISHEMAIL
					.exists()) {
				selectRadioButton(
						CreateOrganizationCustomerAppObj.WidgetInfos.RADIOBUTTON_PUBLISHEMAIL,
						clientE2ETO.getEmailMarketing()
								+ MessageUtility.RADIOBUTTON_YES);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.RADIOBUTTON_YES_NOTFOUND);
			}
		}

	}

	/**
	 * Enter Mobile Phone Number in Create Individual Customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMobilePhoneNumberInd() throws ScriptException {
		if (clientE2ETO.getCellPhoneNumber() != null) {
			if ((CreateIndividualCustomer.WidgetInfos.TEXT_CELLPHONE_Cpp)
					.exists()) {
				setTextInTextbox(
						CreateIndividualCustomer.WidgetInfos.TEXT_CELLPHONE_Cpp,
						clientE2ETO.getCellPhoneNumber(),
						"'" + clientE2ETO.getCellPhoneNumber()
								+ MessageUtility.MOBILEPHONE_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_MOBILEPHONE);
			}
		}
	}

	/**
	 * Enter Calling Preferences Day in Create Organization Customer page for
	 * Fax number.
	 * 
	 * @throws ScriptException
	 */
	public void selectFaxSpecificOrg() throws ScriptException {
		if (clientE2ETO.getFaxCallingPref() != null
				&& clientE2ETO.getFaxCallingPref().equalsIgnoreCase("Specific")) {

			if (clientE2ETO.getFaxSpecificSun() != null
					&& clientE2ETO.getFaxSpecificSun().equals("Sun")) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.FAX_SUNDAY,
						"Sunday Checkbox clicked in Fax phone Section");
				Verify.verifyTrue(true, MessageUtility.SUNDAY);
			}

			if (clientE2ETO.getFaxSpecificMon() != null
					&& clientE2ETO.getFaxSpecificMon().equals("Mon")) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.FAX_MONDAY,
						"Monday Checkbox clicked in Fax phone Section");
				Verify.verifyTrue(true, MessageUtility.MONDAY);
			}

			if (clientE2ETO.getFaxSpecificTue() != null
					&& clientE2ETO.getFaxSpecificTue().equals("Tue")) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.FAX_TUESDAY,
						"Tuesday Checkbox clicked in Fax phone Section");
				Verify.verifyTrue(true, MessageUtility.TUESDAY);
			}

			if (clientE2ETO.getFaxSpecificWed() != null
					&& clientE2ETO.getFaxSpecificWed().equals("Wed")) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.FAX_WEDNESDAY,
						"Wednesday Checkbox clicked in Fax phone Section");
				Verify.verifyTrue(true, MessageUtility.WEDNESDAY);
			}

			if (clientE2ETO.getFaxSpecificThu() != null
					&& clientE2ETO.getFaxSpecificThu().equals("Thu")) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.FAX_THURSDAY,
						"Thursday Checkbox clicked in Fax phone Section");
				Verify.verifyTrue(true, MessageUtility.THURSDAY);
			}

			if (clientE2ETO.getFaxSpecificFri() != null
					&& clientE2ETO.getFaxSpecificFri().equals("Fri")) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.FAX_FRIDAY,
						"Friday Checkbox clicked in Fax phone Section");
				Verify.verifyTrue(true, MessageUtility.FRIDAY);
			}

			if (clientE2ETO.getFaxSpecificSat() != null
					&& clientE2ETO.getFaxSpecificSat().equals("Sat")) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.FAX_SATURDAY,
						"Saturday Checkbox clicked in Fax phone Section");
				Verify.verifyTrue(true, MessageUtility.SATURDAY);
			}

		}

	}

	/**
	 * verify permission To Text Yes radio button displayed .
	 * 
	 * @throws ScriptException
	 */
	public void verifypermissionToTextYes() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_YES
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.PERMISSIONTOTEXT_YES);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PERMISSIONTOTEXT_YES_NOTFOUND);
		}
	}

	/**
	 * verify permission To Text No radio button displayed .
	 * 
	 * @throws ScriptException
	 */
	public void verifypermissionToTextNo() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_NO
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.PERMISSIONTOTEXT_NO);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PERMISSIONTOTEXT_NO_NOTFOUND);
		}
	}

	/**
	 * verify permission To Text DidNotAsk radio button displayed .
	 * 
	 * @throws ScriptException
	 */
	public void verifypermissionToTextDidNotAsk() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_DIDNOTASK
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.PERMISSIONTOTEXT_DIDNOTASK);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PERMISSIONTOTEXT_DIDNOTASK_NOTFOUND);
		}
	}

	/**
	 * Enter SSN number in Add Member(s) page.
	 * 
	 * @throws ScriptException
	 */
	public void enterHHSSN() throws ScriptException {
		if ((AddIndividualPageObjects.WidgetInfos.TEXT_SSN).exists()) {
			TextField hhSSN = new TextField("id=ssn0");
			setTextInTextbox(hhSSN, clientE2ETO.getHhSSN(),
					clientE2ETO.getHhSSN() + MessageUtility.SSN1);
		} else {
			Verify.verifyTrue(false, MessageUtility.SSN_NOTDISPLAYED);
		}
	}

	/**
	 * Enter SIN number in Add Member(s) page.
	 * 
	 * @throws ScriptException
	 */
	public void enterHHSIN() throws ScriptException {
		if ((AddIndividualPageObjects.WidgetInfos.TEXT_SIN).exists()) {
			TextField hhSIN = new TextField("id=sin0");
			setTextInTextbox(hhSIN, clientE2ETO.getHhSIN(),
					clientE2ETO.getHhSIN() + MessageUtility.SIN);
		} else {
			Verify.verifyTrue(false, MessageUtility.SIN_NOTDISPLAYED);
		}
	}

	/**
	 * click Proceed with Cancel Button.
	 * 
	 * @throws ScriptException
	 */
	public void clickProceedwithCancelButton() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.SPAN_PROCEEDWITHCANCEL
				.exists()) {

			CreateIndividualCustomer.WidgetInfos.SPAN_PROCEEDWITHCANCEL.click();
			Verify.verifyTrue(true, MessageUtility.BUTTON_CANCELWITHPROCEED);
		} else
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_CANCELWITHPROCEED_NOTDIOSPLAYED);
	}

	/**
	 * Select Organization Type in Create Organization customer page.
	 * 
	 * @throws ScriptException
	 */
	public void selectOrganizationType() throws ScriptException {

		WebElement organizationType = getWebDriverInstance()
				.findElement(
						By.xpath("//div[@id='scrollableArea']/fieldset/div/fieldset/div/span/div/div/div[1]/input"));
		organizationType.click();
		waitForTime(2);
		getWebDriverInstance()
				.findElement(
						By.xpath("//div[@class='dijitPopup dijitComboBoxMenuPopup']/ul/li[5]"))
				.click();
		Verify.verifyTrue(true, MessageUtility.ORGANIZATIONTYPE);
	}

	/**
	 * Enter Tax Id Number in Create Organization customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterTaxIdNumberOrg() throws ScriptException {
		waitForTime(3);
		if (clientE2ETO.getTaxIdNumber() != null) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_TAXIDNUMBER,
					clientE2ETO.getTaxIdNumber(), MessageUtility.TAXID_VALUE);
		}
	}

	/**
	 * Select State from add address pop up window.
	 * 
	 * @throws ScriptException
	 */
	/**
	 * click Create Individual Customer link in Customer search page.
	 * 
	 * @throws ScriptException
	 */
	public void clickCreateIndividualCustomer() throws ScriptException {
		waitForPageLoad(
				CreateIndividualCustomer.WidgetInfos.LINK_QB_CREATEINDIVIDUALCUSTOMER,
				40);
		if ((CreateIndividualCustomer.WidgetInfos.LINK_QB_CREATEINDIVIDUALCUSTOMER)
				.exists()) {
			click(CreateIndividualCustomer.WidgetInfos.LINK_QB_CREATEINDIVIDUALCUSTOMER,
					MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_NOTFOUND);
		}
	}

	public void clickCreateIndividualCustomerCRC() throws ScriptException {

		setCRCTopFrame();
		waitForPageLoad(
				CreateIndividualCustomer.WidgetInfos.LINK_QB_CREATEINDIVIDUALCUSTOMER,
				10);
		if ((CreateIndividualCustomer.WidgetInfos.LINK_QB_CREATEINDIVIDUALCUSTOMER)
				.exists()) {
			click(CreateIndividualCustomer.WidgetInfos.LINK_QB_CREATEINDIVIDUALCUSTOMER,
					MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_NOTFOUND);
		}
	}

	/**
	 * Verify Mobile Calling Preference link in Create Individual/Organization
	 * customer page.
	 * 
	 * @throws ScriptException
	 */
	public void verifyMobileCallingPreference() throws ScriptException {
		try {
			if ((CreateIndividualCustomer.WidgetInfos.LINK_MOBILE_CALLING_PREFERENCE)
					.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_MOBILECALLINGPREFERENCE_CLICKED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_MOBILECALLINGPREFERENCE_NOTCLICKED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}

	/**
	 * validate Permission To Text for Fax Phone.
	 * 
	 * @throws ScriptException
	 */
	public void validatePermissionToTextInFaxPhone() throws ScriptException {
		Div DIV_PTT_HOME = new Div("id=faxPhoneWrapper");
		if (!DIV_PTT_HOME.getText().contains("Permission to text:")) {
			Verify.verifyTrue(true,
					MessageUtility.PERMISSIONTOTEXT_NOTDISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.PERMISSIONTOTEXT_DISPLAYED);
		}
	}

	/**
	 * remove Phone number in CustomerInfo page.
	 * 
	 * @param phoneToRemove
	 */
	public void removePhoneCustomerInfo_CRC(String phoneToRemove) {
		int count = 1;
		boolean flag = false;
		while (true) {
			flag = getWebDriverInstance()
					.findElement(
							By.xpath("//div[@id='gridPhones']/div[2]/div/div/div/div/div/table/tbody/tr["
									+ count + "]/td[2]/a")).isDisplayed();
			if (flag) {
				String phone = getWebDriverInstance()
						.findElement(
								By.xpath("//div[@id='gridPhones']/div[2]/div/div/div/div/div/table/tbody/tr["
										+ count + "]/td[2]")).getText();
				System.out.println("phone number:" + phone);
				if (phone.contains(phoneToRemove)) {
					getWebDriverInstance()
							.findElement(
									By.xpath("//div[@id='gridPhones']/div[2]/div/div/div/div/div/table/tbody/tr["
											+ count + "]/td[2]/a")).click();
					setIFrame();
					waitForPageLoad(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
							5);
					if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
							.exists()) {
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
								.click();
						Verify.verifyTrue(true,
								MessageUtility.BUTTON_REMOVE_CLICKED);
						isErrorPage("Remove Phone");
						break;
					}
				}
				count++;
			} else {
				Verify.verifyTrue(false, MessageUtility.REMOVEPHONE_NOTFOUND);
				break;
			}
		}
		setCRCDefaultFrame();
	}

	public void removePhoneCustomerInfo(String phoneToRemove) {
		int count = 1;
		while (true) {
			WebElement element = getWebDriverInstance().findElement(
					By.xpath("//div[@id='gridPhones']/div/div/div/div/div/div["
							+ count + "]/table/tbody/tr/td[2]/a"));
			if (element.isDisplayed()) {
				String phone = element.getText();
				if (phone.contains(phoneToRemove)) {
					WebElement removePhone = getWebDriverInstance()
							.findElement(
									By.xpath("//div[@id='gridPhones']/div/div/div/div/div/div["
											+ count
											+ "]/table/tbody/tr/td[5]/a"));
					removePhone.click();
					setIFrame();
					waitForPageLoad(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
							5);
					if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
							.exists()) {
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
								.click();
						Verify.verifyTrue(true,
								MessageUtility.BUTTON_REMOVE_CLICKED);
						isErrorPage("Remove Phone");
						setTopFramewithDefaultContent();
						break;
					}

				}
				count++;
			} else {
				Verify.verifyTrue(false, MessageUtility.REMOVEPHONE_NOTFOUND);
				break;
			}
		}
	}

	/**
	 * Enter SIN number in Create Individual customer page.
	 * 
	 * @throws ScriptException
	 */
	public void enterSIN() throws ScriptException {
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_SIN.exists()) {
			setTextInTextbox(SSNSINObjects.WidgetInfos.TEXTFIELD_SIN,
					clientE2ETO.getSinNum(), MessageUtility.SIN);
			Verify.verifyTrue(true, clientE2ETO.getSinNum()
					+ MessageUtility.SIN);
		} else {
			Verify.verifyTrue(false, MessageUtility.SIN_NOTDISPLAYED);
		}
	}

	/**
	 * Enter SIN number in Customer Information page.
	 * 
	 * @throws ScriptException
	 */
	public void enterSINPersonalInfo() throws ScriptException {
		waitForPageLoad(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN,
				10);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN
				.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN,
					clientE2ETO.getSinNum(), MessageUtility.SIN);
		} else {
			waitForPageLoad(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN,
					10);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN
					.exists()) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN,
						clientE2ETO.getSinNum(), MessageUtility.SIN);
			} else {
				Verify.verifyTrue(false, MessageUtility.SIN_NOTDISPLAYED);
			}
		}
	}

	/**
	 * Enter SSN number in Customer Information page.
	 * 
	 * @throws ScriptException
	 */
	public void enterSSNPersonalInfo() throws ScriptException {
		waitForPageLoad(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN,
				10);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN
				.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN,
					clientE2ETO.getSsnNum(), MessageUtility.SSN);
		} else {
			waitForPageLoad(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN,
					15);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN
					.exists()) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN,
						clientE2ETO.getSsnNum(), MessageUtility.SSN);

			} else {
				Verify.verifyTrue(false, MessageUtility.SSN_NOTDISPLAYED);
			}
		}
	}

	/**
	 * Enter SSN/SIN number's in Customer Information page.
	 * 
	 * @throws ScriptException
	 */
	public void verifySSNAndSINinPersonalInfopage() throws ScriptException {
		waitForPageLoad(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN,
				10);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN
				.exists()) {
			String ssnValue = Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN
					.getText();
			String ssnSubStringApp = ssnValue.substring(7);
			String ssnSubStringMdb = clientE2ETO.getSsnNum().substring(5);
			if (ssnSubStringApp.equalsIgnoreCase(ssnSubStringMdb)) {
				Verify.verifyTrue(true, MessageUtility.SSN_PARTIALMASKED);
			}
		} else {
			Verify.verifyTrue(true, MessageUtility.SSN_NOTPARTIALMASKED);
			waitForPageLoad(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN,
					15);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN
					.exists()) {
				String ssnValue = Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN
						.getText();
				String ssnValueMdb = clientE2ETO.getSsnNum();
				if (ssnValue.equalsIgnoreCase(ssnValueMdb)) {
					Verify.verifyTrue(true, MessageUtility.SSN);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.SSN_NOTPARTIALMASKED);
			}
		}

		waitForPageLoad(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN,
				10);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN
				.exists()) {
			String sinValue = Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN
					.getText();
			if (sinValue.equals("XXX-XX-XXXX")) {
				Verify.verifyTrue(true, MessageUtility.SIN_FULLYMASKED);
			}
		} else {
			Verify.verifyTrue(true, MessageUtility.SIN_NOTFULLYMASKED);
			waitForPageLoad(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN,
					10);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN
					.exists()) {
				String ssnValueMdb = clientE2ETO.getSinNum();
				String sinValue = Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN
						.getText();
				if (sinValue.equalsIgnoreCase(ssnValueMdb)) {
					Verify.verifyTrue(true, MessageUtility.SIN);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.SIN_NOTFULLYMASKED);
			}
		}
	}

	/**
	 * Clear SSN number in Customer Information page.
	 * 
	 * @throws ScriptException
	 */
	public void clearSSNPersonalInfo() throws ScriptException {
		waitForPageLoad(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN,
				10);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN
				.exists()) {
			Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN
					.clearText();
			Verify.verifyTrue(true, "SSN value is cleared Successfully");
		} else {
			waitForPageLoad(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN,
					15);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN
					.exists()) {
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN
						.clearText();
				Verify.verifyTrue(true, MessageUtility.SSN_CLEAR);
			} else {
				Verify.verifyTrue(false, MessageUtility.SSN_NOTCLEAR);
			}
		}
	}

	/**
	 * Clear SIN number in Customer Information page.
	 * 
	 * @throws ScriptException
	 */
	public void clearSINPersonalInfo() throws ScriptException {
		waitForPageLoad(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN,
				10);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN
				.exists()) {
			Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN
					.clearText();
			Verify.verifyTrue(true, MessageUtility.SIN_CLEAR);
		} else {
			waitForPageLoad(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN,
					10);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN
					.exists()) {
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN
						.clearText();
				Verify.verifyTrue(true, MessageUtility.SIN_CLEAR);
			} else {
				Verify.verifyTrue(false, MessageUtility.SIN_NOTCLEAR);
			}
		}
	}

	/**
	 * STEP 1 To verify that system allows US Agent to i) create a client with
	 * US SSN and CN SIN through create individual page ii) update US SSN and CN
	 * SIN to valid value iii) update US SSN and CN SIN to null iv) update US
	 * SSN and CN SIN fields from null to valid value
	 * 
	 * @param updateTasks
	 * @param scenarioTasks
	 * @throws ScriptException
	 */
	public void createCustomerAndAddUpdateSSNAndSIN() throws ScriptException {
		if (clientE2ETO.getType().equalsIgnoreCase("createCustSSNSIN")
				|| clientE2ETO.getType().equalsIgnoreCase(
						"createCustSSNSINcanada")) {
			String SSNSIN = clientE2ETO.getType();
			createIndividualCustomerWithSSNAndSIN(SSNSIN);

		}
		if (clientE2ETO.getType().equalsIgnoreCase("addSSNSIN")) {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldTestObjects.WidgetInfos.CUSTOMER_LINK,
						HouseHoldTestObjects.WidgetInfos.LINK_HHCUSTOMERINFO);
				isCustomerInfoPageExists();
				clickUpdatePersonalInfo();
				enterSSNPersonalInfo();
				enterSINPersonalInfo();
				verifySSNAndSINinPersonalInfopage();
				clickSaveButton();
				setTopFrame();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		}
		if (clientE2ETO.getType().equalsIgnoreCase("clearSSNSIN")) {
			if (isCustomerInfoPageExists()) {
				clickUpdatePersonalInfo();
				clearSSNPersonalInfo();
				clearSINPersonalInfo();
				clickSaveButton();
				setTopFrame();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		}
		if (clientE2ETO.getType().equalsIgnoreCase("updateSSNSIN")) {
			if (isCustomerInfoPageExists()) {
				clickUpdatePersonalInfo();
				waitForPageLoad(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN,
						30);
				enterSSNPersonalInfo();
				enterSINPersonalInfo();
				clickSaveButton();
				setTopFrame();
				waitForTime(5);
				clickHHPageCustomer();
				handleCimsVersion();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		}
	}

	/**
	 * STEP 3: To verify that system allows US Agent to i) add a member to
	 * household with US SSN and CN SIN
	 * 
	 * @param updateTasks
	 * @param scenarioTasks
	 * @throws ScriptException
	 */
	public void enterSSNAndSINaddInd() throws ScriptException {
		if (clientE2ETO.getType().equalsIgnoreCase("SSNSINAddInd")) {
			if (isHHPageLaunched()) {
				clickMemberActionsAddIndPage();
				setWindow(EndToEndConstants.ADDMEMBERS, 10, 1);
				handleCimsVersion();
				isAddIndMembersPageLaunched();
				enterHHFirstName();
				enterHHLastName();
				enterHHSSN();
				enterHHSIN();
				selectAddAddress();
				clickCreateMember();
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 40, 1);
				isHHPageLaunched();
				refreshHHPage();
				isHosuseHoldPageLaunchedOrNot();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		}
	}

	/**
	 * verify Search Book In Customer Search Page for Shared Agent.
	 * 
	 * @throws ScriptException
	 */

	public void verifySearchBookInCSPageSharedAgent() throws ScriptException {

		waitForPageLoad(CreateIndividualCustomer.WidgetInfos.DIV_SEARCH_BOOK,
				30);
		if ((CreateIndividualCustomer.WidgetInfos.DIV_SEARCH_BOOK).exists())
			Verify.verifyTrue(true, MessageUtility.AGENTCODE_DISPLAYED);
		else
			Verify.verifyTrue(false, MessageUtility.AGENTCODE_NOTDISPLAYED);

	}

	public void createIndividualCustomerCRC() {

		try {

			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 10);
			setCRCDefaultFrame();
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				enterNameAndAddressCreateIndividual();
				clickCreateCustomers();
				verifyAddressStandzation();
				waitForTime(6);
				clickContinueButtonIfExists();
				setCRCDefaultFrame();
				verifyHouseholdPageLaunched();
				

			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {

			scriptError(e);

		} catch (Exception e) {

			Verify.verifyTrue(false, e.getMessage());

		}

	}

	/**
	 * Enter SIN in Add Individual Member(s) Page.
	 * 
	 * @throws ScriptException
	 */

	public void enterSINinAddIndPage() throws ScriptException {
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_SIN_MEMBER.exists()) {
			setTextInTextbox(SSNSINObjects.WidgetInfos.TEXTFIELD_SIN_MEMBER,
					clientE2ETO.getSinNum(), clientE2ETO.getSinNum()
							+ MessageUtility.SIN);
			SSNSINObjects.WidgetInfos.TEXTFIELD_SIN_MEMBER.click();
		} else
			Verify.verifyTrue(false, MessageUtility.SIN_NOTDISPLAYED);
	}

	/**
	 * Enter SSN in Add Individual Member(s) Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterSSNinAddIndPage() throws ScriptException {
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_SSN_MEMBER.exists()) {
			setTextInTextbox(SSNSINObjects.WidgetInfos.TEXTFIELD_SSN_MEMBER,
					clientE2ETO.getSsnNum(), clientE2ETO.getSsnNum()
							+ MessageUtility.SSN);
			SSNSINObjects.WidgetInfos.TEXTFIELD_SSN_MEMBER.click();
		} else
			Verify.verifyTrue(false, MessageUtility.SSN_NOTDISPLAYED);
	}

	/**
	 * Enter lastName/firstName/Address in Add Individual Member(s) Page.
	 * 
	 * @throws ScriptException
	 */
	public void addAdditionalIndividualMember() throws ScriptException {
		waitForPageLoad(AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME);
		if ((AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME).exists()) {
			AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME.click();
			setTextInTextbox(
					AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME,
					clientE2ETO.getAddAddlIndFirstName(),
					clientE2ETO.getAddAddlIndFirstName()
							+ MessageUtility.FIRSTNAME_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);
		}
		if ((AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME).exists()) {
			AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME.click();
			setTextInTextbox(
					AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME,
					clientE2ETO.getAddAddlIndLastName(),
					clientE2ETO.getAddAddlIndLastName()
							+ MessageUtility.LASTNAME_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);
		}
		selectAddAddress();
	}

	/**
	 * Click Create Organization Customer link in customer search Page.
	 */
	public void clickCreateOrganizationCustomer() {
		try {
			if (CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGCUSTOMER
					.exists()) {
				try {
					click(CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGCUSTOMER,
							MessageUtility.LINK_CREATEORGANIZATION_CLICKED);
					isCreateOrganizationPageLaunched();
				} catch (Exception e) {
					Verify.verifyTrue(false,
							MessageUtility.LINK_CREATEORGANIZATION_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_CREATEORGANIZATION_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click Create Organization Customer link in customer search Page for CRC
	 */
	public void clickCreateOrganizationCustomer_CRC() {
		try {
			if (CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGCUSTOMER
					.exists()) {
				try {
					click(CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGCUSTOMER,
							MessageUtility.LINK_CREATEORGANIZATION_CLICKED);
					isCreateOrganizationPageLaunched_CRC();
				} catch (Exception e) {
					Verify.verifyTrue(false,
							MessageUtility.LINK_CREATEORGANIZATION_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_CREATEORGANIZATION_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * verify SSN number in Customer Information page.
	 * 
	 * @throws ScriptException
	 */
	public void verifySSNinCustomerInfopage() throws ScriptException {
		waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL, 10);
		if (Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL.exists()) {
			String masked = "XXX-XX-" + clientE2ETO.getSsnNum().substring(5);
			String unMasked = clientE2ETO.getSsnNum().substring(0, 3) + "-"
					+ clientE2ETO.getSsnNum().substring(3, 5) + "-"
					+ clientE2ETO.getSsnNum().substring(5);
			TextField maskedSSN = new TextField("value=" + masked);
			TextField unMaskedSSN = new TextField("value=" + unMasked);
			if (maskedSSN.exists() || unMaskedSSN.exists())
				Verify.verifyTrue(true, MessageUtility.SSN_DISPLAYED);
			else
				Verify.verifyTrue(false, MessageUtility.SSN_NOTDISPLAYED);
		} else
			Verify.verifyTrue(false, MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
	}

	/**
	 * Click Create Individual Customer link in customer search Page for agent.
	 */
	public void clickCreateIndividual() {
		try {
			waitForTime(4);
			/*if (CreateIndividualCustomer.WidgetInfos.LINK_ABSCREATE_INDIVIDUAL
					.exists()) {
				click(CreateIndividualCustomer.WidgetInfos.LINK_ABSCREATE_INDIVIDUAL,
						MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_CLICKED);
				isCreateIndividualPageLaunched();
			}*/
			if (CreateIndividualCustomer.WidgetInfos.LINK_CREATE_INDIVIDUAL
					.exists()) {
				CreateIndividualCustomer.WidgetInfos.LINK_CREATE_INDIVIDUAL.click();
				/*click(CreateIndividualCustomer.WidgetInfos.LINK_CREATE_INDIVIDUAL,
						MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_NOTFOUND);*/
				isCreateIndividualPageLaunched();
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click Create Individual Customer link in customer search Page for
	 * ProdTeamPortal.
	 */
	public void clickCreateIndividualProdTeamPortal() {
		try {
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_CREATE_INDIVIDUAL,
					15);
			if (CreateIndividualCustomer.WidgetInfos.LINK_CREATE_INDIVIDUAL
					.exists()) {
				click(CreateIndividualCustomer.WidgetInfos.LINK_CREATE_INDIVIDUAL,
						MessageUtility.LINK_CREATEINDIVIDUALCUSTOMER_CLICKED);
				setWindow(EndToEndConstants.CREATE_INDIVIDUAL_PORTAL, 15, 2);
				isErrorPage("Create Individual");
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click Create Organization Customer link in customer search Page for
	 * Support Write.
	 */
	public void clickCreateOrganizationSupportWritePortal() {
		try {
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGANIZATION,
					15);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGANIZATION
					.exists()) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGANIZATION,
						MessageUtility.LINK_CREATEORGANIZATION_CLICKED);
				setWindow(EndToEndConstants.CIMS_VERSION, 15, 2);
				isErrorPage("Create Individual");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_CREATEORGANIZATION_NOTFOUND);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	public void validateErrorMessages_SSNCombine() throws ScriptException {
		waitForPageLoad(Update_Misc_Objects.WidgetInfos.DIV_MESSAGE_SUMMARY, 20);
		if (Update_Misc_Objects.WidgetInfos.DIV_MESSAGE_SUMMARY.exists()) {
			WebElement errorMessage = getWebDriverInstance().findElement(
					By.cssSelector("div#messageSummary ul>li"));
			String actualErrorMessage = errorMessage.getText();
			String expectedErrorMessage = clientE2ETO.getErrorMessageOne()
					+ clientE2ETO.getErrorMessageTwo();
			if (expectedErrorMessage.equalsIgnoreCase(actualErrorMessage)) {
				Verify.verifyTrue(true, expectedErrorMessage
						+ MessageUtility.ERRORMESSAGE_DISPLAYED);
			} else {
				Verify.verifyTrue(false, expectedErrorMessage
						+ MessageUtility.ERRORMESSAGE_NOTDISPLAYED);
			}
		} else {
			Verify.verifyTrue(false, "The Error Message is not displayed");
		}
	}

	/**
	 * Clear SSN Number.
	 * 
	 * @throws ScriptException
	 */
	public void clearSSN() throws ScriptException {
		SSNSINObjects.WidgetInfos.TEXTFIELD_SSN_MEMBER.clearText();
	}

	/**
	 * Clear SIN Number.
	 * 
	 * @throws ScriptException
	 */
	public void clearSIN() throws ScriptException {
		SSNSINObjects.WidgetInfos.TEXTFIELD_SIN_MEMBER.clearText();
	}

	/**
	 * Enter Invalid SSN In PersonalInfo Section in customer information page.
	 * 
	 * @throws ScriptException
	 */

	public void enterInvalidSSNInPersonalInfoSection() throws ScriptException {
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_US_SSN.exists()) {
			setTextInTextbox(SSNSINObjects.WidgetInfos.TEXTFIELD_US_SSN,
					clientE2ETO.getUsSSN(), clientE2ETO.getUsSSN()
							+ MessageUtility.USSSN_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.USSSN_NOTFOUND);
		}
	}

	/**
	 * Enter Invalid SIN In PersonalInfo Section in customer information page.
	 * 
	 * @throws ScriptException
	 */
	public void enterInvalidSINInPersonalInfoSection() throws ScriptException {
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_SIN.exists()) {
			setTextInTextbox(SSNSINObjects.WidgetInfos.TEXTFIELD_SIN,
					clientE2ETO.getCnSIN(), clientE2ETO.getCnSIN()
							+ MessageUtility.CNSIN_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.CNSIN_NOTFOUND);
		}
	}

	/**
	 * Launch Verify Info Page for separate functionality.
	 * 
	 * @throws ScriptException
	 */
	public void launchVerifInfoPage() throws ScriptException {
		if (CustomerSeparateAppObj.WidgetInfos.LINK_NEXT.exists()) {
			click(CustomerSeparateAppObj.WidgetInfos.LINK_NEXT,
					MessageUtility.LINK_NEXT);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_NEXT_NOTCLICKED);
		}
	}

	/**
	 * Select Radio Button for Birth Date/SSN/Marital
	 * status/Citizenship/TaxIDP/Death Date/Org type in Conflicting customer
	 * information page.
	 * 
	 * @throws ScriptException
	 */
	public void accessConflictInfoPageAllowedValuesSecondRadioButton()
			throws ScriptException {
		waitForPageLoad(
				ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE,
				20);
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.CONFLICTPAGE_LOADED);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE
				.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE2,
					MessageUtility.DOB);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN.exists()) {

			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN3,
					MessageUtility.SSN);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS
				.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS,
					MessageUtility.MARRITALSTATUS);
			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_CITIZENSHIP
					.exists()) {
				if (clientE2ETO.getCitizenshipAllowedValues() != null
						&& clientE2ETO.getCitizenshipAllowedValues().length() > 1) {
					if (clientE2ETO.getCitizenshipAllowedValues() != null)
						selectRadioButton(
								ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_CITIZENSHIP,
								MessageUtility.CITIZENSHIP);
				}
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_LANGUAGE
						.exists()) {
					if (clientE2ETO.getPreferredLanguagesAllowedValues() != null
							&& clientE2ETO.getPreferredLanguagesAllowedValues()
									.length() > 1) {
						if (clientE2ETO.getPreferredLanguagesAllowedValues() != null)
							selectRadioButton(
									ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_LANGUAGE,
									MessageUtility.LANGUAGE);
					}
					if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_TAXID
							.exists()) {
						selectRadioButton(
								ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_TAXID,
								MessageUtility.TAXIDP);
					}
					if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_DEATHDATE
							.exists()) {
						selectRadioButton(
								ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_DEATHDATE,
								MessageUtility.DEATHDATE);
					}
					if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_ORGTYPE
							.exists()) {
						selectRadioButton(
								ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_ORGTYPE,
								MessageUtility.ORGANIZATIONTYPE);
					}
				}
			}
		}
	}

	/**
	 * Launch Verify Info Page from Conflicting customer information page.
	 * 
	 * @throws ScriptException
	 */
	public void launchVerifyInfoPage() throws ScriptException {
		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.LINK_NEXT, 20);
		if (ConflictCustomerInfoAppObj.WidgetInfos.LINK_NEXT.exists()) {
			click(ConflictCustomerInfoAppObj.WidgetInfos.LINK_NEXT,
					MessageUtility.LINK_NEXT);
		} else {
			Verify.verifyTrue(false, MessageUtility.CONFLICTPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * Click Add Individual link from member action drop down.
	 * 
	 * @throws ScriptException
	 */
	public void clickMemberActionsAddIndPage() throws ScriptException {

		Div memberActionsDropDown = new Div("id=hhMembersTitleDropdown");
		memberActionsDropDown.click();
		Link addIndividual = new Link("id=hh_members_title_action1");
		addIndividual.click();
		waitForTime(5);
		Verify.verifyTrue(true, MessageUtility.LINK_ADDINDIVIDUAL);
	}

	/**
	 * Click Update Personal Info link from Customer info page.
	 */
	public void clickUpdatePersonalInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(
						Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL, 10);
				if ((Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL)
						.exists()) {
					click(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL,
							MessageUtility.LINK_UPDATEPERSONALINFO);
					setIFrame();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.LINK_UPDATEPERSONALINFO_NOTFOUND);
				}

			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}

	/**
	 * Verify Search Book In Customer Search page for SingleAgent.
	 * 
	 * @throws ScriptException
	 */
	public void verifySearchBookInCSPageSingleAgent() throws ScriptException {
		waitForPageLoad(CreateIndividualCustomer.WidgetInfos.DIV_SEARCH_BOOK,
				15);
		if (!(CreateIndividualCustomer.WidgetInfos.DIV_SEARCH_BOOK).exists()) {
			Verify.verifyTrue(true, MessageUtility.AGENTCODE_NOTDISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.AGENTCODE_DISPLAYED);
		}
	}

	/**
	 * Enter SIN for second customer in Separate Customer Page.
	 * 
	 * @throws ScriptException
	 */
	public void setSINToCustomerTwo() throws ScriptException {
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_NEWCLIENTSIN.exists()) {
			setTextInTextbox(SSNSINObjects.WidgetInfos.TEXTFIELD_NEWCLIENTSIN,
					clientE2ETO.getSinTwo(), clientE2ETO.getSinTwo()
							+ MessageUtility.CNSIN_CUSTTWO);
		} else {
			Verify.verifyTrue(false, MessageUtility.CNSIN_CUSTTWO_NOTFOUND);
		}
	}

	/**
	 * create Individual Customer customer with mandatory fields.
	 */
	public void createIndividualCustomer() {
		try {
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 25);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				enterNameAndAddressCreateIndividual();
				clickCreateCustomers();
				clickPrivacyOptionWordTrack();
				verifyAddressStandzation();
				clickContinueButtonIfExists();
				verifyHouseholdPageLaunched();
				//verifyAddedIndCustomer(clientE2ETO.getLastName().toUpperCase());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * create Individual Customer customer with SSN/SIN.
	 * 
	 * @throws ScriptException
	 * @param SSNSIN
	 */
	public void createIndividualCustomerWithSSNAndSIN(String SSNSIN)
			throws ScriptException {
		try {
			waitForTime(3);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				if (SSNSIN.equalsIgnoreCase("createCustSSNSIN")) {
					enterNameAndAddressCreateIndividual();
				}
				if (SSNSIN.equalsIgnoreCase("createCustSSNSINCanada")) {
					enterNameAndAddressCreateIndividualCanada();
				}
				enterSSN();
				enterSIN();
				clickCreateCustomers();
				verifyAddressStandzation();
				handleCimsVersion();
				isHouseholdPageLaunched();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Fill Mobile phone in Create Individual
	 * 
	 * @throws ScriptException
	 */
	public void creatIndCustMobilePhoneData() throws ScriptException {
		waitForPageLoad(
				CreateIndividualCustomer.WidgetInfos.TEXT_CELLPHONE_Cpp, 10);
		if (CreateIndividualCustomer.WidgetInfos.TEXT_CELLPHONE_Cpp.exists()) {
			enterMobilePhoneNumberInd();
			verifyPermissionToTextOptions();
			permissionToText();
			clickMobileCallingPreference();
			selectCallingPrefDayMobile();
			selectCallingPrefFromTimeMobile();
			selectCallingPrefToTimeMobile();
		} else
			Verify.verifyTrue(false, MessageUtility.MOBILEPHONEINFO_NOTFOUND);
	}

	/**
	 * Fill Home phone in Create Individual
	 * 
	 * @throws ScriptException
	 */
	public void creatIndCustHomePhoneData() throws ScriptException {
		waitForPageLoad(CreateIndividualCustomer.WidgetInfos.TEXT_PERSON_PHONE,
				10);
		if (CreateIndividualCustomer.WidgetInfos.TEXT_PERSON_PHONE.exists()) {
			validatePermissionToTextInHomePhone();
			enterHomePhoneNumber();
			clickHomeCallingPreference();
			selectCallingPrefDayHome();
			selectCallingPrefFromTimeHomeInd();
			selectCallingPrefToTimeHomeInd();
		} else
			Verify.verifyTrue(false, MessageUtility.HOMEPHONEINFO_NOTFOUND);
	}

	/**
	 * Fill AdditionalPhone in Create Individual
	 * 
	 * @throws ScriptException
	 */
	public void creatIndCustAdditionalPhoneData() throws ScriptException {
		waitForPageLoad(
				CreateIndividualCustomer.WidgetInfos.TEXT_ADDITIONALPHONENUMBER,
				10);
		if (CreateIndividualCustomer.WidgetInfos.TEXT_ADDITIONALPHONENUMBER
				.exists()) {
			validatePermissionToTextInAdditionalPhone();
			selectAdditionalType();
			enterAdditionalPhoneNumber();
			clickAdditionalCallingPreference();
			selectCallingPrefDayaddtl();
			selectCallingPrefFromTimeAddtl();
			selectCallingPrefToTimeAdddtl();
		} else
			Verify.verifyTrue(false,
					MessageUtility.ADDITIONALPHONEINFO_NOTFOUND);
	}

	/**
	 * Fill Email Info in Create Individual
	 * 
	 * @throws ScriptException
	 */
	public void creatIndCustEmailData() throws ScriptException {
		waitForPageLoad(
				CreateIndividualCustomer.WidgetInfos.TEXT_INDEMAILADDRESS, 10);
		if (CreateIndividualCustomer.WidgetInfos.TEXT_INDEMAILADDRESS.exists()) {
			selectEmailTab();
			enterEmailAddress();
			setMarketingIndicator();
		} else
			Verify.verifyTrue(false, MessageUtility.EMAILINFO_NOTFOUND);
	}

	/**
	 * Enter HearAboutOffice/Mostimportanttoyou in Create Individual
	 * 
	 * @throws ScriptException
	 */
	public void creatIndCustMarketingInfo() throws ScriptException {
		waitForPageLoad(
				CreateIndividualCustomer.WidgetInfos.TEXT_HEARABOUTOFFICECODE,
				10);
		if (CreateIndividualCustomer.WidgetInfos.TEXT_HEARABOUTOFFICECODE
				.exists()) {
			selectHearAboutOfficeInd();
			selectMostimportanttoyouInd();
		} else
			Verify.verifyTrue(false, MessageUtility.MARKETINGINFO_NOTFOUND);
	}

	/**
	 * Create Individual Customer With Phone and Email.
	 */
	public void createIndividualCustomerWithPhoneEmailData_CRC() {
		try {
			setCRCDefaultFrame();
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 20);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				enterNameAndAddressCreateIndividual();
				creatIndCustMobilePhoneData();
				/*
				 * creatIndCustHomePhoneData();
				 * creatIndCustAdditionalPhoneData();
				 */
				creatIndCustEmailData();
				creatIndCustMarketingInfo();
				clickCreateCustomers();
				verifyAddressStandzation();
				isHouseholdPageLaunched();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	public void createIndividualCustomerWithPhoneEmailData() {
		try {
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 20);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				enterNameAndAddressCreateIndividual();
				creatIndCustMobilePhoneData();
				creatIndCustHomePhoneData();
				creatIndCustAdditionalPhoneData();
				creatIndCustEmailData();
				creatIndCustMarketingInfo();
				clickCreateCustomers();
				verifyAddressStandzation();
				isHouseholdPageLaunched();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * create Individual customer With Additional Members.
	 */
	public void createIndividualWithAdditionalMembers() {
		try {
			if (isPortalSearchPageExist() || isCustomerSearchPageExistsABS()) {
				clickCreateIndividual();
			}
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 25);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				enterNameAndAddressCreateIndividual();
				
				clickAddAdditionalIndividual();
				verifyAddressStandzation();
				waitForTime(4);
			}
			if (AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME
						.exists()) {
					verifySSNAddIndPage();
					addAdditionalIndividualMember();
					clickAddAdditionalOrganizationTab();
					if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HHADDITIONALORGANIZATIONNAME
							.exists()) {
						addAdditionalOrganizationCreate();
						clickCreateMember();
						verifyAddressStandzation();
						handleCimsVersion();
						isHouseholdPageLaunched();
					}
				
				validateAddedIndividualHouseHoldMember();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e); 
		}
		 catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter Name And Address in Create Individual customer page for us.
	 */
	public void enterNameAndAddressCreateIndividual() {
		try {
			waitForPageLoad(CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 25);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				launchBasicInfo();
				isBasicInfoPageLaunched();
				//fillAgentCode();
				fillAgent();
				enterFirstName();
				enterLastName();
				selectUSType();
				enterMailingStreet();
				enterMailingCity();
				selectMailingState();
				enterMailingZip();
				verifySSNAndSIN();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Enter Name And Address in Create Individual customer page for Canada.
	 */
	public void enterNameAndAddressCreateIndividualCanada() {
		try {
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 25);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				launchBasicInfo();
				isBasicInfoPageLaunched();
				fillAgentCode();
				enterFirstName();
				enterLastName();
				selectCanadaTypeForMailing();
				enterMailingStreet();
				enterMailingCity();
				selectMailingProvince();
				enterMailingZip();
				verifySSNAndSIN();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Verify Create Individual Customer Page Exists or not.
	 * 
	 * @throws ScriptException
	 * @return
	 */
	public boolean isCreateIndividualPageExists() throws ScriptException {
		waitForPageLoad(CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB,
				20);
		if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Verify add Individual members page Launched or not.
	 * 
	 * @throws ScriptException
	 * @return
	 */
	public boolean isAddIndMembersPageLaunched() throws ScriptException {
		waitForPageLoad(AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME, 30);
		if (AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME.exists())
			return true;
		else
			return false;
	}

	/**
	 * Create individual customer with SSN and SIN for us.
	 * 
	 * @param number
	 */
	public void validateSSNandSINforCreatedCustomer(String number) {
		try {
			if (isPortalSearchPageExist()) {
				clickCreateIndividual();
				enterNameAndAddressCreateIndividual();
				if (number.equalsIgnoreCase("SSN")) {
					enterSSN();
				} else if (number.equalsIgnoreCase("SIN")) {
					enterSIN();
				} else if (number.equalsIgnoreCase("Both")) {
					enterSSN();
					enterSIN();
				}
				clickCreateCustomers();
				verifyAddressStandzation();
				launchCustomerInfoPageFromHHPage();
				if (number.equalsIgnoreCase("SSN")) {
					verifySSNinCustomerInfopage();
				} else if (number.equalsIgnoreCase("SIN")) {
					verifySINnotDisplayedinCustomerInfopage();
				} else if (number.equalsIgnoreCase("Both")) {
					verifySSNinCustomerInfopage();
					verifySINnotDisplayedinCustomerInfopage();
				}
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 15, 2);
				navigateToSearchPageFromHH();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Create individual customer with SSN and SIN for Canada.
	 * 
	 * @param number
	 */
	public void validateSSNandSINforCreatedCustomerCanada(String number) {
		try {
			if (isPortalSearchPageExist()) {
				clickCreateIndividual();
				enterNameAndAddressCreateIndividualCanada();
				if (number.equalsIgnoreCase("SSN")) {
					enterSSN();
				} else if (number.equalsIgnoreCase("SIN")) {
					enterSIN();
				} else if (number.equalsIgnoreCase("Both")) {
					enterSSN();
					enterSIN();
				}
				clickCreateCustomers();
				verifyAddressStandzation();
				launchCustomerInfoPageFromHHPage();
				if (number.equalsIgnoreCase("SSN")) {
					verifySSNinCustomerInfopage();
				} else if (number.equalsIgnoreCase("SIN")) {
					verifySINnotDisplayedinCustomerInfopage();
				} else if (number.equalsIgnoreCase("Both")) {
					verifySSNinCustomerInfopage();
					verifySINnotDisplayedinCustomerInfopage();
				}
				clickHHPageCustomer();
				navigateToSearchPageFromHH();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Add individual customer with SSN and SIN from Household page.
	 * 
	 * @param number
	 * @throws ScriptException
	 */
	public void validateSSNandSINforAddedIndividual(String number)
			throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				clickMemberActionsAddIndPage();
				setWindow("Add Member(s)", 10, 2);
				if (!isErrorPage("Add Individual")) {
					enterHHFirstName();
					enterHHLastName();
					clickAndChooseSelectAddress();
					if (number.equalsIgnoreCase("SSN")) {
						enterSSNinAddIndPage();
					} else if (number.equalsIgnoreCase("SIN")) {
						enterSINinAddIndPage();
					} else if (number.equalsIgnoreCase("Both")) {
						enterSSNinAddIndPage();
						enterSINinAddIndPage();
					}

					clickNameFieldtoEnableCreateButton();
					clickCreateMember();
					isErrorPage("Add Individual");
					setWindow("Household Information", 30, 2);
					isHouseholdPageLaunched();
					refreshHHPage();
					verifyAddedIndOrgCustomerInHHPage(clientE2ETO
							.getHhFirstName().toUpperCase()
							+ " "
							+ clientE2ETO.getHhLastName().toUpperCase());
				} else {
					Verify.verifyTrue(false, MessageUtility.ADDINDIVIDUAL_FAIL);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Enter SSN and SIN in UpdatePersonelInfo from Customer info page.
	 * 
	 * @param number
	 */
	public void validateSSNandSINinUpdatePersonelInfo(String number) {
		try {
			setTopFramewithDefaultContent();
			if (isCustomerInfoPageExists()) {
				clickUpdatePersonalInfo();
				setIFrame();
				if (number.equalsIgnoreCase("SSN")) {
					enterSSNPersonalInfo();
				} else if (number.equalsIgnoreCase("SIN")) {
					enterSINPersonalInfo();
				} else if (number.equalsIgnoreCase("Both")) {
					enterSSNPersonalInfo();
					enterSINPersonalInfo();
				}
				clickSaveButton();
				// Need error page to modify this method
				// isErrorPage("Update Personel Info");
				if (number.equalsIgnoreCase("SSN")) {
					verifySSNinCustomerInfopage();
				} else if (number.equalsIgnoreCase("SIN")) {
					verifySINnotDisplayedinCustomerInfopage();
				} else if (number.equalsIgnoreCase("Both")) {
					verifySSNinCustomerInfopage();
					verifySINnotDisplayedinCustomerInfopage();
				}

			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Verify SIN not Displayed in Customer Info page.
	 * 
	 * @throws ScriptException
	 */
	public void verifySINnotDisplayedinCustomerInfopage()
			throws ScriptException {
		waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL, 10);
		if (Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL.exists()) {
			Div SIN = new Div("id=SIN");
			if (!SIN.exists())
				Verify.verifyTrue(true, MessageUtility.SIN_NOTDISPLAYED);
			else
				Verify.verifyTrue(false, MessageUtility.SIN_UNEXPECTED);
		} else
			Verify.verifyTrue(false, MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
	}

	/**
	 * Create Organization customer With Additional Members.
	 */

	public void createOrganizationWithAdditionalMembers() {
		try {
			if (isPortalSearchPageExist()) {
				clickCreateOrganization();
			}
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME,
					25);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME
					.exists()) {
				enterNameAndAddressCreateOrganizarion();
				clickAddAdditionalIndividual();
				verifyAddressStandzation();
				waitForPageLoad(
						AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME, 30);
				if (AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME
						.exists()) {
					setAddMemberDataIndividual();
					clickAddAdditionalOrganizationTab();
					if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HHADDITIONALORGANIZATIONNAME
							.exists()) {
						addAdditionalOrganizationCreate();
						clickCreateMember();
						waitForPageLoad(
								HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE,
								5);
						/** Validate House Hold Members with already Created */

						launchCMPageFromHHPage("innerText=Refresh/Close",
								"innerText=Refresh");
						isHouseholdPageLaunched();
					}
				}
				validateAddedOrganizationHouseHoldMember();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEORGANIZATIONPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter Name And Address for creating Organization customer.
	 * 
	 * @throws ScriptException
	 */

	public void enterNameAndAddressCreateOrganizarion() throws ScriptException {
		waitForPageLoad(
				CreateOrganizationCustomerAppObj.WidgetInfos.TEXTFIELD_ORG_NAME,
				25);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXTFIELD_ORG_NAME
				.exists()) {
			fillAgentCode();
			selectOrganizationType();
			fillOrgName();
			selectUSOrgType();
			enterMailingStreetOrg();
			enterMailingCityOrg();
			selectAddAddressStatProvMailing();
			enterMailingZipOrg();

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
		}
	}

	public void selectAddAddressStatProvMailing() throws ScriptException {

		getWebDriverInstance().findElement(
				By.xpath("//div[@id='widget_stateLabel[0]']/div")).click();
		waitForTime(3);
		getWebDriverInstance().findElement(By.id("stateLabel[0]_popup13"))
				.click();
	}

	/** Validate the ability to Create Individual customer Through HH Page */
	public void addAndVerifyIndCustFromMemberActions() {
		try {
			if (isHHPageLaunched()) {
				clickMemberActionsAddIndPage();
				setWindow(EndToEndConstants.ADDMEMBERS, 30, 2);
				if (!isErrorPage("Add Individual")) {
					addIndividual();
					setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 30, 2);
					setTopFramewithDefaultContent();
					refreshHHPage_SW();
					verifyAddedIndOrgCustomerInHHPage(clientE2ETO
							.getHhFirstName().toUpperCase()
							+ " "
							+ clientE2ETO.getHhLastName().toUpperCase());
				} else {
					Verify.verifyTrue(false, MessageUtility.ADDINDIVIDUAL_FAIL);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ADDINDIVIDUAL_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Validate the ability to Create Individual customer Through HH Page
	 * 
	 * @throws ScriptException
	 */
	public void addAndVerifyIndCustFromMemberActionsForAHQB()
			throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				clickMemberActionsAddIndPage();
				setWindow(EndToEndConstants.ADDMEMBERS, 30, 2);
				setCRCDefaultFrame();
				if (!isErrorPage("Add Individual")) {
					addIndividual();
					clickContinueButtonIfExists();
					isHouseholdPageLaunched();
					verifyAddedIndOrgCustomerInHHPage(clientE2ETO
							.getHhFirstName().toUpperCase()
							+ " "
							+ clientE2ETO.getHhLastName().toUpperCase());
				} else {
					Verify.verifyTrue(false, MessageUtility.ADDINDIVIDUAL_FAIL);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ADDINDIVIDUAL_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click Create Organization link.
	 */

	public void clickCreateOrganization() {
		try {
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGANIZATION,
					20);
			if ((CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGANIZATION)
					.exists()) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.LINK_CREATEORGANIZATION,
						MessageUtility.LINK_CREATEORGANIZATION_CLICKED);
				setWindow(EndToEndConstants.CREATE_ORAGANIZATION_AGENT, 15, 1);
				setTopFrame();
				isCreateOrganizationLaunched();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_CREATEORGANIZATION_NOTFOUND);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Validate Create Organization customer Page Launched or not.
	 * 
	 * @throws ScriptException
	 */
	public void isCreateOrganizationPageLaunched() throws ScriptException {

		setTopFramewithDefaultContent();
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.TEXTFIELD_ORG_NAME)
				.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CREATEORGANIZATIONPAGE_LAUNCHED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CREATEORGANIZATIONPAGE_NOTLAUNCHED);
		}
	}

	public void isCreateOrganizationPageLaunched_CRC() throws ScriptException {
		getWebDriverInstance().switchTo().defaultContent();
		getWebDriverInstance().switchTo().frame("TopFrame");
		setTopFrame();
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME)
				.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CREATEORGANIZATIONPAGE_LAUNCHED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CREATEORGANIZATIONPAGE_NOTLAUNCHED);
		}
	}

	/** Enter Org Type and Name */
	public void createOrgCustNameData() {
		try {
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGNAME,
					3);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGNAME
					.exists()) {
				selectOrganizationType();
				fillOrgName();
			} else
				Verify.verifyTrue(false, MessageUtility.NAMEINFO_NOTFOUND);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter Address
	 * 
	 * @throws ScriptException
	 */
	public void createOrgCustAddressData() throws ScriptException {
		waitForPageLoad(
				CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MCITY, 10);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MCITY.exists()) {
			selectUSTypeOrg();
			enterMailingStreetOrg();
			enterMailingCityOrg();
			selectMailingState();
			enterMailingZipOrg();
		} else
			Verify.verifyTrue(false, MessageUtility.ADDRESSINFO_NOTFOUND);
	}

	/**
	 * Create Organization Customer with Canada Address.
	 * 
	 * @throws ScriptException
	 */
	public void createOrgCustCanadaAddressData() throws ScriptException {
		waitForPageLoad(
				CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MCITY, 10);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MCITY.exists()) {
			selectCanadaTypeForMailing();
			enterMailingStreetOrg();
			enterMailingCityOrg();
			selectMailingState();
			enterMailingZipOrg();
		} else
			Verify.verifyTrue(false, MessageUtility.ADDRESSINFO_NOTFOUND);

	}

	/**
	 * Enter Mobile Phone Number
	 * 
	 * @throws ScriptException
	 */
	public void createOrgCustMobilePhoneData() throws ScriptException {
		waitForPageLoad(
				CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MOBILEPHONENUM,
				10);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_MOBILEPHONENUM
				.exists()) {
			clickPhoneTab();
			enterMobilePhoneNumOrg();
			permissionToText();
			verifypermissionToTextYes();
			verifypermissionToTextNo();
			verifypermissionToTextDidNotAsk();
			verifyMobileCallingPreference();
			clickMobileCallingPreferenceOrg();
			selectCellCallingPrefDayOrg();
			selectCellCallingPrefFromTimeOrg();
			selectCellCallingPrefToTimeOrg();
		} else
			Verify.verifyTrue(false, MessageUtility.MOBILEPHONEINFO_NOTFOUND);
	}

	/**
	 * Enter Fax Phone Number
	 * 
	 * @throws ScriptException
	 */
	public void createOrgCustFaxPhoneData() throws ScriptException {
		waitForPageLoad(
				CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_FAXPHONENUM,
				10);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_FAXPHONENUM
				.exists()) {
			validatePermissionToTextInFaxPhone();
			enterFaxPhoneNumberOrg();
			clickFaxCallingPreferenceOrg();
			selectFaxCallingPrefDayOrg();
			selectCallingPrefFromTimeFaxOrg();
			selectCallingPrefToTimeFaxOrg();
			selectFaxSpecificOrg();
		} else
			Verify.verifyTrue(false, MessageUtility.FAXPHONEINFO_NOTFOUND);
	}

	/** Enter Phone details for Additional Type phone */
	public void createOrgCustAdditionalPhoneData() {
		try {
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDITIONALPHONENUM,
					10);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDITIONALPHONENUM
					.exists()) {
				validatePermissionToTextInAdditionalPhone();
				enterAdditionalPhoneNumberOrg();
				clickAdditionalCallingPreferenceOrg();
				selectAdditionalCallingPrefDayOrg();
				selectAdditionalCallingPrefFromTimeOrg();
				selectAdditionalCallingPrefToTimeOrg();
			} else
				Verify.verifyTrue(false,
						MessageUtility.ADDITIONALPHONEINFO_NOTFOUND);
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter Details Marketing Info
	 * 
	 * @throws ScriptException
	 */
	public void createOrgCustMarketingInfo() throws ScriptException {
		waitForPageLoad(
				CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HEARABOUTOFFICE,
				10);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HEARABOUTOFFICE
				.exists()) {
			selectHearAboutOfficeOrg();
			selectMostimportanttoyouOrg();
		} else
			Verify.verifyTrue(false, MessageUtility.MARKETINGINFO_NOTFOUND);
	}

	/**
	 * Create Organization Customer With Phone Data.
	 */
	public void createOrgCustomerWithPhoneData() {
		try {
			enterOrgNameAddressMobileAndEmail();
			clickCreateCustomers();
			verifyAddressStandzation();
			verifyAddedOrgCustomer(clientE2ETO.getOrganizationName());
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter Organization Name,Address,Mobile And Email for Creating
	 * Organization Customer.
	 */
	public void enterOrgNameAddressMobileAndEmail() {

		fillAgentCode();
		createOrgCustNameData();
		createOrgCustAddressData();
		createOrgCustMobilePhoneData();
		createOrgCustFaxPhoneData();
		createOrgCustAdditionalPhoneData();
		createOrgCustMarketingInfo();
	}

	/**
	 * Create Organization Customer With Phone And Email.
	 */
	public void createOrgCustomerWithPhoneDataAndEmail() {
		try {
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXTFIELD_ORG_NAME,
					5);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXTFIELD_ORG_NAME
					.exists()) {
				enterOrgNameAddressMobileAndEmail();
				fillEmailAddress();
				clickCreateCustomers();
				verifyAddressStandzation();
				handleCimsVersion();
				isHHPageLaunched();
				if (!isErrorPage(EndToEndConstants.CREATE_ORAGANIZATION))
					verifyAddedOrgCustomer(clientE2ETO.getOrganizationName());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEORGANIZATIONPAGE_NOTLAUNCHED);

			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Create Organization Customer With Name And Address.
	 */
	public void createOrgCustomerWithNameAddressData() {
		try {
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME,
					25);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME
					.exists()) {
				fillAgentCode();
				createOrgCustNameData();
				createOrgCustAddressData();
				clickCreateCustomers();
				verifyAddressStandzation();
				isErrorPage(EndToEndConstants.CREATE_ORAGANIZATION);
				handleCimsVersion();
				clickContinuetoHHifExists();
				verifyAddedOrgCustomer(clientE2ETO.getOrganizationName());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEORGANIZATIONPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Navigate To Customer Search Page From HH page.
	 */
	public void navigateToSearchPageFromHH() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(
						HouseHoldPageObjects.WidgetInfos.REFRESH_CLOSE_MENU,
						HouseHoldPageObjects.WidgetInfos.CLOSE);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
			setParentWindow();
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Enter Name and address details in add individual members page.
	 * 
	 * @throws ScriptException
	 */
	public void setAddMemberDataIndividual() throws ScriptException {
		waitForPageLoad(AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME);
		if ((AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME).exists()) {
			AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME.click();
			setTextInTextbox(
					AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME,
					"testFName", MessageUtility.FIRSTNAME_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);
		}
		if ((AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME).exists()) {
			AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME.click();
			setTextInTextbox(
					AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME,
					"testLName", MessageUtility.LASTNAME_VALUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);
		}
		selectAddAddress();

	}

	/**
	 * Verify searched customer Exist or not.
	 * 
	 * @throws ScriptException
	 * @return
	 */
	public boolean isSelectedOneCustomerExist() throws ScriptException {
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.DIV_SEARCH_RESULT, 30);
		boolean flag = false;
		if (SearchSelectCustomerAppObj.WidgetInfos.DIV_SEARCH_RESULT.exists()) {
			String searchandSelectOneCustomer = SearchSelectCustomerAppObj.WidgetInfos.DIV_SEARCH_RESULT
					.getText();
			if (searchandSelectOneCustomer.contains(clientE2ETO
					.getSS1CFirstCustomer()))
				flag = true;
			else
				flag = false;
		}
		return flag;
	}

	/**
	 * Verify Separate Customer Page Launched or not.
	 * 
	 * @return
	 */
	public boolean isSeparateCustomerPageLaunched() {
		waitForPageLoad(
				CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEALLNAME,
				20);
		if (CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEALLNAME
				.exists())
			return true;
		else
			return false;
	}

	/**
	 * Fill Mobile Phone,Work Phone,Additional Phone,Email data in Create
	 * Organization Customer
	 */
	public void createOrgCustWithMobileWorkAdditionalEmailData() {
		try {
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME,
					25);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME
					.exists()) {
				fillAgentCode();
				createOrgCustNameData();
				createOrgCustAddressData();
				createOrgCustMobilePhoneData();
				enterBusinessPhoneNum();
				createOrgCustAdditionalPhoneData();
				fillOrgEmailAddressInformation();
				clickCreateCustomers();
				verifyAddressStandzation();
				isHouseholdPageLaunched();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEORGANIZATIONPAGE_NOTLAUNCHED);

			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Fill Mobile Phone,Work Phone,Additional Phone,Email data in Create
	 * Organization Customer for CRC
	 */
	public void createOrgCustWithMobileWorkAdditionalEmailData_CRC() {
		try {
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME,
					25);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ORGANIZATIONNAME
					.exists()) {
				fillAgentCode();
				createOrgCustNameData();
				createOrgCustAddressData();
				createOrgCustMobilePhoneData();
				enterBusinessPhoneNum();
				createOrgCustAdditionalPhoneData();
				fillOrgEmailAddressInformation();
				clickCreateCustomers();
				verifyAddressStandzation();
				setCRCDefaultFrame();
				clickContinueButtonIfExists();
				isHouseholdPageLaunched();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEORGANIZATIONPAGE_NOTLAUNCHED);

			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Fill Email Address in Create Organization Customer page.
	 */
	public void fillOrgEmailAddressInformation() {
		try {
			clickEmailTab();
			fillEmailAddress();
			selectEmailAddressForMarketingYes();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Create Individual Customer With Phone And Email.
	 */
	public void createIndividualCustomerWithPhoneAndEmail() {
		try {
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 25);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				verifySSNAndSIN();
				enterNameAndAddressWithPhoneAndEmailCreateIndividual();
				clickCreateCustomers();
				verifyAddressStandzation();
				if (!isErrorPage("Household")) {
					handleCimsVersion();
					verifyHouseholdPageLaunched();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Create Individual Customer With Phone And Email.
	 */
	public void enterNameAndAddressWithPhoneAndEmailCreateIndividual()
			throws ScriptException {
		try {
			if (isCreateIndividualPageExists()) {
				enterNameAndAddressCreateIndividualSW();
				/*
				 * validatePermissionToTextHidden();
				 * enterMobilePhoneNumberInd(); if
				 * (CreateIndividualCustomer.WidgetInfos
				 * .RADIOBUTTON_PERMISSION_YES .exists()) {
				 * CreateIndividualCustomer
				 * .WidgetInfos.RADIOBUTTON_PERMISSION_YES.click(); }
				 * enterHomePhoneNumber(); enterAdditionalPhoneNumber();
				 * enterEmailAddress();
				 */
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Enter Name And Address for Creating Individual customer for SupportWrite.
	 */
	public void enterNameAndAddressCreateIndividualSW() {
		try {
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB, 25);
			if (CreateIndividualCustomer.WidgetInfos.LINK_BASICINFOTAB.exists()) {
				launchBasicInfo();
				isBasicInfoPageLaunched();
				fillAgentCode();
				enterFirstName();
				enterLastName();
				selectUSType();
				enterMailingStreet();
				enterMailingCity();
				selectMailingState();
				enterMailingZip();
				verifySSNAndSIN();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEINDIVIDUALPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Validate Error message for invalid SSN.
	 * 
	 * @throws ScriptException
	 */
	public void validateErrorMessages_SSNSeperate() throws ScriptException {
		waitForPageLoad(Update_Misc_Objects.WidgetInfos.DIV_MESSAGE_SUMMARY, 20);
		if (Update_Misc_Objects.WidgetInfos.DIV_MESSAGE_SUMMARY.exists()) {
			String actualErrorMessage = getWebDriverInstance().findElement(
					By.cssSelector("div#messageSummary ul>li")).getText();
			String expectedErrorMessage = clientE2ETO.getErrorMessageOne()
					+ clientE2ETO.getErrorMessageTwo();
			if (expectedErrorMessage.equalsIgnoreCase(actualErrorMessage)) {
				Verify.verifyTrue(true, expectedErrorMessage
						+ MessageUtility.ERRORMESSAGE_DISPLAYED);
			} else {
				Verify.verifyTrue(false, expectedErrorMessage
						+ MessageUtility.ERRORMESSAGE_NOTDISPLAYED);
			}
		} else {
			Verify.verifyTrue(false, "The Error Message is not displayed");
		}
	}

	/**
	 * Enter Invalid USSSN in Conflicting information page.
	 * 
	 * @throws ScriptException
	 */
	public void enterInvalidUSSSN_Combine() throws ScriptException {
		waitForPageLoad(SSNSINObjects.WidgetInfos.TEXTFIELD_USSSN_COMBINE, 20);
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_USSSN_COMBINE.exists())
			setTextInTextbox(SSNSINObjects.WidgetInfos.TEXTFIELD_USSSN_COMBINE,
					clientE2ETO.getUsSSN_Combine(), MessageUtility.SSN1);
	}

	/**
	 * Validate Create Organization customer page launched or not.
	 * 
	 * @throws ScriptException
	 * @return
	 */

	public boolean isCreateOrganizationLaunched() throws ScriptException {

		waitForTime(3);
		if ((CreateOrganizationCustomerAppObj.WidgetInfos.TEXTFIELD_ORG_NAME)
				.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Access Create Organization page
	 * 
	 * @param TIN
	 */
	public void accessCreateOrgPageWithTIN(String TIN) {
		try {
			if (isCreateOrganizationLaunched()) {
				fillAgentCode();
				createOrgCustNameData();
				if (TIN.equalsIgnoreCase("createOrg")) {
					createOrgCustAddressData();
				}
				if (TIN.equalsIgnoreCase("createOrgCanada")) {
					createOrgCustCanadaAddressData();
				}
				enterTaxIdNumberOrg();
				clickCreateCustomers();
				verifyAddressStandzation();
				handleCimsVersion();
				setTopFramewithDefaultContent();
				isHouseholdPageLaunched();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CREATEORGANIZATIONPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}

	}

	/**
	 * Select individual radio button in Portal Search page
	 * 
	 * @throws ScriptException
	 */
	public void searchIndividual() throws ScriptException {
		if (isPortalSearchPageExist()) {
			if (ABSPortalTestObjects.WidgetInfos.RADIOBUTTON_SEARCHOPTION
					.exists()) {
				ABSPortalTestObjects.WidgetInfos.RADIOBUTTON_SEARCHOPTION
						.click();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		}
	}

	/**
	 * Enter name and address in Add individual members page.
	 * 
	 * @throws ScriptException
	 */
	public void validateAddMembersPage() throws ScriptException {
		if (isHHPageLaunched()) {
			clickMemberActionsAddIndPage();
			if (isAddIndMembersPageLaunched()) {
				enterHHFirstName();
				enterHHLastName();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ADDINDIVIDUAL_NOTLAUNCHED);
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * Validate Add individual members page launched or not.
	 */
	public void verifyAddMembersPageFromHH() {
		try {
			if (isAgentBusinessSystemExist()) {
				clickCustomer();
				if (isPortalSearchPageExist()) {
					launchPortalCustomerSearchPage();
					launchPortalHHPage();
					validateAddMembersPage();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
				}

			} else {
				Verify.verifyTrue(false, MessageUtility.ABSPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Select searched customer from customer search page.
	 * 
	 * @throws ScriptException
	 */
	public void selectPortalCustomerFromTable() throws ScriptException {
		Link LINK_CUST = new Link("text=" + clientE2ETO.getCustomerOneData());
		waitForPageLoad(LINK_CUST, 20);
		if (LINK_CUST.exists()) {
			LINK_CUST.click();
			click(LINK_CUST, MessageUtility.CUSTNAME_CLICKED);
		} else {
			Verify.verifyTrue(false, MessageUtility.CUSTDATA_NOTFOUND);
		}
	}
	
	/**
	 * CMP - Canada Scenario 4
	 * 
	 * @throws ScriptException
	 */
	public void canadaNonAgentNotAbleToSearchOnUSPolicy()
			throws ScriptException {

		searchCustomerByAccountPolicy_NonAgent();
		verifyErrorMessageForScenario4();
		//clickPolicyClearButton();
	}
	
	public void searchCustomerByAccountPolicy() throws ScriptException {

		clickOnAcctPolicy_Agent();
		enterPolicyNumber_Agent();
		clickPortalSeacrhButton();
		waitForTime(1);

	}
	
	public void searchCustomerByAccountPolicy_NonAgent() throws ScriptException {

		clickOnAcctPolicy_NonAgent();
		enterPolicyNumber_NonAgent();
		clickPolicySearchButton();
		waitForTime(1);

	}
	
	public void clickOnAcctPolicy_Agent() throws ScriptException {

		if (ABSPortalTestObjects.WidgetInfos.RADIOBUTTON_ACCTPOLICY.exists()) {
			click(ABSPortalTestObjects.WidgetInfos.RADIOBUTTON_ACCTPOLICY,
					"Account/Policy is clicked successfully in the customer search page");
			waitForTime(3);
		}
	}

	public void clickOnAcctPolicy_NonAgent() throws ScriptException {

		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ACCOUNTPOLICY
				.exists()) {
			click(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ACCOUNTPOLICY,
					"Account/Policy is clicked successfully in the customer search page");
			waitForTime(5);
		}
	}
	
	public void enterPolicyNumber_NonAgent() throws ScriptException {

		// policy number - "101 4753-D08-60C"
		if (ABSCustomerSearchTestObjects.WidgetInfos.TEXTFIELD_POLICYNUMBER
				.exists())
			setTextInTextbox(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXTFIELD_POLICYNUMBER,
					clientE2ETO.getPolicyNumber(),
					"Policy number is entered successfully");
	}
	
	public void clickPolicySearchButton() throws ScriptException {
		if ((ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_POLICYSEARCH).exists()) {
				
			click(ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_POLICYSEARCH,
					"Search Button is clicked as expected");
		} else {
			Verify.verifyTrue(false,
					"Search Button is not displayed as expected");
		}
	}
	
	public void canadaNonAgentNotAbleToSearchOnUSBob() throws ScriptException {

		clickBob();
		enterAgentCode();
		enterBobLastName();
		clickSearchButton();
		waitForTime(3);
		verifyErrorMessageForScenario4();
	}
	
	public void enterBobLastName() throws ScriptException {

		/*System.out.println("entered meth");
		String text = getWebDriverInstance()
				.findElement(
						By.xpath("//div[@id='agentNameSearchCriteria']/div[1]/div[2]/div/input"))
				.getText();
		System.out.println("text" + text);*/
		System.out.println("Entered last name meth");
		waitForTime(2);
		 if(ABSCustomerSearchTestObjects.WidgetInfos.TEXT_AGENT_SEARCH_LASTNAME.exists())
		 {
			 System.out.println("Entered If");
		    setTextInTextbox(ABSCustomerSearchTestObjects.WidgetInfos.TEXT_AGENT_SEARCH_LASTNAME,
		 "SMITH", "Last name is entered successfully");
		 }
		 System.out.println("---EOIF---");
		/*getWebDriverInstance()
				.findElement(
						By.xpath("//div[@id='agentNameSearchCriteria']/div[1]/div[2]/div/input"))
				.sendKeys("SMITH");*/
	}


}
