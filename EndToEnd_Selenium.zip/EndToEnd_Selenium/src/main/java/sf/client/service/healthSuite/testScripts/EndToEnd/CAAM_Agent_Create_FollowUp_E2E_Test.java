package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.appObjects.ABSPortalTestObjects;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;
import statefarm.widget.manager.Verify;


//import org.apache.poi.hssf.record.formula.functions.Row;

//import org.apache.poi.hssf.usermodel.HSSFCell;
//import org.apache.poi.hssf.usermodel.HSSFRow;
//import org.apache.poi.hssf.usermodel.HSSFSheet;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



//import org.apache.poi.hssf.usermodel.HSSFDataFormatter;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;





import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;




public class CAAM_Agent_Create_FollowUp_E2E_Test extends BaseScript {
	
	
	String query = "select * from Agent_CreateIndCust_Scenario10";
	public void executeScript() throws IOException {

		/**Validate Customer Search Page*/
		createCustTasks.isSplunkSearchPageLaunchedOrNot();
		readClientExistingQuerySheet();
	}
	
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentCreateIndCustScenario10(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);				
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchSplunkUser(scriptName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
				//readandWriteExcel();
			}
		}
			catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*public void readandWriteExcel() {
		try {
			  // Specify the path of file
			  File src=new File(currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\Client-E+QUERY Sheet.xlsx");
			   // load file
			   FileInputStream fis=new FileInputStream(src);
		 
			   // Load workbook
			   HSSFWorkbook wb=new HSSFWorkbook(fis);
			   
			   // Load sheet- Here we are loading first sheetonly
			      HSSFSheet sh1= wb.getSheetAt(0);
			 
			  // getRow() specify which row we want to read.

			  // and getCell() specify which column to read.
			  // getStringCellValue() specify that we are reading String data.


			 System.out.println(sh1.getRow(0).getCell(2).getRichStringCellValue());
			 System.out.println(sh1.getRow(0).getCell(1).getRichStringCellValue());
			 System.out.println(sh1.getRow(1).getCell(0).getRichStringCellValue());
			 System.out.println(sh1.getRow(1).getCell(1).getRichStringCellValue());
			 System.out.println(sh1.getRow(2).getCell(0).getRichStringCellValue());
			 System.out.println(sh1.getRow(2).getCell(1).getRichStringCellValue());
			 
			  } catch (Exception e) {
			   System.out.println(e.getMessage());
			  }
	}*/
	
	/*public ArrayList OpenAndReadExcel(){
	    FileInputStream file = null;
	    HSSFWorkbook workBook = null;
	    ArrayList <String> rows = new ArrayList();

	    //open the file

	    try {
	         file = new FileInputStream(new File(currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\Client-E+QUERY Sheet.xlsx"));
	    } catch (FileNotFoundException e) {
	        // TODO Auto-generated catch block
	        System.out.println("Could not open Input File");
	        e.printStackTrace();
	    }

	    //  open the input stream as a workbook

	        try {
	             workBook = new HSSFWorkbook(file);
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            System.out.println("Can't Open HSSF workbook");
	            e.printStackTrace();
	        }

	        // get the sheet
	        HSSFSheet sheet = workBook.getSheetAt(0);

	        // add an iterator for every row and column
	        Iterator<HSSFRow> rowIter =  sheet.rowIterator();

	        while (rowIter.hasNext())
	        {

	            String rowHolder = "";
	            HSSFRow row = (HSSFRow) rowIter.next();
	            Iterator<HSSFCell> cellIter = row.cellIterator();
	            Boolean first =true;
	            while ( cellIter.hasNext())
	            {
	                if (!first)
	                    rowHolder = rowHolder + ",";

	                HSSFCell cell = (HSSFCell) cellIter.next();

	                rowHolder = rowHolder + cell.toString() ;
	                first = false;
	            }

	            rows.add(rowHolder);

	        }

	    return rows;

	}*/
	public void WriteOutput(ArrayList<String> rows) {

	    // TODO Auto-generated method stub
	    PrintStream outFile ;
	    try {


	        outFile = new PrintStream("fruity.txt");
	        for(String row : rows)
	        {   
	            outFile.println(row);
	        }
	        outFile.close();

	    } catch (FileNotFoundException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }
	}
	
	public void readClientExistingQuerySheet() throws IOException {
		
		File src=new File(currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\Client-E+QUERY Sheet.xlsx");
		   // load file
		   FileInputStream fis=new FileInputStream(src);
	 
		   // Load workbook
		   XSSFWorkbook wb=new XSSFWorkbook(fis);
		   XSSFSheet sheet = wb.getSheetAt(1);
		   
		   DataFormatter formatter = new DataFormatter();
		   
		   for (Iterator<Row>  iterator = sheet.rowIterator();iterator.hasNext();) {
			   
			   XSSFRow row = (XSSFRow) iterator.next();
			  if((row.getRowNum()!=0) ) {
				  System.out.println("praveen"+row.getRowNum());
			   XSSFCell cell = row.getCell(6);
			  enterSplunkQuery(formatter.formatCellValue(cell).toString());
			   //enterSplunkQuery(cell.toString());
			   //System.out.println("praveen2"+cell.toString());
			   
			  }
		   }
  }
	
public void readAndWriteTimeSheet() throws IOException {
		
		File src=new File(currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\Env_Support_Team_Hours_Sep_2017 - V 2.xlsx");
		   // load file
		   FileInputStream fis=new FileInputStream(src);
	 
		   // Load workbook
		   XSSFWorkbook wb=new XSSFWorkbook(fis);
		   XSSFSheet sheet = wb.getSheetAt(1);
		   
		   DataFormatter formatter = new DataFormatter();
		   
		   for (Iterator<Row>  iterator = sheet.rowIterator();iterator.hasNext();) {
			   
			   XSSFRow row = (XSSFRow) iterator.next();
			  if((row.getRowNum()!=0) ) {
				  System.out.println("praveen"+row.getRowNum());
			   XSSFCell cell = row.getCell(6);
			  enterSplunkQuery(formatter.formatCellValue(cell).toString());
			   //enterSplunkQuery(cell.toString());
			   //System.out.println("praveen2"+cell.toString());
			   
			  }
		   }
  }
	
 public void enterSplunkQuery(String query)  {
	 ABSPortalTestObjects.WidgetInfos.TEXTAREA_SEARCH.setValue(query.toString());
	 createCustTasks.clickPresetsArrowDown();
 }
 }


	





