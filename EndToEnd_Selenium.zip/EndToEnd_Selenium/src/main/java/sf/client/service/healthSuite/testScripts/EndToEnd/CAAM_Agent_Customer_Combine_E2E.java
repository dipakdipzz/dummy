package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class CAAM_Agent_Customer_Combine_E2E extends BaseScript {
	
	String query = "select * from Agent_CreateIndCust_Scenario10";
	public void executeScript() {		
	/**Search and Select Two Customers and Click on Next link.*/
		combineTasks.verifyAndSearchandSelectTwoCustomersPage();
		/**Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.*/
		combineTasks.verifyInfoandClickCombine();
		/**Launch HH Page after the 'Combine Customer'*/
		/**CASL US Scenarios Tc23-Tc24*/
		//productTasks.verifyEmessageafterCombine();
		scenarioTasks.clickHHPageCustomer();
	}
	
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentCreateIndCustScenario10(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);				
				//launcher = new LaunchApplication(getWATConfig());
				//launcher.launchUser(scriptName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
			}
		}
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}


