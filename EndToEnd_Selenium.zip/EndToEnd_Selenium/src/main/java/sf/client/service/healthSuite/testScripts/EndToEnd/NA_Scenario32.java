package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class NA_Scenario32 extends BaseScript {

	int count = 0;
	String query = "select * from NA_Scenario32";

	public void executeScript(String custType) throws Exception {
		createCustTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		createCustTasks.setCustomerSearchTopFrame();
		/**customer search*/
		productTasks.launchHHPageFromCustomerSearchPage();
		createCustTasks.validateUSSSNCNSINDriversLicenseCustomerInfo(custType);
	}

	public void scriptMain() {

		try {

			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {

				clientE2ETO = databaseUtil.loadTestDataNAScenario32(
						dbresultSet, clientE2ETO);

				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				productTasks = new ProductTasks(clientE2ETO);
				
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());

				createCustTasks.createResultsFile(resultsFileName(),
						scriptName());

				String custType = clientE2ETO.getCustomerType();
				count++;
				System.out.println("-------count---------" + count);
				executeScript(custType);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
