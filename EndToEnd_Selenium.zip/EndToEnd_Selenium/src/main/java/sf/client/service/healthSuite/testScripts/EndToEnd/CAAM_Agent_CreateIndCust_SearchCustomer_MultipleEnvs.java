package sf.client.service.healthSuite.testScripts.EndToEnd;

import java.lang.reflect.InvocationTargetException;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;
import statefarm.widget.manager.Verify;


public class CAAM_Agent_CreateIndCust_SearchCustomer_MultipleEnvs extends BaseScript {
	int rowCount = 0;
	int count = 0;
	String query = "select * from CAAM_Agent_CreateIndCust_SearchCustomer_MultipleEnvs";
	public void executeScript() {

		/**Validate Customer Search Page*/
		createCustTasks.launchCustomerSeachPage();
		/**validate Create Individual & Create Organization link Exists in Customer Search page.*/
		scenarioTasks.verifyCreateIndOrg();
		/**Click the 'Create Individual'  link */
		createCustTasks.clickCreateIndividual();
		
		/**Validate the ability to Create Individual customer*/
		createCustTasks.createIndividualCustomer();
		createCustTasks.closeHHPage();
		createCustTasks.setParentWindow();
		createCustTasks.launchNewlyCreatedCustomerSearchPage();
		createCustTasks.launchNewCustomerHHPage();
		//createCustTasks.closeHHPage();
		//createCustTasks.setParentWindow();
		createCustTasks.launchHouseholdpageFromPortal();
		launcher.shutdownServer();
		
	}
	
	public void createAndSearchCustomer() throws InvocationTargetException {
		
			try {
				Verify.verifyTrue(true, "**********   Started executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ "  ********* ");
				
				
				createCustTasks
						.appendMessage("**********   Started executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ "  ********* ");
				executeScript();
				Verify.verifyTrue(true, "**********  Finished executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ "  *********  ");
				createCustTasks
						.appendMessage("**********  Finished executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ "  ********* ");
			} catch (Exception e) {
				createCustTasks.appendToResultFile(
						false,
						"Exception occured while accessing "
								+ transferObject.getTestcaseName()
								+ " And the error message is: "
								+ e.getMessage());
				createCustTasks.setStatus(
						false,
						"Exception occured while accessing "
								+ transferObject.getTestcaseName()
								+ " And the error message is: "
								+ e.getMessage());
			}
		} 
	

	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentCreateIndCustScenario10(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				
					
				if (clientE2ETO.getIsTest().equalsIgnoreCase("1")) {
				launcher = new LaunchApplication(getWATConfig());
				//launcher.launchUserDB(scriptName(),clientE2ETO.getPortalTestId(),EncryptAndDecryptUtil.getDecrypted(clientE2ETO.getPortalPassword(), 24),clientE2ETO.getUrlPortal(),clientE2ETO.getPortalDomain());
				launcher.launchUserDB(scriptName(),clientE2ETO.getPortalTestId(),clientE2ETO.getPortalPassword(),clientE2ETO.getUrlPortal(),clientE2ETO.getPortalDomain());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				createAndSearchCustomer();
				}
			}
			
			
		}
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}


