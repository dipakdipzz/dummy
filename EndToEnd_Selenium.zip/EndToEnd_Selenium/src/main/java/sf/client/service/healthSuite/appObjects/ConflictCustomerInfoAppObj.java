package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.TextField;

public class ConflictCustomerInfoAppObj {
	
	private static final String RADIO_BUTTON_BIRTHDATE ="name=selectedDateOfBirth"; 
	private static final String RADIO_BUTTON_BIRTHDATE2 ="id=sx1lxxb2pu";
	private static final String RADIO_BUTTON_SSN_SIN = "name=selectedTaxId";
	private static final String RADIO_BUTTON_SSN_SIN1 = "id=snwts972pt";
	private static final String RADIO_BUTTON_SSN_SIN2= "id=snwts972pu";
	private static final String RADIO_BUTTON_SSN_SIN_OTHER = "id=snwts9719k0z4";
	private static final String TEXT_SSNSIN_OTHER = "id=otherTaxId";
	private static final String LINK_NAVIGATE_PREVIOUS = "text=< Previous";
	private static final String LINK_NAVIGATE_NEXT = "text=Next >";
	private static final String RADIO_BUTTON_SELECTED_MARITALSTATUS = "name=selectedMaritalStatus";
	private static final String RADIO_BUTTON_SELECTED_CITIZENSHIP = "name=selectedCitizenship";
	private static final String RADIO_BUTTON_SELECT_LANGUAGE = "name=selectedLanguage";
	private static final String RADIO_BUTTON_SELECTED_TAXIDP = "name=selectedTaxId";
	private static final String RADIO_BUTTON_SELECTED_DEATHDATE = "name=selectedDeathDate";
	private static final String RADIO_BUTTON_SELECTED_ORG_TYPE = "name=selectedOrgType";
	private static final String RADIO_BUTTON_DOB = "name=selectedDateOfBirth|value=p1";
	private static final String RADIO_BUTTON_SSN_SIN3 = "id=snwts9719k0z4";
	private static final String LINK_HELP_ONTHIS_PAGE = "text=help on this page";
	private static final String RADIO_BUTTON_NO_VALUE = "id=noValueId";
	private static final String DIV_CONFLICT_CUSTOMER_INFOPAGE = "text=Conflicting Customer Information ";
	
	@WidgetIDs
	public static class WidgetInfos {
		
		public static final RadioButton RADIOBUTTON_BIRTHDATE = new RadioButton(RADIO_BUTTON_BIRTHDATE);
		public static final RadioButton RADIOBUTTON_BIRTHDATE2 = new RadioButton(RADIO_BUTTON_BIRTHDATE2);
		public static final RadioButton RADIOBUTTON_SSN_SIN = new RadioButton(RADIO_BUTTON_SSN_SIN);
		public static final RadioButton RADIOBUTTON_SSN_SIN1 = new RadioButton(RADIO_BUTTON_SSN_SIN1);
		public static final RadioButton RADIOBUTTON_SSN_SIN2 = new RadioButton(RADIO_BUTTON_SSN_SIN2);
		public static final RadioButton RADIOBUTTON_SSN_SIN_OTHER = new RadioButton(RADIO_BUTTON_SSN_SIN_OTHER);
		public static final RadioButton RADIOBUTTON_SELECT_MARITAL_STATUS =new RadioButton(RADIO_BUTTON_SELECTED_MARITALSTATUS);
		public static final RadioButton RADIOBUTTON_SELECT_CITIZENSHIP = new RadioButton(RADIO_BUTTON_SELECTED_CITIZENSHIP);
		public static final RadioButton RADIOBUTTON_SELECT_LANGUAGE = new RadioButton(RADIO_BUTTON_SELECT_LANGUAGE);
		public static final RadioButton RADIOBUTTON_SELECT_TAXID =new RadioButton(RADIO_BUTTON_SELECTED_TAXIDP);
		public static final RadioButton RADIOBUTTON_SELECT_DEATHDATE = new RadioButton(RADIO_BUTTON_SELECTED_DEATHDATE);
		public static final RadioButton RADIOBUTTON_SELECT_ORGTYPE =new RadioButton(RADIO_BUTTON_SELECTED_ORG_TYPE);
		public static final RadioButton RADIOBUTTON_DOB = new RadioButton(RADIO_BUTTON_DOB);
		public static final RadioButton RADIOBUTTON_SSN_SIN3 = new RadioButton(RADIO_BUTTON_SSN_SIN3);
		public static final RadioButton RADIOBUTTON_SSN_NOVALUE  = new RadioButton(RADIO_BUTTON_NO_VALUE);
		public static final TextField TEXT_SSN_SIN_OTHER = new TextField(TEXT_SSNSIN_OTHER);
		public static final Link LINK_PREVIOUS = new Link(LINK_NAVIGATE_PREVIOUS);
		public static final Link LINK_NEXT = new Link(LINK_NAVIGATE_NEXT);
		public static final Link  LINK_HELP_ON_PAGE = new Link(LINK_HELP_ONTHIS_PAGE);
		public static final Div DIV_CONFLICT_CUSTINFOPAGE  = new Div(DIV_CONFLICT_CUSTOMER_INFOPAGE);
		
	}
}