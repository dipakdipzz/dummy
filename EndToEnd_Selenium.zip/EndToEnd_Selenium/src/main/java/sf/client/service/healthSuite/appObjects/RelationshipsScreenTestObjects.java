package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;

public class RelationshipsScreenTestObjects {
	
	// public static final Link RELATIONSHIP_LINK = new Link("text=Relationship*");
	// public static final Link INDIVIDUAL_LINK = new Link("text=Add Individual");
	// public static final ListBox RLN_LISTBOX = new ListBox("name=relationships.relationshipCode");
	// public static final Button BUTTON_SAVE = new Button("id=save");
	// public static final Button BUTTON_CANCEL = new Button("id=cancel");
	// public static final Div DIV_RELATIONSHIPS_MEMBERSINSIDEHH = new Div("id=householdRelationships");

	private static final String RELATIONSHIPS_LINK_RELATIONSHIP = "text=Relationship*";
	private static final String RELATIONSHIPS_LINK_ADD_INDIVIDUAL = "text=Add Individual";
	private static final String RELATIONSHIPS_BUTTON_SAVE = "id=save";
	private static final String RELATIONSHIPS_LISTBOX_RELATIONSHIPCODE = "name=relationships.relationshipCode";
	private static final String RELATIONSHIPS_BUTTON_CANCEL = "id=cancel";
	private static final String RELATIONSHIPS_DIV_MEMBERS_INSIDE_HOUSEHOLD = "id=householdRelationships";	

	@WidgetIDs
	public static class WidgetInfos {
		public static final Link LINK_RELATIONSHIP = new Link(RELATIONSHIPS_LINK_RELATIONSHIP);
		public static final Link LINK_ADD_INDIVIDUAL = new Link(RELATIONSHIPS_LINK_ADD_INDIVIDUAL);
		
		public static final Button BUTTON_SAVE = new Button(RELATIONSHIPS_BUTTON_SAVE);
		public static final Button BUTTON_CANCEL = new Button(RELATIONSHIPS_BUTTON_CANCEL);
		
		public static final ListBox LISTBOX_RELATIONSHIP_CODE = new ListBox(RELATIONSHIPS_LISTBOX_RELATIONSHIPCODE);
		
		public static final Div DIV_MEMBERS_INSIDE_HOUSEHOLD = new Div(RELATIONSHIPS_DIV_MEMBERS_INSIDE_HOUSEHOLD);
	}
}
