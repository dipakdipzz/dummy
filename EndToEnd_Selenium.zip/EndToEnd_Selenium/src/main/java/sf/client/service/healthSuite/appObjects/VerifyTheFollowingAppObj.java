package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;

public class VerifyTheFollowingAppObj {

	/*public static final Button BUTTON_SEPARATE = new Button("id=separate");
	public static final Div DIV_CUST1_ACC_POLICIES = new Div("id=clientOneagreements");
	public static final Div DIV_CUST2_ACC_POLICIES = new Div("id=clientTwoagreements");*/
	
	private static final String SEPARATECUSTOMER_BUTTON_SEPARATE = "id=separate";
	private static final String SEPARATECUSTOMER_DIV_CUSTOMERONE_ACCOUNT_POLICIES = "id=clientOneagreements";
	private static final String SEPARATECUSTOMER_DIV_CUSTOMERTWO_ACCOUNT_POLICIES = "id=clientTwoagreements";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final Button BUTTON_SEPARATE = new Button(SEPARATECUSTOMER_BUTTON_SEPARATE);
		public static final Div DIV_CUSTOMERONE_ACCOUNT_POLICIES = new Div(SEPARATECUSTOMER_DIV_CUSTOMERONE_ACCOUNT_POLICIES);
		public static final Div DIV_CUSTOMERTWO_ACCOUNT_POLICIES = new Div(SEPARATECUSTOMER_DIV_CUSTOMERTWO_ACCOUNT_POLICIES);
	}
}
