package sf.client.service.common.helpers;

public class Constants {
	public static final String URL_PORTAL = "urlPortal";
	public static final String URL_AHQB = "urlAHQB";
	public static final String URL_ABS = "urlAbs";
	public static final String USER = "User";
	public static final String PASSWORD = "password";
	public static final String USERNAME = "username";
	public static final String USE_RUN_AS = "useRunAs";
	public static final String TRUE_UPPER = "TRUE";
	public static final String EMPTY_STRING = "";
	public static final String URL_EQUALS = "url=";
	public static final String DOMAIN = "domain";
	public static final String ENTER = "{enter}";
	public static final String TEST_ID = "testId";
	public static final String PORTAL_TEST_ID = "portalTestId";
	public static final String PORTAL_DOMAIN = "portalDomain";
	public static final String PORTAL_PASSWORD = "portalPassword";
	public static final String ABS_TEST_ID = "absTestId";
	public static final String ABS_DOMAIN = "absDomain";
	public static final String ABS_PASSWORD = "absPassword";
	public static final String AHQB_TEST_ID = "qbTestId";
	public static final String AHQB_DOMAIN = "qbDomain";
	public static final String AHQB_PASSWORD = "qbPassword";
	public static final String CRC_TEST_ID = "crcTestId";
	public static final String CRC_DOMAIN = "crcDomain";
	public static final String CRC_PASSWORD = "crcPassword";
	public static final String URL_CRC = "urlCRC";
	public static final String PRODTEAM_TEST_ID = "prodTeamTestId";
	public static final String PRODTEAM_DOMAIN = "prodTeamDomain";
	public static final String PRODTEAM_PASSWORD = "prodTeamPassword";
	public static final String PORTAL_TEST_ID_ONE = "portalTestIdOne";
	public static final String PORTAL_DOMAIN_ONE = "portalDomainOne";
	public static final String PORTAL_TEST_ID_TWO = "portalTestIdTwo";
	public static final String PORTAL_DOMAIN_TWO = "portalDomainTwo";
	
	public static final String URL_SPLUNK = "urlSplunk";
	public static final String SPLUNK_USER_ID ="splunkUserId";
	public static final String SPLUNK_PASSWORD ="splunkPassword";
	public static final String SPLUNK_DOMAIN = "splunkDomain";
	
	public static final String URL_ART = "urlART";
	public static final String ART_USER_ID ="artUserId";
	public static final String ART_PASSWORD ="artPassword";
	public static final String ART_DOMAIN = "artDomain";
}
