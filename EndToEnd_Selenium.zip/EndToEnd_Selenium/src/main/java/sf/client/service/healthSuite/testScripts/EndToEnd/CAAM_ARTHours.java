package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.appObjects.ABSPortalTestObjects;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;
import statefarm.wat.util.KeyboardUtility;
import statefarm.widget.manager.Verify;


//import org.apache.poi.hssf.record.formula.functions.Row;

//import org.apache.poi.hssf.usermodel.HSSFCell;
//import org.apache.poi.hssf.usermodel.HSSFRow;
//import org.apache.poi.hssf.usermodel.HSSFSheet;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



//import org.apache.poi.hssf.usermodel.HSSFDataFormatter;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;





import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;




public class CAAM_ARTHours extends BaseScript {
	
	
	String query = "select * from Agent_CreateIndCust_Scenario10";
	public void executeScript() throws IOException {

		/**Validate Customer Search Page*/
		createCustTasks.isARTPageLaunchedOrNot();
		readAndWriteTimeSheet();
	}
	
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentCreateIndCustScenario10(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);				
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchARTTimeSheetUser(scriptName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
				//readandWriteExcel();
			}
		}
			catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
public void readAndWriteTimeSheet() throws IOException {
		
		File src=new File(currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\Env_Support_Team_Hours_Sep_2017 - V 2.xlsx");
		   // load file
		   FileInputStream fis=new FileInputStream(src);
	 
		   // Load workbook
		   XSSFWorkbook wb=new XSSFWorkbook(fis);
		   XSSFSheet sheet = wb.getSheetAt(1);
		   
		   DataFormatter formatter = new DataFormatter();
		   
		   for (Iterator<Row>  iterator = sheet.rowIterator();iterator.hasNext();) {
			   
			   XSSFRow row = (XSSFRow) iterator.next();
			  if((row.getRowNum()!=0) ) {
				  System.out.println("praveen"+row.getRowNum());
			   XSSFCell cell = row.getCell(0);
			   XSSFCell saturdayCell = row.getCell(7);
			   XSSFCell sundayCell = row.getCell(8);
			   XSSFCell mondayCell = row.getCell(9);
			   XSSFCell tuesdayCell = row.getCell(10);
			   XSSFCell wednesdayCell = row.getCell(11);
			   XSSFCell thursdayCell = row.getCell(12);
			   XSSFCell fridayCell = row.getCell(13);
			   enterLoginId(formatter.formatCellValue(cell).toString());
			   enterPassword(formatter.formatCellValue(cell).toString());
			   clickARTButton();
			   createCustTasks.clickARTWSRS();
			   enterWeekEndDate();
			   clickARTButtonOk();
			   
			   enterSatHours(formatter.formatCellValue(saturdayCell).toString());
			   enterSunHours(formatter.formatCellValue(sundayCell).toString());
			   enterMonHours(formatter.formatCellValue(mondayCell).toString());
			   enterTuesHours(formatter.formatCellValue(tuesdayCell).toString());
			   enterWedHours(formatter.formatCellValue(wednesdayCell).toString());
			   enterThursHours(formatter.formatCellValue(thursdayCell).toString());
			   enterFridayHours(formatter.formatCellValue(fridayCell).toString());
			   
			   clickUpdateHours();
			  }
		   }
  }
	
 public void enterSplunkQuery(String query)  {
	 ABSPortalTestObjects.WidgetInfos.TEXTAREA_SEARCH.setValue(query.toString());
	 createCustTasks.clickPresetsArrowDown();
 }
 
 public void enterLoginId(String logIn) {
	 ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_LOGIN_ID.setValue(logIn.toString());
 }
 
public void enterPassword(String password) {
	ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_PASSWORD.setValue(password.toString());
}

public void clickARTButton(){
	ABSPortalTestObjects.WidgetInfos.BUTTON_ART_SUBMIT.click();
}

public void enterWeekEndDate() {
	ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_WEEKEND_DATE.setValue("10/20/2017");
	clickARTButtonOk();
}

public void clickARTButtonOk(){
	ABSPortalTestObjects.WidgetInfos.BUTTON_ART_SUBMIT_OK.click();
}

public void enterSatHours(String satHours) {
	
	if(satHours.equalsIgnoreCase("WO")) {
	ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_11.setValue("");
	}
	else {
		ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_11.setValue(satHours);
	}
}

public void enterSunHours(String sunHours) {
	if(sunHours.equalsIgnoreCase("WO")) {
		ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_12.setValue("");
		}
		else {
			ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_12.setValue(sunHours);
		}
}

public void enterMonHours(String monHours) {
	if(monHours.equalsIgnoreCase("WO")) {
		ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_13.setValue("");
		}
		else {
			ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_13.setValue(monHours);
		}
}

public void enterTuesHours(String tuesHours) {
	if(tuesHours.equalsIgnoreCase("WO")) {
		ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_14.setValue("");
		}
		else {
			ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_14.setValue(tuesHours);
		}
}

public void enterWedHours(String wedHours) {
	if(wedHours.equalsIgnoreCase("WO")) {
		ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_15.setValue("");
		}
		else {
			ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_15.setValue(wedHours);
		}
}

public void enterThursHours(String thursHours) {
	if(thursHours.equalsIgnoreCase("WO")) {
		ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_16.setValue("");
		}
		else {
			ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_16.setValue(thursHours);
		}
}

public void enterFridayHours(String fridayHours) {
	if(fridayHours.equalsIgnoreCase("WO")) {
		ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_17.setValue("");
		}
		else {
			ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ART_TEXT_HOURS_17.setValue(fridayHours);
		}
}


public void clickUpdateHours() {
	ABSPortalTestObjects.WidgetInfos.BUTTON_ART_UPDATE_TOTALS.click();
	createCustTasks.waitForTime(6);
	ABSPortalTestObjects.WidgetInfos.BUTTON_ART_SUBMIT_OK.click();
	createCustTasks.waitForTime(6);
	KeyboardUtility.sendKeys("{ENTER}");
	createCustTasks.waitForTime(6);
	KeyboardUtility.sendKeys("{ENTER}");
	createCustTasks.waitForTime(6);
	KeyboardUtility.sendKeys("{ENTER}");
	createCustTasks.waitForTime(6);
	KeyboardUtility.sendKeys("{ENTER}");
}






}


	





