package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;

public class Agent_Ind_Search_Scenario1 extends BaseScript {
	String query = "select * from Agent_Ind_Search_Scenario1";

	public void executeScript() throws Exception {
		
		productTasks.launchHouseholdpageFromPortal();
		
		/**US Scenario 3 */
		//productTasks.usAgentNotAbleToSearchOnCanadaData();
		productTasks.launchCustomerInfoPageFromHHPage();
		/**CASL CANADA Scenarios Tc1-Tc4*/
		productTasks.EmessageOnlySendWithCASLFieldY();
		/**CASL CANADA Scenarios Tc5-Tc8*/
		productTasks.doNotsendEmessageWithCASLFieldY();
		/**CASL US Scenarios Tc9-Tc10*/
		productTasks.verifyEmessageFieldWithCASLFieldN();
		/**CASL US Scenarios Tc11-Tc12*/
		productTasks.verifyEmessageFieldWithCASLFieldY();
		/**CASL US Scenarios Tc13-Tc14*/
		productTasks.changingFromOnlyEmessageToUnsubscribe();
		/**CASL US Scenarios Tc23-Tc24*/
		//productTasks.verifyEmessageafterCombine();
		
		//** Launching HH Page 
		/*productTasks.launchHouseholdpageFromPortal();
		*//** Verifying Previous Review Date functionality *//*
		productTasks.verifyPreviousReviewDateFunctionality();
		productTasks.refreshHHPage();
		productTasks.verifyPreviousReviewDateDisplayedAsLinkinHHpage(productTasks.getPreviousReviewDate());
		
		*//** Verifying Next Review Date functionality *//*
		productTasks.verifyNextReviewDateFunctionality();
		productTasks.refreshHHPage();
		productTasks.verifyNextReviewDateDisplayedAsLinkinHHpage(productTasks.getNextReviewDate());
		*//** Verifying Accounts/Policies with Others *//*
		productTasks.verifyAccountsPoliciesWithOthers();
		*//** Creating Auto,Bank Policy with Others *//*
		productTasks.createAutoBankPolicesWithOthers();
		*//** Validate count of Auto and Bank Policy with Others *//*
		productTasks.verifyCreatedAutoBankPolicies();
		*//** Launching,Verifying and updating Auto Policy *//*
		productTasks.updateAutoPoliciesWithOthers();
		*//** Removing the Bank Policy *//*
		productTasks.removeBankPoliciesWithOthers();
		*//** Adding an Individual from HH Page *//*
		//createCustTasks.addAndVerifyIndCustFromMemberActions();
		*//** Validating Remove From Book *//*
		removeFromBookTasks.verifyRemoveFromBook();
		*//** Verify Active customer cannot be deleted via Remove From Book *//*
		removeFromBookTasks.validateActiveCustomerRemoval();
		*//** Validating Separate/Combine *//*
		productTasks.verifyCombineSeparatePage();
		*//** Search and Select Customer from Search and Select one Customer Page. *//*
		separateCustTasks.verifySearchandSelectOneCustomerPage();
		*//** Separating a Customer. *//*
		separateCustTasks.separateCustomer();
		*//** CASL Canada Scenarios TC15&17 */
		productTasks.verifyOnlySendElectronicMessageForBothClient();
		/** CASL Canada Scenarios TC16&18 */
		productTasks.verifyDoNotSendElectronicMessageForBothClient();
		/** CASL Canada Scenarios TC19&21 */
		productTasks.verifyOnlyAndDoNotSendElectronicMessageForClients();
		/** CASL Canada Scenarios TC20&22 */
		productTasks.verifyDoNotAndOnlySendElectronicMessageForClients();
		/** Validate Comments section *//*
		scenarioTasks.validateCommentsSectionHHPage();
		*//**Validate the Refresh links in the Household page in the refresh/Close menu*//*
		createCustTasks.refreshHHPage();
		*//** Verifying Presentation Kit *//*
		productTasks.verifyPresentationKit();
		*//** Validate the Close links in the Household page in the refresh /Close menu*//*
		createCustTasks.closeHHPage();*/
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataAgentIndSearchScenario1(
						dbresultSet, clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				productTasks = new ProductTasks(clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				removeFromBookTasks = new RemoveFromBookTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				
				launcher = new LaunchApplication(getWATConfig());
				
				launcher.launchUser(this.getClass().getSimpleName());
				
				productTasks.createResultsFile(resultsFileName(), scriptName());
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
