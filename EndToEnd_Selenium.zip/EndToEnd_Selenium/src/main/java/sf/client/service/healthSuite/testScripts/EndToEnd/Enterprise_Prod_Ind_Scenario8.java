package sf.client.service.healthSuite.testScripts.EndToEnd;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class Enterprise_Prod_Ind_Scenario8 extends BaseScript
{

	String query = "select * from Enterprise_Prod_Ind_Scenario8";
	 
	 	public void executeScript() throws Exception{ 
	 		/**
			 * validate Create Ind , Create Org 
			 *validate Enterprise connect & Enterprise View link does not Exists in
			 *Customer Search page.
			 */
	 		scenarioTasks.setTopFrame();
	 		scenarioTasks.setCustomerSearchTopFrame();
			scenarioTasks.validateLinksDisplayedInCustSearchPage();
			/**
			 *  Connect Customer.
			 */
			// outdated functionality
			//connectCustTasks.connectCustomers();
			
			/**
			 *  Launch HH page From Customer Search page.
			 */
			hhNavigationTasks.launchHHPageFromCustomerSearchPage();
			/**
			 *  Validate that the Household hyperlink and Non household hyperlinks are not displayed in the Household Menu
			 */
			hhNavigationTasks.validateHouseholdNonHouseholdLinks();
			/**
			 *  Launch Relationship page
			 */
			hhNavigationTasks.validateAndLaunchRelationshipPage();
			/**
			 *  Validate the Contents of Relationship page.
			 */
			hhRelationshipTasks.validateRelationshipPage();
			/**
			 *  Close Relationship page.
			 */
			hhRelationshipTasks.closeRelationshipPage();
			/**
			 * Validate the Policy Listing Print Page
			 */
			scenarioTasks.validatePolicyListingPrintInHHpage();
			/**
			 * Search and Select Two Customers and Click on Next link. 
			 *//*
			combineTasks.verifySearchandSelectTwoCustomersPageABS();*/
		/*	*//**
			 * Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.. 
			 *//*
			combineTasks.verifyInfoandClickCombine();*/
		
			
			
	 	 		
	 	}
 	public void scriptMain() {
			try {
				try {
					transferObject=setTestDataObject(transferObject);
					transferObject.setDbQuery(query);
					
					dbresultSet =databaseUtil.getCoreData(transferObject);
					
					while(dbresultSet.next()){
						clientE2ETO = databaseUtil.loadTestDataEnterpriseProdIndScenario8(dbresultSet,clientE2ETO);
						scenarioTasks =new ScenarioTasks(clientE2ETO);
						hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
						hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
						connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
						combineTasks = new CombineCustomersTasks(clientE2ETO);
						
						launcher = new LaunchApplication(getWATConfig());
						launcher.launchUser(this.getClass().getSimpleName());
						combineTasks.createResultsFile(resultsFileName(),scriptName());
						executeScript();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	 	
	 	
	 	

	 }

