package sf.client.service.healthSuite.testsuite;


import sf.client.service.common.helpers.StopSeleniumServerScript;
import sf.client.service.healthSuite.testScripts.EndToEnd.CAAM_Agent_CreateIndCust_SearchCustomer_E2E;
import sf.client.service.healthSuite.testScripts.EndToEnd.CAAM_Agent_CustomerInfo_Address_Phone_E2E;
import sf.client.service.healthSuite.testScripts.EndToEnd.CAAM_Agent_CustomerInfo_Email_PersonalInfo_E2E;
import sf.client.service.healthSuite.testScripts.EndToEnd.CAAM_Agent_Customer_Combine_E2E;
import sf.client.service.healthSuite.testScripts.EndToEnd.CAAM_Agent_OOB_Ind_E2E;
import statefarm.wat.script.WATScriptSuite;

public class RunCAAMScenariosScripts extends WATScriptSuite{
	@Override
	public void buildSuite() {
		addScript(CAAM_Agent_CreateIndCust_SearchCustomer_E2E.class);
		//addScript(CAAM_Agent_Customer_Combine_E2E.class);
		addScript(CAAM_Agent_CustomerInfo_Address_Phone_E2E.class);
		addScript(CAAM_Agent_CustomerInfo_Email_PersonalInfo_E2E.class);
		//addScript(CAAM_Agent_OOB_Ind_E2E.class);
		addScript(StopSeleniumServerScript.class);
	}
}
