package sf.client.service.common.helpers;

import sf.client.service.healthSuite.baseScripts.BaseScript;
import statefarm.widget.manager.Verify;

public class StopSeleniumServerScript extends BaseScript{
	
	LaunchApplication launcher = null;
	public void scriptMain() {
		launcher = new LaunchApplication(getWATConfig());
		try {
			launcher.shutdownServer();
			
		}catch(Exception e){
			Verify.verifyTrue(false, "Failed to stop selenium server "+e.getMessage());
			System.exit(0);
		}
		
	}
}
