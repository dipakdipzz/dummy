package sf.client.service.common.helpers;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.wat.log.WATLogger;
import statefarm.wat.script.data.IDataContainer;
import statefarm.wat.util.KeyboardUtility;
import statefarm.wat.util.WATConfiguration;
import statefarm.widget.CommandLine;
import statefarm.widget.gui.Browser;

public class LaunchApplication extends WatUtility {

	CommandLine cmd = null;
	private Browser browser = new Browser();
	public ClientE2ETO clientE2ETO = new ClientE2ETO();

	public LaunchApplication(WATConfiguration config) {
		super(config);

	}

	public IDataContainer getDataContainer() {
		browser.closeAllWindows();
		return watConfig.getUserConfigContainer();
	}

	protected WATLogger getLogger(Class logger) {
		return (WATLogger) WATLogger.getLogger(logger);
	}

	/**
	 * This method returns the User config container
	 * 
	 * @param iDataContainer
	 * @return IDataContainer
	 */
	public IDataContainer getIDataContainer(String iDataContainer) {
		return getDataContainer().getContainer(iDataContainer);
	}

	/**
	 * This method returns the login Id got from the data container
	 * 
	 * @param globalInput
	 * @param specificInput
	 * @return String
	 */
	public String getCredentials(IDataContainer globalInput,
			IDataContainer specificInput, String testcasename) {
		String url = null;
		String[] s = ("@".concat(testcasename.replace(".", "@"))).split("@");
		int length = s.length;
		String scriptName = s[(length - 1)];
		if (scriptName.toUpperCase().indexOf("AGENT") >= 0
				|| scriptName.toUpperCase().indexOf("AGENCY") >= 0
				|| scriptName.toUpperCase().indexOf("PORTAL") >= 0) {
			url = specificInput.getField(Constants.URL_PORTAL);
		} else if (scriptName.toUpperCase().indexOf("AHQB") >= 0) {
			url = specificInput.getField(Constants.URL_AHQB);
		} else if (scriptName.toUpperCase().indexOf("CRC") >= 0) {
			url = specificInput.getField(Constants.URL_CRC);
		}
		else {
			url = specificInput.getField(Constants.URL_ABS);
		}

		url = url.replace("amp;amp", "&");
		String loginId = specificInput.getField(Constants.USERNAME);
		browser.openNewWindow(url);
		waitForTime(40);
		KeyboardUtility.sendKeys("{ESC}");
		waitForTime(10);
		KeyboardUtility.sendKeys("{ESC}");
		waitForTime(10);
		KeyboardUtility.sendKeys("{ESC}");
		
		browser.getActiveWindow().maximize();
		return loginId;
	}
	
	public String getSplunkCredentials(IDataContainer globalInput,
			IDataContainer specificInput, String testcasename) {
		String url = null;
				
			url = specificInput.getField(Constants.URL_SPLUNK);
		System.out.println("url:"+url);
		url = url.replace("amp;amp", "&");
		String loginId = specificInput.getField(Constants.USERNAME);
		browser.openNewWindow(url);
		waitForTime(40);
		/*KeyboardUtility.sendKeys("{ESC}");
		waitForTime(10);
		KeyboardUtility.sendKeys("{ESC}");
		waitForTime(10);
		KeyboardUtility.sendKeys("{ESC}");*/
		
		browser.getActiveWindow().maximize();
		return loginId;
	}
	
	
	public String getARTCredentials(IDataContainer globalInput,
			IDataContainer specificInput, String testcasename) {
		String url = null;
				
			url = specificInput.getField(Constants.URL_ART);
		System.out.println("url:"+url);
		//url = url.replace("amp;amp", "&");
		String loginId = specificInput.getField(Constants.USERNAME);
		browser.openNewWindow(url);
		waitForTime(10);
		/*KeyboardUtility.sendKeys("{ESC}");
		waitForTime(10);
		KeyboardUtility.sendKeys("{ESC}");
		waitForTime(10);
		KeyboardUtility.sendKeys("{ESC}");*/
		
		browser.getActiveWindow().maximize();
		return loginId;
	}

	
	/**
	 * This method returns the login Id got from the mdb file
	 * 
	 * @param globalInput
	 * @param specificInput
	 * @return String
	 */
	public String getCredentialsDB(IDataContainer globalInput,
			IDataContainer specificInput, String testcasename,String urlPortal) {
		String url = null;
		String[] s = ("@".concat(testcasename.replace(".", "@"))).split("@");
		int length = s.length;
		String scriptName = s[(length - 1)];
		if (scriptName.toUpperCase().indexOf("AGENT") >= 0
				|| scriptName.toUpperCase().indexOf("AGENCY") >= 0
				|| scriptName.toUpperCase().indexOf("PORTAL") >= 0) {
			url = urlPortal;
			
		} else if (scriptName.toUpperCase().indexOf("AHQB") >= 0) {
			url = specificInput.getField(Constants.URL_AHQB);
		} else if (scriptName.toUpperCase().indexOf("CRC") >= 0) {
			url = specificInput.getField(Constants.URL_CRC);
		}
		else {
			url = specificInput.getField(Constants.URL_ABS);
		}

		url = url.replace("amp;amp", "&");
		String loginId = specificInput.getField(Constants.USERNAME);
		browser.openNewWindow(url);
		waitForTime(30);
		KeyboardUtility.sendKeys("{ESC}");
		waitForTime(5);
		KeyboardUtility.sendKeys("{ESC}");
		waitForTime(5);
		KeyboardUtility.sendKeys("{ESC}");
		
		browser.getActiveWindow().maximize();
		return loginId;
	}

	
	public String getCredentials(IDataContainer globalInput,
			IDataContainer specificInput) {
		String url = specificInput.getField(Constants.URL_PORTAL);
		String loginId = specificInput.getField(Constants.USERNAME);
		browser.openNewWindow(url);
		browser.getActiveWindow().maximize();

		return loginId;

	}

	public String launchUser() {
		return getCredentials(getDataContainer(),
				getIDataContainer(Constants.USER));
	}

	public String launchUser(String testcasename) {
		try {
		clearCache();
        waitForTime(10);
        closeBrowser();
        System.out.println("launch meth");
        launchSeleniumServer(testcasename);
		return getCredentials(getDataContainer(),
				getIDataContainer(Constants.USER), testcasename);
		}
        catch(Exception e){
    		return getCredentials(getDataContainer(),
    				getIDataContainer(Constants.USER), testcasename);
        }
	}
	
	public String launchSplunkUser(String testcasename) {
		try {
		clearCache();
        waitForTime(10);
        closeBrowser();
        System.out.println("launch meth");
        launchSplunkSeleniumServer(testcasename);
		return getSplunkCredentials(getDataContainer(),
				getIDataContainer(Constants.USER), testcasename);
		}
        catch(Exception e){
    		return getSplunkCredentials(getDataContainer(),
    				getIDataContainer(Constants.USER), testcasename);
        }
	}
	
	
	public String launchARTTimeSheetUser(String testcasename) {
		try {
		clearCache();
        waitForTime(10);
        closeBrowser();
        System.out.println("launch meth");
        launchARTSeleniumServer(testcasename);
		return getARTCredentials(getDataContainer(),
				getIDataContainer(Constants.USER), testcasename);
		}
        catch(Exception e){
    		return getARTCredentials(getDataContainer(),
    				getIDataContainer(Constants.USER), testcasename);
        }
	}
	
	public String launchUserDB(String testcasename,String portalTestId,String portalPassword,String urlPortal,String portalDomain) {
		try {
		clearCache();
        waitForTime(10);
        closeBrowser();
        System.out.println("launch meth");
        launchSeleniumServerDB(testcasename,portalTestId,portalPassword,portalDomain);
		return getCredentialsDB(getDataContainer(),
				getIDataContainer(Constants.USER), testcasename,urlPortal);
		}
        catch(Exception e){
    		return getCredentialsDB(getDataContainer(),
    				getIDataContainer(Constants.USER), testcasename,urlPortal);
        }
	}
	
	public String launchSplunkUserDB(String testcasename,String portalTestId,String portalPassword,String urlPortal,String portalDomain) {
		try {
		clearCache();
        waitForTime(10);
        closeBrowser();
        System.out.println("launch meth");
        launchSeleniumServerDB(testcasename,portalTestId,portalPassword,portalDomain);
		return getCredentialsDB(getDataContainer(),
				getIDataContainer(Constants.USER), testcasename,urlPortal);
		}
        catch(Exception e){
    		return getCredentialsDB(getDataContainer(),
    				getIDataContainer(Constants.USER), testcasename,urlPortal);
        }
	}

	public void closeBrowser() {

		cmd = new CommandLine();
		cmd.execute("taskkill /f /im IEDriverServer.exe");
	}
	public void closewindows() {
		browser.closeAllWindows();
	}

	public void launchSeleniumServer(String testCaseName) {
		String[] s = ("@".concat(testCaseName.replace(".", "@"))).split("@");
		int length = s.length;
		String scriptName = s[(length - 1)];
		String portalTestId = getDataContainer().getField(Constants.PORTAL_TEST_ID);
		String absTestId = getDataContainer().getField(Constants.ABS_TEST_ID);
		String qbTestId = getDataContainer().getField(Constants.AHQB_TEST_ID);
		String crcTestId = getDataContainer().getField(Constants.CRC_TEST_ID);
		String prodTeamTestId = getDataContainer().getField(Constants.PRODTEAM_TEST_ID);
		String portalDomain = getDataContainer().getField(Constants.PORTAL_DOMAIN);
		String absDomain = getDataContainer().getField(Constants.ABS_DOMAIN);
		String qbDomain = getDataContainer().getField(Constants.AHQB_DOMAIN);
		String crcDomain = getDataContainer().getField(Constants.CRC_DOMAIN);
		String prodTeamDomain = getDataContainer().getField(Constants.PRODTEAM_DOMAIN);
		String portalPassword = getDataContainer().getField(Constants.PORTAL_PASSWORD);
		String absPassword = getDataContainer().getField(Constants.ABS_PASSWORD);
		String qbPassword = getDataContainer().getField(Constants.AHQB_PASSWORD);
		String crcPassword = getDataContainer().getField(Constants.CRC_PASSWORD);
		String prodTeamPassword = getDataContainer().getField(Constants.PRODTEAM_PASSWORD);
		if (scriptName.toUpperCase().indexOf("AGENT")>=0 || scriptName.toUpperCase().indexOf("AGENCY") >= 0) {
			System.out.println("portalTestId:"+portalTestId);
			System.out.println("portalPassword:"+portalPassword);
		createSeleniumServerBatchFileForMP(portalTestId,portalDomain);
		setCredintialsToLaunchSeleniumServer(portalTestId,portalPassword);
		}else if (scriptName.toUpperCase().indexOf("AHQB") >= 0) {
			createSeleniumServerBatchFileForMP(qbTestId,qbDomain);
			setCredintialsToLaunchSeleniumServer(qbTestId,qbPassword);
		}else if (scriptName.toUpperCase().indexOf("CRC") >= 0) {
			createSeleniumServerBatchFileForMP(crcTestId,crcDomain);
			setCredintialsToLaunchSeleniumServer(crcTestId,crcPassword);
		}else if (scriptName.toUpperCase().indexOf("PROD") >= 0) {
			createSeleniumServerBatchFileForMP(prodTeamTestId,prodTeamDomain);
			setCredintialsToLaunchSeleniumServer(prodTeamTestId,prodTeamPassword);
		}
		else{
			createSeleniumServerBatchFileForMP(absTestId,absDomain);
			setCredintialsToLaunchSeleniumServer(absTestId,absPassword);
		}
	}
	
	public void launchSplunkSeleniumServer(String testCaseName) {
		String splunkUserId = getDataContainer().getField(Constants.SPLUNK_USER_ID);
		String splunkPassword = getDataContainer().getField(Constants.SPLUNK_PASSWORD);
		String splunkDomain = getDataContainer().getField(Constants.SPLUNK_DOMAIN);
		
		createSeleniumServerBatchFileForMP(splunkUserId,splunkDomain);
		setCredintialsToLaunchSeleniumServer(splunkUserId,splunkPassword);
	}
	
	public void launchARTSeleniumServer(String testCaseName) {
		String artUserId = getDataContainer().getField(Constants.ART_USER_ID);
		String artPassword = getDataContainer().getField(Constants.ART_PASSWORD);
		String artDomain = getDataContainer().getField(Constants.ART_DOMAIN);
		
		createSeleniumServerBatchFileForMP(artUserId,artDomain);
		setCredintialsToLaunchSeleniumServer(artUserId,artPassword);
	}
	
	public void launchSeleniumServerDB(String testCaseName,String portalTestId,String portalPassword,String portalDomain) {
		String[] s = ("@".concat(testCaseName.replace(".", "@"))).split("@");
		int length = s.length;
		String scriptName = s[(length - 1)];
		System.out.println("clientE2ETO.getPortalTestId():"+clientE2ETO.getPortalTestId());
		String absTestId = getDataContainer().getField(Constants.ABS_TEST_ID);
		String qbTestId = getDataContainer().getField(Constants.AHQB_TEST_ID);
		String crcTestId = getDataContainer().getField(Constants.CRC_TEST_ID);
		String prodTeamTestId = getDataContainer().getField(Constants.PRODTEAM_TEST_ID);
		String absDomain = getDataContainer().getField(Constants.ABS_DOMAIN);
		String qbDomain = getDataContainer().getField(Constants.AHQB_DOMAIN);
		String crcDomain = getDataContainer().getField(Constants.CRC_DOMAIN);
		String prodTeamDomain = getDataContainer().getField(Constants.PRODTEAM_DOMAIN);
		String absPassword = getDataContainer().getField(Constants.ABS_PASSWORD);
		String qbPassword = getDataContainer().getField(Constants.AHQB_PASSWORD);
		String crcPassword = getDataContainer().getField(Constants.CRC_PASSWORD);
		String prodTeamPassword = getDataContainer().getField(Constants.PRODTEAM_PASSWORD);
		if (scriptName.toUpperCase().indexOf("AGENT")>=0 || scriptName.toUpperCase().indexOf("AGENCY") >= 0) {
			System.out.println("portalTestId:"+portalTestId);
			System.out.println("portalPassword:"+portalPassword);
			
		createSeleniumServerBatchFileForMP(portalTestId,portalDomain);
		setCredintialsToLaunchSeleniumServer(portalTestId,portalPassword);
		}else if (scriptName.toUpperCase().indexOf("AHQB") >= 0) {
			createSeleniumServerBatchFileForMP(qbTestId,qbDomain);
			setCredintialsToLaunchSeleniumServer(qbTestId,qbPassword);
		}else if (scriptName.toUpperCase().indexOf("CRC") >= 0) {
			createSeleniumServerBatchFileForMP(crcTestId,crcDomain);
			setCredintialsToLaunchSeleniumServer(crcTestId,crcPassword);
		}else if (scriptName.toUpperCase().indexOf("PROD") >= 0) {
			createSeleniumServerBatchFileForMP(prodTeamTestId,prodTeamDomain);
			setCredintialsToLaunchSeleniumServer(prodTeamTestId,prodTeamPassword);
		}
		else{
			createSeleniumServerBatchFileForMP(absTestId,absDomain);
			setCredintialsToLaunchSeleniumServer(absTestId,absPassword);
		}
	}


	public void createSeleniumServerBatchFileForMP(String testId,String domain) {		
		File startSeleniumForMP = new File(currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\"+testId+ ".bat");
		try {
			startSeleniumForMP.createNewFile();
			BufferedWriter startSeleniumServerForMP = new BufferedWriter(
			new FileWriter(startSeleniumForMP));
			startSeleniumServerForMP.write("runas.exe /netonly /user:"+domain+"\\"
			+ testId +" \""
			+ currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\"
			+ "\\sel_start.bat\"\r\n");
			startSeleniumServerForMP.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void clearCache(){
		cmd = new CommandLine();
		cmd.execute(currentProject
				+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\CloseBrowsersAndClearCache.bat");
	}
	public void shutdownServer(){
		cmd = new CommandLine();
		cmd.execute(currentProject
				+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\shutdownSeleniumServer.bat");
		waitForTime(10);
	}
	
	public void setCredintialsToLaunchSeleniumServer(String testId,String password){
		cmd = new CommandLine();
		cmd.execute(currentProject+ "\\src\\main\\java\\sf\\client\\service\\Common\\data\\"+testId+ ".bat");
		waitForTime(25);
		KeyboardUtility.sendKeys(password);
		KeyboardUtility.sendKeys("{ENTER}");
		KeyboardUtility.sendKeys("exit");
		KeyboardUtility.sendKeys("{ENTER}");
		waitForTime(2);
	}
}
