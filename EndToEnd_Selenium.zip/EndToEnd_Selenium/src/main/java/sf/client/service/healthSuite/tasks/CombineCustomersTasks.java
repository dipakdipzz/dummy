package sf.client.service.healthSuite.tasks;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.CWNonAgentCSObjects;
import sf.client.service.healthSuite.appObjects.ConflictCustomerInfoAppObj;
import sf.client.service.healthSuite.appObjects.CustomerMaintenanceAppObj;
import sf.client.service.healthSuite.appObjects.HouseHoldMove_PageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.SearchSelectCustomerAppObj;
import sf.client.service.healthSuite.appObjects.VerifyInfoAppObj;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.gui.Div;
import statefarm.widget.manager.Verify;

public class CombineCustomersTasks extends HouseHoldTasks {
	int countSS2C;
	/**
	 * Parameterized Constructor
	 * 
	 * @param clientE2ETO
	 */
	public CombineCustomersTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}
	/**
	 * Empty Constructor
	 */
	public CombineCustomersTasks() {

	}
	/**
	 * Launch Search and Select Two Customers page From Customer Maintenance page. 
	 */
	public void launchSS2CPageFromCMPage(){
		try{
			waitForPageLoad(CustomerMaintenanceAppObj.WidgetInfos.LINK_COMBINECUSTOMERS, 10);
			if (CustomerMaintenanceAppObj.WidgetInfos.LINK_COMBINECUSTOMERS.exists()) {
				click(CustomerMaintenanceAppObj.WidgetInfos.LINK_COMBINECUSTOMERS,
						MessageUtility.COMBINE_CUSTOMERS);
			} else {
				Verify.verifyTrue(false,
						"  Customer Maintenance page does not Exist");
			}
		}catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Search and Select Two Customers From Search and Select Two Customers page for agent role. 
	 */
	public void accessAgentSS2CPage() {
		try{
			waitForPageLoad(
					SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
					20);
			if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
					.exists()) {
				if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
						.exists()) {
					SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
							.click();
				}
				if (countSS2C == 0) {
					if (clientE2ETO.getLastNameSS2CFirstCust() != null)
						enterMandatoryfieldtoEnablebutton(
								SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_LASTNAME,
								clientE2ETO.getLastNameSS2CFirstCust());
					Verify.verifyTrue(true, clientE2ETO.getLastNameSS2CFirstCust()
							+ MessageUtility.LASTNAME);
					if (clientE2ETO.getFirstNameSS2CFirstCust() != null)
						setTextInTextbox(
								SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_FIRSTNAME,
								clientE2ETO.getFirstNameSS2CFirstCust(),
								clientE2ETO.getFirstNameSS2CFirstCust()
										+ MessageUtility.FIRSTNAME);
					if (clientE2ETO.getZip() != null) {
						setTextInTextbox(
								SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_ZIP,
								clientE2ETO.getZip(), clientE2ETO.getZip()
										+ MessageUtility.ZIP);
					} else {
						if (clientE2ETO.getCity() != null)
							if (SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_CITY
									.exists())
								setTextInTextbox(
										SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_CITY,
										clientE2ETO.getCity(),
										clientE2ETO.getCity()
												+ MessageUtility.CITY);
						if (clientE2ETO.getState() != null)
							if (SearchSelectCustomerAppObj.WidgetInfos.LISTBOX_ENTERPRISENAMESEARCHCRITERIA_STATE
									.exists())
								selectFromListbox(
										SearchSelectCustomerAppObj.WidgetInfos.LISTBOX_ENTERPRISENAMESEARCHCRITERIA_STATE,
										clientE2ETO.getState(),
										MessageUtility.STATE);
					}
					if (clientE2ETO.getLastNameSS2CSecondCust() != null) {
						countSS2C += 1;
					}
				} else {
					if (SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_CITY
							.isEnabled())
						SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_CITY
								.setText("");
					if (SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_FIRSTNAME
							.isEnabled())
						SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_FIRSTNAME
								.setText("");
					if (SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_LASTNAME
							.isEnabled())
						SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_LASTNAME
								.setText("");
					if (SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_ZIP
							.isEnabled())
						SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_ZIP
								.setText("");
	
					if (clientE2ETO.getLastNameSS2CSecondCust() != null)
	
						enterMandatoryfieldtoEnablebutton(
								SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_LASTNAME,
								clientE2ETO.getLastNameSS2CSecondCust());
					Verify.verifyTrue(true,
							clientE2ETO.getLastNameSS2CSecondCust()
									+ MessageUtility.LASTNAME);
	
					if (clientE2ETO.getFirstNameSS2CSecondCust() != null)
	
						setTextInTextbox(
								SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_FIRSTNAME,
								clientE2ETO.getFirstNameSS2CSecondCust(),
								clientE2ETO.getFirstNameSS2CSecondCust()
										+ MessageUtility.FIRSTNAME);
	
					if (clientE2ETO.getZipSS2C() != null) {
	
						setTextInTextbox(
								SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_ZIP,
								clientE2ETO.getZipSS2C(), clientE2ETO.getZipSS2C()
										+ MessageUtility.ZIP);
					} else {
						if (clientE2ETO.getCitySS2C() != null)
							setTextInTextbox(
									SearchSelectCustomerAppObj.WidgetInfos.TEXTFIELD_AGENTNAMESEARCHCRITERIA_CITY,
									clientE2ETO.getCitySS2C(), "City");
	
						if (clientE2ETO.getStateSS2C() != null)
							selectFromListbox(
									SearchSelectCustomerAppObj.WidgetInfos.LISTBOX_ENTERPRISENAMESEARCHCRITERIA_STATE,
									clientE2ETO.getStateSS2C(),
									MessageUtility.STATE);
	
					}
					if (clientE2ETO.getLastNameSS2CFirstCust() != null) {
						countSS2C = 0;
					}
				}
				if (SearchSelectCustomerAppObj.WidgetInfos.BUTTON_SEARCH.exists()) {
					click(SearchSelectCustomerAppObj.WidgetInfos.BUTTON_SEARCH,
							MessageUtility.BUTTON_SEARCH);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
			}
		}catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Search and Select Two Customers From Search and Select Two Customers page for NonAgent. 
	 */
	public void accessAgentSS2CPageABS(){
		try{
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
				20);
		if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
				.exists()) {
			if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
					.exists()) {
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
						.click();
			}
			if (countSS2C == 0) {
				if (clientE2ETO.getLastNameSS2CFirstCust() != null) {
					enterMandatoryfieldtoEnablebutton(
							ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME,
							clientE2ETO.getLastNameSS2CFirstCust());
					Verify.verifyTrue(true,
							clientE2ETO.getLastNameSS2CFirstCust()
									+ MessageUtility.LASTNAME);
				}
				if (clientE2ETO.getFirstNameSS2CFirstCust() != null) {
					setTextInTextbox(
							ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_FIRSTNAME,
							clientE2ETO.getFirstNameSS2CFirstCust(),
							clientE2ETO.getFirstNameSS2CFirstCust()
									+ MessageUtility.FIRSTNAME);
				}
				if (clientE2ETO.getZip() != null) {
					setTextInTextbox(
							ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_ZIP,
							clientE2ETO.getZip(), clientE2ETO.getZip()
									+ MessageUtility.ZIP);
				} else {
					if (clientE2ETO.getCity() != null)
						if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY
								.exists())
							setTextInTextbox(
									ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY,
									clientE2ETO.getCity(),
									clientE2ETO.getCity()
											+ MessageUtility.CITY);
					if (clientE2ETO.getState() != null)
						if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.exists())
							selectFromListbox(
									ABSCustomerSearchTestObjects.WidgetInfos.LIST_STATE,
									clientE2ETO.getState(),
									MessageUtility.STATE);
				}
				if (clientE2ETO.getLastNameSS2CSecondCust() != null) {
					countSS2C += 1;
				}
			} else {
				if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.isEnabled())
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.setText("");
				if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.isEnabled())
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.setText("");
				if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.isEnabled())
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.setText("");
				if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.isEnabled())
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY.setText("");

				if (clientE2ETO.getLastNameSS2CSecondCust() != null)

					enterMandatoryfieldtoEnablebutton(
							ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME,
							clientE2ETO.getLastNameSS2CSecondCust());
				Verify.verifyTrue(true,
						clientE2ETO.getLastNameSS2CSecondCust()
								+ MessageUtility.LASTNAME);

				if (clientE2ETO.getFirstNameSS2CSecondCust() != null)

					setTextInTextbox(
							ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_FIRSTNAME,
							clientE2ETO.getFirstNameSS2CSecondCust(),
							clientE2ETO.getFirstNameSS2CSecondCust()
									+ MessageUtility.FIRSTNAME);

				if (clientE2ETO.getZipSS2C() != null) {

					setTextInTextbox(
							ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_ZIP,
							clientE2ETO.getZipSS2C(), clientE2ETO.getZipSS2C()
									+ MessageUtility.ZIP);
				} else {
					if (clientE2ETO.getCitySS2C() != null)
						if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY
								.exists())
							setTextInTextbox(
									ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY,
									clientE2ETO.getCitySS2C(), MessageUtility.CITY);

					if (clientE2ETO.getStateSS2C() != null)
						if (ABSCustomerSearchTestObjects.WidgetInfos.LIST_STATE.exists())
							selectFromListbox(
									ABSCustomerSearchTestObjects.WidgetInfos.LIST_STATE,
									clientE2ETO.getStateSS2C(),
									MessageUtility.STATE);

				}
				if (clientE2ETO.getLastNameSS2CFirstCust() != null) {
					countSS2C = 0;
				}
			}
			if (ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_SUBMIT.exists()) {
				click(ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_SUBMIT,
						MessageUtility.BUTTON_SEARCH);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
		}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * launch Customer Information Page from Search and Select Two Customers page. 
	 */
	public void launchConflictInfoPage(){
		try{
			waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.LINK_NEXT, 15);
			if (CWNonAgentCSObjects.WidgetInfos.LINK_NEXT.exists()) {
				click(CWNonAgentCSObjects.WidgetInfos.LINK_NEXT,
						MessageUtility.LINK_NEXT);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
			}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Select searched customer from Search and Select Two Customers page. 
	 * @param customer
	 */
	public void selectcCustomerFromMclbAndAddToMclb(String customer) {
		try{
		if (customer != null && customer.length() > 1) {
			if (SearchSelectCustomerAppObj.WidgetInfos.BUTTON_VIEWCOMBINEADD.exists()) {
				boolean selected = selectCustomerFromTable(customer);
				if (!selected) {
					Verify.verifyTrue(false,  customer + MessageUtility.CUSTOMER_NOTSELECTED);
							
				}
				if (selected) {
					System.out.println("Praveen BUTTON_VIEWCOMBINEADD:");
					click(SearchSelectCustomerAppObj.WidgetInfos.BUTTON_VIEWCOMBINEADD,
							MessageUtility.BUTTON_ADD);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
			}
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.CUSTOMERNAME_NULL);
		}
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * launch Verify Information Page. 
	 */
	public void launchVerifyInfoPage() {
		try{
		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.LINK_NEXT, 30);
		if (ConflictCustomerInfoAppObj.WidgetInfos.LINK_NEXT.exists()) {
			click(ConflictCustomerInfoAppObj.WidgetInfos.LINK_NEXT,
					MessageUtility.LINK_NEXT);
			Verify.verifyTrue(true, MessageUtility.LINK_NEXT);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CONFLICTPAGE_NOTLAUNCHED);
		}
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Verify SSN number in Verify Information Page for combine functionality. 
	 */
	public void verifySSNCombineCustPage(){
		try{
		String USSSN_TEXT = " ";
		String CNSIN_TEXT = " ";
		WebElement elementUSSSN = getWebDriverInstance()
		.findElement(
				By.xpath("label[text()='US SSN:']"));
		WebElement elementCNSIN = getWebDriverInstance()
		.findElement(
				By.xpath("label[text()='CN SIN:']"));
		if(elementUSSSN.isDisplayed()){
			
			USSSN_TEXT = elementUSSSN.getText();
			
		}

		if(elementCNSIN.isDisplayed()){
			
			CNSIN_TEXT = elementCNSIN.getText();
			
		}
		if (USSSN_TEXT != null && USSSN_TEXT.contains("US SSN:")) {
			Verify.verifyTrue(
					true,
					MessageUtility.USSSN_DISPLAYED);
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.USSSN_NOTDISPLAYED);
		}
		if (CNSIN_TEXT != null && CNSIN_TEXT.contains("CN SIN:")) {
			Verify.verifyTrue(
					true,
					MessageUtility.CNSIN_DISPLAYED);
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.CNSIN_NOTDISPLAYED);
		}
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Click combine customer button. 
	 */
	public void combineCustomerbutton(){
		try{
		waitForPageLoad(VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE, 30);
		if (VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE.exists()) {
			if (ConflictCustomerInfoAppObj.WidgetInfos.LINK_PREVIOUS.exists()) {
				if (VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE.exists()) {
					VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE.click();
					Verify.verifyTrue(true,
							MessageUtility.BUTTON_COMBINE);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.BUTTON_COMBINE_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.VERIFYINFOPAGE_NOTLOADED);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.VERIFYINFOPAGE_NOTEXISTS);
		}
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}

	}
	/**
	 * Select and add searched first customer from Search and Select Two Customers page. 
	 */
	public void selectCombineFirstCustomerFromMCLB() {
		try {
			waitForTime(8);
			if (SearchSelectCustomerAppObj.WidgetInfos.BUTTON_VIEWCOMBINEADD.exists()) {
				selectcCustomerFromMclbAndAddToMclb(clientE2ETO
						.getCombineCust1Name());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.BUTTON_ADD_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Select and add searched Second customer from Search and Select Two Customers page. 
	 */
	public void selectCombineSecondCustomerFromMCLB(){
		try{
		waitForTime(20);
		if (SearchSelectCustomerAppObj.WidgetInfos.BUTTON_VIEWCOMBINEADD.exists()) {
			selectcCustomerFromMclbAndAddToMclb(clientE2ETO
					.getCombineCust2Name());
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_ADD_NOTFOUND);
		}
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Select date of birth radio button from Conflicting Customer Information page. 
	 */
	public void selectDOBMaritalStatusRadioButton() {
		try{
		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.LINK_HELP_ON_PAGE, 10);

		if (ConflictCustomerInfoAppObj.WidgetInfos.LINK_HELP_ON_PAGE.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CONFLICTPAGE_LOADED);

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE.exists())
				selectRadioButton(ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_DOB,
						MessageUtility.DOB);

			else
				Verify.verifyTrue(true, MessageUtility.DOB_SUCCESS);
			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS
					.exists())
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS,
						MessageUtility.MARRITALSTATUS);

			else
				Verify.verifyTrue(true, MessageUtility.MARRITALSTATUS_SUCCESS);

		}

		else {
			Verify.verifyTrue(false,
					MessageUtility.CONFLICTPAGE_NOTLAUNCHED);

		}
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}


	/**
	 * Click on NewChangePT option in the ACTION drop menu for auto policy from account&Policies pop up window.
	 * <p>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:HTC Off-Shore
	 */
	public void clickNewChangePTForAUTO(){
		Div policiesTable = new Div("class=policyDiv");
		if (policiesTable.exists()) {
			int divCount = 1;
			WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
					"div/div["+divCount+"]/table/tbody/tr[1]/td/strong"));
			if (policyType.getText().equalsIgnoreCase("Auto")) {
				divCount++;
				WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
				actionMenu.click();
				waitForTime(2);
				WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
				if (actionTypes.getText().contains("New Change - PT"))
						
				{
					WebElement newChangePT = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[3]/td[2]"));
					newChangePT.click();
					Verify.verifyTrue(
							true,
							MessageUtility.NEWCHANGEPTAUTO_CLICKED);
				}
				else
					Verify.verifyTrue(false,
							MessageUtility.ACTIONMENUOPTIONS_NOTDISPLAYED);
			}
		}
		
	}

	/**
	 * Click on  Add A Vehicle option in the ACTION drop menu for auto policy from account&Policies pop up window.
	 * <p>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 */
public void clickAddAVehicleForAUTO(){
		
		Div policiesTable = new Div("class=policyDiv");
		if (policiesTable.exists()) {
			int divCount = 1;
			WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
					"div/div["+divCount+"]/table/tbody/tr[1]/td/strong"));
			if (policyType.getText().equalsIgnoreCase("Auto")) {
				divCount++;
				WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
				actionMenu.click();
				waitForTime(2);
				WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
				if (actionTypes.getText().contains("Add a Vehicle"))
				{
					WebElement addAVehicle = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[4]/td[2]"));
					addAVehicle.click();
					Verify.verifyTrue(
							true,
							MessageUtility.ADDAVEHICLE_CLICKED);
				}
				else
					Verify.verifyTrue(false,
							MessageUtility.ACTIONMENUOPTIONS_NOTDISPLAYED);
			}
		}
		
	}

	/**
	 * Click on  NewChangePT option in the ACTION drop menu for Fire policy from account&Policies pop up window.
	 * <p>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. 
	 */
	public void clickNewChangePTForFire(){
		
		int divCount = 1;
		Div policiesTable = new Div("class=policyDiv");
		if (policiesTable.exists()) {
			while(true)
			{
			WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
					"div/div["+divCount+"]/table/tbody/tr[1]/td/strong"));
			if (policyType.getText().equalsIgnoreCase("Fire")) {
				divCount++;
				WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
				actionMenu.click();
				waitForTime(2);
				WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));

				if (actionTypes.getText().contains("New Change - PT"))
				{
					WebElement newChangePT = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[3]/td[2]"));	
					newChangePT.click();
					Verify.verifyTrue(
							true,
							MessageUtility.NEWCHANGEPTFIRE_CLICKED);
					break;
				}

				else
					Verify.verifyTrue(false,
							MessageUtility.ACTIONMENUOPTIONS_NOTDISPLAYED);
			}
			divCount++;
		}
		}
	}
	
	public void Policies()
	{
		int divCount = 1;
		Div policies = new Div("id=gridInsurance");
		if (policies.exists()) {
		while(true)
		{		
			WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
					"div/div["+divCount+"]/table/tbody/tr[1]/td[1]/span"));
			if (policyType.getText().equalsIgnoreCase("Auto")) {
				divCount++;
				WebElement autoPolicy = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
				if(autoPolicy.isDisplayed())
				{
					autoPolicy.click();
					waitForTime(15);
					Verify.verifyTrue(true,MessageUtility.AUTOPOLICY_CLICKED);
					isAutoPoliciesPageLaunched();
					closeAutoAppScreen();
				
				}
				else
					Verify.verifyTrue(false,MessageUtility.AUTOPOLICY_NOTFOUND);	
						
			}
			if (policyType.getText().equalsIgnoreCase("Fire")) {
				divCount++;
				WebElement firePolicy = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
				if(firePolicy.isDisplayed())
				{
					firePolicy.click();
					waitForTime(15);
					Verify.verifyTrue(true,MessageUtility.FIREPOLICY_CLICKED);
					
				}
				else
					Verify.verifyTrue(false,MessageUtility.FIREPOLICY_NOTFOUND);	
						
			}
			if (policyType.getText().equalsIgnoreCase("Health")) {
				divCount++;
				WebElement healthPolicy = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
				if(healthPolicy.isDisplayed())
				{
					healthPolicy.click();
					Verify.verifyTrue(true,MessageUtility.HEALTHPOLICY_CLICKED);
				}
				else
					Verify.verifyTrue(false,MessageUtility.HEALTHPOLICY_NOTFOUND);	
						
			}
			if (policyType.getText().equalsIgnoreCase("Life")) {
				divCount++;
				WebElement lifePolicy = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
				if(lifePolicy.isDisplayed())
				{
					lifePolicy.click();
					Verify.verifyTrue(true,MessageUtility.LIFEPOLICY_CLICKED);
					break;
				}
				else
					Verify.verifyTrue(false,MessageUtility.LIFEPOLICY_NOTFOUND);	
						
			}
			divCount++;
			}
		}
		
	}

	/**
	 * Click on  Payment option in the ACTION drop menu for Fire policy from account&Policies pop up window..
	 * <p>
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * @throws ScriptException
	 */


	public void clickPaymentForFire() throws Exception {
		
			Div policiesTable = new Div("class=policyDiv");
			int divCount = 1;
			if (policiesTable.exists()) {
				while(true)
			{
				
				WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[1]/td/strong"));
				if (policyType.getText().equalsIgnoreCase("Fire")) {
					divCount++;
					WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
							"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
					actionMenu.click();
					WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));

					if (actionTypes.getText().contains("Payment"))
					{
						WebElement payment = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[1]/td[2]"));
						payment.click();
						Verify.verifyTrue(
								true,
								MessageUtility.PAYMENTFIRE_CLICKED);
						break;
					}
					
					else
						Verify.verifyTrue(false,
								MessageUtility.ACTIONMENUOPTIONS_NOTDISPLAYED);
				}
				divCount++;
			}
			}
		}



	/**
	 * Display all policies from customer information page. 
	 */
	public void accountPoliciesTableCustomerInfo() {
		try {
			
			WebElement agreements = getWebDriverInstance().findElement(By.xpath("//div[@class='dojoxGridContent']"));
			if (agreements.isDisplayed()) {
				String text = agreements.getText();
				if (text.isEmpty()) {
					Verify.verifyTrue(true,
							MessageUtility.POLICIES_NOTFOUND);
				} else {
					Verify.verifyTrue(true,MessageUtility.TEXT_POLICIES);
					Verify.verifyTrue(true, text);
				}
			}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}

	}
	/**
	 * Select dateofbirth/SSN/Maritalstatus/Citizenship/Language/TaxIDP/DeathDate/Orgtype radio button from Conflicting Customer Information page. 
	 */
	public void accessConflictInfoPageAllowedValuesSecondRadioButton()
			throws Exception {
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CONFLICTPAGE_LOADED);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE2,
					MessageUtility.DOB);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2.exists()) {
			selectRadioButton(ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2,
					MessageUtility.SSN);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS
				.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS,
					MessageUtility.MARRITALSTATUS);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_CITIZENSHIP
				.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_CITIZENSHIP,
					MessageUtility.CITIZENSHIP);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_LANGUAGE.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_LANGUAGE,
					MessageUtility.LANGUAGE);

		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_TAXID.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_TAXID,
					MessageUtility.TAXIDP);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_DEATHDATE.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_DEATHDATE,
					MessageUtility.DEATHDATE);
		}
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_ORGTYPE.exists()) {
			selectRadioButton(
					ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_ORGTYPE,
					MessageUtility.SSN);
		}
	}

	/**
	 * Click mr icon from HH page. 
	 */
	public void clickMRIcon() {
		try {
			if (HouseHoldPageObjects.WidgetInfos.MR_ICON_HHPAGE.exists()) {
				WebElement mrIcon = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div/div/div/div[2]/table/tbody/tr[2]/td[4]/a/span"));
				mrIcon.click();
				waitForTime(10);
				Verify.verifyTrue(true, MessageUtility.MRICON_CLICKED);
			} else {
				Verify.verifyTrue(false, MessageUtility.MRICON_NOTFOUND);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getLocalizedMessage());
		}
	}
	/**
	 * To verify Search and Select Two Customer's page launched or not. 
	 * @return  
	 * @throws ScriptException
	 */
	public boolean isSearchandSelectTwoCustomerPage() throws ScriptException {
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
				30);
		if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
				.exists()) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * To verify Verify info page launched or not and to click combine button. 
	 * 
	 */
	public void verifyInfoandClickCombine() {
		try {
			if (isSelectedTwoCustomersExist()) {
				//if (true) {
				launchConflictInfoPage();
				if (isConflictPageLaunched()) {
					accessConflictInfoPageAllowedValuesSecondRadioButton();
					launchVerifyInfoPage();
				}
				if (isCombinePageExists()) {
					verifySSNCombineCustPage();
					combineCustomerbutton();
					if (!isCombineSuccess()) {
						clickHHPageCustomer();
						setTopFrame();
						handleCimsVersion();
					} else {
						isErrorPage("Combine Customer");
					}
				} else {
					Verify.verifyTrue(
							false,
							MessageUtility.VERIFYINFOPAGE_NOTLOADED);
				}

			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.SELECTEDCUSTNOTADDED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * To verify Conflict info page launched or not. 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isConflictInfoPageExists() throws ScriptException {
		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.LINK_HELP_ON_PAGE, 15);
		if (ConflictCustomerInfoAppObj.WidgetInfos.LINK_HELP_ON_PAGE.exists()) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * To verify Combine functionality is Success or not. 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isCombineSuccess() throws ScriptException {
		if (isHHPageLaunched()) {
			Verify.verifyTrue(true, MessageUtility.COMBINE_SUCCESS);
			return true;
		} else {
			Verify.verifyTrue(false, MessageUtility.COMBINE_FAIL);
			return false;
		}
	}

	/**
	 *Click on  Payment option in the ACTION drop menu for AUTO policy from account&Policies pop up window.
	 */
	public void launchPaymentAutoPolicy() {
		try {
			if (isPortalSearchPageExist()) {
				clickAccountandPoliciesTwisty();
				clickPaymentFromAutoActionDropdown();
				waitForTime(10);
				setWindow("Household", 10, 2);
				waitForTime(2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH,5,2);
				
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ACCOUNTSPOLICIESPAGE_NOTEXISTS);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}		
	}

	/**
	 * Click on  Payment option in the ACTION drop menu for AUTO policy from account&Policies pop up window.
	 */
	public void clickPaymentFromAutoActionDropdown() {
		Div policiesTable = new Div("class=policyDiv");
		if (policiesTable.exists()) {
			int divCount = 1;
			WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
					"div/div["+divCount+"]/table/tbody/tr[1]/td/strong"));
			if (policyType.getText().equalsIgnoreCase("Auto")) {
				divCount++;
				WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
				actionMenu.click();
				waitForTime(2);
				WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
				if (actionTypes.getText().contains("Payment"))
						
				{
					WebElement newChangePT = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[1]/td[2]"));
					newChangePT.click();
					Verify.verifyTrue(
							true,
							MessageUtility.PAYMENTAUTO_CLICKED);
				}
				else
					Verify.verifyTrue(false,
							MessageUtility.ACTIONMENUOPTIONS_NOTDISPLAYED);
			}
		}	
	}


	/**
	 * Click on  ReportALoss option in the ACTION drop menu for Fire policy from account&Policies pop up window.
	 */
	public void launchReportALossFirePolicy() {
		try {
			clickReportALossFromFireActionDropdown();
			waitForTime(10);
			setWindow("Household", 10, 2);
			waitForTime(2);
			getWebDriverInstance().close();
			waitForTime(2);
			setWindow(EndToEndConstants.CUSTOMER_SEARCH, 5, 2);

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			e.printStackTrace();
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on  ReportALoss option in the ACTION drop menu for Fire policy.
	 */
	public void clickReportALossFromFireActionDropdown() {
		int divCount = 1;
		Div policiesTable = new Div("class=policyDiv");
		if (policiesTable.exists()) {
			while(true)
			{
			WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
					"div/div["+divCount+"]/table/tbody/tr[1]/td/strong"));
			if (policyType.getText().equalsIgnoreCase("Fire")) {
				divCount++;
				WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
				actionMenu.click();
				waitForTime(2);
				WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
				if (actionTypes.getText().contains("Report a Loss"))
				{
					WebElement reportALoss = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[2]/td[2]"));	
					reportALoss.click();
					Verify.verifyTrue(
							true,
							MessageUtility.REPORTALOSS_CLICKED);
					break;
				}

				else
					Verify.verifyTrue(false,
							MessageUtility.ACTIONMENUOPTIONSFIRE_NOTDISPLAYED);
			}
			divCount++;
		}
		}
	}


	/**
	 * Click on  NewChangePT option in the ACTION drop menu for Auto policy from account&Policies pop up window.
	 */
	public void launchNewChangePTAutoPolicy(){
		try {
				clickNewChangePTForAUTO();
				waitForTime(10);
				setWindow("Household", 10, 2);
				waitForTime(2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH,5,2);
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	
	/**
	 * Click on  Add A Vehicle option in the ACTION drop menu for Auto policy from account&Policies pop up window.
	 */
	public void launchAddVechicleAutoPolicy(){
		try {
				clickAddAVehicleForAUTO();
				waitForTime(10);
				setWindow("Household", 10, 2);
				waitForTime(2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH,5,2);
				waitForTime(2);
				clickClose();
				waitForTime(5);
			} 
		 catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch(Exception e){
					Verify.verifyTrue(false,e.getMessage());
		}
	}
	/**
	 * Click on  New Change PT option in the ACTION drop menu for Fire policy from account&Policies pop up window.
	 */


	public void launchNewChangePTFirePolicy(){
			try {
					clickAccountandPoliciesTwisty();
					clickNewChangePTForFire();
					waitForTime(10);
					setWindow("Household", 10, 2);
					waitForTime(2);
					getWebDriverInstance().close();
					waitForTime(2);
					setWindow(EndToEndConstants.CUSTOMER_SEARCH,5,2);
				
			} catch (ScriptException scriptException) {
				scriptError(scriptException);
			} catch(Exception e){
				e.printStackTrace();
						Verify.verifyTrue(false, e.getMessage());
			}
	}
	/**
	 * Click on Payment option in the ACTION drop menu for Fire policy from account&Policies pop up window.
	 */
	public void launchPaymentFirePolicy(){
		try {
				clickPaymentForFire();
				waitForTime(10);
				setWindow("Household", 10, 2);
				waitForTime(2);
				getWebDriverInstance().close();
				waitForTime(2);
				setWindow(EndToEndConstants.CUSTOMER_SEARCH,5,2);
				
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}  catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * To verify verify information page is launched or not for combine functionality.
	 * @return
	 */
	public boolean isCombinePageExists() {
		waitForPageLoad(VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE, 30);
		if (VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE.exists()) {
			return true;
		} else {
			return false;
		}

	}
	/**
	 * Launch verify information page from Conflicting Customer Information page.
	 * @param ab
	 */
	public void verifyInfoandClickCombineSSN(String ab) {
		try {
			if (isSearchandSelectTwoCustomerPage()) {
				launchConflictInfoPage();
				if (isConflictInfoPageExists()) {
					accessConflictInfoPage(ab);
					launchVerifyInfoPage();
				}

				combineCustomerbutton();
				isCombineSuccess();
				if (isErrorPage("Combine Customer")) {
					clickHHPageCustomer();
					handleCimsVersion();
				}

			} else {
				Verify.verifyTrue(false,
						MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
				clickHHPageCustomer();
				handleCimsVersion();
				
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Select dateofbirth/SSN/Maritalstatus/Citizenship/Language/TaxIDP/DeathDate/Orgtype radio button from Conflicting Customer Information page.
	 * @param x 
	 * @throws ScriptException
	 */
	public void accessConflictInfoPage(String x) throws ScriptException {

		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.DIV_CONFLICT_CUSTINFOPAGE, 15);
		if (ConflictCustomerInfoAppObj.WidgetInfos.DIV_CONFLICT_CUSTINFOPAGE.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CONFLICTPAGE_LOADED);

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE.exists()) {
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE2,
						MessageUtility.DOB);
			}

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS
					.exists()) {
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS,
						MessageUtility.MARRITALSTATUS);
			}

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_CITIZENSHIP
					.exists()) {
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_CITIZENSHIP,
						MessageUtility.CITIZENSHIP);
			}

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_LANGUAGE.exists()) {
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_LANGUAGE,
						MessageUtility.LANGUAGE);
			}

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_TAXID.exists()) {
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_TAXID,
						MessageUtility.TAXIDP);
			}

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_DEATHDATE
					.exists()) {
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_DEATHDATE,
						MessageUtility.DEATHDATE);
			}

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_ORGTYPE
					.exists()) {
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_ORGTYPE,
						MessageUtility.ORGANIZATIONTYPE);
			}

			if (x.equalsIgnoreCase("selectCustOneSSN")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN1.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2,
							MessageUtility.FIRSTSSN);
				}
			}

			if (x.equalsIgnoreCase("selectCustOneSSNSW")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN1.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2,
							MessageUtility.FIRSTSSN);
				}
			}

			if (x.equalsIgnoreCase("selectCustOneSSNCanada")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN1.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2,
							MessageUtility.FIRSTSSN);
				}
			}

			if (x.equalsIgnoreCase("selectCustTwoSSN")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2,
							MessageUtility.SECONDSSN);
				}
			}

			if (x.equalsIgnoreCase("selectCustTwoSSNSW")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2,
							MessageUtility.SECONDSSN);
				}
			}

			if (x.equalsIgnoreCase("selectCustTwoSSNCanada")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2,
							MessageUtility.SECONDSSN);
				}
			}

			if (x.equalsIgnoreCase("selectNewSSN")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN_OTHER
						.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN_OTHER,
							"SSN selected");
					setTextInTextbox(
							ConflictCustomerInfoAppObj.WidgetInfos.TEXT_SSN_SIN_OTHER,
							"503162489", MessageUtility.NEWSSN);
				}
			}

			if (x.equalsIgnoreCase("selectNewSSNSW")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN_OTHER
						.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN_OTHER,
							"SSN selected");
					setTextInTextbox(
							ConflictCustomerInfoAppObj.WidgetInfos.TEXT_SSN_SIN_OTHER,
							"503162489", MessageUtility.NEWSSN);
				}
			}

			if (x.equalsIgnoreCase("selectNewSSNCanada")) {
				if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN_OTHER
						.exists()) {
					selectRadioButton(
							ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN_OTHER,
							"SSN selected");
					setTextInTextbox(
							ConflictCustomerInfoAppObj.WidgetInfos.TEXT_SSN_SIN_OTHER,
							"503162489", MessageUtility.NEWSSN);
				}
			}

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CONFLICTPAGE_NOTLAUNCHED);
		}
	}
	/**
	 * launch And Verify MR Icon from HouseHold page.
	 * 
	 */
	public void launchAndVerifyMRIcon() {
		try {
			if (isHHPageLaunched()) {
				clickMRIcon();
				verifyMRIcon();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}
	/**
	 * search and Select Second Customer from Search and Select Two Customer's page.
	 * @throws ScriptException
	 * 
	 */
	public void searchandSelectSecondCustomer() throws ScriptException {
		if (selectCustomerFromTable(clientE2ETO.getCombineCust1Name())) {
			accessAgentSS2CPage();
			selectCombineSecondCustomerFromMCLB();

		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.SECONDCUSTNOTFOUND);
		}
	}
	/**
	 * search and Select First Customer from Search and Select Two Customer's page for support write.
	 * 
	 */
	public void searchandSelectFirstCustomerABS() throws ScriptException {
		if (selectCustomerFromTable(clientE2ETO.getCombineCust1Name())) {
			accessAgentSS2CPageABS();
			selectCombineSecondCustomerFromMCLB();

		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.FIRSTCUSTNOTFOUND);
		}
	}
	/**
	 * verify And Search and Select Two Customers from Search and Select Two Customer's page for agent.
	 * 
	 */

	public void verifyAndSearchandSelectTwoCustomersPage() {
			try {
				if (isHHPageLaunched()) {
					clickMenuBar(HouseHoldTestObjects.WidgetInfos.CUSTOMER_LINK, HouseHoldTestObjects.WidgetInfos.LINK_CUSTOMER_UNDERCOMBINESEPARATE_CRC);
					if (isCustomerMaintanancePage()) {
						launchSS2CPageFromCMPage();
						if (isSearchandSelectTwoCustomerPage()) {
							accessAgentSS2CPage();
							selectCombineFirstCustomerFromMCLB();
							searchandSelectSecondCustomer();
						} else {
							Verify.verifyTrue(false,
									MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
						}
					} else {
						Verify.verifyTrue(false,
								MessageUtility.CUSTMAINTAINENCEPAGE_NOTLAUNCHED);
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException exception) {
				scriptError(exception);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}
	
	/**
	 * Launch Search and Select Two Customer's Page from customer search page.
	 * 
	 */
	public void combineSearchandSelectTwoCustomers() {
		try{
			if (isAgentBusinessSystemExist()) {
				clickCustomer();
				if (isPortalSearchPageExist()) {
					launchPortalCustomerSearchPage();
					launchPortalHHPage();
					verifyAndSearchandSelectTwoCustomersPage();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
				}
	
			} else {
				Verify.verifyTrue(false, MessageUtility.ABSPAGE_NOTLAUNCHED);
			}
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * verify And Search and Select Two Customers from Search and Select Two Customer's page for Support Write.
	 * 
	 */
	public void verifySearchandSelectTwoCustomersPageABS() {
		try {
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 25, 2);
			setTopFrame();
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_CUSTOMERTAB,
						HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_COMBINESEPARATE);
				if (isCustomerMaintanancePage()) {
					launchSS2CPageFromCMPage();
					if (isSearchandSelectTwoCustomerPage()) {
						accessAgentSS2CPageABS();
						selectCombineFirstCustomerFromMCLB();
						searchandSelectFirstCustomerABS();
					} else {
						Verify.verifyTrue(false,
								MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTMAINTAINENCEPAGE_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false,e.getMessage());
		}
		}
	/**
	 * Select SSN for first customer in Conflicting Customer Information page.
	 * 
	 */
	public void combineselectCustOneSSN() {
	try{	
		if (clientE2ETO.getType().equalsIgnoreCase("selectCustOneSSN")) {
			verifyAndSearchandSelectTwoCustomersPage();
			verifyInfoandClickCombineSSN("selectCustOneSSN");
		}
		if (clientE2ETO.getType().equalsIgnoreCase("selectCustOneSSNSW")) {
			verifySearchandSelectTwoCustomersPageABS();
			verifyInfoandClickCombineSSN("selectCustOneSSNSW");
		}
		if (clientE2ETO.getType().equalsIgnoreCase("selectCustOneSSNCanada")) {
			verifyAndSearchandSelectTwoCustomersPage();
			verifyInfoandClickCombineSSN("selectCustOneSSNCanada");
		}
	} catch(Exception e){
		Verify.verifyTrue(false, e.getMessage());
	}
	}
	/**
	 * Select SSN for second customer in Conflicting Customer Information page.
	 * 
	 */
	public void combineSelectCustTwoSSN() {
		try{
		if (clientE2ETO.getType().equalsIgnoreCase("selectCustTwoSSN")) {
			verifyAndSearchandSelectTwoCustomersPage();
			verifyInfoandClickCombineSSN("selectCustTwoSSN");
		}
		if (clientE2ETO.getType().equalsIgnoreCase("selectCustTwoSSNSW")) {
			verifySearchandSelectTwoCustomersPageABS();
			verifyInfoandClickCombineSSN("selectCustTwoSSNSW");
		}
		if (clientE2ETO.getType().equalsIgnoreCase("selectCustTwoSSNCanada")) {
			verifyAndSearchandSelectTwoCustomersPage();
			verifyInfoandClickCombineSSN("selectCustTwoSSNCanada");
		}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Enter new SSN in Conflicting Customer Information page.
	 * 
	 */
	public void combineSelectNewSSN(){
		if (clientE2ETO.getType().equalsIgnoreCase("selectNewSSN")) {
			verifyAndSearchandSelectTwoCustomersPage();
			verifyInfoandClickCombineSSN("selectNewSSN");
		}
		if (clientE2ETO.getType().equalsIgnoreCase("selectNewSSNSW")) {
			verifySearchandSelectTwoCustomersPageABS();
			verifyInfoandClickCombineSSN("selectNewSSNSW");
		}
		if (clientE2ETO.getType().equalsIgnoreCase("selectNewSSNCanada")) {
			verifyAndSearchandSelectTwoCustomersPage();
			verifyInfoandClickCombineSSN("selectNewSSNCanada");
		}
	}


	public void clickAccountandPoliciesTwisty() {
			try {
				
					WebElement accountPolicies = getWebDriverInstance().findElement(By.xpath("//div[@id='gridNode']/div/div/div/div/div/div/table/tbody/tr/td[1]/span/span"));
					if (accountPolicies.isDisplayed()) {
						accountPolicies.click();
						waitForTime(5);
						Verify.verifyTrue(true,
								MessageUtility.ACCOUNTSANDPOLICES_CLICKED);
					} else
						Verify.verifyTrue(false,
								MessageUtility.ACCOUNTSANDPOLICES_NOTCLICKED);
				
			} catch (ScriptException e) {
				scriptError(e);
			}
		}
	
	public void clickClose()
	{
		try
		{
			WebElement close = getWebDriverInstance().findElement(By.xpath("//div[@class='policyCloseDiv']/span/span"));
			close.click();
			Verify.verifyTrue(true, MessageUtility.BUTTON_CLOSE);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
