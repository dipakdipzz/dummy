package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Span;

/**
 * This class contains all the page objects related to Auto Policy View Page
 */
public class AutoPolicyViewPageObjects {
	
	private static final String AUTOPOLICY_DIV_AUTOPOLICYHEADER = "class=autoPolicyHeaderL";
	private static final String AUTOPOLICY_SPAN_VIEWFIREHEADER = "text=Fire Policy Information";
	
	@WidgetIDs
	public static class WidgetInfos {
		
		public static final Div DIV_AUTOPOLICYHEADER = new Div(
				AUTOPOLICY_DIV_AUTOPOLICYHEADER);
		public static final Span SPAN_VIEWFIREHEADER = new Span(
				AUTOPOLICY_SPAN_VIEWFIREHEADER);
		
	}
}
