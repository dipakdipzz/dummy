package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Label;
import statefarm.widget.gui.Link;

public class RemoveFromBookPageObj {
	
	// public static final Button REMOVE_FROM_BOOK =new Button ("text=Remove");
	// public static final Button CANCEL_REMOVE_BEFORE_CONFORM =new Button
	// ("text=Cancel");
	// public static final Button OK_TO_CONFIRM =new Button ("text=OK");
	// public static final Button CANCEL_REMOVAL = new Button ("text=Cancel");
	// public static final Label WARNING1 =new Label
	// ("text= - Your access to any activities for the customers you select will also be removed!");
	// public static final Label WARNING2 =new Label
	// ("text= - Any customer-to-customer relationships for the customers you select will no longer be viewable!");
	// public static final Label WARNING3= new Label
	// ("text= - Any Accounts / Policies with Others information for the customers you select will no longer be viewable!");
	// public static final Label WARNING4= new Label
	// ("text= - Any applications or quotes that exist for the customers you select will no longer be viewable!");
	// public static final Div NON_DISCLOSURE =new Div ("id=footer");
	// public static final Div DIV_RFB =new Div("id=pageContent");

	private static final String REMOVEFROMBOOK_BUTTON_REMOVE = "text=Remove";
	private static final String REMOVEFROMBOOK_BUTTON_CANCEL = "text=Cancel";
	private static final String REMOVEFROMBOOK_BUTTON_OK = "text=OK";
	private static final String REMOVEFROMBOOK_LABEL_WARNING1 = "text= - Your access to any activities for the customers you select will also be removed!";
	private static final String REMOVEFROMBOOK_LABEL_WARNING2 = "text= - Any customer-to-customer relationships for the customers you select will no longer be viewable!";
	private static final String REMOVEFROMBOOK_LABEL_WARNING3 = "text= - Any Accounts / Policies with Others information for the customers you select will no longer be viewable!";
	private static final String REMOVEFROMBOOK_LABEL_WARNING4 = "text= - Any applications or quotes that exist for the customers you select will no longer be viewable!";
	private static final String REMOVEFROMBOOK_DIV_NON_DISCLOSURE = "id=footer";
	private static final String REMOVEFROMBOOK_DIV_PAGECONTENT = "id=pageContent";
	private static final String REMOVEFROMBOOK_TEXT_REMOVEFROMBOOK = "text=Remove From Book";

	public static Link getWp_link_searchCustomerName(String custName) { /*Verify while modifying in Tasks files */
		return new Link("text=" + custName + "*");
	}

	public static CheckBox getWp_checkBox_customerRemove(int checkNumber) { /*Verify while modifying in Tasks files */
		return new CheckBox("name=eligibleRemoveFromBooks[" + checkNumber + "].checkedForRemoval");
	}

	public static Label getWp_label_EligibleCustName(String customerName) { /*Verify while modifying in Tasks files */
		return new Label("text=" + customerName);
	}

	public static CheckBox getWp_checkBox_customerRemove(String forProperty) { /*Verify while modifying in Tasks files */
		return new CheckBox("id=" + forProperty);
	}

	@WidgetIDs
	public static class WidgetInfos {
		public static final Button BUTTON_REMOVE = new Button(REMOVEFROMBOOK_BUTTON_REMOVE);
		public static final Button BUTTON_CANCEL = new Button(REMOVEFROMBOOK_BUTTON_CANCEL);
		public static final Button BUTTON_OK = new Button(REMOVEFROMBOOK_BUTTON_OK);

		public static final Label LABEL_WARNING1 = new Label(REMOVEFROMBOOK_LABEL_WARNING1);
		public static final Label LABEL_WARNING2 = new Label(REMOVEFROMBOOK_LABEL_WARNING2);
		public static final Label LABEL_WARNING3 = new Label(REMOVEFROMBOOK_LABEL_WARNING3);
		public static final Label LABEL_WARNING4 = new Label(REMOVEFROMBOOK_LABEL_WARNING4);

		public static final Div NON_DISCLOSURE = new Div(REMOVEFROMBOOK_DIV_NON_DISCLOSURE);
		public static final Div DIV_PAGECONTENT = new Div(REMOVEFROMBOOK_DIV_PAGECONTENT);
		public static final Link LINK_REMOVEFROMBOOK = new Link(REMOVEFROMBOOK_TEXT_REMOVEFROMBOOK);
	}
}
