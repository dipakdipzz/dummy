package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Label;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

public class HouseHoldMove_PageObjects {
	
	

	public static final String HOUSEHOLDMOVE_PAYMENYBILLHISTORY = "text=Payment/Bill History";
	public static final String HOUSEHOLDMOVE_BILLINGPAYMENTCLOSE = "id=ConsolBtnClose";
	public static final String HOUSEHOLDMOVE_CLOSECUSTOMERCHANGE = "name=closeCustomerInitiatedAssignment";
	public static final String HOUSEHOLDMOVE_CHANGEAGENT = "text=Change Agent";
	public static final String HOUSEHOLDMOVE_PRODMANAGER_CLOSE = "id=close";
	public static final String HOUSEHOLDMOVE_CREATENOTE = "text=Create Note";
	public static final String HOUSEHOLDMOVE_SMP_TAB = "text=Apply SMP";
	public static final String HOUSEHOLDMOVE_DIRECTMAIL = "text=Direct Mail";
	public static final String HOUSEHOLDMOVE_ACTIVITY_LIST = "text=Household Activities";
	public static final String HOUSEHOLDMOVE_CREATEFOLLOWUP = "text=Create Follow-up";
	public static final String HOUSEHOLDMOVE_PRODMANAGER_1 = "id=logoTop";
	public static final String HOUSEHOLDMOVE_CLOSE_CREATEFOLLOWUP = "id=cancelButton";
	public static final String HOUSEHOLDMOVE_NEWSFPP = "text=New SFPP";
	public static final String HOUSEHOLDMOVE_ACTIVITIESTAB = "text=Activities";
	public static final String CREATEFOLLOWUP_ACTIVITYACTIONS = "text=Activity Actions";
	public static final String CREATEFOLLOWUP_REFRESHRESULTS = "text=Refresh Results";
	public static final String HOUSEHOLDMOVE_HHACTIVITIES = "text=Activity List";
	public static final String HOUSEHOLDMOVE_FOLLOWUP = "text=Create Follow-up";
	public static final String HOUSEHOLDMOVE_NOTE = "text=Create Note";
	public static final String HOUSEHOLDMOVE_ACTIVITIESSMP = "text=SMP";
	public static final String HOUSEHOLDMOVE_MARKETINGTAB = "text=Marketing";
	public static final String HOUSEHOLDMOVE_IFRTOOLS = "text=IFR Tools";
	public static final String HOUSEHOLDMOVE_ACTIONPLAN = "text=Action Plan";
	public static final String HOUSEHOLDMOVE_NAQS = "text=NAQs";
	public static final String HOUSEHOLDMOVE_SMP = "text=SMP";
	public static final String HOUSEHOLDMOVE_MARKETINGOPP = "text=Marketing Opportunities";
	public static final String HouseHoldMove_DirectMail = "text=Direct Mail";
	public static final String HOUSEHOLDMOVE_APPQUOTECLOSE = "name=close";
	public static final String HOUSEHOLDMOVE_SFPPCLOSE = "value=Close";
	public static final String HOUSEHOLDMOVE_COMBINESEPARATE = "text=Combine/Separate";
	public static final String HOUSEHOLDMOVE_CREATENOTE_CLOSE = "id=cancelButton";
	public static final String HOUSEHOLDMOVE_LINK_MOVEMEMBERS_BETWEEN_TWOHOUSEHOLDS = "text=Move members between two households";
	public static final String HOUSEHOLDMOVE_BUTTON_SAVEMOVE = "id=save";
	public static final String HOUSEHOLDMOVE_TEXT_AGENTNAMESEARCHCRITERIAL = "id=agentNameSearchCriteria.lastName"; 
	public static final String HOUSEHOLDMOVE_TEXT_AGENTNAMESEARCHCRITERIAF = "id=agentNameSearchCriteria.firstName";
	public static final String HOUSEHOLDMOVE_TEXT_AGENTNAMESEARCHCRITERIAZ = "id=agentNameSearchCriteria.zip";
	public static final String HOUSEHOLDMOVE_TEXT_AGENTNAMESEARCHCRITERIAC = ".class=Html.INPUT.text|.id=agentNameSearchCriteria.city";
	public static final String HOUSEHOLDMOVE_BUTTON_SEARCHBUTTON = "id=agentNameSearch";
	public static final String HOUSEHOLDMOVE_TABLE_MOVECUSTTWONAMES = "id=householdMembers1";
	public static final String HOUSEHOLDMOVE_TABLE_MOVECUSTTWONAMES2 = "id=householdMembers2";
	public static final String HOUSEHOLDMOVE_BUTTON_MOVECUSTONENAME = "text=Move >";
	public static final String HOUSEHOLDMOVE_BUTTON_MOVECUSTTWONAME = "text=< Move";
	public static final String HOUSEHOLDMOVE_SELECT_AGENTHHMOVES = "onclick=agentSelected(*);";
	public static final String HOUSEHOLDMOVE_LINK_MOVEMEMBERS_TO_NEW_HOUSEHOLD = "text=Move members to a new household";
	public static final String HOUSEHOLDMOVE_CUSTOMERTAB = "text=Customer";
	public static final String HOUSEHOLDMOVE_CUSTOMERINFO = "text=Customer Information";	
	
	public static final String HOUSEHOLDMOVE_HOUSEHOLDTAB = "text=Household";
	public static final String HOUSEHOLDMOVE_LOSSHISTORY = "text=Loss History";

	public static final String HOUSEHOLDMOVE_POLICY_LISTING_PRINT = "text=Policy Listing Print";
	public static final String HOUSEHOLDMOVE_CLAIM_STATUS ="text=Claim Status";
	public static final String HOUSEHOLDMOVE_APPQUOTETAB = "text=App Quote";
	public static final String HOUSEHOLDMOVE_NEWAPPQUOTE = "text=New App/Quote";
	public static final String HOUSEHOLDMOVE_PRODMANAGER = "text=Production Manager";
	public static final String HOUSEHOLDMOVE_LINK_PAYMENTREFERENCE = "text=New business application reference # search";
	
	public static final String CREATEFOLLOWUP_TEXT_DUEON = "id=followupPriorityInd";
	public static final String CREATEFOLLOWUP_LISTBOX_LINEOFBUSINESS = "id=followupLineCode";
	public static final String CREATEFOLLOWUP_LISTBOX_CATEGORY = "id=followupCategoryCode";
	public static final String CREATEFOLLOWUP_TEXT_DESCRIPTION = "id=followupDescription";
	public static final String CREATEFOLLOWUP_TEXTAREA_REMARKS = "id=followupRemarks";
	public static final String CREATEFOLLOWUP_BUTTON_SAVE  =  "id=saveButton";
	
	
	
	
	
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final Link LOSSHISTORY = new Link(HOUSEHOLDMOVE_LOSSHISTORY);
		public static final Button BILLINGPAYMENTCLOSE = new Button(HOUSEHOLDMOVE_BILLINGPAYMENTCLOSE);
		public static final Link PAYMENTREFERENCELINK = new Link(HOUSEHOLDMOVE_LINK_PAYMENTREFERENCE);
		public static final Button CLOSECUSTOMERCHANGE = new Button(HOUSEHOLDMOVE_CLOSECUSTOMERCHANGE);
		public static final Button PRODMANAGER_CLOSE = new Button(HOUSEHOLDMOVE_PRODMANAGER_CLOSE);
		public static final Label CREATENOTE = new Label(HOUSEHOLDMOVE_CREATENOTE);
		public static final Div SMP = new Div(HOUSEHOLDMOVE_SMP_TAB);
		public static final Label DIRECTMAIL = new Label(HOUSEHOLDMOVE_DIRECTMAIL);
		public static final Span ACTIVITY_LIST = new Span (HOUSEHOLDMOVE_ACTIVITY_LIST);
		public static final Label CREATEFOLLOWUP = new Label(HOUSEHOLDMOVE_CREATEFOLLOWUP);
		public static final Div PRODMANAGER = new Div(HOUSEHOLDMOVE_PRODMANAGER_1);
		public static final Button CLOSE_CREATEFOLLOWUP = new Button (HOUSEHOLDMOVE_CLOSE_CREATEFOLLOWUP);
		public static final Button APPQUOTECLOSE = new Button(HOUSEHOLDMOVE_APPQUOTECLOSE);
		public static final Button SFPPCLOSE = new Button(HOUSEHOLDMOVE_SFPPCLOSE);
		public static final Button CREATENOTE_CLOSE = new Button (HOUSEHOLDMOVE_CREATENOTE_CLOSE);
		public static final Link LINK_MOVEMEMBERS_BETWEEN_TWOHOUSEHOLDS = new Link(HOUSEHOLDMOVE_LINK_MOVEMEMBERS_BETWEEN_TWOHOUSEHOLDS);
		public static final Button BUTTON_SAVEMOVE = new Button(HOUSEHOLDMOVE_BUTTON_SAVEMOVE);
		public static final TextField TEXT_AGENTNAMESEARCHCRITERIAL = new TextField(HOUSEHOLDMOVE_TEXT_AGENTNAMESEARCHCRITERIAL); // TextGuiTestObject
		public static final TextField TEXT_AGENTNAMESEARCHCRITERIAF = new TextField(HOUSEHOLDMOVE_TEXT_AGENTNAMESEARCHCRITERIAF); // TextGuiTestObject
		public static final TextField TEXT_AGENTNAMESEARCHCRITERIAZ = new TextField(HOUSEHOLDMOVE_TEXT_AGENTNAMESEARCHCRITERIAZ); // TextGuiTestObject
		public static final TextField TEXT_AGENTNAMESEARCHCRITERIAC = new TextField(HOUSEHOLDMOVE_TEXT_AGENTNAMESEARCHCRITERIAC); // TextGuiTestObject
		public static final Button BUTTON_SEARCHBUTTON = new Button(HOUSEHOLDMOVE_BUTTON_SEARCHBUTTON);
		public static final Div TABLE_MOVECUSTTWONAMES = new Div(HOUSEHOLDMOVE_TABLE_MOVECUSTTWONAMES);
		public static final Div TABLE_MOVECUSTTWONAMES2 = new Div(HOUSEHOLDMOVE_TABLE_MOVECUSTTWONAMES2);
		public static final Button BUTTON_MOVECUSTONENAME = new Button(HOUSEHOLDMOVE_BUTTON_MOVECUSTONENAME);
		public static final Button BUTTON_MOVECUSTTWONAME = new Button(HOUSEHOLDMOVE_BUTTON_MOVECUSTTWONAME);
		public static final Link SELECT_AGENTHHMOVES = new Link (HOUSEHOLDMOVE_SELECT_AGENTHHMOVES);
		public static final Link LINK_MOVEMEMBERS_TO_NEW_HOUSEHOLD = new Link(HOUSEHOLDMOVE_LINK_MOVEMEMBERS_TO_NEW_HOUSEHOLD);
		public static final Link LINK_HOUSEHOLDMOVE_CUSTOMERTAB = new Link(HOUSEHOLDMOVE_CUSTOMERTAB);
		public static final Link LINK_HOUSEHOLDMOVE_COMBINESEPARATE = new Link(HOUSEHOLDMOVE_COMBINESEPARATE);
		public static final Link LINK_HOUSEHOLDMOVE_CUSTOMERINFO = new Link(HOUSEHOLDMOVE_CUSTOMERINFO);
		public static final Link POLICYLISTINGPRINT = new Link(HOUSEHOLDMOVE_POLICY_LISTING_PRINT);
		public static final Link CLAIMSTATUS= new Link(HOUSEHOLDMOVE_CLAIM_STATUS);
		public static final Link NEWAPPQUOTEMENU = new Link(HOUSEHOLDMOVE_APPQUOTETAB);
		public static final Link NEWAPPQUOTE = new Link(HOUSEHOLDMOVE_NEWAPPQUOTE);
		public static final Link LINK_HOUSEHOLDMOVE_PRODMANAGER = new Link(HOUSEHOLDMOVE_PRODMANAGER);

		public static final Link LINK_HOUSEHOLDMOVE_ACTIVITIESTAB = new Link(HOUSEHOLDMOVE_ACTIVITIESTAB);
		public static final Link LINK_CREATEFOLLOWUP_ACTIVITYACTIONS = new Link(CREATEFOLLOWUP_ACTIVITYACTIONS);
		public static final Link LINK_CREATEFOLLOWUP_REFRESHRESULTS = new Link(CREATEFOLLOWUP_REFRESHRESULTS);
		public static final Link LINK_HOUSEHOLDMOVE_HHACTIVITIES = new Link(HOUSEHOLDMOVE_HHACTIVITIES);
		public static final Link LINK_HOUSEHOLDMOVE_FOLLOWUP = new Link(HOUSEHOLDMOVE_FOLLOWUP);
		public static final Link LINK_HOUSEHOLDMOVE_NOTE = new Link(HOUSEHOLDMOVE_NOTE);
		public static final Link LINK_HOUSEHOLDMOVE_ACTIVITIESSMP = new Link(HOUSEHOLDMOVE_ACTIVITIESSMP);
		public static final Link LINK_HOUSEHOLDMOVE_MARKETINGTAB = new Link(HOUSEHOLDMOVE_MARKETINGTAB);
		public static final Link LINK_HOUSEHOLDMOVE_IFRTOOLS = new Link(HOUSEHOLDMOVE_IFRTOOLS);
		public static final Link LINK_HOUSEHOLDMOVE_ACTIONPLAN = new Link(HOUSEHOLDMOVE_ACTIONPLAN);
		public static final Link LINK_HOUSEHOLDMOVE_NAQS = new Link(HOUSEHOLDMOVE_NAQS);
		public static final Link LINK_HOUSEHOLDMOVE_SMP = new Link(HOUSEHOLDMOVE_SMP);
		public static final Link LINK_HOUSEHOLDMOVE_MARKETINGOPP = new Link(HOUSEHOLDMOVE_MARKETINGOPP);
		public static final Link LINK_HOUSEHOLDMOVE_DIRECTMAIL = new Link(HOUSEHOLDMOVE_DIRECTMAIL);
		public static final Link LINK_HOUSEHOLDMOVE_NEWSFPP = new Link(HOUSEHOLDMOVE_NEWSFPP);
		
		
		public static final TextField CREATEFOLLOWUP_DUEON = new TextField(CREATEFOLLOWUP_TEXT_DUEON);
		public static final ListBox LIST_CREATEFOLLOWUP_LINEOFBUSINESS = new ListBox(CREATEFOLLOWUP_LISTBOX_LINEOFBUSINESS);
		public static final ListBox LIST_CREATEFOLLOWUP_CATEGORY = new ListBox(CREATEFOLLOWUP_LISTBOX_CATEGORY);
		public static final TextField CREATEFOLLOWUP_DESCRIPTION = new TextField(CREATEFOLLOWUP_TEXT_DESCRIPTION);
		public static final TextField CREATEFOLLOWUP_REMARKS = new TextField(CREATEFOLLOWUP_TEXTAREA_REMARKS);
		public static final Button CREATEFOLLOWUP_SAVE  = new Button(CREATEFOLLOWUP_BUTTON_SAVE);
		
}
}
