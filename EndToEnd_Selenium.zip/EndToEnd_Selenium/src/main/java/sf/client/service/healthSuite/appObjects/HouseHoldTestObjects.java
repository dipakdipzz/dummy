package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

public class HouseHoldTestObjects

{
	
	/*public static final Link LINK_HOUSEHOLD= new Link("text=Household");
	public static final Link ADDPRODUCTS= new Link("text=Add Products with Others");
	public static final Link PREVIOUSREVIEWDATE= new Link("id=lastReviewDate");
	public static final Link NEXTREVIEWDATE= new Link("id=nextReviewDate");
	public static final Link HOUSEHOLD_LINK = new Link("text=Household");
	public static final Link CUSTOMER_LINK = new Link("text=Customer");
	public static final Link MARKETING_LINK = new Link("text=Marketing");
	public static final Div INTERNETENABLED = new Div("text=Internet Enabled");
	public static final Link PRESENATIONKIT_LINK = new Link("innerText=Presentation Kit");
	public static final Link LINK_CUSTOMER_UNDERCOMBINESEPARATE_CRC = new Link("innerText=Combine/Separate");
	public static final Link LINK_HOUSEHOLDMOVES_CRC = new Link("innerText=Household Moves");
	public static final Link memberDrpDwn = new Link("text=Member Actions");
	public static final Link addIndMember = new Link("text=*Add Individual");
	public static final Link addOrgMember = new Link("innerText=*Add Organization");
	public static final Span SPAN_Products_with_Others=new Span("text=Products with Others (3)");
	public static final Span policyListingPrint=new Span("text=Your�Policies�and�Accounts");
	public static final TextField TEXT_ST_AGENT_CODE = new TextField("id=txtAgentCode");
	public static final Button BTN_AGENT_OK = new Button("id=btnOK|name=btnOK");
	*/
	
	public static final String HOUSEHOLDTEST_LINK_HOUSEHOLD = "text=Household";
	public static final String HOUSEHOLDTEST_ADDPRODUCTS = "text=Add Products with Others";
	public static final String HOUSEHOLDTEST_PREVIOUSREVIEWDATE = "id=lastReviewDate"; 
	public static final String HOUSEHOLDTEST_NEXTREVIEWDATE = "id=nextReviewDate";
	public static final String HOUSEHOLDTEST_HOUSEHOLD_LINK = "text=Household";
	public static final String HOUSEHOLDTEST_CUSTOMER_LINK = "text=Customer";
	public static final String HOUSEHOLDTEST_CUSTOMER_INFO = "text=Customer Information";
	public static final String HOUSEHOLDTEST_MARKETING_LINK = "text=Marketing";
	public static final String HOUSEHOLDTEST_INTERNETENABLED = "text=Internet Enabled";
	public static final String HOUSEHOLDTEST_LINK_HOUSEHOLDMOVES_CRC = "innerText=Household Moves";
	public static final String HOUSEHOLDTEST_MEMBERDRPDWN = "text=Member Actions";
	public static final String HOUSEHOLDTEST_ADDORGMEMBER = "text=*Add Organization";
	public static final String HOUSEHOLDTEST_SPAN_PRODUCTS_WITH_OTHERS =  "text=Products with Others (3)";
	public static final String HOUSEHOLDTEST_POLICYLISTINGPRINT = "text=Your�Policies�and�Accounts";
	public static final String HOUSEHOLDTEST_TEXT_ST_AGENT_CODE = "id=txtAgentCode";
	public static final String HOUSEHOLDTEST_BTN_AGENT_OK = "id=btnOK|name=btnOK";
	public static final String HOUSEHOLDTEST_PRESENATIONKIT_LINK = "text=Presentation Kit";
	public static final String HOUSEHOLDTEST_LINK_CUSTOMER_UNDERCOMBINESEPARATE_CRC = "text=Combine/Separate";
	public static final String HOUSEHOLDTEST_ADDINDMEMBER = "text=*Add Individual";
	private static final String LINK_HOUSEHOLDMOVE_HH_CUSTOMERINFO = "text=Customer Information";
	public static final String HOUSEHOLDTEST_PAGE_ACTIONS_LINK = "text=Page Actions";
	public static final String HOUSEHOLDTEST_PAGE_ACTIONS_REFRESH = "text=Refresh";
	public static final String HOUSEHOLDTEST_CUSTOMER_PROFILE_PRINT = "text=Customer Profile Print";
	public static final String HOUSEHOLDTEST_PAGE_ACTIONS_CLOSE = "text=Close";
	
	
	@WidgetIDs
	public static class WidgetInfos {
		
		
		public static final Link LINK_HOUSEHOLD= new Link(HOUSEHOLDTEST_LINK_HOUSEHOLD);
		public static final Link ADDPRODUCTS= new Link(HOUSEHOLDTEST_ADDPRODUCTS);
		public static final Link PREVIOUSREVIEWDATE= new Link(HOUSEHOLDTEST_PREVIOUSREVIEWDATE);
		public static final Link NEXTREVIEWDATE= new Link(HOUSEHOLDTEST_NEXTREVIEWDATE);
		public static final Link HOUSEHOLD_LINK = new Link(HOUSEHOLDTEST_HOUSEHOLD_LINK);
		public static final Link CUSTOMER_LINK = new Link(HOUSEHOLDTEST_CUSTOMER_LINK);
		public static final Link CUSTOMER_INFO = new Link(HOUSEHOLDTEST_CUSTOMER_INFO);
		public static final Link MARKETING_LINK = new Link(HOUSEHOLDTEST_MARKETING_LINK);
		public static final Div INTERNETENABLED = new Div(HOUSEHOLDTEST_INTERNETENABLED);
		public static final Link PRESENATIONKIT_LINK = new Link(HOUSEHOLDTEST_PRESENATIONKIT_LINK);
		public static final Link LINK_CUSTOMER_UNDERCOMBINESEPARATE_CRC = new Link(HOUSEHOLDTEST_LINK_CUSTOMER_UNDERCOMBINESEPARATE_CRC);
		public static final Link LINK_HOUSEHOLDMOVES_CRC = new Link(HOUSEHOLDTEST_LINK_HOUSEHOLDMOVES_CRC);
		public static final Link MEMBERDRPDWN = new Link(HOUSEHOLDTEST_MEMBERDRPDWN);
		public static final Link ADDINDMEMBER = new Link(HOUSEHOLDTEST_ADDINDMEMBER);
		public static final Link ADDORGMEMBER = new Link(HOUSEHOLDTEST_ADDORGMEMBER);
		public static final Span SPAN_PRODUCTS_WITH_OTHERS=new Span(HOUSEHOLDTEST_SPAN_PRODUCTS_WITH_OTHERS);
		public static final Span POLICYLISTINGPRINT=new Span(HOUSEHOLDTEST_POLICYLISTINGPRINT);
		public static final TextField TEXT_ST_AGENT_CODE = new TextField(HOUSEHOLDTEST_TEXT_ST_AGENT_CODE);
		public static final Button BTN_AGENT_OK = new Button(HOUSEHOLDTEST_BTN_AGENT_OK);
		public static final Link PAGE_ACTIONS_LINK = new Link(HOUSEHOLDTEST_PAGE_ACTIONS_LINK);
		public static final Link PAGE_ACTIONS_REFRESH = new Link(HOUSEHOLDTEST_PAGE_ACTIONS_REFRESH);
		public static final Link LINK_HHCUSTOMERINFO =  new Link (LINK_HOUSEHOLDMOVE_HH_CUSTOMERINFO);
		public static final Link LINK_CUSTOMER_PROFILE_PRINT = new Link(HOUSEHOLDTEST_CUSTOMER_PROFILE_PRINT);
		public static final Link LINK_PAGE_ACTIONS_CLOSE = new Link(HOUSEHOLDTEST_PAGE_ACTIONS_CLOSE);
		
	}
}
