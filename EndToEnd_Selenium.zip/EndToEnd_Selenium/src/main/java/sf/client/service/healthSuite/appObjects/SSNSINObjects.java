package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

public class SSNSINObjects

{
	/*public static final TextField TEXT_SIN = new TextField(
			"name=person.sin.number");
	public static final TextField TEXT_SSN_Member = new TextField("id=ssn0");
	public static final TextField US_SSN = new TextField("id=person.tin.number");
	public static final TextField TEXT_SIN_Member = new TextField("id=sin0");
	public static final Link printAdditionalInfo = new Link(
			"text=Print Additional Separate Information");
	public static final TextField text_CNSIN_Combine = new TextField("id=");
	public static final TextField SIN_CustTwo = new TextField("id=newClientSIN");
	public static final Button policiesTwisty = new Button("name=pbtn");
	public static final Div policyStatus = new Div("class=policyStatusDiv");
	public static final Div policyTitleName = new Div(
			"class=policyDlgTitleName");
	public static final Div policiesTable = new Div("class=policyDiv");
	public static final Span closeButton = new Span("text=Close");
	public static final Div gridInsurance = new Div("id=gridInsurance");
	public static final TextField text_USSSN_Combine = new TextField(
			"id=otherTaxId");*/
	
	private static final String SSNSIN_TEXTFIELD_SIN = "name=person.sin.number";
	private static final String SSNSIN_TEXTFIELD_SSN_MEMBER = "id=ssn0"; 
	private static final String SSNSIN_TEXTFIELD_US_SSN = "id=person.tin.number";
	public static final String SSNSIN_TEXTFIELD_SIN_MEMBER = "id=sin0";
	private static final String SSNSIN_LINK_PRINT_ADDITIONAL_SEPARATE_INFO = "text=Print Additional Separate Information";
	private static final String SSNSIN_TEXTFIELD_CNSIN_COMBINE = "id=";
	private static final String SSNSIN_TEXTFIELD_NEWCLIENTSIN = "id=newClientSIN";
	private static final String SSNSIN_BUTTON_POLICIES_TWISTY = "name=pbtn";
	private static final String SSNSIN_DIV_POLICYSTATUS = "class=policyStatusDiv";
	private static final String SSNSIN_DIV_POLICYTITLENAME = "class=policyDlgTitleName";
	private static final String SSNSIN_DIV_POLICIES_TABLE = "class=policyDiv";
	private static final String SSNSIN_SPAN_CLOSE = "text=Close";
	private static final String SSNSIN_DIV_GRIDINSURANCE = "id=gridInsurance";
	public static final String SSNSIN_TEXTFIELD_USSSN_COMBINE = "id=otherTaxId";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final TextField TEXTFIELD_SIN = new TextField(SSNSIN_TEXTFIELD_SIN);
		public static final TextField TEXTFIELD_SSN_MEMBER = new TextField(SSNSIN_TEXTFIELD_SSN_MEMBER);
		public static final TextField TEXTFIELD_US_SSN = new TextField(SSNSIN_TEXTFIELD_US_SSN);
		public static final TextField TEXTFIELD_SIN_MEMBER = new TextField(SSNSIN_TEXTFIELD_SIN_MEMBER);
		public static final Link LINK_PRINT_ADDITIONAL_SEPARATE_INFO = new Link(SSNSIN_LINK_PRINT_ADDITIONAL_SEPARATE_INFO);
		public static final TextField TEXTFIELD_CNSIN_COMBINE = new TextField(SSNSIN_TEXTFIELD_CNSIN_COMBINE);
		public static final TextField TEXTFIELD_NEWCLIENTSIN = new TextField(SSNSIN_TEXTFIELD_NEWCLIENTSIN);
		public static final Button BUTTON_POLICIES_TWISTY = new Button(SSNSIN_BUTTON_POLICIES_TWISTY);
		public static final Div DIV_POLICYSTATUS = new Div(SSNSIN_DIV_POLICYSTATUS);
		public static final Div DIV_POLICYTITLENAME = new Div(SSNSIN_DIV_POLICYTITLENAME);
		public static final Div DIV_POLICIES_TABLE = new Div(SSNSIN_DIV_POLICIES_TABLE);
		public static final Span SPAN_CLOSE = new Span(SSNSIN_SPAN_CLOSE);
		public static final Div DIV_GRIDINSURANCE = new Div(SSNSIN_DIV_GRIDINSURANCE);
		public static final TextField TEXTFIELD_USSSN_COMBINE = new TextField(SSNSIN_TEXTFIELD_USSSN_COMBINE);
	}
}
