package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.TestDataObject;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.helpers.DatabaseUtil;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;
import sf.client.service.healthSuite.to.ClientE2ETO;

public class Agent_CreateIndCust_Scenario11 extends BaseScript {
	int count = 0;
	String query = "select * from Agent_CreateIndCust_Scenario11";

	public void executeScript() throws Exception {

		/** Portal Search page launch*/
		createCustTasks.launchCustomerSeachPage();
		/**
		 * validate Create Ind & Create Org link Exists in Customer Search page.
		 * validate Enterprise connect & Enterprise View link does not Exists in
		 * Customer Search page.
		 */
		scenarioTasks.verifyCreateIndOrgConnectEnterpriseviewLinksPresent();

		/**
		 *  Create With International Characters.
		 */
		createCustTasks.createIndividualWithAdditionalMembers();

		/**
		 *  Customer Information verifications
		 */
		
		createCustTasks.launchCustomerInfoPageFromHHPage();

		/**
		 *  Add alias with International Characters
		 */
		updateTasks.addFirstAlias();

		/**
		 *  Add US Address
		 */
		updateTasks.addAddressCustomerInfo();

		/**
		 *  Update Address
		 */
		updateTasks.updateAddressCustomerInfo();

		/**
		 *  Add Email
		 */
		updateTasks.addEmailCustomerInfo();

		/**
		 *  Personal Info
		 */
		updateTasks.updatePersonalInfoCustomerInfo();

		/**
		 *  Customer Interest
		 */
		updateTasks.addCustomerInterestsCustomerInfo();

		/**
		 * Validate Change Agent Page
		 */

		updateTasks.launchHHPageFromCustomerInfo();
		updateTasks.validateChangeAgentPageInHH();

		/**
		 * Validate Payment Bill History Page
		 */
		updateTasks.validatePaymentBillingHistoryHH();

		/**
		 * Validate Close option displayed under the Refresh/Close Menu in
		 * Household Page
		 */
		updateTasks.closeHHPage();
		launcher.shutdownServer();
	}

	public void scriptMain() {

		try {
			databaseUtil = new DatabaseUtil();
			clientE2ETO = new ClientE2ETO();
			transferObject = new TestDataObject();
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil
						.loadTestDataAgentCreateIndCustScenario11(dbresultSet,
								clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());

				scenarioTasks
						.createResultsFile(resultsFileName(), scriptName());

				executeScript();

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
