package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class CRC_CreateInd_Scenario15 extends BaseScript
{
	int count=0;
	String query = "select * from CRC_CreateInd_Scenario15";
	
public void executeScript() throws Exception

	{	
	String searchType = clientE2ETO.getType();
		
	if(searchType.equalsIgnoreCase("RegularChars")){
	   
		scenarioTasks.clickLaunchContactCenterOnlineForQBRole();
       /**
	     * Create Individual Customer
	     */
	    createCustTasks.clickCreateIndividualCustomerCRC();
			 
       /**
		 * Validate the ability to Create Individual customer
		 */
		createCustTasks.createIndividualCustomerCRC();	 
			 
			 
		/**
		 * Launch Customer Info From HH page
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();		
			
		/**
		 * Add an Alias - Name (Regular Characters). Also Add Preferred Name
		 * Update this Alias - Name with International Characters including � &
		 * �
		 */
		updateTasks.addUpdateAliasCRC();		
				
		/**
		 * Validate Cancel functionality in Change Address Window
		 */
		scenarioTasks.launchAndCancelInCOA();
		//scenarioTasks.setCRCDefaultFrame();
		/**
		 * Remove all Phones
		 */
		//updateTasks.removeAllPhonesFromCustomerInfo_CRC();
		/**
		 * Add,Update and Remove Work Phone
		 *//*
		updateTasks.addWorkPhoneCustomerInfo_CRC();
		updateTasks.updateWorkPhoneCustomerInfo();
		createCustTasks.removePhoneCustomerInfo_CRC(clientE2ETO.getUpdatePhoneNumber());

		*/
		/**
		 *  Validate the Active Customer bar name and Close link in Household page
		 */
		 scenarioTasks.clickCRCOnlineTabtoNavigatetoSearchPagefromHHpage();
				
		/**
		 *  search for a Customer
		 */
		 scenarioTasks.launchHHPageFromCRCAHQBCustSearchPage();
				
		 /**
		  * Launch Customer Info From HH page
		  */
		 createCustTasks.launchCustomerInfoPageFromHHPage();	 
		 hhNavigationTasks.selectCustomerNameLinkABS();
		 scenarioTasks.setCRCDefaultFrame();
		 scenarioTasks.clickContinueButtonIfExists();
		 scenarioTasks.setCRCDefaultFrame();
		 /**
		  * Validate Product Inactive page    
		  */
		hhNavigationTasks.validateInactivePoliciesTabInHHPage();       
		
		/**
		 * Verify Customer Combine/Separate & Household Moves hyper links are not available
		 */
		hhNavigationTasks.validateHHMovesAndCustomerCombineInHHPage();	  
			
	     /**
	      * Validate that Add Individual & Add Organization hyper links are not displayed in the Household members section
	      */
		// scenarioTasks.validateAddIndAndAddOrgLinksInHHPageCRC();	       
		 scenarioTasks.clickCRCOnlineTabtoNavigatetoSearchPagefromHHpage();	 
	} 
	/*if(searchType.equalsIgnoreCase("InternationalChars")){
		
		 *//**
		 * search for a Customer
		 *//*
			 
		scenarioTasks.launchHHPageFromCRCAHQBCustSearchPage();		  
	}			
		*/
			
}
	
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataCRCCreateIndScenario15(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
			
				if(count==0) {
					launcher = new LaunchApplication(getWATConfig());
					launcher.launchUser(scriptName());
					scenarioTasks.createResultsFile(resultsFileName(),scriptName());
					}
					executeScript();
					count++;
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}		
	}
}