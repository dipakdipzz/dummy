package sf.client.service.common.helpers;

import javax.swing.Timer;




public class ScriptException extends RuntimeException
{
	
	static final long serialVersionUID = 0;
	private String exceptionMessage = null;
	private int exceptionStatus = 0;
	private String testStep = null;
	
	public ScriptException() 
	{
		this.setTestStep("(Method Name : " + super.getStackTrace()[0].getMethodName()+" ,Line Number : " + super.getStackTrace()[0].getLineNumber()+")");
	}
	
	
	public ScriptException(Exception e) 
	{
		this.setTestStep("(Method Name : " + e.getStackTrace()[0].getMethodName()+" ,Line Number : " + e.getStackTrace()[0].getLineNumber()+")");
	}

	public ScriptException(Exception e,String msg) 
	{
		this.setTestStep(msg + "(Method Name : " + e.getStackTrace()[0].getMethodName()+" ,Line Number : " + e.getStackTrace()[0].getLineNumber()+")");
	}
	
	public ScriptException(String msg)
	{
		super(msg);
		
		this.setExceptionMessage(msg);
		this.setTestStep("(Method Name : " + super.getStackTrace()[0].getMethodName()+" ,Line Number : " + super.getStackTrace()[0].getLineNumber()+")");
	}

	public ScriptException(String msg,int stat)
	{
		this.setExceptionMessage(msg);
		this.setExceptionStatus(stat);
		this.setTestStep("(Method Name : " + super.getStackTrace()[0].getMethodName()+" ,Line Number : " + super.getStackTrace()[0].getLineNumber()+")");
	}
	
	public void log()
	{
	}

	
	public void DBlog(javax.swing.Timer testCaseTimer)
	{
		// Now stop the running timer and log the error
		testCaseTimer.stop();
	}

	public void DBlog(Timer testCaseTimer,String msg)
	{
		// Now stop the running timer and log the error
		testCaseTimer.stop();
	}

	
	/**
	 * @return the testStep
	 */
	public String getTestStep() {
		return testStep;
	}

	/**
	 * @param testStep the testStep to set
	 */
	public void setTestStep(String testStep) {
		this.testStep = testStep;
	}

	/**
	 * @return the exceptionMessage
	 */
	public String getExceptionMessage() {
		return exceptionMessage;
	}

	/**
	 * @param exceptionMessage the exceptionMessage to set
	 */
	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	/**
	 * @return the exceptionStatus
	 */
	public int getExceptionStatus() {
		return exceptionStatus;
	}

	/**
	 * @param exceptionStatus the exceptionStatus to set
	 */
	public void setExceptionStatus(int exceptionStatus) {
		this.exceptionStatus = exceptionStatus;
	}
	
}
