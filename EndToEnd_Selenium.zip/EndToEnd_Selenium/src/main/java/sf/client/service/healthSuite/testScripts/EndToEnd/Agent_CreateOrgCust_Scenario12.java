package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class Agent_CreateOrgCust_Scenario12 extends BaseScript
{
	int count=0;
	String query = "select * from Agent_CreateOrgCust_Scenario12";
	public void executeScript() throws Exception{
		
		/**
		* Validate Customer Search Page
		*/
		createCustTasks.launchCustomerSeachPage();
		/**
		 * validate Create Ind & Create Org link Exists in Customer Search page.
		 *validate Enterprise connect & Enterprise View link does not Exists in
		 *Customer Search page.
		 */
		scenarioTasks.verifyCreateIndOrgConnectEnterpriseviewLinksPresent();
		/**
		* Create Organization Customer With International Characters.
		*/
		createCustTasks.createOrganizationWithAdditionalMembers();
		/**
		 *  Add an Individual
		 *//*
		scenarioTasks.addIndividualinHouseholdPage();

		*//**
		 *  Add an Organization
		 *//*
		scenarioTasks.addOrganizationinHouseholdPage();
		*//**
		 *  Customer Information verifications
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();
		/**
		 *  Add alias with International Characters
		 */
		updateTasks.addOrganizationFirstAlias();

		/**
		 *  Add alias with International Characters
		 */
		updateTasks.addOrganizationSecondAlias();

		/**
		 *  Add US Address
		 */
		updateTasks.addAddressCustomerInfo();
		
		/**
		 *  Update Address
		 */
		updateTasks.updateAddressCustomerInfo();
		
		/**
		 *  Add Email
		 */
		updateTasks.addEmailCustomerInfo();
		/**
		 *  Update Email
		 */
		updateTasks.updateEmail();
		/**
		 *  Remove Email
		 */
		updateTasks.removeEmail();
		/**
		 *  Update Organizational Fields
		 */
		updateTasks.updateOrganizationalInfo();
		/**
		 *  Navigate back to HH Page By Clicking Customer Active Bar.
		 */
		scenarioTasks.clickHHPageCustomer();
		scenarioTasks.setTopFrame();
		/**
		 *  Validate that the Household hyperlink and Non household hyperlinks are not displayed in the Household Menu
		 */
		hhNavigationTasks.validateHouseholdNonHouseholdLinks();
		/**
		 *  Validate the Relationship hyperlink displayed in under Household Menu in Household page
		 */
		hhNavigationTasks.validateAndLaunchRelationshipPage();
		/**
		 *  Verify the Relationship Page Exists and Add Individual in Member Inside and Member Outside the Household
		 */
		hhRelationshipTasks.verifyAndAddHouseholdAndNonHouseholdIndInRelationshipPage();
		/**
		 *  Validate that the Internet Enabled column is displayed in the Household members section with its field values ('Y' & 'N')
		 */
		scenarioTasks.isInternetEnabledColumnDisplayedforHTMLHHpage();
		
		/**
		 * Validate that the Life App is launhced, when the life App policy number is clicked in the Product Inactive page 
		 */
		hhNavigationTasks.validateInactivePoliciesTabInHHPage();
		scenarioTasks.launchLifeAppfromProductsInactivePage();
		
		/**
		 * Launch & Validate the Customer Profile Print document from Household page. Close it. (Errors if Customer details has International character)
		 */
		updateTasks.validateCustomerProfilePrintInHH();
				
	}
		public void scriptMain()  {
				
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			
			dbresultSet =databaseUtil.getCoreData(transferObject);
			
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentCreateOrgCustScenario12(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				
				executeScript();
				}
			} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}
