package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.TextField;

/**
 * This class contains all the page objects related to AddressSO
 */
public class AddressSO {
	
	private static final String ADDRESSSO_TEXTFIELD_STREET1 = "id=coaMailingStreet1";
	private static final String ADDRESSSO_TEXTFIELD_CITY = "id=coaMailingCity";
	private static final String ADDRESSSO_LISTBOX_STATE = "id=coaMailingState";
	private static final String ADDRESSSO_TEXTFIELD_ZIP = "id=coaMailingZip";
	private static final String ADDRESSSO_BUTTON_SAVE = "id=savesubmit";
	private static final String ADDRESSSO_BUTTON_OK = "id=ok";
	private static final String ADDRESSSO_BUTTON_FINISH_ADDRESSSTANDARDIZATION = "id=finish";
	public static final String ADDRESSSO_BUTTON_CLOSE = "text=Cancel";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final TextField TEXT_STREET1= new TextField(
				ADDRESSSO_TEXTFIELD_STREET1);
		public static final TextField TEXT_CITY= new TextField(
				ADDRESSSO_TEXTFIELD_CITY);
		public static final ListBox LIST_STATE= new ListBox(
				ADDRESSSO_LISTBOX_STATE);
		public static final TextField TEXT_ZIP= new TextField(
				ADDRESSSO_TEXTFIELD_ZIP);
		public static final Button BUTTON_SAVE= new Button(
				ADDRESSSO_BUTTON_SAVE);
		public static final Button BUTTON_OK_ADDRESSSTANDARDIZATION= new Button(
				ADDRESSSO_BUTTON_OK);
		public static final Button BUTTON_FINISH_ADDRESSSTANDARDIZATION= new Button(
				ADDRESSSO_BUTTON_FINISH_ADDRESSSTANDARDIZATION);
		public static final Button BUTTON_CLOSE = new Button(ADDRESSSO_BUTTON_CLOSE);
	}
}