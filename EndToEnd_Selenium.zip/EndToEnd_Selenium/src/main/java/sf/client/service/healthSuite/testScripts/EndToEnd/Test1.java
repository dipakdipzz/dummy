package sf.client.service.healthSuite.testScripts.EndToEnd;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.server.browserlaunchers.Firefox2Launcher;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Test1
{

	
	public static void main(String[] args)
	 {
		
	 //   setProperty(WebDriver.chrome.driver);
		WebDriver obj  = new FirefoxDriver();
		obj.get("https://www.google.co.in");
		
		
	}

}
