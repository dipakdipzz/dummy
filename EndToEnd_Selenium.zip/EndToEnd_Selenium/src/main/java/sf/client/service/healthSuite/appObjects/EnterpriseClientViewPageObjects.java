package sf.client.service.healthSuite.appObjects;

import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.TextField;

public class EnterpriseClientViewPageObjects {
	
	private static final String DIV_ENTERPRISE_ID = "id=entepriseId";
	private static final String DIV_DISPLAY_NAMES = "id=displayNames";
	private static final String TEXT_CLIENT_ID = "id=clientId";
	private static final String BUTTON_SEARCH = "value=Search";
	private static final String DIV_BIRTHDATE = "id=birthDate";
	private static final String DIV_CITIZENSHIP = "id=citizenship";
	private static final String DIV_CLIENT_ID = "id=clientId";
	private static final String DIV_DEATH_DATE = "id=deathDate";
	private static final String DIV_GENDER = "id=gender";
	private static final String DIV_LANGUAGE_OF_CHOICE = "id=languageOfChoice";
	private static final String DIV_MARITAL_STATUS = "id=maritalStatus" ;
	private static final String DIV_SSN = "id=SSN" ;
	private static final String DIV_PHONE_NUMBER = "id=phoneNumber";
	private static final String DIV_DRIVERS_LICENSE = "id=driversLicense";
	private static final String DIV_EMAIL = "id=email";
	private static final String DIV_DISPLAY_NAME = "id=displayName";

	public static class WidgetInfos {	

		public static final Div HTML_ENTEPRISEID = new Div(DIV_ENTERPRISE_ID); 
		public static final Div HTML_DISPLAYNAMES = new Div(DIV_DISPLAY_NAMES); // GuiTestObject
		public static final TextField TEXT_CLIENTID = new TextField(TEXT_CLIENT_ID); // TextGuiTestObject
		public static final Button BUTTON_SEARCHSUBMIT = new Button(BUTTON_SEARCH);
		public static Div getWp_html_birthDate(int count) {
			return new Div(DIV_BIRTHDATE+count);
		}
		public static Div getWp_html_citizenship(int count) {
			return new Div(DIV_CITIZENSHIP+count);
		}
		public static Div getWp_html_clientId(int count) {
			return new Div(DIV_CLIENT_ID+count); 
		}
		public static Div getWp_html_deathDate(int count) {
			return new Div(DIV_DEATH_DATE+count);
		}
		public static Div getWp_html_gender(int count) {
			return new Div(DIV_GENDER+count);
		}
			public static Div getWp_html_languageOfChoice(int count) {
			return new Div(DIV_LANGUAGE_OF_CHOICE+count);
		}
		public static Div getWp_html_maritalStatus(int count) {
			return new Div(DIV_MARITAL_STATUS+count);
		}
	
		public static Div getWp_html_SSN(int count) {
			return new Div(DIV_SSN+count);
		}
		
		public static Div getwp_html_phoneNumber(int count) {
			return new Div(DIV_PHONE_NUMBER+count);
		}
		
		public static Div getwp_html_driversLicense(int count) {
			return new Div(DIV_DRIVERS_LICENSE+count);
		}
		
		public static Div getwp_html_email(int count) {
			return new Div(DIV_EMAIL+count);
		}
		public static Div getWp_html_displayName(int count) {
			return new Div(DIV_DISPLAY_NAME+count);
		}
	}
}
