package sf.client.service.healthSuite.tasks;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.RemoveFromBookPageObj;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.manager.Verify;

public class RemoveFromBookTasks extends HouseHoldTasks {
	String customerName = null;
	String activeCustomerCheckProperty = null;

	public RemoveFromBookTasks() {

	}

	public RemoveFromBookTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}
    /**
     * Validating Active Customer Bar
     * @throws ScriptException
     */
	public void validateClientBar() throws ScriptException {
		
		String cust = clientE2ETO.getCsFirstName() + " "+clientE2ETO.getCsLastName();
		System.out.println("cust name before link"+cust);
		Link customerName = new Link(cust);
		System.out.println("customer name after link=="+customerName);
		if(customerName.exists())
			Verify.verifyTrue(true, MessageUtility.CUSTNAME_DISPLAYED);
		else
			Verify.verifyTrue(false, MessageUtility.CUSTNAME_NOTDISPLAYED);
		/*if ((clientE2ETO.getFirstNameSearchpage() != null && RemoveFromBookPageObj
				.getWp_link_searchCustomerName(
						clientE2ETO.getCsLastName()).exists())
				|| (clientE2ETO.getOrgNameSearchpage()) != null
				&& RemoveFromBookPageObj.getWp_link_searchCustomerName(
						clientE2ETO.getOrgNameSearchpage()).exists()) {

			if (clientE2ETO.getFirstNameSearchpage() != null) {

				customerName = RemoveFromBookPageObj
						.getWp_link_searchCustomerName(
								clientE2ETO.getFirstNameSearchpage()).getText();
				
			} else {
				customerName = RemoveFromBookPageObj
						.getWp_link_searchCustomerName(
								clientE2ETO.getOrgNameSearchpage()).getText();
				System.out.println("customer name=="+customerName);
			}
			if (customerName != null
					&& (clientE2ETO.getFirstNameSearchpage() != null && customerName
							.contains(clientE2ETO.getFirstNameSearchpage()))
					|| (clientE2ETO.getOrgNameSearchpage() != null && customerName
							.contains(clientE2ETO.getOrgNameSearchpage()))) {

				Verify.verifyTrue(true,
						"In client Bar Customer name displayed as expected :"
								+ customerName);
			} else {
				Verify.verifyTrue(false,
						"In client Bar Customer name NOT displayed as expected .");
			}
		} else {
			Verify.verifyTrue(false,
					"In client Bar Customer name NOT displayed as expected .");
		}*/
	}
    /**
     * Clicking Cancel Button in Remove From Book page
     * @throws ScriptException
     */
	public void cancelRemovalFromBook() throws ScriptException {
		waitForPageLoad(RemoveFromBookPageObj.WidgetInfos.BUTTON_CANCEL, 15);
		if (RemoveFromBookPageObj.WidgetInfos.BUTTON_CANCEL.exists()) {
			click(RemoveFromBookPageObj.WidgetInfos.BUTTON_CANCEL,
					MessageUtility.BUTTON_CANCEL);
		}
	}
    /**
     * Validating Contents in Remove From Book page
     * @throws Exception
     */
	public void validateRFBPage() throws Exception {
		if (RemoveFromBookPageObj.WidgetInfos.BUTTON_REMOVE.exists()) {
			if (RemoveFromBookPageObj.getWp_checkBox_customerRemove(0).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.REMOVEFROMBOOK_LAUNCHED);
				validateClientBar();
				validateWarningMessages();
				if (clientE2ETO.getAgentName() != null && customerName != null) {
					validateAgentName(clientE2ETO.getAgentName());
					verifyActiveCustomerRemove(getActiveCustomerName());
				}
				validateRemoveButtonInRFBPage();
				validateCancelButtonInRFBPage();
				validateNonDisclosure();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.REMOVEFROMBOOK_NOTLAUNCHED);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.REMOVEFROMBOOK_NOTLAUNCHED);
		}
	}
    /**
     * Getting Active Customer Name
     * @return
     */
	public String getActiveCustomerName() {
		if (HouseHoldPageObjects.WidgetInfos.HH_ACTIVE_CUSTOMER_BAR.exists()) {
			customerName = HouseHoldPageObjects.WidgetInfos.HH_ACTIVE_CUSTOMER_BAR
					.getText();
		} else {
			customerName = "";
		}
		return customerName;

	}
    /**
     * Validating Warning Messages in Remove From Book page
     * @throws ScriptException
     */
	public void validateWarningMessages() throws ScriptException {
		if (RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING1.exists()) {
			Verify.verifyTrue(true, RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING1.getText()
					+ MessageUtility.DISPLAYED);
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.WARNING1);
		}
		if (RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING2.exists()) {
			Verify.verifyTrue(true, RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING2.getText()
					+ MessageUtility.DISPLAYED);
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.WARNING2);
		}
		if (RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING3.exists()) {
			Verify.verifyTrue(true, RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING3.getText()
					+ MessageUtility.DISPLAYED);
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.WARNING3);
		}
		if (RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING4.exists()) {
			Verify.verifyTrue(true, RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING4.getText()
					+ MessageUtility.DISPLAYED);
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.WARNING4);
		}
	}
    /**
     * Validating AgentName in Remove From Book page
     * @param agentName
     * @throws ScriptException
     */
	public void validateAgentName(String agentName) throws ScriptException {
		String agentNameFromScreen = null;
		if (RemoveFromBookPageObj.WidgetInfos.LABEL_WARNING1.exists()) {
			Div confirmFormData = new Div("id=pageBodyPartyManagement");
			agentNameFromScreen = confirmFormData.getText();
			if (agentNameFromScreen.contains(agentName)) {
				Verify.verifyTrue(true,
						MessageUtility.AGENTNAME_DISPLAYED + agentName);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.AGENTNAME_NOTDISPLAYED);
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.AGENTNAME_NOTDISPLAYED);
		}

	}
    /**
     * Verify ActiveCustomer Removal from Remove From Book page
     * @param customerName
     * @return
     * @throws ScriptException
     */
	@SuppressWarnings("deprecation")
	public String verifyActiveCustomerRemove(String customerName)
			throws ScriptException {
		if (RemoveFromBookPageObj.getWp_label_EligibleCustName(customerName)
				.exists()) {
			try {
				activeCustomerCheckProperty = (String) (RemoveFromBookPageObj
						.getWp_label_EligibleCustName(customerName))
						.getProperty("for");
			} catch (Exception e) {
				activeCustomerCheckProperty = null;
			}
			if (activeCustomerCheckProperty != null
					&& RemoveFromBookPageObj.getWp_checkBox_customerRemove(
							activeCustomerCheckProperty).exists()) {

			} else {
				Verify.verifyTrue(false, customerName
						+ MessageUtility.CUSTNAME_NOTELIGIBLE);
			}
		}
		return activeCustomerCheckProperty;
	}
    /**
     * Validating Remove Button In Remove From Book page
     * @throws ScriptException
     */
	public void validateRemoveButtonInRFBPage() throws ScriptException {
		if (RemoveFromBookPageObj.WidgetInfos.BUTTON_REMOVE.exists()) {
			if (RemoveFromBookPageObj.WidgetInfos.BUTTON_REMOVE.isEnabled()) {
				Verify.verifyTrue(true,
						MessageUtility.BUTTON_REMOVE_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.BUTTON_REMOVE_NOTDISPLAYED);
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_REMOVE_NOTDISPLAYED);
		}
	}
    /**
     * Validating Cancel Button In Remove From Book page
     * @throws ScriptException
     */
	public void validateCancelButtonInRFBPage() throws ScriptException {
		if (RemoveFromBookPageObj.WidgetInfos.BUTTON_CANCEL.exists()) {
			if (RemoveFromBookPageObj.WidgetInfos.BUTTON_CANCEL.isEnabled()) {
				Verify.verifyTrue(true,
						MessageUtility.BUTTON_CANCEL_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.BUTTON_CANCEL_NOTDISPLAYED);
			}
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.BUTTON_CANCEL_NOTDISPLAYED);
		}
	}
    /**
     * Validating NonDisclosure Link In Remove From Book page
     * @throws ScriptException
     */
	public void validateNonDisclosure() throws ScriptException {
		if (RemoveFromBookPageObj.WidgetInfos.NON_DISCLOSURE.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.NONDISCLOSURE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.NONDISCLOSURE_NOTDISPLAYED);
		}
	}
    /**
     * Checking  Active Customer Check box To Remove
     * @throws ScriptException
     */
	public void checkActiveCustomerToRemove() throws ScriptException {
		waitForPageLoad(
				RemoveFromBookPageObj
						.getWp_checkBox_customerRemove("eligibleRemoveFromBooks[0].checkedForRemoval"),
				10);
		if (RemoveFromBookPageObj.getWp_checkBox_customerRemove(
				"eligibleRemoveFromBooks[0].checkedForRemoval").exists()) {
			click(RemoveFromBookPageObj
					.getWp_checkBox_customerRemove("eligibleRemoveFromBooks[0].checkedForRemoval"),
					MessageUtility.ACTIVECUSTOMER_CLICKED);
		} else {
			Verify.verifyTrue(false,MessageUtility.ACTIVECUSTOMER_NOTFOUND);
		}
	}
    /**
     * Launching Remove From Book Confirm Page by clicking Remove button
     * @throws ScriptException
     */
	public void launchRFBConfirmPage() throws ScriptException {
		if (RemoveFromBookPageObj.WidgetInfos.BUTTON_REMOVE.exists()) {
			click(RemoveFromBookPageObj.WidgetInfos.BUTTON_REMOVE,
					MessageUtility.BUTTON_REMOVE_CLICKED);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_REMOVE_NOTDISPLAYED);
		}
	}
   /**
    * Clicking OK button in Remove From Book Confirm Page
    * @throws ScriptException
    */
	public void confirmmRemovalInRFBConfirm() throws ScriptException {
		if (isRFBConfirmPageExists()) {
			if (RemoveFromBookPageObj.WidgetInfos.BUTTON_OK.exists()) {
				click(RemoveFromBookPageObj.WidgetInfos.BUTTON_OK,
						MessageUtility.BUTTON_CONFIRM);
			} else {
				Verify.verifyTrue(false, MessageUtility.BUTTON_OK_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.REMOVEFROMBOOKCONFIRMATIONPAGE_NOTLAUNCHED);
		}
	}
    /**
     * Verify HHPage Launch After Clicking OK button in Remove From Book Confirm Page 
     * @throws ScriptException
     */
	public void verifyHHPageLaunchAfterConfirm() throws ScriptException {
		System.out.println("getAllWindowTitlesCount:"
				+ getAllWindowTitlesCount());
		if (getAllWindowTitlesCount() != 1) {
			if (isHHPageLaunched()) {
				Verify.verifyTrue(true,
						MessageUtility.HOUSEHOLDPAGE_LAUNCHED);
				clickMenuBar("text=Refresh/Close", "text=Close");

				/** Navigate to Customer Search Page */

				setWindow("Agents Business System", 30, 2);
				isPortalCustomerSearchPageLaunchedOrNot();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} else if (getAllWindowTitlesCount() == 1) {
			setWindow("Agents Business System", 30, 2);
			isPortalCustomerSearchPageLaunchedOrNot();
		}
	}
    /**
     * Verify Remove From Book Functionality
     */
	public void verifyRemoveFromBook() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar("text=Customer", "text=Remove From Book");
				if (!isErrorPage("Remove From Book")) {
					validateRFBPage();
					cancelRemovalFromBook();
					waitForPageLoad(HouseHoldTestObjects.WidgetInfos.MARKETING_LINK, 10);
					isHosuseHoldPageLaunchedOrNot();
				} else {
					launchCustomerInfoPageFromHHPage();
					clickHHPageCustomer();
					isHosuseHoldPageLaunchedOrNot();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}
   /**
    * Validating  Active Customer Removal
    */
	public void validateActiveCustomerRemoval() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar("text=Customer", "text=Remove From Book");
				if (!isErrorPage("Remove From Book")) {
					checkActiveCustomerToRemove();
					cancelRemovalFromBook();
					waitForPageLoad(HouseHoldTestObjects.WidgetInfos.MARKETING_LINK, 20);
				} else {
					isHosuseHoldPageLaunchedOrNot();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}
   /**
    * Verify Remove From Book Page is Exists
    * @return
    * @throws ScriptException
    */
	public boolean isRemoveFromBookPageExists() throws ScriptException {
		waitForPageLoad(RemoveFromBookPageObj.WidgetInfos.DIV_PAGECONTENT, 15);
		if (RemoveFromBookPageObj.WidgetInfos.DIV_PAGECONTENT.exists()) {
			return true;
		} else {
			return false;
		}
	}
    /**
     * Verify Remove From Book Confirm Page  is Exists
     * @return
     * @throws ScriptException
     */
	public boolean isRFBConfirmPageExists() throws ScriptException {
		if (RemoveFromBookPageObj.WidgetInfos.BUTTON_OK.exists()) {
			return true;
		} else {
			return false;
		}
	}
    /**
     * Verify HHMembers In Remove From Book page
     * @throws ScriptException
     */
	public void verifyHHMembersInRemoveFromBook() throws ScriptException {
		waitForPageLoad(RemoveFromBookPageObj.WidgetInfos.DIV_PAGECONTENT, 20);
		if (isRemoveFromBookPageExists()) {
				getHouseholdMembers();
				checkActiveCustomerToRemove();
				launchRFBConfirmPage();
			}
		} 
	
   /**
    * Validating Remove From Book Page is Launched
    */
	public void validateRemoveFromBookPageLaunhed() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar("text=Customer", "text=Remove From Book");
				if (isRemoveFromBookPageExists()) {
					cancelRemovalFromBook();
				} else {
					isErrorPage("Remove From Book");
					clickHHPageCustomer();
					handleCimsVersion();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}

public void getHouseholdMembers()
{
	List<WebElement> members = getWebDriverInstance().findElements(By.xpath("//div[@id='pageContent']/form/fieldset/div[6]"));
	for(int i = 0;i<members.size();i++)
	{
		String name = members.get(i).getText();
		Verify.verifyTrue(true,name+" "+MessageUtility.CUSTOMERPRESENT);
	}
}
}