package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.TextField;

public class SearchSelectCustomerAppObj {
	
	// public static final RadioButton RADIOBUTTON_SEARCHBYTYPEAGENTNAME = new RadioButton("name=searchByType");
	// public static final TextField TEXT_AGENTNAMESEARCHCRITERIAL = new TextField("id=agentNameSearchCriteria.lastName");
	// public static final TextField TEXT_AGENTNAMESEARCHCRITERIAF = new TextField("id=agentNameSearchCriteria.firstName");
	// public static final TextField TEXT_AGENTNAMESEARCHCRITERIAZ = new TextField("id=agentNameSearchCriteria.zip");
	// public static final TextField TEXT_AGENTNAMESEARCHCRITERIAC = new TextField("id=agentNameSearchCriteria.city");
	// public static final ListBox LIST_ENTERPRISENAMESEARCHCRITSTATE = new ListBox("id=enterpriseNameSearchCriteria.state");
	// public static final Button BUTTON_SEARCHBUTTON = new Button("id=agentNameSearch");
	// public static final Button BUTTON_CANCELBUTTON = new Button("id=cancel");
	// public static final Button BUTTON_ADDBUTTON = new Button("id=viewCombineAdd");
	// public static final Div DIV_SELECTED_CUSTOMERS = new Div("id=selectedCustomersTable");
	// public static final Div SEARCH_RESULT = new Div("id=searchResults");
	// public static final Div PAGE_MOVE_DATA = new Div("id=clientOneAllNames");
	// public static final Div SEPARATE_CUSTOMER_PAGE = new Div("id=clientOneagreements");

	private static final String SEARCHSELECTCUSTOMER_RADIOBUTTON_SEARCHBYTYPE = "name=searchByType";
	private static final String SEARCHSELECTCUSTOMER_TEXTFIELD_LASTNAME = "id=agentNameSearchCriteria.lastName";
	private static final String SEARCHSELECTCUSTOMER_TEXTFIELD_FIRSTNAME = "id=agentNameSearchCriteria.firstName";
	private static final String SEARCHSELECTCUSTOMER_TEXTFIELD_ZIP = "id=agentNameSearchCriteria.zip";
	private static final String SEARCHSELECTCUSTOMER_TEXTFIELD_CITY = "id=agentNameSearchCriteria.city";
	private static final String SEARCHSELECTCUSTOMER_LISTBOX_STATE = "id=enterpriseNameSearchCriteria.state";
	private static final String SEARCHSELECTCUSTOMER_BUTTON_AGENTNAME_SEARCH = "id=agentNameSearch";
	private static final String SEARCHSELECTCUSTOMER_BUTTON_CANCEL = "id=cancel";
	private static final String SEARCHSELECTCUSTOMER_BUTTON_VIEWCOMBINEADD = "id=viewCombineAdd";
	private static final String SEARCHSELECTCUSTOMER_DIV_SELECTED_CUSTOMERS = "id=selectedCustomersTable";
	private static final String SEARCHSELECTCUSTOMER_DIV_SEARCH_RESULT = "id=searchResults";
	private static final String SEARCHSELECTCUSTOMER_DIV_PAGE_MOVE_DATA = "id=clientOneAllNames";
	private static final String SEARCHSELECTCUSTOMER_DIV_SEPARATE_CUSTOMER_PAGE = "id=clientOneagreements";

	@WidgetIDs
	public static class WidgetInfos {
		public static final RadioButton RADIOBUTTON_SEARCHBYTYPEAGENTNAME = new RadioButton(SEARCHSELECTCUSTOMER_RADIOBUTTON_SEARCHBYTYPE);

		public static final TextField TEXTFIELD_AGENTNAMESEARCHCRITERIA_LASTNAME = new TextField(SEARCHSELECTCUSTOMER_TEXTFIELD_LASTNAME);
		public static final TextField TEXTFIELD_AGENTNAMESEARCHCRITERIA_FIRSTNAME = new TextField(SEARCHSELECTCUSTOMER_TEXTFIELD_FIRSTNAME);
		public static final TextField TEXTFIELD_AGENTNAMESEARCHCRITERIA_ZIP = new TextField(SEARCHSELECTCUSTOMER_TEXTFIELD_ZIP);
		public static final TextField TEXTFIELD_AGENTNAMESEARCHCRITERIA_CITY = new TextField(SEARCHSELECTCUSTOMER_TEXTFIELD_CITY);

		public static final ListBox LISTBOX_ENTERPRISENAMESEARCHCRITERIA_STATE = new ListBox(SEARCHSELECTCUSTOMER_LISTBOX_STATE);

		public static final Button BUTTON_SEARCH = new Button(SEARCHSELECTCUSTOMER_BUTTON_AGENTNAME_SEARCH);
		public static final Button BUTTON_CANCEL = new Button(SEARCHSELECTCUSTOMER_BUTTON_CANCEL);
		public static final Button BUTTON_VIEWCOMBINEADD = new Button(SEARCHSELECTCUSTOMER_BUTTON_VIEWCOMBINEADD);

		public static final Div DIV_SELECTED_CUSTOMERS = new Div(SEARCHSELECTCUSTOMER_DIV_SELECTED_CUSTOMERS);
		public static final Div DIV_SEARCH_RESULT = new Div(SEARCHSELECTCUSTOMER_DIV_SEARCH_RESULT);
		public static final Div DIV_PAGE_MOVE_DATA = new Div(SEARCHSELECTCUSTOMER_DIV_PAGE_MOVE_DATA);
		public static final Div DIV_SEPARATE_CUSTOMER_PAGE = new Div(SEARCHSELECTCUSTOMER_DIV_SEPARATE_CUSTOMER_PAGE);
	}
}
