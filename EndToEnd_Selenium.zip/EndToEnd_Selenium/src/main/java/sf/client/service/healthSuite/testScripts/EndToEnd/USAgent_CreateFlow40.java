package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class USAgent_CreateFlow40 extends BaseScript 
{
	String query = "select * from USAgent_CreateFlow40";
	
public void executeScript() throws Exception{
		
		
	   /**
	    * Validate Customer Search Page
	    */
         createCustTasks.launchCustomerSeachPage();
         
		
	    /**Create a Customer with US SSN number in the Create Customer page. 
		 * 
		 */
      // createCustTasks.validateSSNandSINforCreatedCustomer("SSN");
		
		/**Create a Customer with CN SIN number in the Create Customer page. 
		 * 
		 */
		
       // createCustTasks.validateSSNandSINforCreatedCustomer("SIN");
        
		
		/**Create individual Customer with both US SSN and CN SIN number in the Create Customer page. 
		 * 
		 */
		
        createCustTasks.validateSSNandSINforCreatedCustomer("Both");
        
        /**
		 * Search for a Individual Customer and navigate to HH page - Enterprise Customer
		 */
        createCustTasks.launchPortalCustomerSearchPage();
        createCustTasks.launchPortalHHPage();
		
		/**
		 * Add an individual household member with US SSN information in Add members page.
		 */
        // Member actions not clicked instead of it Activity Actions
		//createCustTasks.validateSSNandSINforAddedIndividual("SSN");
		
		
		/**
		 * Add an individual household member with CN SIN information in Add members page.
		 */
 
		//createCustTasks.validateSSNandSINforAddedIndividual("SIN");
		
		/**Add an individual household member with both US SSN and CN SIN information in Add members page.
		 * 
		 */
		 
		//createCustTasks.validateSSNandSINforAddedIndividual("Both");
		
		/**Verify the system displays both the US SSN and CN SIN field in the Update personal information page
		 * 
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();
		createCustTasks.clickUpdatePersonalInfo();
		ssnSINTasks.verifySSNPersonalInfo();
		ssnSINTasks.verifySINPersonalInfo();
		
		/**update personal information with US SSN in the Update personal information page.
		 * 
		 */
		
		createCustTasks.validateSSNandSINinUpdatePersonelInfo("SSN");
				
		/** update personal information with CN SIN in the Update personal information page.
		 * 
		 */
		createCustTasks.validateSSNandSINinUpdatePersonelInfo("SIN");
		
		
		/**update personal information with both US SSN and CN SIN in the Update personal information page.
		 * 
		 */
		createCustTasks.validateSSNandSINinUpdatePersonelInfo("Both");
		createCustTasks.setTopFramewithDefaultContent();
		scenarioTasks.clickHHPageCustomer();
		
		/**
		 * Search and Select Two Customers and Click on Next link. 
		 */
		combineTasks.verifyAndSearchandSelectTwoCustomersPage();
		
		/**
		 *  Display of US SSN information in the Verify information- conflict page and  ability to select US SSN number of Customer1 and 2 in the verify information conflict page
		 */
		ssnSINTasks.validateSSNForTwoCustomers();
		
		/**
		 * Ability to enter new US SSN number  in the verify information- conflict page
		 */
		ssnSINTasks.validateNewSSNinConflictInfoPage();
		
		/**
		 * Ability to select No Value Radio Button in the verify information- conflict page
		 */
		ssnSINTasks.selectAndValidateNoValueRadioButtonForSSN();
		
		
	}
	public void scriptMain()  {
				
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			
			dbresultSet =databaseUtil.getCoreData(transferObject);
			
			while(dbresultSet.next()){
				
				clientE2ETO = databaseUtil.loadTestDataUSAgentCreateFlow40(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				ssnSINTasks=new SSNSINTasks(clientE2ETO);
				combineTasks  = new CombineCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				
				executeScript();
			}
			
			
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}



