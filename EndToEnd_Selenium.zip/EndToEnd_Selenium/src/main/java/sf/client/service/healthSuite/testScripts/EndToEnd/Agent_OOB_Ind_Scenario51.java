package sf.client.service.healthSuite.testScripts.EndToEnd;

import com.gargoylesoftware.htmlunit.ScriptException;

import sf.client.service.common.helpers.Constants;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;

/**
 * Test Id:FN6149
 * 		 i=49(Default)
 * Test Id:FN6146
 * 		 i=46
 * Test Id:FN6287
 * 		 i=87
 * @author u7kv
 *	
 */
public class Agent_OOB_Ind_Scenario51 extends BaseScript{
	private String query="select * from Agent_OOB_Ind_Scenario51";
	String id=null;
	String pwd=null;
	String domain=null;
	int i=49;
	boolean isServerLaunched = false;
	public void executeScript() throws Exception{
		if(i==46){
			/**Launch Household page*/
			createCustTasks.launchHouseholdpageFromPortal();
			/**"Activity Actions":Verify that an activity is created for the logging agent*/
			oobIndividualTasks.verifyActivityCreatedForLoggingAgent();
			}else{
			/**Launch Household through OOB search*/
			oobIndividualTasks.clickCustomerTab();
			/** Fetch OOB Data to launch OOB POlicies Page*/
			oobIndividualTasks.fetchDataOob();
			/**Close HH Page*/
			oobIndividualTasks.closeHHPage();
			/**Set Window to Agents Business System*/
			oobIndividualTasks.setWindow("Agents Business System", 30, 2);
			/**Launch Household page*/
			createCustTasks.launchHouseholdpageFromPortal();
			/**"Activity Actions":Verify that an activity is created for the logging agent*/
			oobIndividualTasks.verifyActivityCreatedForLoggingAgent();
			/**Launch Customer Info from HH page*/
			createCustTasks.launchCustomerInfoPageFromHHPage();
			/**Verify Relationship to Agent in Customer Info page */
			oobIndividualTasks.verifyRelationshipToAgent();
			}
	}
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgent_OOB_Ind_Scenario51(dbresultSet,clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				oobIndividualTasks = new OOBIndividualTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				if(i==87){
					//if(!isServerLaunched){
						id=launcher.getDataContainer().getField(Constants.PORTAL_TEST_ID_TWO);
						domain=launcher.getDataContainer().getField(Constants.PORTAL_DOMAIN_TWO);
						shutdownAndStartSeleniumServer();
					//	isServerLaunched=true;
				//	}
					launchUserAndExecuteScript();
					System.out.println("87 "+clientE2ETO.getLastName());
				}
				if(i==49){
					launcher.shutdownServer();
					launchUserAndExecuteScript();
					executeScript();
					System.out.println("49 "+clientE2ETO.getLastName());
					i=46;
				}
				if(i==46){
					id=launcher.getDataContainer().getField(Constants.PORTAL_TEST_ID_ONE);
					pwd=launcher.getDataContainer().getField(Constants.PORTAL_PASSWORD);
					domain=launcher.getDataContainer().getField(Constants.PORTAL_DOMAIN_ONE);
					shutdownAndStartSeleniumServer();
					launchUserAndExecuteScript();
					System.out.println("46 "+clientE2ETO.getLastName());
					i=87;
				}
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void shutdownAndStartSeleniumServer() throws ScriptException{
		launcher.shutdownServer();
		launcher.createSeleniumServerBatchFileForMP(id,domain);
		launcher.setCredintialsToLaunchSeleniumServer(id,pwd);
	}
	public void launchUserAndExecuteScript() throws Exception{
		launcher.launchUser(this.getClass().getSimpleName());
		createCustTasks.createResultsFile(resultsFileName(),scriptName());
		executeScript();
	}
}
