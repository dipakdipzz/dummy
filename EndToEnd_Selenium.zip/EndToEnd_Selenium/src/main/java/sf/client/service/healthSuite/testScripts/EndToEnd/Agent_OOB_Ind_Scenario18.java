package sf.client.service.healthSuite.testScripts.EndToEnd;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class Agent_OOB_Ind_Scenario18 extends BaseScript
{
	int count=0;
	String query = "select * from Agent_OOB_Ind_Scenario18";

	public void executeScript() throws Exception{
		/**
		 *  Launch hh page through oob search
		 */
		oobIndividualTasks.clickCustomerTab();
		oobIndividualTasks.fetchDataOob();
				
		/**
		 *  Customer Information verifications
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();
		
		
		/**
		 *  Add alias with International Characters
		 */
		updateTasks.addFirstAlias();

		/**
		 *  Add alias with International Characters
		 */
		updateTasks.addSecondAlias();
		
		/**
		 *  Add US Address
		 */
		updateTasks.addAddressCustomerInfo();
		
	/*	*//**
		 *  Remove US Address
		 *//*
		updateTasks.searchandRemoveAddress(clientE2ETO.getmStreet());
		*//**
		 *  Add Email
		 *//*
		updateTasks.addEmailCustomerInfo();
		*//**
		 *  Remove Email
		 *//*
		updateTasks.removeEmail();
		*//**
		 *  Add Mobile Phone Number
		 *//*
		updateTasks.removeAllPhonesFromCustomerInfo();
		updateTasks.addMobilePhoneCustomerInfo();
		*//**
		 *  Add Home Phone number with Calling preferences 
		 *//*
		updateTasks.addHomePhoneCustomerInfo(); 
		
		*//**
		 *  Remove HomePhone
		 *//*
		     				    	
	    createCustTasks.removePhoneCustomerInfo(clientE2ETO.getHomePhoneNumber());

		*//**
		 * Update Personal Information All Fields
		 *//*
		updateTasks.updatePersonalInformation();

		*//**
		 *  Customer Interest
		 *//*
		updateTasks.addCustomerInterestsCustomerInfo();
		
		*//**
		 *  Add Employment
		 *//*
			    
	    scenarioTasks.updateEmploymentAddEmployment();
	    *//**
		 *  Add Life events
		 *//*
	    scenarioTasks.lifeEventsAddEventSC1();*/
		/**
		 *  Navigate back to HH Page By Clicking Customer Active Bar.
		 */
		scenarioTasks.clickHHPageCustomer(); 
		scenarioTasks.setTopFrame();
		/**
		 *  Validate InternetEnabledColoumn.
		 */
	    scenarioTasks.clickIsInternetEnabledNOption();
		scenarioTasks.isInternetEnabledColumnDisplayedforHTMLHHpage();
		/**
		 *  Validate Mr Icon.
		 *//* 
		combineTasks.launchAndVerifyMRIcon();
	    createCustTasks.launchCMPageFromHHPage("text=Refresh/Close", "text=Close");
	    combineTasks.setWindow(EndToEndConstants.AGENT_BUSINESS_SYSTEM, 30, 2);
	    createCustTasks.getWebDriverInstance().switchTo().defaultContent();

	    *//**
		 *  Search For customer.
		 *//* 
	    createCustTasks.searchIndividual();
	    combineTasks.launchPortalCustomerSearchPage();
		 *//**
		 *  Launch hh Page.
		 *//*
		combineTasks.launchPortalHHPage();
		 
	    *//**
		 * Creating  Auto,Bank Policy with Others
		 *//*	
		productTasks.createAutoBankPolicesWithOthers();
		 *//**
		 * Click on the 'Customer Profile Print' option in the Action drop down button for a Customer in the Household member section. Navigates to Cust Info page. Navigate back to Household page
		 *//*
		scenarioTasks.clickCustomerProfilePrintFromActionsDropdown();
				
		*//**
		 * Validate that the Life App is launhced, when the life App policy number is clicked in the Product Inactive page 
		 *//*
		hhNavigationTasks.validateInactivePoliciesTabInHHPage();
		scenarioTasks.launchLifeAppfromProductsInactivePage(); 												
		*//**
		 * Search and Select Customer from Search and Select one Customer Page. 
		 *//*
		separateCustTasks.verifySearchandSelectOneCustomerPage();
		*//**
		 * Separating a Customer. 
		 *//*
		separateCustTasks.separateCustomer();
		  
		 createCustTasks.launchCMPageFromHHPage("text=Refresh/Close", "text=Close");
		 combineTasks.setWindow(EndToEndConstants.AGENT_BUSINESS_SYSTEM, 30, 2);
		 createCustTasks.getWebDriverInstance().switchTo().defaultContent();
        *//**
	      *  Search For customer.
		*//* 
		combineTasks.launchPortalCustomerSearchPage();
		*//**
		 *  Payment option in the ACTION drop menu for AUTO policy
		*//* 
		combineTasks.launchPaymentAutoPolicy();
		*//**
		 *  REPORT A LOSS option in the ACTION drop menu for  Fire policy 
		*//* 
		combineTasks.launchReportALossFirePolicy();*/
	}
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestAgentOOBIndScenario18(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				removeFromBookTasks = new RemoveFromBookTasks(clientE2ETO);
				oobIndividualTasks = new OOBIndividualTasks(clientE2ETO);
				combineTasks=new CombineCustomersTasks(clientE2ETO);
				ssnSINTasks =new SSNSINTasks(clientE2ETO);
				productTasks=new ProductTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}



