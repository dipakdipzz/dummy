package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.TextField;

/**
 * This class contains all the page objects related to Add Accounts and Policies
 */
public class AddAccountsandPoliciesPopupObjects {
	
	private static final String DIV_UPDATE_ACCOUNT_POLICIES = "text=Update Accounts / Policies With Others";
	private static final String LISTBOX_LINE_OF_BUSINESS = "id=accounts.lineOfBusinessCode";
	private static final String LISTBOX_STATE_PROVINCE = "id=accounts.stateProvinceCode";
	private static final String LISTBOX_PRODUCT_TYPE = "id=accounts.productTypeCode";
	private static final String LISTBOX_COMPANY_CODE = "id=accounts.companyCode";
	private static final String TEXT_COMPANY_OTHER = "id=accounts.companyOther";
	private static final String TEXT_EXDATE = "id=accounts.termDate";
	private static final String TEXT_DETAILS = "id=accounts.details";
	private static final String LINK_HELP_ON_THIS_PAGE = "text=help on this page";
	private static final String BUTTON_ADD_SAVE	 = "id=save";
	private static final String BUTTON_ADD_CANCEL = "id=cancel";
	private static final String CHECKBOX_FOLLOWUP = "id=followUp";
	private static final String DIV_ADD_ACCOUNT_POLICIES = "id=pageHeading";
	//text=Add Accounts/Policies With Others
	private static final String BUTTON_CANCEL_ADDAUTO_POLICIES = "id=cancel";
	private static final String BUTTON_ADD_REMOVE = "id=remove";
	private static final String BUTTON_ADD_CLOSE = "id=cancel";
	
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final Div DIV_UPDATE_ACC_POLICIES  = new Div(DIV_UPDATE_ACCOUNT_POLICIES);
		public static final ListBox LIST_LINE_OF_BUSINESS  = new ListBox(LISTBOX_LINE_OF_BUSINESS);
		public static final ListBox LIST_STATE_PROV  = new ListBox(LISTBOX_STATE_PROVINCE);
		public static final ListBox LIST_PRODUCT_TYPE  = new ListBox(LISTBOX_PRODUCT_TYPE);
		public static final ListBox LIST_COMPANY  = new ListBox(LISTBOX_COMPANY_CODE);
		public static final TextField TEXT_OTHER_COMPANY  = new TextField(TEXT_COMPANY_OTHER);
		public static final TextField TEXT_TERM_DATE  = new TextField(TEXT_EXDATE);
		public static final TextField TEXT_ACCOUNT_DETAILS  = new TextField(TEXT_DETAILS);
		public static final Link LINK_HELP_ON_PAGE  = new Link(LINK_HELP_ON_THIS_PAGE);
		public static final Button BUTTON_SAVE  = new Button(BUTTON_ADD_SAVE);
		public static final Button BUTTON_CANCEL  = new Button(BUTTON_ADD_CANCEL);
		public static final Button BUTTON_CLOSE  = new Button(BUTTON_ADD_CLOSE);
		public static final CheckBox CHECKBOX_FOLLOW_UP  = new CheckBox(CHECKBOX_FOLLOWUP);
		public static final Div DIV_ADDACCOUNT_POLICIES  = new Div(DIV_ADD_ACCOUNT_POLICIES);
		public static final Button BUTTON_CANCEL_AUTO_POLICIES  = new Button(BUTTON_CANCEL_ADDAUTO_POLICIES);
		public static final Button BUTTON_REMOVE  = new Button(BUTTON_ADD_REMOVE);
	}
	
}