package sf.client.service.healthSuite.testScripts.EndToEnd;

import java.sql.ResultSet;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;


public class Enterprise_SW_Ind_Scenario7 extends BaseScript
{
	String query = "select * from Enterprise_SW_Ind_Scenario7";
	public ResultSet dbresultSet=null;
	
	 
	 	public void executeScript() throws Exception{ 
	 		
	 		/**
			 * validate Create Ind , Create Org 
			 *validate Enterprise connect & Enterprise View link does not Exists in
			 *Customer Search page.
			 */
	 		scenarioTasks.setTopFrame();
	 		scenarioTasks.handleCimsVersion();
			scenarioTasks.setCustomerSearchTopFrame();
			scenarioTasks.validateLinksDisplayedInCustSearchPage();
			/**
			 *  Launch Enterpriseview From Customer Search page.
			 *//*
			connectCustTasks.launchEnterpriseViewPage();
			*/
			/**
			 *  Launch HH page From Customer Search page.
			 */
			connectCustTasks.launchHHPageFromCustomerSearchPage();
			/**
			 *  Validate that the Household hyperlink and Non household hyperlinks are not displayed in the Household Menu
			 */
			hhNavigationTasks.validateHouseholdNonHouseholdLinks();
			/**
			 *  Launch Relationship page
			 */
			hhNavigationTasks.validateAndLaunchRelationshipPage();
			/**
			 *  Validate the Contents of Relationship page.
			 */
			hhRelationshipTasks.validateRelationshipPage();
			/**
			 *  Close Relationship page.
			 */
			hhRelationshipTasks.closeRelationshipPage();
			/**
			 * Search and Select Two Customers and Click on Next link. 
			 */
			//do manually
			/*combineTasks.verifySearchandSelectTwoCustomersPageABS();
			*//**
			 * Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.. 
			 *//*
			combineTasks.verifyInfoandClickCombine();*/
	 	}
 	public void scriptMain() {
			try {
				try {
					transferObject=setTestDataObject(transferObject);
					transferObject.setDbQuery(query);
					
					dbresultSet =databaseUtil.getCoreData(transferObject);
					
					while(dbresultSet.next()){
						clientE2ETO = databaseUtil.loadTestDataEnterpriseSWIndScenario7(dbresultSet,clientE2ETO);
						
						scenarioTasks =new ScenarioTasks(clientE2ETO);
					
						hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
						hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
						connectCustTasks=new ConnectCustomersTasks(clientE2ETO);
						combineTasks = new CombineCustomersTasks(clientE2ETO);
						launcher = new LaunchApplication(getWATConfig());
						launcher.launchUser(this.getClass().getSimpleName());
						scenarioTasks.createResultsFile(resultsFileName(),scriptName());
						executeScript();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	 	
	 	
	 	

	 }

