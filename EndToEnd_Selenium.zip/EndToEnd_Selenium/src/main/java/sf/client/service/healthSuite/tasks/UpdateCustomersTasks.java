package sf.client.service.healthSuite.tasks;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.AddIndividualPageObjects;
import sf.client.service.healthSuite.appObjects.CWNonAgentCSObjects;
import sf.client.service.healthSuite.appObjects.CreateIndividualCustomer;
import sf.client.service.healthSuite.appObjects.CustomerInfoObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldMove_PageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.RelationshipsScreenTestObjects;
import sf.client.service.healthSuite.appObjects.Update_IND_CustomerInfo_PageObjects;
import sf.client.service.healthSuite.appObjects.Update_Misc_Objects;
import sf.client.service.healthSuite.appObjects.Update_ORG_CustomerInfo_PageObjects;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.gui.Browser;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.manager.Verify;

public class UpdateCustomersTasks extends HouseHoldTasks {
	/**
	 * Empty Constructor
	 */
	public UpdateCustomersTasks() {
		super(); 
	}  

	/**
	 * Parameterized Constructor
	 * 
	 * @param clientE2ETO
	 */
	public UpdateCustomersTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}

	/**
	 * Click on Cancel Button
	 * 
	 * @throws ScriptException
	 */
	public void clickCancelButton() throws ScriptException {

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CANCEL.exists())
			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CANCEL,
					MessageUtility.BUTTON_CANCEL);

	}

	/**
	 * Click on Add Interest link in the Customer Information page
	 * 
	 * @throws ScriptException
	 */
	public void clickAddInterest() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDINTEREST.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_ADDINTEREST,
					MessageUtility.LINK_ADDINTEREST_CLICKED);
			setIFrame();
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_ADDINTEREST_NOTDISPLAYED);
		}

	}

	/**
	 * Update the Customer Interest in Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void updateEnterInterest() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_CUSTOMERINTEREST1.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_CUSTOMERINTEREST1,
					checkNull(clientE2ETO.getUpdateCustomerInterest()),
					MessageUtility.ADDINTEREST);
		}
	}

	/**
	 * Click on Update Customer Interest and Enter the Customer Interest and
	 * Click on Save buttons
	 * 
	 * @throws ScriptException
	 */
	public void updateCustomerInterestUpdate() throws ScriptException {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDINTEREST, 15);
				clickCustomerInterestTOUpdate();
				updateEnterInterest();
				clickSaveButton();
				isErrorPage("Add Customer Interest");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTINFOPAGE_LAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Update the Employment in Customer Info Page
	 */
	
	public void updateEmploymentAddEmployment() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddEmployment();
				enterEmployerName();
				selectOccupation();
				selectOccupationStatus();
				selectJobTitle();
				enterAsOfDate();
				clickSaveButton();
				isErrorPage("Add Employment");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_LAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	public void updateEmploymentAddEmployment_CRC() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddEmployment();
				enterEmployerName();
				selectOccupation();
				selectOccupationStatus();
				selectJobTitle();
				enterAsOfDate();
				clickSaveButton();
				isErrorPage("Add Employment");
				setCRCDefaultFrame();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_LAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Click on Add Employment
	 * 
	 * @throws ScriptException
	 */
	public void clickAddEmployment() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDEMPLOYMENT.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_ADDEMPLOYMENT,
					MessageUtility.LINK_ADDEMPLOYMENT);
			setIFrame();
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_ADDEMPLOYMENT_NOTFOUND);
		}
	}

	/**
	 * Enter the Employer Name in Add Employment page
	 * 
	 * @throws ScriptException
	 */
	public void enterEmployerName() throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMPLOYERNAME,
				20);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMPLOYERNAME.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMPLOYERNAME,
					clientE2ETO.getEmployerName(),
					MessageUtility.EMPLOYERNAME_DISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.EMPLOYERNAME_NOTDISPLAYED);
		}
	}

	/**
	 * Enter the Employer Name in Update Employment page
	 * 
	 * @throws ScriptException
	 */
	public void updateEnterEmployerName() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMPLOYERNAME.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMPLOYERNAME,
					clientE2ETO.getUpdateEmployerName(),
					MessageUtility.EMPLOYERNAME_DISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.EMPLOYERNAME_NOTDISPLAYED);
		}
	}

	/**
	 * Select the Occupation Status in the add Employment page
	 * 
	 * @throws ScriptException
	 */
	public void selectOccupation() throws ScriptException {
		if (clientE2ETO.getOccupation() != null) {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATION.exists()) {
				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATION,
						clientE2ETO.getOccupation(), " Occupation list box");
				if (clientE2ETO.getOccupation().equalsIgnoreCase("Other")) {
					setTextInTextbox(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_OCCUPATIONOTHER,
							clientE2ETO.getOccupationOther(),
							MessageUtility.OCCUPATION);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.OCCUPATION_NOTDISPLAYED);
			}
		}
	}

	/**
	 * Select the Occupation Status in the Update Employment page
	 * 
	 * @throws ScriptException
	 */
	public void updateSelectOccupation() throws ScriptException {
		if (clientE2ETO.getUpdateOccupation() != null) {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATION.exists()) {

				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATION,
						clientE2ETO.getUpdateOccupation(),
						MessageUtility.OCCUPATION);

				if (clientE2ETO.getUpdateOccupation().equalsIgnoreCase("OTHER")) {

					setTextInTextbox(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_OCCUPATIONOTHER,
							clientE2ETO.getUpdateOccupationOther(),
							MessageUtility.OCCUPATION);
				}

			} else {
				Verify.verifyTrue(false,
						MessageUtility.OCCUPATION_NOTDISPLAYED);
			}
		}
	}

	/**
	 * Select the Occupation Status from the List box
	 * 
	 * @throws ScriptException
	 */
	public void selectOccupationStatus() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATIONSTATUS.exists()) {
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATIONSTATUS,
					clientE2ETO.getOccupationStatus(),
					MessageUtility.OCCUPATIONSTATUS);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.OCCUPATIONSTATUS_NOTDISPLAYED);
		}
	}

	/**
	 * Update the Occupation Status in the Update Employment Page
	 * 
	 * @throws ScriptException
	 */
	public void updateSelectOccupationStatus() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATIONSTATUS.exists()) {
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_OCCUPATIONSTATUS,
					clientE2ETO.getUpdateOccupationStatus(),
					MessageUtility.OCCUPATIONSTATUS);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.OCCUPATIONSTATUS_NOTDISPLAYED);
		}
	}

	/**
	 * Select the Job Title from the Add Employment page
	 * 
	 * @throws ScriptException
	 */
	public void selectJobTitle() throws ScriptException {

		if (clientE2ETO.getJobTitle() != null) {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_JOBTITLE.exists()) {

				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_JOBTITLE,
						clientE2ETO.getJobTitle(), MessageUtility.JOBTITLE);

				if (clientE2ETO.getJobTitle().equalsIgnoreCase("Other")) {

					setTextInTextbox(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_JOBTITLEOTHER,
							checkNull(clientE2ETO.getJobTitleOther()),
							MessageUtility.JOBTITLE);

				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.JOBTITLE_NOTDISPLAYED);
			}
		}

	}

	/**
	 * Update Job title from the Update Employment page.
	 * 
	 * @throws ScriptException
	 */
	public void updateSelectJobTitle() throws ScriptException {
		if (clientE2ETO.getUpdateJobTitle() != null) {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_JOBTITLE.exists()) {

				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_JOBTITLE,
						clientE2ETO.getUpdateJobTitle(), MessageUtility.JOBTITLE);

				if (clientE2ETO.getUpdateJobTitle().equalsIgnoreCase("Other")) {
					setTextInTextbox(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_JOBTITLEOTHER,
							clientE2ETO.getUpdateJobTitleOther(),
							MessageUtility.JOBTITLE);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.JOBTITLE_NOTDISPLAYED);
			}
		}
	}

	/**
	 * Enter As of Date in the Employment page
	 * 
	 * @throws ScriptException
	 */
	public void enterAsOfDate() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_ASOFDATE_EMP.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_ASOFDATE_EMP,
					clientE2ETO.getEmploymentAsOfDate(), MessageUtility.ASOFDATE);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.ASOFDATE_NOTDISPLAYED);
		}
	}

	/**
	 * Enter As of Date in the Update Employment page
	 * 
	 * @throws ScriptException
	 */
	public void updateEnterAsOfDate() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_ASOFDATE_EMP.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_ASOFDATE_EMP,
					clientE2ETO.getUpdateEmploymentAsOfDate(),
					 MessageUtility.ASOFDATE);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.ASOFDATE_NOTDISPLAYED);
		}
	}

	/**
	 * Remove Employment from the Customer Info page
	 */
	public void updateEmploymentRemove() {
		try {
			if (isCustomerInfoPageExists()) {
				int count = 1;
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDEMPLOYMENT, 10);
				while (true) {
					boolean flag = getWebDriverInstance().findElement(By.xpath("//div[@id='gridEmployments']/div/div/div/div/div/div["+count+"]/table/tbody/tr/td[2]")).isDisplayed();
					if (flag) {
						String employment = getWebDriverInstance().findElement(By.xpath("//div[@id='gridEmployments']/div/div/div/div/div/div["+count+"]/table/tbody/tr/td[2]")).getText();
						if (employment.equalsIgnoreCase(clientE2ETO
								.getUpdateOccupation())) {
							if (getWebDriverInstance().findElement(By.xpath("//div[@id='gridEmployments']/div/div/div/div/div/div["+count+"]/table/tbody/tr/td[5]/a")).isDisplayed()) {
								getWebDriverInstance().findElement(By.xpath("//div[@id='gridEmployments']/div/div/div/div/div/div["+count+"]/table/tbody/tr/td[5]/a")).click();
								if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE
										.exists()) {
									getWebDriverInstance().findElement(By.xpath("//div[@id='removeEmploymentConfirmationDialog']/div[2]/div[13]/div[1]/button[@id='removeContinueButton']")).click();
									if (!isErrorPage("Remove Employment"))
										Verify.verifyTrue(true,
												MessageUtility.REMOVEEMPLOYMENT);
								}
							}
							break;
						}
						count++;

					} else {
						break;
					}
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_LAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Click on radio button US type
	 * 
	 * @throws ScriptException
	 */
	public void selectUSType() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.RADIO_US.exists()) {
			selectRadioButton(Update_IND_CustomerInfo_PageObjects.WidgetInfos.RADIO_US,
					MessageUtility.RADIOBUTTON_US);
		} else {
			Verify.verifyTrue(false, MessageUtility.RADIOBUTTON_US_NOTDISPLAYED);
		}

	}

	/**
	 * Select the Mailing state in Address Section of Customer Info page
	 * 
	 * @param state
	 * @throws ScriptException
	 */
	public void selectMailingState(String state) throws ScriptException {
		if (state != null
				&& Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_MSTATE.exists()) {
			selectFromListbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_MSTATE,
					state, state + MessageUtility.STATE);
		}
	}

	/**
	 * Enter the mailing Postal/Zip in the Address section
	 * 
	 * @param zip
	 * @throws ScriptException
	 */
	public void enterMailingZip(String zip) throws ScriptException {
		if (zip != null
				&& Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MZIPANDPOSTAL
						.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MZIPANDPOSTAL,
					zip, zip + MessageUtility.ZIP_VALUE);

		}
	}

	/**
	 * Enter the Mailing Country in the Address Section
	 * 
	 * @param country
	 *            Country to be Entered
	 * @throws ScriptException
	 */
	public void enterMailingCountry(String country) throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MCOUNTRY, 10);
		if (country != null
				&& Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MCOUNTRY.exists()) {
			Verify.verifyTrue(true, MessageUtility.COUNTRY);

			setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MCOUNTRY,
					country, country
							+ MessageUtility.COUNTRY);

		} else {
			Verify.verifyTrue(false, MessageUtility.COUNTRY_NOTFOUND);
		}

	}

	/**
	 * Click on the Mailing Checkbox in the Address Section
	 * 
	 * @throws ScriptException
	 */
	public void checkUsageMailing() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_USAGEMAILING.exists()) {
			Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_USAGEMAILING
					.setIsChecked(true);
			Verify.verifyTrue(true, MessageUtility.CHECKBOX_MAILINGUSAGE);
		}

	}

	/**
	 * Click on the Usage Residence Checkbox in the Address Section
	 * 
	 * @throws ScriptException
	 */
	public void checkUsageResidence() throws ScriptException {

		Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_USAGERESIDENCE
				.setIsChecked(true);
		Verify.verifyTrue(true, MessageUtility.CHECKBOX_RESIDENCEUSAGE);
	}

	/**
	 * Click on the Usage Business Checkbox in the Address Section
	 * 
	 * @throws ScriptException
	 */
	public void checkUsageBusiness() throws ScriptException {

		Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_USAGEBUSINESSEMPLOYER
				.setIsChecked(true);
		Verify.verifyTrue(true, MessageUtility.CHECKBOX_BUSINESSEMPLOYERUSAGE);

	}

	/**
	 * Click on Add address link in the Customer info section
	 * 
	 * @throws ScriptException
	 */
	public void clickAddAddress() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDADDRESS.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_ADDADDRESS,
					MessageUtility.LINK_ADDADDRESS_CLICKED);
			setIFrame();
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_ADDADDRESS_NOTDISPLAYED);
		}
	}

	/**
	 * Click on Add Email link in the Customer Info section
	 * 
	 * @throws ScriptException
	 */
	public void clickAddEmailLink() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_EMAIL.exists()) {
			Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_EMAIL.click();
			clickAddEmail();
		}
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDEMAIL.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_ADDEMAIL,
					MessageUtility.LINK_ADDEMAIL_CLICKED);
			setIFrame();
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ADDEMAIL_NOTFOUND);
		}

	}

	/**
	 * Update the Email-address in the Customer Info section
	 * 
	 * @throws ScriptException
	 */
	public void updateEnterEmailIND() throws ScriptException {
		if (clientE2ETO.getUpdateEmailAddress() != null) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMAILADDRESS1,
					clientE2ETO.getUpdateEmailAddress(),
					MessageUtility.EMAIL);
		}

	}

	/**
	 * Verify whether all fields in Add Events properly displayed or not
	 */
	public void isAddEventFieldsDisplayed() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIFEEVENT1.exists()) {

			Verify.verifyTrue(true, MessageUtility.LIFEEVENT_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LIFEEVENT_NOTDISPLAYED);
		}

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EVENTDATE1.exists()) {

			Verify.verifyTrue(true, MessageUtility.EVENTDATE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.EVENTDATE_NOTDISPLAYED);
		}

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.exists()) {
			Verify.verifyTrue(true, MessageUtility.BUTTON_SAVE_DISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_SAVE_NOTFOUND);
		}

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CANCEL.exists()) {

			Verify.verifyTrue(true, MessageUtility.BUTTON_CANCEL_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_CANCEL_NOTDISPLAYED);
		}
	}

	/**
	 * Click on Add Event link the Customer Info section
	 * 
	 * @throws ScriptException
	 */
	public void clickAddEvent() throws ScriptException {

		click(Update_Misc_Objects.WidgetInfos.LINK_ADDEVENT, MessageUtility.LINK_ADDEVENT);
	}

	public void enterlifeEventsAsofdate() throws ScriptException {
		if (clientE2ETO.getXdate() != null) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EVENTDATE1,
					clientE2ETO.getXdate(), MessageUtility.ASOFDATE);
		}
	}

	/**
	 * Enter As of Date in the update life event page
	 * 
	 * @throws ScriptException
	 */
	public void updateEnterlifeEventsAsofdate() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EVENTDATE1.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EVENTDATE1,
					clientE2ETO.getUpdateXDate(), MessageUtility.ASOFDATE);
		} else {
			Verify.verifyTrue(false, MessageUtility.ASOFDATE_NOTFOUND);
		}
	}

	/**
	 * Update the Life event in the Customer info page
	 * 
	 * @throws ScriptException
	 * @throws Exception
	 */
	public void lifeEventsUpdate_CRC() throws ScriptException, Exception {
		try {
			if (isCustomerInfoPageExists()) {
				selectLifeEventToUpdate();
				setIFrame();
				updateSelectEvent();
				updateEnterlifeEventsAsofdate();
				clickSaveButton();
				setCRCDefaultFrame();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	public void lifeEventsUpdate() throws ScriptException, Exception {
		try {
			if (isCustomerInfoPageExists()) {
				selectEvent();
				updateSelectEvent();
				updateEnterlifeEventsAsofdate();
				clickSaveButton();
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * Click on the life event link to update
	 * 
	 * @throws ScriptException
	 * @throws java.text.ParseException
	 */
	public void selectLifeEventToUpdate() throws ScriptException,
			java.text.ParseException {
		if (clientE2ETO.getLifeEventOther() != null) {
			Link isEventLink = new Link("text="
					+ clientE2ETO.getLifeEventOther().toUpperCase() + "*");
			if (isEventLink.exists()) {
				isEventLink.click();
			}
		} else {
			if (clientE2ETO.getLifeEvent() != null) {
				Link isEventLink = new Link("text="
						+ clientE2ETO.getLifeEvent() + "*");
				if (isEventLink.exists()) {
					click(isEventLink, MessageUtility.LIFEEVENT_UPDATE);
				}
			}
		}
	}

	/**
	 * Remove life event from the Customer Info page
	 */
	public void lifeEventsRemove() {
		try {
		if (isCustomerInfoPageExists()) {
				clickLifeEventsRemove(clientE2ETO.getUpdateLifeEvent());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	/**
	 * Find and Remove the appropriate life event from the Customer Info page
	 * 
	 * @param eventToBeRemoved
	 */
	public void clickLifeEventsRemove(String eventToBeRemoved) {
		try {
			if (isCustomerInfoPageExists()) {
				int count = 1;
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDEVENT);
				while (true) {
					boolean flag = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_5']/div[1]/div[1]/div[1]/div[1]/table/tbody/tr["+count+"]/td[2]")).isDisplayed();
					if (flag) {
						String lifeEvents =  getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_5']/div[1]/div[1]/div[1]/div[1]/table/tbody/tr["+count+"]/td[2]")).getText();
						if (lifeEvents.contains(eventToBeRemoved)) {
							if (getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_5']/div[1]/div[1]/div[1]/div[1]/table/tbody/tr["+count+"]/td[3]/a")).isDisplayed()) {
								getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_5']/div[1]/div[1]/div[1]/div[1]/table/tbody/tr["+count+"]/td[3]/a")).click();
								if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE.exists()) {
									getWebDriverInstance().findElement(By.xpath("//div[@id='removeEventConfirmationDialog']/div[2]/div[7]/div[1]/button[@id='removeContinueButton']")).click();
									Verify.verifyTrue(true,
											MessageUtility.LIFEEVENT_REMOVE);
								}
							}
							break;
						}
						count++;

					} else {
						break;
					}
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Find and Remove the appropriate Address from the Customer Info page
	 * 
	 * @param street
	 */
	public void searchandRemoveAddress(String street) {
		int count = 1;
		boolean flag = false;
		if (isCustomerInfoPageExists()) {
			while (true) {
				flag = getWebDriverInstance().findElement(By.cssSelector("div#gridAddress"
						+" div.dojoxGridMasterView"
						+ " div.dojoxGridView"
						+ " div.dojoxGridScrollbox>div.dojoxGridContent>div"
						+ ">div:nth-child(" + count + ")>table")).isDisplayed();
				if (flag) {
					String address = getWebDriverInstance().findElement(By.cssSelector("div#gridAddress"
									+" div.dojoxGridMasterView"
									+ " div.dojoxGridView"
									+ " div.dojoxGridScrollbox>div.dojoxGridContent>div"
									+ ">div:nth-child(" + count + ")>table")).getText();
					if (street != null
							&& address.contains(street.toUpperCase())) {
						getWebDriverInstance().findElement(By.cssSelector("div#gridAddress"
								+" div.dojoxGridMasterView"
								+ " div.dojoxGridView"
								+ " div.dojoxGridScrollbox>div.dojoxGridContent>div"
								+ ">div:nth-child(" + count
								+ ")>table>tbody>tr>td:nth-child(7)>a")).click();
						setIFrame();
						waitForPageLoad(
								Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
								5);
						if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
								.exists()) {
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
									.click();
							Verify.verifyTrue(true, "Remove button is Clicked");
							isErrorPage("Remove Address");
							setTopFramewithDefaultContent();
							break;
						}

					}
					count++;
				} else {
					Verify.verifyTrue(false, MessageUtility.LIFEEVENT_REMOVE_NOTFOUND);
					break;
				}
			}
		} else
			Verify.verifyTrue(false,
					MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);

	}


	/**
	 * Click on the Update link in the Customer info page(for individual
	 * Customer)
	 * 
	 * @throws ScriptException
	 */
	public void clickUpdatePersonalInfo() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL,
					MessageUtility.LINK_UPDATEPERSONALINFO);
			setIFrame();
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_UPDATEPERSONALINFO_NOTFOUND);
		}

	}

	/**
	 * Click on Add Phone link in the Customer info page
	 * 
	 * @throws ScriptException
	 */
	public void clickAddPhone() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDPHONE.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_ADDPHONE, MessageUtility.LINK_ADDPHONE);
			setIFrame();
		}
	}


	/**
	 * Select the Specific Days in the Calling Preference from the Customer info
	 * 
	 * @param str
	 */
	public void selectSpecificDay(String str) {
		CheckBox specificSunday = new CheckBox("id=phone.availableSun");
		CheckBox specificMonday = new CheckBox("id=phone.availableMon");
		CheckBox specificTuesday = new CheckBox("id=phone.availableTue");
		CheckBox specificWednesday = new CheckBox("id=phone.availableWed");
		CheckBox specificThursday = new CheckBox("id=phone.availableThu");
		CheckBox specificFriday = new CheckBox("id=phone.availableFri");
		CheckBox specificSaturday = new CheckBox("id=phone.availableSat");

		specificSunday.uncheck();
		specificMonday.uncheck();
		specificTuesday.uncheck();
		specificWednesday.uncheck();
		specificThursday.uncheck();
		specificFriday.uncheck();
		specificSaturday.uncheck();

		if (str != null && str.trim() != "") {
			if (str.equalsIgnoreCase("SUNDAY")) {
				specificSunday.click();
			} else if (str.equalsIgnoreCase("MONDAY")) {
				specificMonday.click();
			} else if (str.equalsIgnoreCase("TUESDAY")) {
				specificTuesday.click();
			} else if (str.equalsIgnoreCase("WEDNESDAY")) {
				specificWednesday.click();
			} else if (str.equalsIgnoreCase("THURSDAY")) {
				specificThursday.click();
			} else if (str.equalsIgnoreCase("FRIDAY")) {

				specificFriday.click();
			} else if (str.equalsIgnoreCase("SATURDAY")) {
				specificSaturday.click();
			}
		}
	}

	/**
	 * Select Calling Preference from the Phone Section of Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void selectCallPreference() throws ScriptException {
		String callingPref = checkNull(clientE2ETO.getCallingPref());
		if (callingPref != null) {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_CALLINGPREFERENCEDAYWORK
					.exists()) {
				Verify.verifyTrue(true,
						" Calling preference Day list box is displayed as expected .");
				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_CALLINGPREFERENCEDAYWORK,
						callingPref, "selected CallingPreferrenceDayWork");
				if (callingPref.equalsIgnoreCase("SPECIFIC")) {
					selectSpecificDay(checkNull(clientE2ETO.getSpecificDays()));
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CALLINGPREFERENCEDAY_NOTDISPLAYED);
			}
		}
	}

	/**
	 * Select the From Time in the Phone Section
	 * 
	 * @throws ScriptException
	 */
	public void selectFromTime() throws ScriptException {
		String fromTime = clientE2ETO.getFromTime();
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_FROMTIMECELL.exists()
				&& fromTime != null) {
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_FROMTIMECELL,
					fromTime, fromTime + MessageUtility.FROMTIME_VALUE);
		}
	}

	/**
	 * Check for null.this method is used to avoid NullPointerException
	 * 
	 * @param str
	 * @return
	 */
	public String checkNull(String str) {
		if (str == null)
			return "";
		else
			return str;
	}

	/**
	 * Select the End Time from the Phone Section
	 * 
	 * @throws ScriptException
	 */
	public void selectEndTime() throws ScriptException {
		String toTime = clientE2ETO.getToTime();
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_TOTIMECELL.exists()
				&& toTime != null)
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_TOTIMECELL,
					toTime, toTime + MessageUtility.TOTIME_VALUE);
	}

	/**
	 * Click on the phone number link to update in the Customer Info section
	 * 
	 * @throws ScriptException
	 */
	public void selectPhoneNumberTOUpdate() throws ScriptException {
		Link LINK_UPDATEPHONE = new Link("text="
				+ clientE2ETO.getCellPhoneNumber());
		waitForPageLoad(LINK_UPDATEPHONE, 10);
		if (LINK_UPDATEPHONE.exists()) {
			click(LINK_UPDATEPHONE, MessageUtility.LINK_UPDATEPHONE);
			setIFrame();
		}
	}

	/**
	 * Enter the Birth Date in the Update Personal page
	 */
	public void enterBirthDate() {
		try {
			if (clientE2ETO.getBirthDate() != null) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_BIRTHDATE,
						clientE2ETO.getBirthDate(),
						clientE2ETO.getBirthDate()
								+ MessageUtility.BIRTHDATE_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.BIRTHDATE_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Click on the Male Radio button in the Update Personal Info page
	 */
	public void selectGenderMale() {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.RADIO_MALE.exists()) {
				selectRadioButton(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.RADIO_MALE,
						MessageUtility.RADIOBUTTON_MALE);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.RADIOBUTTON_MALE_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Enter the License number in the Personal Info page
	 */
	public void enterLicenceNumber() {
		try {
			if (clientE2ETO.getLicenceNumber() != null) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_DRIVERSLICENSENUMBER,
						clientE2ETO.getLicenceNumber(),
						MessageUtility.LICENSE);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Select the Assigned Staff in the Personal info PopUp of Customer Info
	 * page
	 */
	public void selectAssignedStaff() {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_ASSIGNEDSTAFF.exists()) {
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_ASSIGNEDSTAFF
						.selectRandomItem();
				Verify.verifyTrue(true, MessageUtility.ASSIGNEDSTAFF);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ASSIGNEDSTAFF_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Select Living Arrangements in the Update Personal PopUp of Customer Info
	 * page
	 */
	public void selectLivingArrangements() {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIVINGARRANGEMENTS
					.exists()) {
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIVINGARRANGEMENTS
						.selectRandomItem();
				Verify.verifyTrue(true,
						MessageUtility.LIVINGARRANGEMENTS);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LIVINGARRANGEMENTS_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Select Citizenship in the Personal info Popup of Customer Info page
	 */
	public void selectCitizenship() {
		try {
			if (clientE2ETO.getCitizenship() != null) {
				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_CITIZENSHIP,
						clientE2ETO.getCitizenship(),
						clientE2ETO.getCitizenship()
								+ MessageUtility.CITIZENSHIP);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CITIZENSHIP_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Enter the First Year With SF field in the Personal Info popup
	 */
	public void enterFirstYrWithSF() {
		try {
			if (clientE2ETO.getFirstYrWithSF() != null) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTYEARWITHSF, 
						clientE2ETO.getFirstYrWithSF(),
						clientE2ETO.getFirstYrWithSF()
								+ MessageUtility.FIRSTYEARWITHSF);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.FIRSTYEARWITHSF_NOTDISPLAYED);

			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Select the Household income in the Personal Info popup
	 */
	public void selectHouseHoldIncome() {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_HOUSEHOLDINCOME
					.exists()) {
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_HOUSEHOLDINCOME
						.selectItemAtIndex(3);
				Verify.verifyTrue(true, MessageUtility.HOUSEHOLDINCOME);
			} else
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDINCOME_NOTDISPLAYED);
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Enter the As of Date in the Personal info section
	 */
	public void enterPersonalInfoAsOfDate() {
		try {
			if (clientE2ETO.getPersonalInfoAsOfDate() != null) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_ASOFDATE_PERSONALINFO,
						clientE2ETO.getPersonalInfoAsOfDate(),
						clientE2ETO.getPersonalInfoAsOfDate()
								+ MessageUtility.ASOFDATE);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ASOFDATE_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Select the Primary Marketing Contact in the Personal info section
	 */
	public void selectPrimayMarketingContact() {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_PRIMARKCONTACT
					.exists()) {
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_PRIMARKCONTACT
						.setIsChecked(true);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Enter the Customer Category in the Personal info section
	 */
	public void enterCustomerCategory() {
		try {
			if (clientE2ETO.getCustomerCategory() != null) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_CUSTOMERCATEGORY,						clientE2ETO.getCustomerCategory(),
						clientE2ETO.getCustomerCategory()
								+ MessageUtility.CUSTOMERCATEGORY);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTOMERCATEGORY_NOTDISPLAYED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}

	/**
	 * Enter the Death Date in the Personal info section
	 * 
	 * @throws ScriptException
	 */
	public void enterDeathDate() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_DEATHDATE.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_DEATHDATE,
					clientE2ETO.getDeathDate(), "Death Date Entered");
			Verify.verifyTrue(true, MessageUtility.DEATHDATE);
		} else {
			Verify.verifyTrue(false, MessageUtility.DEATHDATE_NOTFOUND);
		}
	}

	/**
	 * Click on Notes link in the Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void clickNotesLink() throws ScriptException {

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LINK_ADDNOTES.exists()) {

			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.LINK_ADDNOTES,
					MessageUtility.LINK_NOTES_CLICKCED);

			Verify.verifyTrue(true, MessageUtility.LINK_NOTES_DISPLAYED);
		} else {
			Verify.verifyTrue(true,
					MessageUtility.LINK_NOTES_NOTDISPLAYED);
		}
	}

	/**
	 * Click on the Foreign radio button in the Address section of Customer Info
	 * page
	 * 
	 * @throws ScriptException
	 */
	public void selectForiegnType() throws ScriptException {

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.RADIO_FOREIGN.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.ADDRESSTYPE_FOREIGN_DISPLAYED);
			selectRadioButton(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.RADIO_FOREIGN,
					MessageUtility.ADDRESSTYPE_FOREIGN_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.ADDRESSTYPE_FOREIGN_NOTDISPLAYED);
		}
	}

	/**
	 * Select Industry from the Update Organization info
	 * 
	 * @throws ScriptException
	 */
	public void selectIndustry() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_INDUSTRY.exists()) {
			Verify.verifyTrue(true, "Industry select box found");

			selectFromListbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_INDUSTRY,
					clientE2ETO.getIndustry(),
					MessageUtility.INDUSTRYLIST);
			if (clientE2ETO.getIndustry().equalsIgnoreCase("OTHER")) {
				if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_INDUSTRYOTHER
						.exists()) {
					setTextInTextbox(
							Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_INDUSTRYOTHER,
							clientE2ETO.getIndustryOther(),
							MessageUtility.INDUSTRYLISTOTHER);
				}
			}

		} else {
			Verify.verifyTrue(false, "Industry select box not found");
		}
	}

	/**
	 * Enter the Number of Employees in the Update Organization info
	 * 
	 * @throws ScriptException
	 */
	public void enterNumberOfEmployees() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_NUMBEROFEMPLOYEES.exists()) {
			setTextInTextbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_NUMBEROFEMPLOYEES,
					checkNull(clientE2ETO.getNumberOfEmployees()),
					clientE2ETO.getNumberOfEmployees()
							+ MessageUtility.NUMBEROFEMPLOYEES);
		}
	}

	/**
	 * Enter Organization revenue in the Update Organization page
	 * 
	 * @throws ScriptException
	 */
	public void enterOrganizationRevenue() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_ORGANIZATIONREVENUE
				.exists()) {
			setTextInTextbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_ORGANIZATIONREVENUE,
					checkNull(clientE2ETO.getOrganizationRevenue()),
					clientE2ETO.getOrganizationRevenue()
							+ MessageUtility.ORGANIZATIONREVENUE);
		}
	}

	/**
	 * Enter First Year With SF in the Update Organization Info
	 * 
	 * @throws ScriptException
	 */
	public void enterFirstYearWSF() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_FIRSTYEARWITHSF.exists()) {
			setTextInTextbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_FIRSTYEARWITHSF,
					checkNull(clientE2ETO.getFirstYrWithSF()),
					clientE2ETO.getFirstYrWithSF() + MessageUtility.FIRSTYEARWITHSF);
		}
	}

	/**
	 * Enter the Customer Category for the Update Organization info
	 * 
	 * @throws ScriptException
	 */
	public void enterCustomerCategoryORG() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_CUSTOMERCATEGORY.exists()) {
			setTextInTextbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_CUSTOMERCATEGORY,
					checkNull(clientE2ETO.getCustomerCategory()),
					clientE2ETO.getCustomerCategory()
							+ MessageUtility.CUSTOMERCATEGORY);

		}
	}

	/**
	 * Select the Primary Contact for Update Organization info
	 * 
	 * @throws ScriptException
	 */
	public void selectPrimayMarketingContactORG() throws ScriptException {

		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_PRIMARYMARKETINGCONTACT
				.exists()) {

			click(Update_ORG_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_PRIMARYMARKETINGCONTACT,
					MessageUtility.PRIMARYMARKETINGCONTACT);
		}
	}

	/**
	 * Click on the Update link in the Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void clickOrganizationInfoUpdate() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LINK_UPDATEORGINFO.exists()) {
			click(Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LINK_UPDATEORGINFO,
					MessageUtility.LINK_ORGANIZATIONINFO);
			setIFrame();
		} else {
			Verify.verifyTrue(true, MessageUtility.LINK_ORGANIZATIONINFO_NOTDISPLAYED);
		}

	}

	/**
	 * Select the Organization Type in the Update Organization Info
	 * 
	 * @throws ScriptException
	 */
	public void selectOrgType() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_ORGTYPE.exists()) {
			selectFromListbox(Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_ORGTYPE,
					clientE2ETO.getOrganizationType(),
					clientE2ETO.getOrganizationType()
							+ MessageUtility.ORGANIZATIONTYPE);
		}
	}

	/**
	 * Select 'Hear About Office' from the Update Organization info
	 * 
	 * @throws ScriptException
	 */
	public void selectHearAboutOffice() throws ScriptException {

		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_HEARABOUTOFFICE.exists()) {
			selectFromListbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_HEARABOUTOFFICE,
					clientE2ETO.getHearAboutOffice(),
					MessageUtility.HEARABOUTOFFICE);
		}

		else {
			Verify.verifyTrue(false,
					MessageUtility.HEARABOUTOFFICE_NOTDISPLAYED);

		}
	}

	/**
	 * Select 'Most Important for You' field in the Update information
	 * 
	 * @throws ScriptException
	 */
	public void selectMostimportanttoyou() throws ScriptException {

		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_MOSTIMPORTANTTOYOU
				.exists()) {

			Verify.verifyTrue(true,
					MessageUtility.IMPORTANTFACTORS);

			selectFromListbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_MOSTIMPORTANTTOYOU,
					clientE2ETO.getMostimportanttoyou(),
					MessageUtility.MOSTIMPORATNTTOYOU);
			if (clientE2ETO.getMostimportanttoyou().equalsIgnoreCase("OTHER")) {
				setTextInTextbox(
						Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_OTHER_MOSTIMPORTANTTOYOU,
						clientE2ETO.getMostimportanttoyouOther(),
						MessageUtility.MOSTIMPORATNTTOYOUOTHER);
			}

		} else {
			Verify.verifyTrue(false,
					MessageUtility.IMPORTANTFACTORS_NOTFOUND);
		}
	}

	/**
	 * Click on Customer Profile Print in Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void clickCustomerProfilePrintUpdateCustinfo()
			throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LINK_CUSTOMERPROFILEPRINT.exists()) {
			click(Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LINK_CUSTOMERPROFILEPRINT,
					MessageUtility.CUSTOMERPROFILE_CLICKED);
		} else {
			Verify.verifyTrue(true, MessageUtility.CUSTOMERPROFILE_NOTDISPLAYED);
		}

	}

	/**
	 * Select Calling Preference from the Phone section
	 * 
	 * @throws ScriptException
	 */
	public void selectCallPreferenceDay() throws ScriptException {

		if (clientE2ETO.getCallingPrefDayWork() != null) {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_CALLINGPREFERENCEDAYWORK
					.exists()) {

				Verify.verifyTrue(true,
						MessageUtility.CALLINGPREFERENCEDAY_DISPLAYED);
				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_CALLINGPREFERENCEDAYWORK,
						clientE2ETO.getCallingPrefDayWork(),
						MessageUtility.WORKCALLINGPREFERENCEDAY_DISPLAYED);
			}
		}
	}

	/**
	 * Click on Permission to Text radio button to 'NO'
	 * 
	 * @throws ScriptException
	 */
	public void permissionToTextNo() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_NO.exists()) {
			selectRadioButton(
					CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_NO,
					MessageUtility.PERMISSIONTOTEXT_NO_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PERMISSIONTOTEXT_NO_NOTFOUND);
		}
	}


	/**
	 * Remove the Email from the Customer info
	 */
	public void removeEmail() {
		try {
			if (isCustomerInfoPageExists()) {
				if (Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_EMAIL.exists()) {
					Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_EMAIL.click();
					clickRemoveEmail();
					setTopFramewithDefaultContent();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Remove the Email from the Customer info for CRC
	 */
	public void removeEmail_CRC() {
		try {
			if (isCustomerInfoPageExists()) {
				if (Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_EMAIL.exists()) {
					Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_EMAIL.click();
					clickRemoveEmail();
					setCRCDefaultFrame();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	
	/**
	 * Enter Work Phone number in the Phone Section
	 * 
	 * @throws ScriptException
	 */
	public void enterWorkPhoneNumber() throws ScriptException {
		if (clientE2ETO.getWorkPhoneNumber() != null) {
			if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE).exists()) {

				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE,
						clientE2ETO.getWorkPhoneNumber(),
						clientE2ETO.getWorkPhoneNumber()
								+ MessageUtility.WORKPHONENUMBER);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.WORKPHONENUMBER_NOTFOUND);

			}
		}
	}

	/**
	 * Enter Home Phone number in the phone section
	 * 
	 * @throws ScriptException
	 */
	public void enterHomePhoneNumber() throws ScriptException {
		if (clientE2ETO.getHomePhoneNumber() != null) {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE.exists()) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE,
						clientE2ETO.getHomePhoneNumber(),
						clientE2ETO.getHomePhoneNumber()
								+ MessageUtility.HOMEPHONENUMBER);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOMEPHONE_NOTDISPLAYED);

			}
		}
	}

	/**
	 * Enter Additional phone number in the phone Section
	 * 
	 * @throws ScriptException
	 */
	public void enterAdditionalPhoneNumber() throws ScriptException {

		if (clientE2ETO.getAdditionalPhoneNumber() != null) {
			if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE).exists()) {

				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE,
						clientE2ETO.getAdditionalPhoneNumber(),
						clientE2ETO.getAdditionalPhoneNumber()
								+ MessageUtility.ADDITIONALTYPEPHONENUMBER_VALUE);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.ADDITIONALTYPEPHONENUMBER_NOTDISPLAYED);

			}
		}
	}

	/**
	 * Enter the Tax Id number in the Update Organization info
	 * 
	 * @throws ScriptException
	 */
	public void enterTaxIdNum() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_TIN_NUMBER.exists()) {
			setTextInTextbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_TIN_NUMBER,
					checkNull(clientE2ETO.getTaxIdNumber()),
					MessageUtility.TAXID_VALUE);
		}
	}

	/**
	 * Update the Organization info in Customer info page
	 */
	public void updateOrganizationalInfo() {
		waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS);
		try {
			if (isCustomerInfoPageExists()) {
				clickOrganizationInfoUpdate();
				selectOrgType();
				enterTaxIdNum();
				selectIndustry();
				enterNumberOfEmployees();
				enterOrganizationRevenue();
				enterFirstYearWSF();
				enterCustomerCategoryORG();
				selectAssignedStaffOrg();
				selectPrimayMarketingContactORG();
				selectHearAboutOffice();
				selectMostimportanttoyou();
				clickSaveButton();
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}

	/**
	 * Select the Assigned staff in the Update Organization info
	 * 
	 * @throws ScriptException
	 */
	public void selectAssignedStaffOrg() throws ScriptException {

		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_ASSIGNEDSTAFF.exists()) {

			Update_ORG_CustomerInfo_PageObjects.WidgetInfos.LISTBOX_ASSIGNEDSTAFF
					.selectItemAtIndex(1);
			Verify.verifyTrue(true,
					MessageUtility.ASSIGNEDSTAFF);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.ASSIGNEDSTAFF_NOTFOUND);
		}

	}

	/**
	 * Update the Email Address in the Customer Info
	 */
	public void updateEmail() {

		try {
			if (isCustomerInfoPageExists()) {
				selectEmailMclb();
				updateEnterEmailIND();
				clickSaveButton();
				isErrorPage("Update Email");
				setTopFramewithDefaultContent();
				verifyAddedEmail(clientE2ETO.getUpdateEmailAddress());

			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Update the Email Address in the Customer Info for CRC
	 */
	public void updateEmail_CRC() {

		try {
			if (isCustomerInfoPageExists()) {
				selectEmailMclb();
				updateEnterEmailIND();
				clickSaveButton();
				isErrorPage("Update Email");
				setCRCDefaultFrame();
				verifyAddedEmail(clientE2ETO.getUpdateEmailAddress());

			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}


	/**
	 * Enter Cell phone number in the Customer info page
	 * 
	 * @throws ScriptException
	 */
	public void enterNumber() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE.exists()
				&& clientE2ETO.getCellPhoneNumber() != null) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE,
					clientE2ETO.getCellPhoneNumber(),
					clientE2ETO.getCellPhoneNumber() + MessageUtility.MOBILEPHONE_VALUE);
		}
	}

	/**
	 * Update the Phone number in the Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void updateEnterNumber() throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE, 10);
		if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE).exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE,
					clientE2ETO.getPhoneNumber(), clientE2ETO.getPhoneNumber()
							+ MessageUtility.HOMEPHONENUMBER);

		} else {
			Verify.verifyTrue(false, MessageUtility.HOMEPHONE_NOTDISPLAYED);
		}

	}

	/**
	 * Click on the Customer interest link in the Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void clickCustomerInterestTOUpdate() throws ScriptException {

		Link clickCustomerInterestLink = new Link(
				"title=Open the Update Customer Interest page|text="
						+ clientE2ETO.getCustomerInterest().toUpperCase() + "");
		if (clickCustomerInterestLink.exists()) {
			clickCustomerInterestLink.click();
			setIFrame();
		}
	}

	/**
	 * Click on the Email Address Link
	 * 
	 * @throws ScriptException
	 */
	public void selectEmailMclb() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_EMAIL.exists()) {
			Update_Misc_Objects.WidgetInfos.LINK_EMAIL.click();
			setIFrame();
		}
	}

	/**
	 * Click on Remove Email trash icon if exists
	 * 
	 * @throws ScriptException
	 */
	public void clickRemoveEmail() throws ScriptException {
		setIFrame();
		Button isRemoveButton = new Button("id=save");
		if (isRemoveButton.exists()) {
			isRemoveButton.click();
			
			if (!isErrorPage("Remove Email"))
				Verify.verifyTrue(true, MessageUtility.REMOVEEMAIL);
		}
	}
	public void clickAddEmail() throws ScriptException {
		setIFrame();
		Button isAddButton = new Button("id=save");
		if (isAddButton.exists()) {
			isAddButton.click();
			if (!isErrorPage("Add Email"))
				Verify.verifyTrue(true, "Email is Added Successfully");
		}
	}


	/**
	 * Select the Occupation status in the Update Employment
	 */
	public void selectOccupationToUpdateEmployment() {
		try {
			if (clientE2ETO.getOccupationOther() != null) {
				Link isEmpLink = new Link(
						"title=Open the Update Employment page|text="
								+ clientE2ETO.getOccupationOther());
				isEmpLink.click();
				setIFrame();
			} else if (clientE2ETO.getOccupation() != null) {
				Link isEmpLink = new Link(
						"title=Open the Update Employment page|text="
								+ clientE2ETO.getOccupation());
				isEmpLink.click();
				setIFrame();
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}


	/**
	 * Update the Life Event in the Customer Info page
	 * 
	 * @throws ScriptException
	 */
	public void updateSelectEvent() throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIFEEVENT1, 20);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIFEEVENT1.exists()) {
			selectFromListbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_LIFEEVENT1,
					clientE2ETO.getUpdateLifeEvent(),
					clientE2ETO.getUpdateLifeEvent()
							+ MessageUtility.LISTBOX_EVENT);
			
		} else {
			Verify.verifyTrue(false, MessageUtility.LISTBOX_EVENT_NOTFOUND);
		}
	}

	/**
	 * Validate Payment Bill History page
	 * 
	 * @throws ScriptException
	 */
	public void validatePaymentBillHistory() throws ScriptException {

		if (HouseHoldMove_PageObjects.WidgetInfos.PAYMENTREFERENCELINK.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.PAYMENTBILLHISTORY_LAUNCHED);
			getWebDriverInstance().close();
		} else
			Verify.verifyTrue(false,
					MessageUtility.LINK_PAYMENTBILLHISTORY_NOTLAUNCHED);

	}

	/**
	 * Enter the Street in the Address section
	 * 
	 * @param street
	 * @throws ScriptException
	 */
	public void enterMailingStandardStreet(String street)
			throws ScriptException {
		if (street != null
				&& Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MSTREET1.exists()) {
			setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MSTREET1,
					street, street + MessageUtility.STREET_VALUE);
		}
	}

	/**
	 * Enter the City in the Address section
	 * 
	 * @param city
	 * @throws ScriptException
	 */
	public void enterMailingStandardCity(String city) throws ScriptException {
		if (city != null
				&& Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MCITY.exists()) {
			setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MCITY,
					city, city + MessageUtility.CITY);
		}
	}

	/**
	 * Click on the Address link to update and Update the Address
	 * 
	 * @throws ScriptException
	 */
	public void selectAddressVersionAndUpdateStandardAddress()
	throws ScriptException {
Link LINK_UPDATE = new Link("text="
		+ clientE2ETO.getmStreet().toUpperCase());
waitForPageLoad(LINK_UPDATE, 30);
if (LINK_UPDATE.exists()) {
	click(LINK_UPDATE, MessageUtility.LINK_UPDATEADDRESS);
	waitForTime(3);
	setIFrame();
	waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MSTREET1,
			25);
	if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MSTREET1).exists()) {

		setTextInTextbox(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MSTREET1,
				clientE2ETO.getmStreet1(), clientE2ETO.getmStreet1()
						+ MessageUtility.STREET_UPDATED);

		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.exists()) {
			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
					MessageUtility.BUTTON_SAVE);

		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_SAVE_NOTFOUND);
		}
	}

} else {
	Verify.verifyTrue(false, "Adress"
			+ clientE2ETO.getmStreet().toUpperCase()
			+ " is not available to update");
}
}

	/**
	 * Update Employment in the Customer Info page
	 */
	public void updateEmploymentUpdate() {
		try {
			if (isCustomerInfoPageExists()) {
				selectOccupationToUpdateEmployment();
				updateEnterEmployerName();
				updateSelectOccupation();
				updateSelectOccupationStatus();
				updateSelectJobTitle();
				updateEnterAsOfDate();
				clickSaveButton();
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	
	/**
	 * Update Employment in the Customer Info page for CRC
	 */
	public void updateEmploymentUpdate_CRC() {
		try {
			if (isCustomerInfoPageExists()) {
				selectOccupationToUpdateEmployment();
				updateEnterEmployerName();
				updateSelectOccupation();
				updateSelectOccupationStatus();
				updateSelectJobTitle();
				updateEnterAsOfDate();
				clickSaveButton();
				setCRCDefaultFrame();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Remove Interest in the Customer Info page
	 */
	public void removeInterest() {
		try {
			if (isCustomerInfoPageExists()) {
				int count = 1;
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDINTEREST);
				while (true) {
					WebElement flag = getWebDriverInstance().findElement(By.cssSelector("div#interestsAcc div#tempInterestGrid div#gridInterests div.dojoxGridMasterView > div div.dojoxGridScrollbox > div.dojoxGridContent"
									+ " > div"
									+ " > div:nth-child("
									+ count
									+ ")"));
					if (flag.isDisplayed()) {
						WebElement interest = getWebDriverInstance().findElement(By.cssSelector("div#interestsAcc div#tempInterestGrid div#gridInterests div.dojoxGridMasterView > div div.dojoxGridScrollbox > div.dojoxGridContent"
										+ " > div"
										+ " > div:nth-child("
										+ count + ")"));
						
						if (interest.getText().contains(clientE2ETO
								.getUpdateCustomerInterest().toUpperCase())) {
							String xpath = "//div[@id='interestsAcc']"
											+ "/div[@class='custInfoGridContainer']"
											+ "/div[2]//div[@class='dojoxGridScrollbox']"
											+ "/div[@class='dojoxGridContent']/div[1]/div["
											+ count
											+ "]/table[1]/tbody[1]/tr[1]/td[2]/a";
							if(getWebDriverInstance().findElement(By.xpath(xpath)).isDisplayed())
							{
								String xpath1 = "//div[@id='interestsAcc']"
										+ "/div[@class='custInfoGridContainer']"
										+ "/div[2]//div[@class='dojoxGridScrollbox']"
										+ "/div[@class='dojoxGridContent']/div[1]/div["
										+ count
										+ "]/table[1]/tbody[1]/tr[1]/td[2]/a";
								WebElement clickOnInterest = getWebDriverInstance().findElement(By.xpath(xpath1));
								clickOnInterest.click();
								waitForTime(4);
								if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE
										.exists()) {
									try {

										getWebDriverInstance()
												.findElement(
														By.cssSelector("div#removeInterestConfirmationDialog div:nth-child(2) div:nth-child(5)>div>button"))
												.click();
										Verify.verifyTrue(true,
												MessageUtility.REMOVEINTEREST);
									}catch(Exception exception){exception.printStackTrace();}
									/*try {

										getWebDriverInstance()
												.findElement(
														By.cssSelector("div#removeInterestConfirmationDialog div.dijitDialogPaneContent div div.removeConfirmationButons>button"))
												.click();
									}catch(Exception exception){exception.printStackTrace();}*/
									/*String xpath2 = "//div[@id='removeInterestConfirmationDialog']/div[@class='dijitDialogPaneContent']/div[5]/div[@class='removeConfirmationButons']/button[@id='removeContinueButton']";
									WebElement clickRemove = getWebDriverInstance().findElement(By.xpath(xpath2));
									if(clickRemove.isDisplayed())
										clickRemove.click();
									if (!isErrorPage("Remove Interest"))
										Verify.verifyTrue(false,
												MessageUtility.REMOVEINTEREST);*/
								}
							}
							break;
						}
						count++;

					} else {
						break;
					}
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Add an Event to the Household
	 * 
	 * @throws ScriptException
	 */
	public void selectEvent() throws ScriptException {

		Link eventLink = new Link("title=Open the Update Life Event page");
		if(eventLink.exists())
			eventLink.click();
		Verify.verifyTrue(true, MessageUtility.LISTBOX_EVENT);
		setIFrame();
	}

	/**
	 * Validate whether Loss History from Household is launched
	 * 
	 * @throws ScriptException
	 */
	public void validateLossHistory() throws ScriptException {
		if (getWindowTitle(1).toUpperCase().indexOf("HOUSEHOLD LOSS HISTORY") > -1) {
			Verify.verifyTrue(true,
					MessageUtility.LOSSHISTORY_LAUNCHED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LOSSHISTORY_NOTLAUNCHED);
		}
		getWebDriverInstance().findElement(By.id("lblClientName")).click();
		waitForTime(3);
	}

	/**
	 * Launch and Validate Loss History Option from the Household menu
	 */
	public void launchAndValidateLossHistory() {
		try {
			if (isHHPageLaunched()) {
				clickLossHistory();
				validateLossHistory();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			clickHHPageCustomer();
		}
	}

	/**
	 * Launch and Verify Policy Listing Print page from the houshold menu
	 */
	public void launchAndVerifyPolicyListingPrintPage() {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD, 15);
				clickMenuBar(HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD, HouseHoldMove_PageObjects.WidgetInfos.POLICYLISTINGPRINT);
				Verify.verifyTrue(true, MessageUtility.POLICYLISTINGPRINT);
				verifyPolicyListingPrint();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 5, 2);
			setTopFramewithDefaultContent();
		}
	}
	/**
	 * Launch and Validate Claim Status from the Household menu
	 */
	public void launchAndValidateClaimStatus() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD, HouseHoldMove_PageObjects.WidgetInfos.CLAIMSTATUS);
				Verify.verifyTrue(true, MessageUtility.CLAIMSTATUS);
				validateClaimstatus();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			clickHHPageCustomer();
		}
	}

	/**
	 * launch and verify New App/Quote from App Quote menu
	 */
	public void launchAndverifyNewAppQuotePage() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.NEWAPPQUOTEMENU, HouseHoldMove_PageObjects.WidgetInfos.NEWAPPQUOTE);
				Verify.verifyTrue(true, MessageUtility.NEWAPPQUOTE);
				fillAgentCode_AppQuoteMenu();
				validateNewAppQuote();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
		finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}
	/**
	 * launch and verify New SFPP from the App Quote menu
	 */

	public void launchAndVerifyNewSFPPPage() {
			try {
				if (isHHPageLaunched()) {
					clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.NEWAPPQUOTEMENU, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_NEWSFPP);
					Verify.verifyTrue(true, MessageUtility.NEWSFPP_LAUNCHED);
					fillAgentCode_AppQuoteMenu();
					validateNewSFPP();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
				}
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			} finally {
				clickHHPageCustomer();
				setTopFrame();
				handleCimsVersion();
			}
		}
	/**
	 * Launch and Verify the Production manager from the App Quote menu
	 */

	public void launchAndVerifyProdManager() {
			try {
				if (isHHPageLaunched()) {
					clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.NEWAPPQUOTEMENU, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_PRODMANAGER);
					verifyProdManager();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
				}
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			} finally {
				clickHHPageCustomer();
				setTopFrame();
				handleCimsVersion();
			}
		}
	/**
	 * Launch and Verify the Activity List from the Activities menu
	 */
	public void launchAndVerifyActivityList() {
		try {
			if (isHHPageLaunched()) {
				launchCMPageFromHHPage(
						HouseHoldMove_PageObjects.HOUSEHOLDMOVE_ACTIVITIESTAB,
						HouseHoldMove_PageObjects.HOUSEHOLDMOVE_HHACTIVITIES);
				handleActMgtVersion();
				verifyActivityList();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}

	/**
	 * Launch and Verify the Create FollowUp from the Activities menu
	 */
	public void launchAndVerifyCreateFollowUp() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_ACTIVITIESTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_FOLLOWUP);
				//handleActMgtVersion();
				verifyCreateFollowUp();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} /*finally {
			clickHHPageCustomer();
			setTopFrame();
			//handleCimsVersion();
		}*/
	}
	
	
	/**
	 * Launch and Verify the Create FollowUp from the Activities menu
	 */
	public void launchAndsaveCreateFollowUp() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_ACTIVITIESTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_FOLLOWUP);
				saveCreateFollowUp();
				isHHPageLaunched();
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_CREATEFOLLOWUP_ACTIVITYACTIONS, HouseHoldMove_PageObjects.WidgetInfos.LINK_CREATEFOLLOWUP_REFRESHRESULTS);
				waitForTime(10);
				verifyActivitesSection();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} 
	}
	
	/**
	 * Verify the Household Member section to verify the Customer.
	 * 
	 * @throws ScriptException
	 */
	public void verifyActivitesSection() throws ScriptException {

		Div activitiesSection = new Div("id=tempActivityGrid");

		if (activitiesSection.exists()) {
			Verify.verifyTrue(true, MessageUtility.ACTIVITY_BEGIN);
			Verify.verifyTrue(true,"======================================================================\n\n");
			Verify.verifyTrue(true,activitiesSection.getText() + "\n\n");
			Verify.verifyTrue(true,"======================================================================\n");
			Verify.verifyTrue(true, MessageUtility.ACTIVITY_END);

			String divText = activitiesSection.getText();
			if ("Test" != null) {
				if (divText.indexOf("Test")>0) {
					Verify.verifyTrue(true, "Test" + MessageUtility.CREATEFOLLOWUP_ACTIVITYSECTION);
				} else {
					Verify.verifyTrue(false, MessageUtility.CREATEFOLLOWUP_ACTIVITIES_NOTEXISTS);
				}
			}

		} else {
			Verify.verifyTrue(false, MessageUtility.CREATEFOLLOWUP_ACTIVITIES_NOTEXISTS);
		}
	}
	
	/**
	 * Enter Due on in Create Follow Up page.
	 * 
	 * @throws ScriptException
	 */
	public void enterDueOn() {
		if((HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_DUEON).exists()) {
			setTextInTextbox(HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_DUEON,"06-22-2016", "06-22-2016 value entered in Due on text box successfully");
		}
		else {
			Verify.verifyTrue(false, "Due on text box is NOT displayed as expected .");
		}
	}
	
	/**
	 * Enter Description in Create Follow Up page.
	 * 
	 * @throws ScriptException
	 */
	public void enterDescription() {
		if((HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_DESCRIPTION).exists()) {
			setTextInTextbox(HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_DESCRIPTION,"Test Description", "Test value entered in Due on text box successfully");
		}
		else {
			Verify.verifyTrue(false, "Due on text box is NOT displayed as expected .");
		}
	}
	
	/**
	 * Enter Remarks in Create Follow Up page.
	 * 
	 * @throws ScriptException
	 */
	public void enterRemarks() {
		if((HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_REMARKS).exists()) {
			setTextInTextbox(HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_REMARKS,"Test Remarks", "Test Remarks value entered in Due on text box successfully");
		}
		else {
			Verify.verifyTrue(false, "Due on text box is NOT displayed as expected .");
		}
	}
	
	
	public void createFollowupLineOfBusiness() { 
		try {		 
			if (HouseHoldMove_PageObjects.WidgetInfos.LIST_CREATEFOLLOWUP_LINEOFBUSINESS.exists()) {
				HouseHoldMove_PageObjects.WidgetInfos.LIST_CREATEFOLLOWUP_LINEOFBUSINESS
						.selectItemAtIndex(1);
			}
		
		} catch (Exception e) {

			Verify.verifyTrue(true, e.getMessage());
		}
		}
	
	public void createFollowupCategory() { 
		try {		 
			if (HouseHoldMove_PageObjects.WidgetInfos.LIST_CREATEFOLLOWUP_CATEGORY.exists()) {
				HouseHoldMove_PageObjects.WidgetInfos.LIST_CREATEFOLLOWUP_CATEGORY
						.selectItemAtIndex(1);
			}
		
		} catch (Exception e) {

			Verify.verifyTrue(true, e.getMessage());
		}
		}
	
	/**
	 * Click on Save button if exists
	 * @throws ScriptException
	 */
		public void clickSaveButton() throws ScriptException {
			waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_SAVE, 10);
			if (HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_SAVE.exists()) {
				click(HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP_SAVE,
						MessageUtility.BUTTON_SAVE);
			} else {
				Verify.verifyTrue(false, MessageUtility.BUTTON_SAVE_NOTFOUND);
			}
		}	
	
	
	/**
	 * Launch and Verify the Create Note from the Activities menu
	 */
	public void launchAndVerifyCreateNote() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_ACTIVITIESTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_NOTE);
				handleActMgtVersion();
				verifyCreateNote();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}

	/**
	 * Launch and Verify the SMP from the Activities menu
	 */
	public void launchAndVerifySMP() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_ACTIVITIESTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_ACTIVITIESSMP);
				handleActMgtVersion();
				verifySMP();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}
	/**
	 * Launch and Verify the IFR Tools from the Marketing menu
	 */
	public void launchAndVerifyIFRTools() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_MARKETINGTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_IFRTOOLS);
				fillAgentCode_AppQuoteMenu();
				validateIFRToolsPage();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}


	/**
	 * Launch and Verify the Action Plan from the Marketing menu
	 */
	public void launchAndVerifyActionPlan() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_MARKETINGTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_ACTIONPLAN);
				validateActionPlanPage();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}

	/**
	 * Launch and Verify the NAQs from the Marketing menu
	 */
	public void launchAndVerifyNAQs() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_MARKETINGTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_NAQS);
				validateMarketingNAQsPage();
			} else {
				Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}
	/**
	 * Launch and Verify the SMP from the Marketing menu
	 */
	public void launchAndVerifySMPFromMarketing() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_MARKETINGTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_SMP);
				verifySMP();
			} else {
				Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}

	/**
	 * Launch and Verify the Marketing Opportunities from the Marketing menu
	 */
	public void launchAndVerifyMarketingOpportunities() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_MARKETINGTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_MARKETINGOPP);
				validateMarketingOppr();
			} else {
				Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}

	/**
	 * Launch and Verify the Direct Mail from the Marketing menu
	 */
	public void launchAndVerifyDirectMail() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_MARKETINGTAB, HouseHoldMove_PageObjects.WidgetInfos.LINK_HOUSEHOLDMOVE_DIRECTMAIL);
				Verify.verifyTrue(true,
						MessageUtility.DIRECTMAIL);
				verifyDirectMail();
			} else {
				Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} finally {
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		}
	}

	/**
	 * Validate Claim Status page is launched
	 * 
	 * @throws ScriptException
	 */
	public void validateClaimstatus() throws ScriptException {
		if (getWindowTitle(1).toUpperCase().indexOf("POLICY CLAIM STATUS") > -1) {
			Verify.verifyTrue(true, MessageUtility.CLAIMSTATUS);
		} else {
			Verify.verifyTrue(false, MessageUtility.CLAIMSTATUS_NOTLAUCNHED);
		}
	}

	/**
	 * Validate Policy Listing Page is launched
	 * 
	 * @throws ScriptException
	 */

	public void verifyPolicyListingPrint() throws ScriptException {
			setWindow("Crystal Reports Viewer", 20, 1);
				Verify.verifyTrue(true, MessageUtility.POLICYLISTINGPRINT_LAUNCHED);
			
				Verify.verifyTrue(false, MessageUtility.POLICYLISTINGPRINT_NOTLAUNCHED);
			

		}
	/**
	 * Validate Loss History page is launched
	 * 
	 * @throws ScriptException
	 */
	public void clickLossHistory() throws ScriptException {
		clickMenuBar(HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD, HouseHoldMove_PageObjects.WidgetInfos.LOSSHISTORY);
		Verify.verifyTrue(true, MessageUtility.LOSSHISTORY_CLICKED);
	
}

	/**
	 * Validate New App/Quote page is launched
	 * 
	 * @throws ScriptException
	 */
	public void validateNewAppQuote() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.APPQUOTECLOSE, 8);
		if (HouseHoldMove_PageObjects.WidgetInfos.APPQUOTECLOSE.exists()) {
			Verify.verifyTrue(true, MessageUtility.NEWAPPQUOTE_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.APPQUOTECLOSE.click();
		} else {
			Verify.verifyTrue(false, MessageUtility.NEWAPPQUOTE_NOTLAUNCHED);
		}
	}

	/**
	 * Validate New SFPP page is launched
	 * 
	 * @throws ScriptException
	 */
	public void validateNewSFPP() throws ScriptException {
		if (HouseHoldMove_PageObjects.WidgetInfos.SFPPCLOSE.exists()) {
			Verify.verifyTrue(true, MessageUtility.NEWSFPP_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.SFPPCLOSE.click();
		} else {
			Verify.verifyTrue(false, MessageUtility.NEWSFPP_NOTLAUNCHED);
		}
	}

	/**
	 * Validate Production Manager page is launched
	 * 
	 * @throws ScriptException
	 */
	public void verifyProdManager() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.PRODMANAGER, 10);
		if (HouseHoldMove_PageObjects.WidgetInfos.PRODMANAGER.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.PRODUCTIONMANAGER_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.PRODMANAGER_CLOSE.click();
		} else
			Verify.verifyTrue(false, MessageUtility.PRODUCTIONMANAGER_NOTLAUNCHED);
	}

	/**
	 * Validate Activity List page is launched
	 * 
	 * @throws ScriptException
	 */
	public void verifyActivityList() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.ACTIVITY_LIST, 10);
		if (HouseHoldMove_PageObjects.WidgetInfos.ACTIVITY_LIST.exists()) {
			Verify.verifyTrue(true, MessageUtility.ACTIVITYLIST_LAUNCHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.ACTIVITYLIST_NOTLAUNCHED);
			clickHHPageCustomer();
		}
	}

	/**
	 * Validate Create FollowUp page is launched
	 * 
	 * @throws ScriptException
	 */
	public void verifyCreateFollowUp() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP, 10);
		if (HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CREATEFOLLOWUP_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.CLOSE_CREATEFOLLOWUP.click();
		} else {
			Verify.verifyTrue(false, MessageUtility.CREATEFOLLOWUP_NOTLAUNCHED);
			clickHHPageCustomer();
		}
	}
	
	/**
	 * Validate Create FollowUp page is launched
	 * 
	 * @throws ScriptException
	 */
	public void saveCreateFollowUp() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP, 20);
		if (HouseHoldMove_PageObjects.WidgetInfos.CREATEFOLLOWUP.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CREATEFOLLOWUP_LAUNCHED);
			//enterDueOn();
			createFollowupLineOfBusiness();
			createFollowupCategory();
			enterDescription();
			enterRemarks();
			clickSaveButton();
		} else {
			Verify.verifyTrue(false, MessageUtility.CREATEFOLLOWUP_NOTLAUNCHED);
			
		}
	}

	/**
	 * Validate Create Note page is launched
	 * 
	 * @throws ScriptException
	 */
	public void verifyCreateNote() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.CREATENOTE, 10);
		if (HouseHoldMove_PageObjects.WidgetInfos.CREATENOTE.exists()) {
			Verify.verifyTrue(true, MessageUtility.CREATENOTE_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.CREATENOTE_CLOSE.click();
		} else {
			Verify.verifyTrue(false, MessageUtility.CREATENOTE_NOTLAUNCHED);
			CWNonAgentCSObjects.WidgetInfos.CUSTOMERNAME_LINK_SUPPORTWRITE.click();
		}
	}

	/**
	 * Validate IFR Tools Page
	 */
	public void validateIFRToolsPage() throws ScriptException {
		try {
			waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE, 5);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE.exists()) {
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE.click();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.IFRTOOLS_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Validate Action Plan Page
	 */
	public void validateActionPlanPage() throws ScriptException {
		try {
			waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE,
					10);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.ACTIONPLAN_LAUNCHED);
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE.click();
			} 
			else
				Verify.verifyTrue(false, MessageUtility.ACTIONPLAN_NOTLAUNCHED);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Validate NAQs page is launched
	 * 
	 * @throws ScriptException
	 */
	public void validateMarketingNAQsPage() throws ScriptException {
		try {
			waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE, 5);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE.exists()) {
				Verify.verifyTrue(true, MessageUtility.NAQs_LAUNCHED);
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CLOSE.click();
			} 
			else
				Verify.verifyTrue(false, MessageUtility.NAQs_NOTLAUNCHED);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Validate SMP page is launched
	 * 
	 * @throws ScriptException
	 */
	public void verifySMP() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.SMP, 20);
		if (HouseHoldMove_PageObjects.WidgetInfos.SMP.exists()) {
			Verify.verifyTrue(true, MessageUtility.SMP_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.CLOSE_CREATEFOLLOWUP.click();
		} 
		else
			Verify.verifyTrue(false, MessageUtility.SMP_NOTLAUNCHED);
	}

	/**
	 * Validate Marketing Opportunities page is launched
	 * 
	 * @throws ScriptException
	 */
	public void validateMarketingOppr() throws ScriptException {
		waitForPageLoad(
				Update_ORG_CustomerInfo_PageObjects.WidgetInfos.DIV_MARKETING_OPPORTUNITIES, 10);
		if (!Update_ORG_CustomerInfo_PageObjects.WidgetInfos.DIV_MARKETING_OPPORTUNITIES
				.exists()) {
			Verify.verifyTrue(false,
					MessageUtility.MARKETINGOPPORTUNITIES_NOTLAUNCHED);
		} else {
			Verify.verifyTrue(true,
					MessageUtility.MARKETINGOPPORTUNITIES_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.CLOSE_CREATEFOLLOWUP.click();
		}
	}

	/**
	 * Validate Marketing Direct Mail page is launched
	 * 
	 * @throws ScriptException
	 */
	public void verifyDirectMail() throws ScriptException {

		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.DIRECTMAIL, 10);
		if (HouseHoldMove_PageObjects.WidgetInfos.DIRECTMAIL.exists()) {
			Verify.verifyTrue(true, MessageUtility.DIRECTMAIL);
		} 
	}

	/**
	 * get the particular Window title
	 * 
	 * @param windowNum
	 * @return return the title
	 */
	public String getWindowTitle(int windowNum) {
		Browser browser = new Browser();
		String browsersTitle = null;
		List<String> browserList = null;
		String returnBrowserTitle = null;
		try {
			for (int i = 0; i < 30; i++) {
				browsersTitle = browser.getActiveWindow().getDocument()
						.getTitle();
				System.out.println(browsersTitle);
				if (browsersTitle.indexOf("Household Information") < 0) {
					break;
				}
				Thread.sleep(100);
			}
			browserList = browser.getAllWindowTitles();
			System.out.println(browserList);

		} catch (InterruptedException e) {
			Verify.verifyTrue(false, e.getMessage());
		}
		if (browserList != null) {
			returnBrowserTitle = browserList.get(windowNum - 1);
		}
		return returnBrowserTitle;
	}

	/**
	 * Validate Change Agent Page is launched
	 * 
	 * @throws ScriptException
	 */
	public void validateChangeAgentPage() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.CLOSECUSTOMERCHANGE, 15);
		if (!HouseHoldMove_PageObjects.WidgetInfos.CLOSECUSTOMERCHANGE.exists()) {
			Verify.verifyTrue(false, MessageUtility.CHANGEAGENT_NOTLAUNCHED);
		} else {
			Verify.verifyTrue(true, MessageUtility.CHANGEAGENT_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.CLOSECUSTOMERCHANGE.click();
		}
	}

/**
 * Enter the SSN number in the Update Personal info section
 */
	public void enterSSN() {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN.exists()
					&& clientE2ETO.getSsnNum() != null) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN,
						clientE2ETO.getSsnNum(), MessageUtility.SSN1);
			} else if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN.exists()
					&& clientE2ETO.getSsnNum() != null) {
				setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN,
						clientE2ETO.getSsnNum(), MessageUtility.SSN1);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}
/**
 * Click on Add Alias link in the Customer Info page.
 */
	public void clickAddAlias() {
		try {
			if (Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS.exists()) {
				click(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS,
						MessageUtility.LINK_ADDALIAS);
				setIFrame();
			} else {
				Verify.verifyTrue(true, MessageUtility.LINK_ADDALIAS_NOTDISPLAYED);
			}

		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Select Permission to text radio button to Yes
 * @throws ScriptException
 */
	public void permissionToText() throws ScriptException {
		if (clientE2ETO.getPermissionText() != null) {
			if (clientE2ETO.getPermissionText().equalsIgnoreCase("Yes")) {
				if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_YES
						.exists()) {
					selectRadioButton(
							CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_YES,
							MessageUtility.PERMISSIONTOTEXT_YES_CLICKED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.PERMISSIONTOTEXT_YES_NOTFOUND);
				}
			}

			if (clientE2ETO.getPermissionText().equalsIgnoreCase("No")) {
				if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_NO.exists()) {
					selectRadioButton(
							CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_NO,
							MessageUtility.PERMISSIONTOTEXT_NO_CLICKED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.PERMISSIONTOTEXT_NO_NOTFOUND);
				}
			}

			if (clientE2ETO.getPermissionText().equalsIgnoreCase("DidNotAsk")) {
				if (CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_DIDNOTASK
						.exists()) {
					selectRadioButton(
							CreateIndividualCustomer.WidgetInfos.RADIOBUTTON_PERMISSION_DIDNOTASK,
							MessageUtility.PERMISSIONTOTEXT_DIDNOTASK_CLICKED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.PERMISSIONTOTEXT_DIDNOTASK_NOTFOUND);
				}
			}
		}

	}
/**
 * Enter Dummy Email Address i.e)noemail@noemail.com
 * @throws ScriptException
 */
	public void enterDummyEmail() throws ScriptException {
		if (Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_EMAILADDRESS1.exists()) {
			setTextInTextbox(
					Update_ORG_CustomerInfo_PageObjects.WidgetInfos.TEXTFIELD_EMAILADDRESS1,
					"noemail@noemail.com",
					"noemail@noemail.com dummy email entered successfully");
			Verify.verifyTrue(true, MessageUtility.DUMMYEMAIL);
		}else {
			Verify.verifyTrue(false, MessageUtility.EMAIL_NOTDISPLAYED);
		}
	}
/**
 * Verify the added US address
 * @param address
 * @throws ScriptException
 */
	public void verifyAddedAddressUS(String address) throws ScriptException {
		Link ADDED_ADRESS = new Link("text=" + address.toUpperCase());
		waitForPageLoad(ADDED_ADRESS, 10);
		if (ADDED_ADRESS.exists()) {
			Verify.verifyTrue(true, MessageUtility.ADDRESS_ADDED);
		}
	}
/**
 * Add an Alias in the Customer info page
 */
	public void addFirstAlias() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddAlias();
				waitForTime(3);
				accessSecondAddAliasPageFirstInternationalChars();
				isErrorPage("Add Alias");
				String alias = clientE2ETO.getAliasFirstName() + " "
						+ clientE2ETO.getAliasLastName();
				setTopFramewithDefaultContent();
				verifyAddedAlias(alias);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Add an Alias in the Customer info page for CRC
	 */
		public void addFirstAlias_CRC() {
			try {
				if (isCustomerInfoPageExists()) {
					clickAddAlias();
					waitForTime(3);
					accessSecondAddAliasPageFirstInternationalChars();
					isErrorPage("Add Alias");
					String alias = clientE2ETO.getAliasFirstName() + " "
							+ clientE2ETO.getAliasLastName();
					setCRCDefaultFrame();
					verifyAddedAlias(alias);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException scriptException) {
				scriptError(scriptException);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}
/**
 * Add Organization alias in the Customer info page
 */
	
	public void addOrganizationFirstAlias() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddAlias();
				accessSecondAddAliasOrgPageFirstInternationChars();
				isErrorPage("Add Alias");
				setTopFramewithDefaultContent();
				verifyAddedAlias(clientE2ETO.getAliasLastName());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Add an Alias with international Characters for Individual
 */
	public void addSecondAlias() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddAlias();
				waitForTime(3);
				accessSecondAddAliasPageSecondInternationalChars();
				isErrorPage("Add Alias");
				setTopFramewithDefaultContent(); 
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS);
				selectNameVersionAndUpdateInternationChars();
				isErrorPage("Update Alias");
				setTopFramewithDefaultContent(); 
				selectNameVersionAndRemove();
				isErrorPage("Remove Alias");
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Add an Alias with international Characters for Individual
	 */
		public void addSecondAlias_CRC() {
			try {
				if (isCustomerInfoPageExists()) {
					clickAddAlias();
					waitForTime(3);
					accessSecondAddAliasPageSecondInternationalChars();
					isErrorPage("Add Alias");
					waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS);
					selectNameVersionAndRemove();
					isErrorPage("Remove Alias");
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException e) {
				scriptError(e);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}


/**
 * Add an Alias with international Characters for Organization
 */
	
	public void addOrganizationSecondAlias() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddAlias();
				accessSecondAddAliasOrgPageSecondInternationChars();
				isErrorPage("Add Alias");
				setTopFramewithDefaultContent();
				verifyAddedAlias(clientE2ETO.getSecondAliasLastName());
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS);
				selectNameVersionAndUpdateOrgInternationChars();
				isErrorPage("Update Alias");
				setTopFramewithDefaultContent();
				verifyAddedAlias(clientE2ETO.getOrganizationName());
				selectNameVersionAndRemove_ORG();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Add an Address to the Household
 */

	public void addAddressCustomerInfo() {
			try {
				if (isCustomerInfoPageExists()) {
					clickAddAddress();
					selectAddressType();
					enterMailingStandardStreet(clientE2ETO.getmStreet());
					enterMailingStandardCity(clientE2ETO.getmCity());
					selectMailingState(clientE2ETO.getMstate());
					enterMailingZip(clientE2ETO.getMzip());
					clickSave();
					//clickSaveButton();
					verifyAddressStandzation();
					isErrorPage("Add Address");
					setTopFramewithDefaultContent();
					verifyAddedAddress(clientE2ETO.getmStreet());
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException e) {
				scriptError(e);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}
	
	

/**
 * Update address in the Address section
 */
	public void updateAddressCustomerInfo() {
		try {
			waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDADDRESS);
			if (isCustomerInfoPageExists()) {
				selectAddressVersionAndUpdateStandardAddress();
				verifyAddressStandzation();
				isErrorPage("Update Address");
				setTopFramewithDefaultContent();
				verifyAddedAddress(clientE2ETO.getmStreet1());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Add an Email in the Customer info page
 */

	public void addEmailCustomerInfo() {
			try {
				if (isCustomerInfoPageExists()) {
					clickAddEmailLink();
					waitForTime(3);
					accessAddEmailPage();
					isErrorPage("Add Email");
					setTopFramewithDefaultContent();
					verifyAddedEmail(clientE2ETO.getEmail());
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException scriptException) {
				scriptError(scriptException);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}

/**
 * Add an Email in the Customer info page
 */
	public void addEmailCustomerInfo_CRC() {
			try {
				if (isCustomerInfoPageExists()) {
					clickAddEmailLink();
					accessAddEmailPage();
					isErrorPage("Add Email");
					setCRCDefaultFrame();
					verifyAddedEmail(clientE2ETO.getEmail());
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException scriptException) {
				scriptError(scriptException);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}


	/** 
	 * verify SSN in update Personal Info
	 */
	public void updatePersonalInfoCustomerInfo() {
			try {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL, 15);
				if (isCustomerInfoPageExists()) {
					updatePersonalInfo();
					setTopFramewithDefaultContent();
					verifySSNCustomerInfoPage();
					isErrorPage("Update Personal Information");
				} else {
					Verify.verifyTrue(
							false,
							MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException e) {
				scriptError(e);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
	}
	
	/** 
	 * verify SSN in update Personal Info for CRC
	 */
	public void updatePersonalInfoCustomerInfo_CRC() {
			try {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL, 15);
				if (isCustomerInfoPageExists()) {
					updatePersonalInfo();
					isErrorPage("Update Personal Information");
					setCRCDefaultFrame();
					verifySSNCustomerInfoPage();
				} else {
					Verify.verifyTrue(
							false,
							MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException e) {
				scriptError(e);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
	}
	

	
/**
 *Enter Birth,Gender,Martial and SSN In Personal Info
 */

	
	public void updatePersonalInfoInCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				enterBirthGenderMaritalSSNInPersonalInfo();
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	
/**
 * Add Customer Interest to the Household through Cusotmer Info page
 */
	public void addCustomerInterestsCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDINTEREST, 15);
				clickAddInterest();
				enterCustomerInterest();
				clickSave();
				isErrorPage("Add Customer Interest");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Enter the Customer Interest in Interest Section
 * @throws ScriptException
 */
	public void enterCustomerInterest() throws ScriptException {
		waitForPageLoad(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_CUSTOMERINTEREST1, 10);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_CUSTOMERINTEREST1.exists()
				&& clientE2ETO.getCustomerInterest() != null) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_CUSTOMERINTEREST1,
					clientE2ETO.getCustomerInterest(),
					MessageUtility.CUSTOMERINTEREST_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTOMERINTEREST_NOTDISPLAYED);
		}

	}
/**
 * Click on Save button if exists
 * @throws ScriptException
 */
	public void clickSave() throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE, 10);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.exists()) {
			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
					MessageUtility.BUTTON_SAVE);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_SAVE_NOTFOUND);
		}

	}
	
	
	
	
/**
 * Navigate back to Household by Clicking on the Customer name link
 */
	public void launchHHPageFromCustomerInfo() {
		try {

			if (isCustomerInfoPageExists()) {
				clickHHPageCustomer();
				setTopFrame();
				verifyHouseholdPageLaunched();
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Launch and validate Change Agent from Household menu
 */
	public void validateChangeAgentPageInHH() {
		try {
			if (isHHPageLaunched()) {
				launchCMPageFromHHPage(
						HouseHoldMove_PageObjects.HOUSEHOLDMOVE_HOUSEHOLDTAB,
						HouseHoldMove_PageObjects.HOUSEHOLDMOVE_CHANGEAGENT);
				setWindow("Customer Initiated Assignment",3,2);
				validateChangeAgentPage();
				waitForTime(2);
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION,3,2);
				setTopFrame();
				waitForPageLoad(HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE, 30);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 *  Launch and validate Payment/Bill History from Household menu
 */
	public void validatePaymentBillingHistoryHH() {
		try {
			if (isHHPageLaunched()) {
				launchCMPageFromHHPage(
						HouseHoldMove_PageObjects.HOUSEHOLDMOVE_HOUSEHOLDTAB,
						HouseHoldMove_PageObjects.HOUSEHOLDMOVE_PAYMENYBILLHISTORY);
				Verify.verifyTrue(true,
						MessageUtility.PAYMENTBILLHISTORY_LAUNCHED);
				setChildWindow(3);
				validatePaymentBillHistory();
				waitForTime(2);
				setChildWindow(2);
				setTopFrame();
				waitForPageLoad(HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE, 30);

			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Validate the Phone numbers in Active Customer bar
 */
	public void validatePhoneNumbersDisplayedActiveCustomerBar() {
		try {
			String phoneNumbers = getWebDriverInstance().findElement(By.xpath("//div[@id='divClientBar']/table/tbody/tr[1]/td[4]/select")).getText();
			if(phoneNumbers.contains(clientE2ETO.getCellPhoneNumber()) && phoneNumbers.contains(clientE2ETO.getHomePhoneNumber()))
				Verify.verifyTrue(true, MessageUtility.PHONENUMBERS);
		}
		 catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Add Mobile Phone to the Household through Customer info page
 */
	public void addMobilePhoneCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddPhone();
				if (isSelectListItemPresent(
						AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
						"Mobile Phone")) {
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							"Mobile Phone",
							MessageUtility.MOBILEPHONE_SELECTED);
					enterNumber();
					permissionToTextNo();
					clickSaveButton();
					isErrorPage("Add Mobile Phone");
					setTopFramewithDefaultContent();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.MOBILEPHONE_NOTSELECTED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	

/**
 * Update the Mobile phone in the Customer info
 */
	
	public void updateMobilePhoneCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDPHONE, 10);
				updatePhoneNumber();
				setIFrame();
				permissionToText();
				clickSaveButton();
				isErrorPage("update Phone");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Add Home Phone number to the Household through Customer Info page
 */

	public void addHomePhoneCustomerInfo() {
			try {
				
				if (isCustomerInfoPageExists()) {
					clickAddPhone();
					if (isSelectListItemPresent(
							AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE, "Home Phone")) {
						selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
								"Home Phone", MessageUtility.HOMEPHONE_SELECTED);
						enterHomePhoneNumber();
						selectCallPreference();
						selectFromTime();
						selectEndTime();
						clickSaveButton();
						isErrorPage("Add Phone");
						setTopFramewithDefaultContent();
					} else {
						Verify.verifyTrue(false,
								MessageUtility.HOMEPHONE_NOTSELECTED);
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException scriptException) {
				scriptError(scriptException);
			} catch (Exception e) {
				Verify.verifyTrue(false, e.getMessage());
			}
		}


/**
 * This method will remove all phones from Customer info.
 * we need to call this method before we add phone to the Household.
 */

	
	public void removeAllPhonesFromCustomerInfo() {
		try {
			
			while (true) {
				if (Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_PHONENUMBER.exists()) {
					Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_PHONENUMBER.click();
					setIFrame();
					waitForPageLoad(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE, 5);
					if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
							.exists()) {
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.click();
					}
					if (isErrorPage(EndToEndConstants.REMOVE_ALL_PHONE)) {
						break;
					}
					setTopFramewithDefaultContent();
				} else {
					break;
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	public void removeAllPhonesFromCustomerInfo_CRC() {
		try {
			
			while (true) {
				if (Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_PHONENUMBER.exists()) {
					Update_Misc_Objects.WidgetInfos.IMAGE_REMOVE_PHONENUMBER.click();
					setIFrame();
					waitForPageLoad(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE, 5);
					if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE
							.exists()) {
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.click();
					}
					if (isErrorPage(EndToEndConstants.REMOVE_ALL_PHONE)) {
						break;
					}
					setCRCDefaultFrame();
				} else {
					break;
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

/**
 * Add the Additional phone number in the Customer info 
 */
	
	public void addAdditionalPhoneCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDPHONE, 20);
				clickAddPhone();
				if (isSelectListItemPresent(
						AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
						"Additional Personal Phone")) {
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							"Additional Personal Phone",
							MessageUtility.ADDITIONALPERSONALPHONE_SELECTED);
					enterAdditionalPhoneNumber();
					validatePermissionToTextHidden();
					clickSaveButton();
					isErrorPage("Add Phone");
					setTopFramewithDefaultContent();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.ADDITIONALPERSONALPHONE_NOTSELECTED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	

	/** Add Work Phone */
	public void addWorkPhoneCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddPhone();
				if (isSelectListItemPresent(
						AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE, "Work Phone")) {
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							"Work Phone", MessageUtility.WORKPHONE_SELECTED);
					enterWorkPhoneNumber();
					selectCallPreference();
					selectFromTime();
					selectEndTime();
					clickSaveButton();
					isErrorPage("Add Phone");
					setTopFramewithDefaultContent();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.WORKPHONE_NOTSELECTED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/** Add Work Phone */
	public void addWorkPhoneCustomerInfo_CRC() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddPhone();
				if (isSelectListItemPresent(
						AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE, "Work Phone")) {
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							"Work Phone", MessageUtility.WORKPHONE_SELECTED);
					enterWorkPhoneNumber();
					selectCallPreference();
					selectFromTime();
					selectEndTime();
					clickSaveButton();
					isErrorPage("Add Phone");
					setCRCDefaultFrame();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.WORKPHONE_NOTSELECTED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Validate Policies Section in the Customer info.if available we are going display those details*/
	public void validatePoliciesInfoSection() {
		try {
			if (isCustomerInfoPageExists()) {

				String accountPolicyInfo = CustomerInfoObjects.WidgetInfos.DIV_POLICYSECTION
						.getText();
				Verify.verifyTrue(true, MessageUtility.ACCOUNTPOLICY_BEGIN);
				Verify.verifyTrue(true,accountPolicyInfo + "/n/n");
				Verify.verifyTrue(true, MessageUtility.ACCOUNTPOLICY_END);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Validate Customer Profile Print from the Customer menu in the HH page*/
	public void validateCustomerProfilePrintInHH() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldTestObjects.WidgetInfos.CUSTOMER_LINK, HouseHoldTestObjects.WidgetInfos.LINK_CUSTOMER_PROFILE_PRINT);
				validateCustomerProfilePrint(2);
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 3, 2);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 5, 2);
		}
	}
	
	
	/**
	 * Click on Add Alias link in the Customer Info page for CRC.
	 */
	public void clickAddAlias_CRC() {
		try {
			if (Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS.exists()) {
				click(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS,
						MessageUtility.LINK_ADDALIAS);
				getWebDriverInstance().switchTo().defaultContent();
				getWebDriverInstance().switchTo().frame("TopFrame");
				setTopFrame();
				setIFrame();
				waitForTime(15);
			} else {
				Verify.verifyTrue(true, MessageUtility.LINK_ADDALIAS_NOTDISPLAYED);
			}

		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
/**Add dummy email*/
	public void addDummyEmail() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddEmailLink();
				enterDummyEmail();
				clickSaveButton();
				isErrorPage("Adding Dummy Email");
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**Update Home Phone To Mobile Phone In Customer Info Page*/
	public void updateHomePhoneToMobilePhoneInCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDPHONE, 10);
				if (Update_Misc_Objects.WidgetInfos.LINK_ADDPHONE.exists()) {
					updateHomePhoneNumber();
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							"Mobile Phone",
							MessageUtility.MOBILEPHONE_SELECTED);
					enterNumber();
					permissionToText();
					clickSaveButton();
					isErrorPage("update HomePhone To MobilePhone InCustomerInfo ");
					setTopFramewithDefaultContent();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Add Work Phone to the Household*/
	public void addWokPhoneCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddPhone();
				waitForPageLoad(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE, 5);
				if (AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE.exists()) {
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							EndToEndConstants.WORK_PHONE,
							MessageUtility.WORKPHONE_SELECTED);
					enterWorkPhoneNumber();
					selectCallPreferenceDay();
					selectFromTime();
					selectEndTime();
					clickSaveButton();
					isErrorPage(EndToEndConstants.WORK_PHONE);
					setTopFramewithDefaultContent();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
				isErrorPage(EndToEndConstants.WORK_PHONE);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Add, Update,and delete address from the Household info page*/
	public void addUpdateDeleteAddress() throws ScriptException {
		waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDADDRESS, 20);
		if (Update_Misc_Objects.WidgetInfos.LINK_ADDADDRESS.exists()) {
			addAddressCustomerInfo();
			updateAddressCustomerInfo();
			addAndRemoveAddressForeign();
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_ADDADDRESS_NOTDISPLAYED);
		}
	}
/**Add and Remove the Foreign address through the Customer Info page*/
	public void addAndRemoveAddressForeign() {
		try {
			if (isCustomerInfoPageExists()) {
				click(Update_Misc_Objects.WidgetInfos.LINK_ADDADDRESS,
						"Add Address Link clicked successfully");
				waitForPageLoad(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_USAGEMAILING,
						10);
				setIFrame();
				if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_USAGEMAILING
						.exists()) {
					checkUsageMailing();
					selectForiegnType();
					enterMailingStandardStreet(clientE2ETO.getForeignAddress());
					enterMailingStandardCity(clientE2ETO.getForeignCity());
					enterMailingCountry(clientE2ETO.getForeignCountry());
					enterMailingZip(clientE2ETO.getForeignPostal());
					clickSave();
					//clickSaveButton();
					setTopFramewithDefaultContent();
					searchandRemoveAddress(clientE2ETO.getForeignAddress());
				} else {
					Verify.verifyTrue(false,
							MessageUtility.ADDADDRESSPAGE_NOTLAUNCHED);
				}
			} else
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/** Verify the Added Email in the Customer Info Section*/
	public void verifyAddedEmail(String email) throws ScriptException {
		if (email != null) {
			Link ADDED_EMAIL = new Link("text=" + email.toUpperCase());
			waitForPageLoad(ADDED_EMAIL, 10);
			if (ADDED_EMAIL.exists()) {
				Verify.verifyTrue(true, MessageUtility.EMAIL_ADDED);
			} else {
				Verify.verifyTrue(false, MessageUtility.EMAIL_NOTADDED);
			}
		}
	}

/**Enter Last name  in the Add Alias Page(International Chars)*/
		public void accessSecondAddAliasPageSecondInternationalChars_CRC()
		throws ScriptException {
			waitForTime(3);
			getWebDriverInstance().switchTo().defaultContent();
			getWebDriverInstance().switchTo().frame("TopFrame");
			setTopFrame();
			getWebDriverInstance().switchTo().frame("addUpdateDialogIframe");
			if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME).exists()) {
		setTextInTextbox(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME,
				clientE2ETO.getSecondAliasFirstName(),
				MessageUtility.FIRSTNAME_VALUE);
	
	} else {
		Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);
	}
	if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME).exists()) {
		setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
				clientE2ETO.getSecondAliasLastName(),
				MessageUtility.LASTNAME_VALUE);
	} else {
		Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);
	}
	click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
			MessageUtility.BUTTON_SAVE);
	if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE).exists()) {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE);
		click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
				MessageUtility.BUTTON_CONTINUE);
	}
	}
		
	public void accessSecondAddAliasPageSecondInternationalChars()
		throws ScriptException {
		if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME).exists()) {
		setTextInTextbox(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME,
				clientE2ETO.getSecondAliasFirstName(),
				MessageUtility.FIRSTNAME_VALUE);
	
	} else {
		Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);
	}
	if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME).exists()) {
		setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
				clientE2ETO.getSecondAliasLastName(),
				MessageUtility.LASTNAME_VALUE);
	} else {
		Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);
	}
	click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
			MessageUtility.BUTTON_SAVE);
	if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE).exists()) {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE);
		click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
				MessageUtility.BUTTON_CONTINUE);
	}
	//setCRCDefaultFrame();
	setTopFramewithDefaultContent();
	try {
			String updateName = clientE2ETO.getSecondAliasFirstName() + " "
					+ clientE2ETO.getSecondAliasLastName();
			Link LINK_UPDATE = new Link("text=" + updateName.toUpperCase());
			if (LINK_UPDATE.exists()) {
				click(LINK_UPDATE, MessageUtility.LINK_UPDATENAME);
				setIFrame();
				if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME)
						.exists()) {
					setTextInTextbox(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
							clientE2ETO.getUpdateLastName(),
							clientE2ETO.getUpdateLastName()
									+ MessageUtility.LASTNAME_INTLCHAR);
				}
				click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
						MessageUtility.BUTTON_SAVE);
				if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE)
						.exists()) {
					click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
							MessageUtility.BUTTON_CONTINUE);
				}
				//setCRCDefaultFrame();
			} else {
				Verify.verifyTrue(false, updateName
						+ MessageUtility.LINK_UPDATENAME_NOTFOUND);
			}
		
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	

	/**Enter First name in the Add Alias Page(International Chars)*/
	public void accessSecondAddAliasPageFirstInternationalChars() {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME.exists()) {
				
				if (clientE2ETO.getAliasFirstName() != null) {
					setTextInTextbox(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME,
							clientE2ETO.getAliasFirstName(),
							clientE2ETO.getAliasFirstName()
									+ MessageUtility.FIRSTNAME_VALUE);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.TEXT_FIRSTNAME);
				}
				if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME)
						.exists() && clientE2ETO.getAliasLastName() != null) {
					setTextInTextbox(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
							clientE2ETO.getAliasLastName(),
							clientE2ETO.getAliasLastName()
									+ MessageUtility.LASTNAME_VALUE);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.TEXT_LASTNAME);
				}
				if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.exists()) {
					click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
							MessageUtility.BUTTON_SAVE);
				}
				if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE
						.exists()) {
					click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
							MessageUtility.BUTTON_CONTINUE);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.ADDALIASPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**Enter Last name in the Add Alias Page(International Chars-Organization)*/
	public void accessSecondAddAliasOrgPageFirstInternationChars()
			throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TXT_ORGALIAS);
		if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TXT_ORGALIAS).exists()) {
			setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TXT_ORGALIAS,
					clientE2ETO.getAliasLastName(),
					MessageUtility.ORGANIZATIONNAME_VALUE);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.TEXT_ORGNAME_NOTFOUND);
		}
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE, 10);
		click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
				MessageUtility.BUTTON_SAVE);

		if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE).exists()) {
			waitForPageLoad(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE, 10);

			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
					MessageUtility.BUTTON_CONTINUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_CONTINUE_NOTFOUND);
		}
	}
	/**Enter Organization name in the Add Alias Page(International Chars)*/
	public void accessSecondAddAliasOrgPageSecondInternationChars()
			throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TXT_ORGALIAS);
		if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TXT_ORGALIAS).exists()) {
			setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TXT_ORGALIAS,
					clientE2ETO.getSecondAliasLastName(),
					MessageUtility.SECONDORGALIAS);
		} else {
			Verify.verifyTrue(false, MessageUtility.SECONDORGALIAS_NOTFOUND);
		}
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE, 10);
		click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
				MessageUtility.BUTTON_SAVE);

		if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE).exists()) {
			waitForPageLoad(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE, 10);

			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
					MessageUtility.BUTTON_CONTINUE);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_CONTINUE_NOTFOUND);
		}

	}
/**Verify the Added Alias in the Customer info*/
	
	public void verifyAddedAlias(String alias) throws ScriptException {

		Link ADDED_ALIAS = new Link("text=" + alias.toUpperCase());
		waitForPageLoad(ADDED_ALIAS, 10);
		if (ADDED_ALIAS.exists()) {
			Verify.verifyTrue(true, MessageUtility.ALIAS_ADDED);
		} else {
			Verify.verifyTrue(false, MessageUtility.ALIAS_NOTADDED);
		}
	}
/**Update the alias name in the Custoemr Info section*/
	public void selectNameVersionAndUpdateInternationChars() {
		try {
			String updateName = clientE2ETO.getSecondAliasFirstName() + " "
					+ clientE2ETO.getSecondAliasLastName();
			Link LINK_UPDATE = new Link("text=" + updateName.toUpperCase());
			waitForPageLoad(LINK_UPDATE, 10);
			if (LINK_UPDATE.exists()) {
				click(LINK_UPDATE, MessageUtility.LINK_UPDATENAME);
				setIFrame();
				if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME)
						.exists()) {
					setTextInTextbox(
							Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
							clientE2ETO.getUpdateLastName(),
							clientE2ETO.getUpdateLastName()
									+ MessageUtility.LASTNAME_INTLCHAR);
				}
				click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
						MessageUtility.BUTTON_SAVE);
				if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE)
						.exists()) {
					click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
							MessageUtility.BUTTON_CONTINUE);
				}
			} else {
				Verify.verifyTrue(false, updateName
						+ MessageUtility.LINK_UPDATENAME_NOTFOUND);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Remove alias from the Customer Info*/
	public void selectNameVersionAndRemove() {
		try {
			String aliasToBeRemoved = clientE2ETO.getAliasFirstName() + " "+ clientE2ETO.getAliasLastName();
			if (isCustomerInfoPageExists()) {
				count = 1;
				while (true) {
					boolean flag = getWebDriverInstance().findElement(By.xpath("//div[@id='gridNames']/div/div/div/div/div/div["+count+"]/table/tbody/tr[1]/td[1]")).isDisplayed();
					if (flag) {
						String alias = getWebDriverInstance().findElement(By.xpath("//div[@id='gridNames']/div/div/div/div/div/div["+count+"]/table/tbody/tr[1]/td[1]")).getText();
						if (alias.contains(aliasToBeRemoved.toUpperCase())) {
							WebElement element = getWebDriverInstance().findElement(By.xpath("//div[@id='gridNames']/div/div/div/div/div/div["+count+"]/table/tbody/tr[1]/td[3]/a"));
							if (element.isDisplayed()) {
								element.click();
								if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE
										.exists()) {
									Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE
											.click();
									if (!isErrorPage("Remove Alias"))
										Verify.verifyTrue(true,
												MessageUtility.REMOVEDALIAS
														+ aliasToBeRemoved);
								}
							}
							break;
						}
						count++;

					} else {
						break;
					}
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	
	public void selectNameVersionAndRemove_ORG() {
		try {
			String aliasToBeRemoved = clientE2ETO.getAliasLastName();
			if (isCustomerInfoPageExists()) {
				count = 1;
				while (true) {
					boolean flag = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div[1]/div[1]/div[1]/div["+count+"]/table/tbody/tr[1]/td[1]")).isDisplayed();
					if (flag) {
						String alias = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div[1]/div[1]/div[1]/div["+count+"]/table/tbody/tr[1]/td[1]")).getText();
						if (alias.contains(aliasToBeRemoved.toUpperCase())) {
							WebElement element = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div[1]/div[1]/div[1]/div["+count+"]/table/tbody/tr[1]/td[3]/a"));
							if (element.isDisplayed()) {
								element.click();
								waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE, 10);
								if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE
										.exists()) {
									Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE
											.click();
									if (!isErrorPage("Remove Alias"))
										Verify.verifyTrue(true,
												MessageUtility.REMOVEDALIAS
														+ aliasToBeRemoved);
								}
							}
							break;
						}
						count++;

					} else {
						break;
					}
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**Remove alias from the Customer Info after updating of Alias in Customer info*/
	public void selectUpdatedNameVersionAndRemove() {
		try {
			String aliasToBeRemoved = clientE2ETO.getAliasFirstName() + " "
					+ clientE2ETO.getUpdateLastName();
			if (isCustomerInfoPageExists()) {
				count = 1;
				
				while (true) {
					WebElement name = getWebDriverInstance()
							.findElement(By.cssSelector("div#gridNames div.dojoxGridMasterView div.dojoxGridScrollbox > div.dojoxGridContent"
									+ " > div"
									+ " > div:nth-child("
									+ count
									+ ")"));
					if (name.isDisplayed()) {
						String alias = name.getText();
						if (alias.contains(aliasToBeRemoved.toUpperCase())) {
							WebElement namesAcc = getWebDriverInstance()
									.findElement(By.xpath("//div[@id='namesAcc']"
											+ "/div[@class='custInfoGridContainer']"
											+ "/div[2]//div[@class='dojoxGridScrollbox']"
											+ "/div[@class='dojoxGridContent']/div[1]/div["
											+ count
											+ "]/table[1]/tbody[1]/tr[1]/td[3]/a"));
							
							if(namesAcc.isDisplayed()) {
							
								namesAcc.click();

								if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE
										.exists()) {
									Update_IND_CustomerInfo_PageObjects.WidgetInfos.REMOVE_CONTINUE
											.click();
									if (!isErrorPage("Remove Alias"))
										Verify.verifyTrue(true,
												MessageUtility.REMOVEDALIAS
														+ aliasToBeRemoved);
								}
							}
							break;
						}
						count++;

					} else {
						break;
					}
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**Update Alias name for organization through Customer info page*/
	public void selectNameVersionAndUpdateOrgInternationChars()
			throws ScriptException {
		String updateName = clientE2ETO.getSecondAliasLastName();
		Link LINK_UPDATE = new Link("text=" + updateName.toUpperCase());
		if (LINK_UPDATE.exists(10)) {
			click(LINK_UPDATE, MessageUtility.LINK_UPDATENAME);
			setIFrame();
			if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TXT_ORGALIAS).exists()) {

				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TXT_ORGALIAS,
						clientE2ETO.getOrganizationName(),
						clientE2ETO.getOrganizationName()
								+ MessageUtility.ORGANIZATIONNAME_INTLCHARS);

			}

			clickSaveButtonAddAlias();
		}
	}
/**Click on Save button in Add alias page*/
	public void clickSaveButtonAddAlias() {
		try {
			waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE, 10);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.exists()) {
				click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
						MessageUtility.BUTTON_SAVE);
				waitForPageLoad(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE, 5);
				if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE
						.exists())
					click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
							MessageUtility.BUTTON_CONTINUE);
			}
			
		} catch (Exception exception) {

		}
	}
/**Enter the Email Address through Customer info*/
	public void accessAddEmailPage() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMAILADDRESS1.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_EMAILADDRESS1,
					clientE2ETO.getEmail(), clientE2ETO.getEmail()
							+ MessageUtility.EMAIL);
		}
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE.exists()) {
			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
					MessageUtility.BUTTON_SAVE);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_SAVE_NOTFOUND);
		}

	}

/**Verify the Added Address in Customer info*/
	public void verifyAddedAddress(String address) throws ScriptException {

		if (address != null) {
			Link ADDED_ADDRESS = new Link("text=" + address.toUpperCase());
			waitForPageLoad(ADDED_ADDRESS, 10);
			if (ADDED_ADDRESS.exists()) {
				Verify.verifyTrue(true, MessageUtility.ADDRESS_ADDED);
			} else {
				Verify.verifyTrue(false, MessageUtility.ADDRESS_NOTADDED);
			}
		}
	}

/**Update the Home Phone number*/
	public void updateHomePhoneNumber() throws ScriptException {
		Link selectPhone = new Link(
				"title=Open the Update Phone Number page|text="
						+ clientE2ETO.getHomePhoneNumber() + "");
		if (selectPhone.exists()) {
			selectPhone.click();
			setIFrame();
			Verify.verifyTrue(true,clientE2ETO.getHomePhoneNumber()
					+ MessageUtility.HOMEPHONENUMBER_UPDATE);
		} else
			Verify.verifyTrue(false, MessageUtility.PHONENUMBER_NOTADDED);

	}
/**Click on Death Note Received in Update Personal Info*/
	public void selectDeathNoteReceived() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_DEATHNOTERECEIVED
				.exists()) {
			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.CHECKBOX_DEATHNOTERECEIVED,
					MessageUtility.DEATHNOTE);
		} else {
			Verify.verifyTrue(false, MessageUtility.DEATHNOTE_NOTFOUND);
		}
	}
/**Verify the US SSN is displayed in the Customer Information page*/
	public void verifySSNCustomerInfoPage_CRC() throws ScriptException {

		setCRCDefaultFrame();
		String USSSN_TEXT = null;
		if (getWebDriverInstance().findElement(By.xpath("dom=document.getElementsByTagName(\"label\")[14]")).isDisplayed()) {
			USSSN_TEXT = getWebDriverInstance().findElement(By.xpath("dom=document.getElementsByTagName(\"label\")[14]")).getText();
		}
		if (USSSN_TEXT != null && USSSN_TEXT.contains("US SSN:")) {
			Verify.verifyTrue(true,
					MessageUtility.USSSN_CUSTINFO_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.USSSN_CUSTINFO_NOTDISPLAYED);
		}

	}
	

	public void verifySSNCustomerInfoPage() throws ScriptException {

			WebElement USSSN_TEXT = getWebDriverInstance().findElement(By.xpath("//div[@class='infoSectionContainer disInBlock']/div[8]/div/label"));
			String text = USSSN_TEXT.getText();
			if(text.equals("US SSN:")){
				Verify.verifyTrue(true,
						MessageUtility.USSSN_CUSTINFO_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.USSSN_CUSTINFO_NOTDISPLAYED);
			}

		}
	
/**Select Driver License location in CRC*/
	public void selectDrLicenceLocationQB() throws ScriptException {
		try {
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_DRIVERSLICENSELOCATIONQB
					.exists()) {
				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_DRIVERSLICENSELOCATIONQB,
						clientE2ETO.getLicensedStateOrProv(),
						"selectDrLicenceLocation");
				Verify.verifyTrue(true, MessageUtility.DRIVERLICENCELOCATION);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**
 * Select Martial Status in Update Personal info page
 */
	public void selectMaritalStatus() {
		try {
			if (clientE2ETO.getMaritalStatus() != null) {
				selectFromListbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.LIST_MARITALSTATUS,
						clientE2ETO.getMaritalStatus(),
						"selectMaritalStatus : "
								+ clientE2ETO.getMaritalStatus());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.MARRITALSTATUS_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}
/**Enter Birth date,Gender,Martial and SSN In Personal Info*/
	public void enterBirthGenderMaritalSSNInPersonalInfo()
			throws ScriptException {
		clickUpdatePersonalInfo();
		if (isPersonalInfolaunched()) {
			enterBirthDate();
			selectGenderMale();
			selectMaritalStatus();
			enterSSN();
			clickSaveButton();
			isErrorPage("Update Personal Information");
			setTopFramewithDefaultContent();
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.UPDATEPERSONALINFOPAGE_NOTLAUNCHED);
		}
	}
/**Update the Personal information in Customer info*/
	public void updatePersonalInfo() throws ScriptException {
		clickUpdatePersonalInfo();
		if (isPersonalInfolaunched()) {
			enterBirthDate();
			selectGenderMale();
			enterLicenceNumQB();
			selectDrLicenceLocationQB();
			selectMaritalStatus();
			enterSSN();
			enterDeathDate();
			selectDeathNoteReceived();
			clickSave();
			//clickSaveButton();
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.UPDATEPERSONALINFOPAGE_NOTLAUNCHED);
		}
	}
/**Update the Personal Info in Customer info (CRC)*/
	public void updateCRCPersonalInfo() throws ScriptException {
		clickCRCUpdatePersonalInfo();
		if (isPersonalInfolaunched()) {
			enterBirthDate();
			selectGenderMale();
			selectDrLicenceLocationQB();
			selectMaritalStatus();
			enterSSN();
			enterDeathDate();
			selectDeathNoteReceived();
			clickSaveButton();
		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.UPDATEPERSONALINFOPAGE_NOTLAUNCHED);
		}
	}
	
	public void clickCRCUpdatePersonalInfo() throws ScriptException {
		if (Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL.exists()) {
			click(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL,
					MessageUtility.LINK_UPDATEPERSONALINFO);
			setIFrame();
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_UPDATEPERSONALINFO_NOTFOUND);
		}

	}
	
	
/**Enter License Number in Personal info page*/
	public void enterLicenceNumQB() throws ScriptException {
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_DRIVERSLICENSENUMBERQB
				.exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_DRIVERSLICENSENUMBERQB,
					clientE2ETO.getDrivingLicense(),
					MessageUtility.LICENCENUMBER_DISPLAYED);
			Verify.verifyTrue(true, MessageUtility.LICENCENUMBER);
		} else {
			Verify.verifyTrue(false, MessageUtility.LICENCENUMBER_NOTFOUND);
		}
	}
/**Update the Phone Number*/
	public void updatePhoneNumber() throws ScriptException {
		Link selectPhone = new Link(
				"title=Open the Update Phone Number page|text="
						+ clientE2ETO.getCellPhoneNumber().toUpperCase() + "");
		if (selectPhone.exists()) {
			selectPhone.click();
			Verify.verifyTrue(true,clientE2ETO.getCellPhoneNumber()
					+ MessageUtility.MOBILEPHONENUMBER_UPDATE);
		} else
			Verify.verifyTrue(false, MessageUtility.PHONENUMBER_NOTADDED);
	}
/**Launch and Validate Customer Profile print in Customer Info page*/
	public void launchAndValidateCustomerProfilePrint() {
		try {
			setTopFramewithDefaultContent();
			if (isCustomerInfoPageExists()) {
				clickCustomerProfilePrintUpdateCustinfo();
				validateCustomerProfilePrint(2);
				setWindow(EndToEndConstants.CUSTOMER_INFORMATION, 3, 1);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**validate Permission to text for Home and Additional phone*/
	public void validatePermissionToTextForHomeAndAdditionalPhone() {
		try {
			if (isCustomerInfoPageExists()) {
				clickAddPhone();
				waitForPageLoad(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE, 15);
				if (AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE.exists()) {
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							"Home Phone", MessageUtility.WORKPHONE_SELECTED);
					validatePermissionToTextHidden();
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							"Additional Personal Phone",
							MessageUtility.ADDITIONALPERSONALPHONE_SELECTED);
					validatePermissionToTextHidden();
					RelationshipsScreenTestObjects.WidgetInfos.BUTTON_CANCEL.click();
					setTopFramewithDefaultContent();
				} else {
					isErrorPage("Validate Permission to Text");
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Update Personal info in Customer info page*/
	public void updatePersonalInformation() {
		try {
			if (isCustomerInfoPageExists()) {
				clickUpdatePersonalInfo();
				waitForPageLoad(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_BIRTHDATE, 10);
				if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_BIRTHDATE.exists()) {
					verifySSNAndSIN();
					enterBirthDate();
					selectGenderMale();
					enterLicenceNumber();
					selectMaritalStatus();
					enterSSN();
					selectLivingArrangements();
					selectCitizenship();
					enterFirstYrWithSF();
					enterCustomerCategory();
					selectHouseHoldIncome();
					selectAssignedStaff();
					enterPersonalInfoAsOfDate();
					selectPrimayMarketingContact();
					clickSaveButton();
					isErrorPage("Update Personal Information");
					setTopFramewithDefaultContent();
				} else {
					isErrorPage("Update Personal Information");
					Verify.verifyTrue(false,
							MessageUtility.UPDATEPERSONALINFOPAGE_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

/**Add,Update and Delete Address In Customer Info*/
	public void addUpdateDelAdressAndAliasInCustInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				addUpdateDeleteAlias();
				addUpdateDeleteAddress();
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Validate Sent Text In Customer Info*/
	public void validateSentTextInCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				if (CustomerInfoObjects.WidgetInfos.PHONEIMAGE.exists()) {
					clickPhoneImage();
					if (CustomerInfoObjects.WidgetInfos.LINEOFBUSINESS.exists()) {
						selectLineOfBusiness();
						selectTemplate(clientE2ETO.getTemplates());
						verifyMessageOnSelectedTemplatesValues_E2E(clientE2ETO
								.getTemplates());
						clickSendButtonEToE();
						setTopFramewithDefaultContent();
					} else {
						Verify.verifyTrue(false,
								MessageUtility.SENDTEXTPAGE_NOTLAUNCHED);
						if (CustomerInfoObjects.WidgetInfos.CANCEL.exists()) {
							click(CustomerInfoObjects.WidgetInfos.CANCEL,
									MessageUtility.BUTTON_CANCEL);
						}
					}
				} else
					Verify.verifyTrue(false,
							MessageUtility.MOBILEPHONEICON);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**Add,Update,Delete alias from the Customer info*/
	public void addUpdateDeleteAlias() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS, 10);
				if (Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS.exists()) {
					clickAddAlias();
					accessAddAliasPage();
					clickSaveButtonAddAlias();
					isErrorPage("Add Alias");
					String alias = clientE2ETO.getAliasFirstName() + " "
							+ clientE2ETO.getAliasLastName();
					setTopFramewithDefaultContent();
					verifyAddedAlias(alias);
					selectNameVersionAndUpdate(clientE2ETO.getUpdateLastName(),
							alias);
					isErrorPage("Update Alias");
					setTopFramewithDefaultContent();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.LINK_ADDALIAS_NOTDISPLAYED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	
	
	
	public void addUpdateAliasCRC() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS, 10);
				if (Update_Misc_Objects.WidgetInfos.LINK_ADDALIAS.exists()) {
					clickAddAlias();
					accessAddAliasPage();
					clickSaveButtonAddAlias();
					isErrorPage("Add Alias");
					String alias = clientE2ETO.getAliasFirstName() + " "
							+ clientE2ETO.getAliasLastName();
					setCRCDefaultFrame();
					verifyAddedAliasCRC(alias);
					selectNameVersionAndUpdate(clientE2ETO.getUpdateLastName(), alias);
					isErrorPage("Update Alias");
					setCRCDefaultFrame();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.LINK_ADDALIAS_NOTDISPLAYED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	public void verifyAddedAliasCRC(String alias) throws ScriptException {

		setCRCDefaultFrame();

		Link ADDED_ALIAS = new Link("text=" + alias.toUpperCase());

		waitForPageLoad(ADDED_ALIAS, 10);

		if (ADDED_ALIAS.exists()) {

		Verify.verifyTrue(true, MessageUtility.ALIAS_ADDED);

		} else {

		Verify.verifyTrue(false, MessageUtility.ALIAS_NOTADDED);

		}

		}



 /**Update Phone Number and Click on Save button*/
	public void updatePhoneUpdatePhone() {
		try {
			if (isCustomerInfoPageExists()) {
				selectPhoneNumberTOUpdate();
				updateEnterNumber();
				clickSaveButton();
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Click on text icon in the Customer info page*/
	public void clickPhoneImage() throws ScriptException {
		try {
			if (CustomerInfoObjects.WidgetInfos.PHONEIMAGE.exists()) {
				CustomerInfoObjects.WidgetInfos.PHONEIMAGE.click();
				setIFrame();
				Verify.verifyTrue(true, MessageUtility.PHONEIMAGE_CLICKED);
			} else
				Verify.verifyTrue(false, MessageUtility.PHONEIMAGE_NOTFOUND);
		} catch (ScriptException e) {
			Verify.verifyTrue(false, MessageUtility.PHONEIMAGE_NOTFOUND);
		}
	}
/**Select the LOB to send message*/
	public void selectLineOfBusiness() throws ScriptException {
		if (CustomerInfoObjects.WidgetInfos.LINEOFBUSINESS.exists()
				&& clientE2ETO.getLineOfBusiness() != null) {
			try {
				selectFromListbox(CustomerInfoObjects.WidgetInfos.LINEOFBUSINESS,
						clientE2ETO.getLineOfBusiness(), "Line Of Business "
								+ MessageUtility.LOB_AUTO);
			} catch (Exception e) {
				Verify.verifyTrue(false, MessageUtility.LOB_NOTFOUND);
			}
		} else
			Verify.verifyTrue(false, MessageUtility.LOB_NOTFOUND);
	}
/**
 * Select Template
 * @param template template to be selected to send message
 */
	public void selectTemplate(String template) {
		try {
			getWebDriverInstance().findElement(By.xpath("//div[@id='pageContent']/form/fieldset/label/span/span/span/span[3]")).click();
			waitForTime(3);
			Link n = new Link("id=dijit_MenuItem_2_text");
			n.click();
			Verify.verifyTrue(true, MessageUtility.TEMPLATE);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}
/**
 * Click on Send button to send message
 */
	public void clickSendButtonEToE() {
		try {
			if (CustomerInfoObjects.WidgetInfos.SEND.exists()) {
				CustomerInfoObjects.WidgetInfos.SEND.click();
				Verify.verifyTrue(true, MessageUtility.BUTTON_SEND);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Enter the First name and Last name in the Add Alias page*/
	public void accessAddAliasPage() throws ScriptException {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME, 15);
		if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME).exists()) {
			setTextInTextbox(
					Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_FIRSTNAME,
					clientE2ETO.getAliasFirstName(),
					clientE2ETO.getAliasFirstName()
							+ MessageUtility.FIRSTNAME_VALUE);
		}
		if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME).exists()) {
			setTextInTextbox(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
					clientE2ETO.getAliasLastName(),
					clientE2ETO.getAliasLastName()
					+ MessageUtility.LASTNAME_VALUE);
		}
	}
/**verify Message On Selected Templates Values in Send Message Pop up*/
	public void verifyMessageOnSelectedTemplatesValues_E2E(
			String selectedTemplate) throws ScriptException {
		try {
			if ("Appointment Reminders".equalsIgnoreCase(selectedTemplate)) {
				if ("Reminder: State Farm Appt @ mm-dd at hh:mm."
						.equalsIgnoreCase(CustomerInfoObjects.WidgetInfos.MESSAGE.getText())) {
					Verify.verifyTrue(
							true,
							MessageUtility.STATEFARMAPPT_DISPLAYED);
				} else {
					Verify.verifyTrue(
							false,
							MessageUtility.STATEFARMAPPT_NOTDISPLAYED);
				}
			} else if ("Late Pay Notifications"
					.equalsIgnoreCase(selectedTemplate)) {
				if ("Reminder: State Farm premium was due on mm-dd"
						.equalsIgnoreCase(CustomerInfoObjects.WidgetInfos.MESSAGE.getText())) {
					Verify.verifyTrue(
							true,
							MessageUtility.STATEFARMPREMIUM_DISPLAYED);
				} else {
					Verify.verifyTrue(
							false,
							MessageUtility.STATEFARMPREMIUM_NOTDISPLAYED);
				}

			} else if ("Towing Reimbursement Ready"
					.equalsIgnoreCase(selectedTemplate)) {
				if ("Claim chk ready for pickup - stop by between HH - HH"
						.equalsIgnoreCase(CustomerInfoObjects.WidgetInfos.MESSAGE.getText())) {
					Verify.verifyTrue(
							true,
							MessageUtility.TOWINGCLAIMCHECK_DISPLAYED);
				} else {
					Verify.verifyTrue(
							false,
							MessageUtility.TOWINGCLAIMCHECK_NOTDISPLAYED);
				}

			} else if ("Happy Birthday & Congrats"
					.equalsIgnoreCase(selectedTemplate)) {
				if ("Happy birthday from your State Farm agent!"
						.equalsIgnoreCase(CustomerInfoObjects.WidgetInfos.MESSAGE.getText())) {
					Verify.verifyTrue(
							true,
							MessageUtility.HAPPYBIRTHDAY_DISPLAYED);
				} else {
					Verify.verifyTrue(
							false,
							MessageUtility.HAPPYBIRTHDAY_NOTDISPLAYED);
				}

			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
/**Click on Alias name link and update the alias*/
	public void selectNameVersionAndUpdate(String lastName, String alias)
	throws ScriptException {
Link LINK_UPDATE = new Link("text=" + alias.toUpperCase());
waitForPageLoad(LINK_UPDATE, 10);
if (LINK_UPDATE.exists()) {
	click(LINK_UPDATE, MessageUtility.LINK_UPDATENAME);
	waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
			5);
	setIFrame();
	if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME).exists()) {
		setTextInTextbox(
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_LASTNAME,
				lastName, MessageUtility.LASTNAME_UPDATED);
	}
	click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_SAVE,
			MessageUtility.BUTTON_SAVE);
	waitForPageLoad(
			Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE, 5);
	if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE).exists()) {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE);
		click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CONTINUE,
				MessageUtility.BUTTON_CONTINUE);
	}
} else {
	Verify.verifyTrue(false,
			MessageUtility.LINK_ADDALIAS_NOTDISPLAYED);
}
}
/**Update the Work Phone in Customer info */
	public void updateWorkPhoneCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDPHONE, 10);
				updateWorkPhoneNumber();
				setIFrame();
				enterUpdateWorkPhoneNumber();
				clickSaveButton();
				isErrorPage("update Phone");
				setCRCDefaultFrame();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**Enter the Work phone number to update*/
	public void updateWorkPhoneNumber() throws ScriptException {
		if (isCustomerInfoPageExists()) {
			Link selectPhone = new Link(
					"title=Open the Update Phone Number page|text="
							+ clientE2ETO.getWorkPhoneNumber());
			if (selectPhone.exists()) {
				selectPhone.click();
				Verify.verifyTrue(true,clientE2ETO.getWorkPhoneNumber()
						+ MessageUtility.WORKPHONENUMBER_UPDATE);
			} else
				Verify.verifyTrue(false, MessageUtility.PHONENUMBER_NOTADDED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
		}
	}
/**Enter the Phone number to update*/
	public void enterUpdateWorkPhoneNumber() throws ScriptException {
		if (clientE2ETO.getWorkPhoneNumber() != null) {
			if ((Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE).exists()) {
				setTextInTextbox(
						Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_HOMEPHONE,
						clientE2ETO.getUpdatePhoneNumber(),
						clientE2ETO.getUpdatePhoneNumber()
								+ MessageUtility.WORKPHONENUMBER);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.WORKPHONENUMBER_NOTFOUND);

			}
		}
	}

	/** Add Mobile Phone Number with Permission Text Did Not Ask */
	public void addMobilePhoneWithDidNotAskPermissionCustomerInfo() {
		try {
			if (isCustomerInfoPageExists()) {
				waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_ADDPHONE, 10);
				clickAddPhone();
				if (isSelectListItemPresent(
						AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
						"Mobile Phone")) {
					selectFromListbox(AddIndividualPageObjects.WidgetInfos.LIST_PHONE_TYPE,
							"Mobile Phone",
							MessageUtility.MOBILEPHONE_SELECTED);
					enterNumber();
					permissionToText();
					clickSaveButton();
					isErrorPage("Add Phone");
				} else {
					Verify.verifyTrue(false,
							MessageUtility.MOBILEPHONE_NOTSELECTED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/** CRC Personal Info */
	public void updateCRCPersonalInfoCustomerInfo() {
		try {
			waitForPageLoad(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL, 15);
			if (isCustomerInfoPageExists()) {
				updateCRCPersonalInfo();
				verifySSNCustomerInfoPage();
				isErrorPage("Update Personal Information");
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.CUSTINFOPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	
	public void updatePersonalInformation_Household() {
		try {
			if (isHHPageLaunched()) {
				String xpath = "//div[@id='gridHHMembers']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div/table/" +
						"tbody/tr/td[2]/span/span/span";
				getWebDriverInstance().findElement(By.xpath(xpath)).click();
				WebElement itemName = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
				if(itemName.getText().contains("Update Personal Information"))
				{
					getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table/tbody/tr[1]/td[2]")).click();
					setWindow("Update Personal Information",5,2);
					Verify.verifyTrue(true, MessageUtility.UPDATEPERSONALINFO_CLICKED);
				}
				else
					Verify.verifyTrue(false, MessageUtility.UPDATEPERSONALINFO_NOTDISPLAYED);
				}
				waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_BIRTHDATE, 10);
				if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_BIRTHDATE.exists()) {
					verifySSNAndSIN();
					enterBirthDate();
					selectGenderMale();
					enterLicenceNumber();
					selectMaritalStatus();
					enterSSN();
					selectLivingArrangements();
					selectCitizenship();
					enterFirstYrWithSF();
					enterCustomerCategory();
					selectHouseHoldIncome();
					selectAssignedStaff();
					enterPersonalInfoAsOfDate();
					selectPrimayMarketingContact();
					clickSaveButton();
					isErrorPage("Update Personal Information");
					setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION,5,2);
					setTopFramewithDefaultContent();
				} else {
					isErrorPage("Update Personal Information");
					Verify.verifyTrue(false,
							MessageUtility.UPDATEPERSONALINFOPAGE_NOTLAUNCHED);
				}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
}
