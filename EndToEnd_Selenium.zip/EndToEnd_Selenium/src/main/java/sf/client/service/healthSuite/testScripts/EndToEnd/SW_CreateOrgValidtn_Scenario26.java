package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class SW_CreateOrgValidtn_Scenario26 extends BaseScript {
	String query = "select * from SW_CreateOrgValidtn_Scenario26";
	public void executeScript(){		
		
		/**
		 * click on Version URL
		 */
		createCustTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		createCustTasks.setCustomerSearchTopFrame();
	
		/**Validating the links in the customer search page*/
		scenarioTasks.validateLinksDisplayedInCustSearchPage();
		/**Enterprise view operation*/
		/* No proper client id to test the functionality
		connectCustTasks.launchAndValidateEnterPriseView();*/
		/**Click Create Organization Customer*/ 
		createCustTasks.clickCreateOrganizationCustomer();
		/**Create Organization Customer*/
		createCustTasks.createOrgCustomerWithPhoneDataAndEmail();
		/**Close HH page*/
		productTasks.closeHHPage_SW();
		scenarioTasks.setCustomerSearchTopFrame();
		/**customer search*/
		productTasks.launchHHPageFromCustomerSearchPage();
	   /* *//**Add New Organization*//*
	    scenarioTasks.addOrganizationinHouseholdPage();*/
		/**Adding policy*/
	    productTasks.createAutoPolicesWithOthers();
 		/**Close HH page*/
	    productTasks.refreshHHPage_SW();
 		/**Verify Created Auto policy*/
	    productTasks.verifyCreatedAutoPoliciy();
 		/**Add Comments*/
		scenarioTasks.validateCommentsSectionHHPage();
	 	/**Validate Insurance policies*/  	
 		scenarioTasks.clickInsurancePolicies();
        scenarioTasks.displayInsurancePolicies();
        /**Validate Bank policies*/ 
        scenarioTasks.clickBankPolicies();
        scenarioTasks.displayBankPolicies();
        /**Validate Mutual Funds policies*/  
        scenarioTasks.clickMutualFundsPolicies();
        scenarioTasks.displayMutualFundPolicies();
        /**Validate SFPP policies*/  
        scenarioTasks.clickSfppPolicies();
        scenarioTasks.displaySfppPolicies();
        /**Validate Product Inactive page*/  	
        scenarioTasks.clickInactivePolicies();
	    scenarioTasks.printInactivePolicies();
	    
	    /**Verify isInternetEnable Column*/
        /* covered in SW_SrchIndCust_Scenario25 scenario
	    scenarioTasks.verifyInternetEnabledColumnWithYAndN();*/
		/**Navigating to Customer Information Page*//*
 		createCustTasks.launchCustomerInfoPageFromHHPage();*/
 		/**CASL CANADA Scenarios Tc1-Tc4*/
	   //productTasks.EmessageOnlySendWithCASLFieldY();
	    /**CASL CANADA Scenarios Tc5-Tc8*/
		//productTasks.doNotsendEmessageWithCASLFieldY();
		/**CASL US Scenarios Tc9-Tc10*/
		//productTasks.verifyEmessageFieldWithCASLFieldN();
		/**CASL US Scenarios Tc11-Tc12*/
		//productTasks.verifyEmessageFieldWithCASLFieldY();
		/**CASL US Scenarios Tc13-Tc14*/
		//productTasks.changingFromOnlyEmessageToUnsubscribe();
 		/**Add alias with Regular Characters*//*
 		updateTasks.addFirstAlias();
        *//**Update  the Added Alias with International characters*//*
        scenarioTasks.selectNameVersionAndUpdate();
        *//**Click on the Change Address hyper link next to the Add address link in the Address section and Add an Address and click SAVE*//*												
        scenarioTasks.launchAndAddAddressInCOA();
        *//**Add Email*//* 
		updateTasks.addEmailCustomerInfo();
		*//**Remove all Phones From Customer Info Page to add*//* 
		updateTasks.removeAllPhonesFromCustomerInfo();
		*//**Enter Mobile Number*//*
		updateTasks.addMobilePhoneCustomerInfo();
		*//**Validate Permission to Text is not displayed for Home Phone Additional Type*//* 
		updateTasks.validatePermissionToTextForHomeAndAdditionalPhone();
		*//**work phone*//*
		updateTasks.addWokPhoneCustomerInfo();		
		*//**Update Personal Information All Fields*//*
		updateTasks.updatePersonalInformation();
		*//**Validate that the new Phone changes/updates are displayed in the Active Customer Bar*//*
		scenarioTasks.validateActiveCustomerBar();
		updateTasks.validatePhoneNumbersDisplayedActiveCustomerBar();
	    *//**Navigate back to HH Page*//*
		scenarioTasks.clickHHPageCustomer();
		scenarioTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();*/
		/**validate And Launch Relationship Page*/
		hhNavigationTasks.validateAndLaunchRelationshipPage();
		/**Verify the Relationship Page Exists and Add Individual in Member Inside and Member Outside the Household*/
		hhRelationshipTasks.verifyAndAddHouseholdAndNonHouseholdIndInRelationshipPage();
		/**Launch Auto Policies from the Household Info section*//*
		scenarioTasks.launchAutoAppfromHHPage();
		scenarioTasks.handleCimsVersion();*/
		/**Launch Fire Policies from the Household Info section*/
		scenarioTasks.launchFireAppfromHHPage();
		scenarioTasks.handleCimsVersion();
		/**Launch Mutual Fund Policies from the Household Info section*/
		scenarioTasks.launchMutualAppfromHHPage();
		scenarioTasks.handleCimsVersion();
		/**Launch SFPP Policies from the Household Info section */
		scenarioTasks.launchSFPPAppfromHHPage();	
		scenarioTasks.handleCimsVersion();
		 
		/**Selecting Update Personal Information Option from the Action Drop Down Menu*/
		scenarioTasks.clickActionsUpdatePersonalInformation();
		
		//do manually
		/**Search and Select Two Customers and Click on Next link.*//* 
		combineTasks.verifySearchandSelectTwoCustomersPageABS();
		*//**Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.*//*
		combineTasks.verifyInfoandClickCombine();
		*//**Search and Select Customer from Search and Select one Customer Page.*//* 
		separateCustTasks.verifySearchandSelectOneCustomerPageABS();
		*//**Separating a Customer.*//*
		separateCustTasks.separateCustomer();			
		*//**Move members to a new household*//*
		hhNavigationTasks.verifyHHMovesMoveMembersToNewHousehold();*/
	}
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataSWCreateOrgValidtnScenario26(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				productTasks=new ProductTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				hhRelationshipTasks =new HHRelationshipTasks(clientE2ETO);
				launcher.launchUser(this.getClass().getSimpleName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}		
	}
}