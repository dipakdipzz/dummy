package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class OOB_SWPortal_EnterpriseView50 extends BaseScript {
	
	String query = "select * from OOB_EnterpriseView_NonAgent50";
	
	
	
public void executeScript() throws Exception{
	
	/**
	 * Validate Customer Search Page
	 */
    createCustTasks.launchCustomerSeachPage();
    
    /**
     * Enter Agent Alias in Customer Search Page
     */
    scenarioTasks.enterAgentAliasinCustomerSearchPage();
    
	oobIndividualTasks.clickOutOfBookAndIndividualRadioButton();
	oobIndividualTasks.isOOBIndividualPageExists();
	oobIndividualTasks.enterNameSectionInOOBIndividualPage();
	oobIndividualTasks.enterVerificationDataOOBIndividualPage();
	oobIndividualTasks.enterMovingToDataInOOBIndividualPage();
	oobIndividualTasks.clickSearch();
    ssnSINTasks.validateAccountandPoliciesTwistyNotPresent();
	   
}
public void scriptMain()  {
	
	try {
		transferObject=setTestDataObject(transferObject);
		transferObject.setDbQuery(query);
		
		dbresultSet =databaseUtil.getCoreData(transferObject);
		
		while(dbresultSet.next()){
			clientE2ETO = databaseUtil.loadTestNonAgentOOBIndScenario50(dbresultSet,clientE2ETO);
			
			createCustTasks = new CreateCustomersTasks(clientE2ETO);
			ssnSINTasks = new SSNSINTasks(clientE2ETO);
			scenarioTasks = new ScenarioTasks(clientE2ETO);
			oobIndividualTasks = new OOBIndividualTasks(clientE2ETO);
			launcher = new LaunchApplication(getWATConfig());
			launcher.launchUser(scriptName());
			
			scenarioTasks.createResultsFile(resultsFileName(),scriptName());
			
			executeScript();
			
		}
		
		
	} 
		catch (Exception e) {
		e.printStackTrace();
	}
}
}
