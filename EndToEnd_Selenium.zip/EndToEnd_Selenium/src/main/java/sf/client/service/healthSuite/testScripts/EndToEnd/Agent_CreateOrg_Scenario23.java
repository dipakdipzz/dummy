package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class Agent_CreateOrg_Scenario23 extends BaseScript{
	int count = 0;
	String query = "select * from Agent_CreateOrg_Scenario23";
	public void executeScript(){

		/**
		 * Validate Customer Search Page
		 */
		createCustTasks.launchCustomerSeachPage();
		/**
		 * validate Create Ind & Create Org link Exists in Customer Search page.
		 */
		scenarioTasks.verifyCreateIndOrg();
		/**
		 * Create Organization Customer With International Characters.
		 */
		createCustTasks.clickCreateOrganization();
		createCustTasks.createOrgCustomerWithPhoneData();
		
		/**
		 * Navigate back to Customer Search and search for existing Customer
		 */
		createCustTasks.navigateToSearchPageFromHH();
		
		/**
		 * Search for a Individual Customer and navigate to HH page - Enterprise Customer
		 */
		createCustTasks.launchPortalCustomerSearchPage();
		createCustTasks.launchPortalHHPage();
			
		/**
		 * Validate that all the Policies belonging to this Enterprise Customer (associated in all the regions - Enterprise wide) is displayed in the Account Policies section onn HH page 
		 */
		scenarioTasks.clickInsurancePolicies();
		scenarioTasks.displayInsurancePolicies();
		
		/**
		 * Navigate to the Customer Info page by  selecting the menu Customer Information option in Customer Menu in Household page
		 *//*
		createCustTasks.launchCustomerInfoPageFromHHPage();
		
		*//**
		 * Add an Alias - Name (Regular Characters). Also Add Preferred Name
		 * Update this Alias - Name with International Characters including � & �
		 *//*
		
		updateTasks.addUpdateDeleteAlias();
		
		*//**
		 *  US Address with International Char   
		 *//*
		updateTasks.addAddressCustomerInfo();

		*//**
		 *  Foreign Address with International Char
		 *//*
		updateTasks.addAndRemoveAddressForeign();

		*//**
		 *  Add Personal Email with International Char
		 *//*
		updateTasks.addEmailCustomerInfo();
		
		*//**
		 * Add Mobile Phone Number
		 *//*
		updateTasks.removeAllPhonesFromCustomerInfo();
		updateTasks.addMobilePhoneCustomerInfo();
		
		*//**
		 * Add Home Phone number with Calling preferences 
		 *//*
		updateTasks.addHomePhoneCustomerInfo(); 
		
		*//**
		 * Add Work Phone number with Calling preferences 
		 *//*
		updateTasks.addWorkPhoneCustomerInfo();
		
		*//**
		 * Validate that the new Phone changes/updates are displayed in the Active Customer Bar //ToDo
		 *//*
		scenarioTasks.validateActiveCustomerBar();
		updateTasks.validatePhoneNumbersDisplayedActiveCustomerBar();
		scenarioTasks.setTopFramewithDefaultContent();
		
		*//**
		 * Update Personal Information  - D.O.B, GENDER, MARTIAL STATUS, SSN
		 *//*
		updateTasks.updatePersonalInfoInCustomerInfo();
		
		*//**
		 * Validate that all the policies associated with this Active Customer is displayed in the Account/Policies section in the Customer Info screen.
		 *//*
		updateTasks.validatePoliciesInfoSection();
		
		*//**
		 * Select Customer bar to navigate to HH page;
		 *//*
		scenarioTasks.clickHHPageCustomer();
		scenarioTasks.setTopFrame();*/
		
		/**
		 * Click on the Inactive Policies tab to display the inactive policies, if any
		 */
		hhNavigationTasks.validateInactivePoliciesTabInHHPage();
				
		/**
		 * Launch Auto Policies from the Household Info section (Select a Customer having all LOB policies)
		 *//*
		hhNavigationTasks.validateAutoPolicyInHHPage();
				
		*//**
		 * Launch Fire Policies from the Household Info section
		 *//*
		scenarioTasks.launchFireAppfromHHPage();
					
		*//**
		 * Launch Health Policies from the Household Info section
		 *//*
		scenarioTasks.launchHealthAppfromHHPage();
					*/
		/**
		 * Click on the 'Add Products with Others' option in the PRODUCT ACTIONS drop down menu and Add policies others
		 */
		hhNavigationTasks.validateAddProductsWithOthersfromHHPage();
		
		/**
		 * Click on the Comments section and add household comments. Include International Characters other than � & �. Type two lines. Save & close.
		 */
		scenarioTasks.validateCommentsSectionfromHHPage();
		
		/**
		 * Click on Add Organization option in the Member Action drop down and add an Organization to the Household
		 *//*
		scenarioTasks.addOrganizationinHouseholdPage();*/
		
		/**
		 * Click on the 'View Customer Information' option in the Action drop down button for a Customer in the Household member section. Navigates to Cust Info page. Navigate back to Household page 
		 */
		scenarioTasks.clickActionsViewCustomerInfoABS();
		
		/**
		 * Validate that the Internet Enabled column value is displayed & hyper linked (N)in the Household members section if a Customer has Birthdate
		 */
		scenarioTasks.verifyInternetEnabledColumnWithN();
		
		/**
		 * Search and Select Two Customers and Click on Next link. 
		 */
		combineTasks.verifyAndSearchandSelectTwoCustomersPage();
		/**
		 * Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.
		 */
		combineTasks.verifyInfoandClickCombine();
		/**
		 * Launch HH Page after the 'Combine Customer'
		 */
		scenarioTasks.clickHHPageCustomer();
		scenarioTasks.setTopFrame();
		/**
		 * Navigate to Household Maintenance screen and perform Household Move transaction.
		 */
		hhNavigationTasks.verifyHHMovesMoveMemberBetweenTwoHouseholds();
	
		
	}

	public void scriptMain() {

		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataAgentCreateOrgScenario23(
						dbresultSet, clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks =new CombineCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				productTasks = new ProductTasks(clientE2ETO);
				scenarioTasks
						.createResultsFile(resultsFileName(), scriptName());

				executeScript();

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
