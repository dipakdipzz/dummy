package sf.client.service.healthSuite.appObjects;



import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.TextField;

public class Update_IND_CustomerInfo_PageObjects {
	
	//public static final String UPDATE_CUSTOMER_INFORMATION_LIST_LIFEEVENT1 =  "id=lifeEvent.lifeEventCode";
	//public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_LIFEEVENT1OTHER =  "id=lifeEvent.lifeEventOther";
	//public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_FEMALE =  "value=Female";
	//public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_SHARE =  "name=person.privacy.preference|.value=Y";
	//public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_DONOTSHARE =  "person.privacy.preference|.value=N";
	//public static final String UPDATE_CUSTOMER_INFORMATION_LINK_PRIVACYEXPLAIN =  "id=privacyExplainLink";
	//public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_OVERSEAS =   "id=address.typeOverseasMilitary";
	//public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MSTREET2=   "id=address.street2";
	//public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MSUBDIVISION =  "id=address.addressUsages[0].subdivision";
	//public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_MCITYFPO =  "id=address.cityFPO";
	//public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_MSTATEAA =   "id=address.stateAA";
	//public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MNOTES =  "id=address.addressUsages[0].note";
	//public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MINCAREOF =  "id=address.addressUsages[0].inCareOf";
	//public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MATTENTION=  "id=address.addressUsages[0].attention";
	//public static final String UPDATE_CUSTOMER_INFORMATION_LINK_DRIVINGDIRECTIONS =  "class=Html.A|text=Get Driving Directions";
	//public static final String UPDATE_CUSTOMER_INFORMATION_BUTTON_GETDIRECTIONS =  "id=getDirections";
	//public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_USCHECKEDDEFAULT =   "id=address.typeUS|CHECKED=true";
	//public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_CANADACHECKEDDEFAULT =   "id=address.typeCanada|CHECKED=true";
	//public static final String UPDATE_CUSTOMER_INFORMATION_SELECT_USSTATEDEFAULT =  "name=address.stateCode|text=Alabama Alaska Arizona Arkansas California Colorado Connecticut Delaware District of Columbia Florida Georgia Hawaii Idaho Illinois Indiana Iowa Kansas Kentucky Louisiana Maine Maryland Massachusetts Michigan Minnesota Mississippi Missouri Montana Nebraska Nevada New Hampshire New Jersey New Mexico New York North Carolina North Dakota Ohio Oklahoma Oregon Pennsylvania Rhode Island South Carolina South Dakota Tennessee Texas Utah Vermont Virginia Washington West Virginia Wisconsin Wyoming";
	//public static final String UPDATE_CUSTOMER_INFORMATION_SELECT_CANADAPROVINCEDEFAULT =  "name=address.provinceCode|text=Alberta British Columbia Manitoba New Brunswick Newfoundland and Labrador Northwest Territories Nova Scotia Nunavut Ontario Prince Edward Island Quebec Saskatchewan Yukon";
	//public static final String UPDATE_CUSTOMER_INFORMATION_LIST_PREFERREDLANGUAGE =  "id=language.preferredLanguageValue";//".id=person.preferredLanguage";
	//public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_HEARINGIMPAIRED =  "id=hearingImpaired";//".id=person.hearingImpaired";
	//public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_CELLEXTENSION =  "id=phone.extension";//".id=person.phones[2].extension";
	//public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_USAGEPERSONAL =  "id=phone.usagePersonal";
	//public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_USAGEBUSINESS =  "id=phone.usageBusiness";
	//public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_EMAILPERSONAL1 =  "id=email.personal";//person.emails[0].personal
	//public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_EMAILBUSINESS1 =  "id=email.business";//person.emails[0].business
	//public static final String UPDATE_CUSTOMER_INFORMATION_LABEL_PRIMARYMARKETCONTEXPLAINLINK =  "id=primaryMarketingContactExplainLinkPopup|text=Primary marketing contact - CAUTION! Use only when marketing systems consistently choose the wrong person in a household for direct mail marketing mailings. The use of this indicator will override the system for non-targeted household marketing mailings. Avoid adding the indicator to multiple people in a household. When setting this indicator to *";
	//public static final String UPDATE_CUSTOMER_INFORMATION_EVENTVALUES = "Additions or improvements to your home,Birth/Adoption of Child,Birth of Grandchild,Buying a Car,Buying a Home,Care of an aging parent,Care of household member with special needs,Change In Marital Status,Donation or large gift of money,Education Planning,Empty Nest,Extended absence from work,Graduation,Job Change,Loss of a Loved One,Major Illness of Loved One,Marriage,Moving,New Driver,Other major purchase or expense,Purchase of investment property,Receipt of a large sum of money,Retirement,Sale of Home,Sale of investment property,Starting a business,Other";
	//public static final String UPDATE_CUSTOMER_INFORMATION_TRASH_ICON =  "id=removeEmail0";
	
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_TITLE =   "id=personName.titleCode"; //AllowedTitles //personName.titleCode
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_FIRSTNAME =   "id=personName.firstName"; //.id:  fName //personName.firstName
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_LASTNAME =   "id=personName.lastName"; //.id:  lName //personName.lastName
	public static final String UPDATE_CUSTOMER_INFORMATION_BUTTON_SAVE  =  "id=save";
	public static final String UPDATE_CUSTOMER_INFORMATION_BUTTON_CLOSE =  "id=cancel";
	public static final String UPDATE_CUSTOMER_INFORMATION_BUTTON_CANCEL =  "id=cancel";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_EMPLOYERNAME =  "id=employment.employerName";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_OCCUPATION =  "id=employment.occupationCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_OCCUPATIONOTHER =  "id=employment.occupationOther";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_OCCUPATIONSTATUS =  "id=employment.occupationStatusCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_JOBTITLE =  "id=employment.jobTitleCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_JOBTITLEOTHER =  "id=employment.jobTitleOther";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_ASOFDATE_EMP =  "id=employment.jobTitleStatusDate";
	public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_US =  "id=address.typeUS";
	public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_USAGEBUSINESSEMPLOYER =  "id=address.addressUsages[2].usageBusinessEmployer";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_EVENTDATE1 =  "id=lifeEvent.eventDate";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_LIVINGARRANGEMENTS =  "id=person.enterpriseMarketingInfo.livingArrangementValue";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_CITIZENSHIP =  "id=person.citizenshipCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_FIRSTYEARWITHSF =  "id=person.enterpriseMarketingInfo.firstYearWithSF";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_CUSTOMERCATEGORY =  "id=person.agent.agentMarketingInfo.customerCategory";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_HOUSEHOLDINCOME=  "id=person.agent.agentMarketingInfo.householdIncomeCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_ASOFDATE_PERSONALINFORMATION =  "id=person.agent.agentMarketingInfo.householdIncomeDate";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_DEATHDATE =  "id=person.deathDate";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_BIRTHDATE =  "id=person.birthDate";
	public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_MALE =  "value=Male";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_ASSIGNEDSTAFF =  "id=person.agent.staffAssociateId";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_MARITALSTATUS =  "id=person.maritalStatusCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_PRIMARKCONTACT=  "id=person.enterpriseMarketingInfo.marketingMailingRecipientIndicator";
	public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_DEATHNOTERECEIVED=  "id=person.deceased";
	public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_FOREIGN =   "id=address.typeForeignUSTerritory";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MSTREET1 =   "id=address.street1";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MCITY =   "id=address.city";
	public static final String UPDATE_CUSTOMER_INFORMATION_RADIO_MCITYAPO =  "id=address.cityAPO";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_MSTATE=   "name=address.stateCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MCOUNTRY =   "name=address.countryCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MZIPANDPOSTAL =   "id=address.zipPostalCode";
	public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_USAGEMAILING= "id=address.addressUsages[0].usageMailing";
	public static final String UPDATE_CUSTOMER_INFORMATION_LINK_ADDNOTES =  "id=linkaddressaddressUsages0note";
	public static final String UPDATE_CUSTOMER_INFORMATION_CHECKBOX_USAGERESIDENCE =  "id=address.addressUsages[1].usageResidence";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_CUSTOMERINTEREST1 =  "id=personInterest.text"; 
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_HOMEPHONE =  "id=phone.number"; //".id=person.phones[0].number";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_CALLINGPREFERENCEDAYWORK =  "name=phone.phoneAvailability";//".name=person.phones[1].phoneAvailability";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_FROMTIMECELL =  "id=phone.availabilityStartTime";//".name=person.phones[2].availabilityStartTime";
	public static final String UPDATE_CUSTOMER_INFORMATION_LIST_TOTIMECELL = "id=phone.availabilityEndTime";// ".name=person.phones[2].availabilityEndTime";
	public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_EMAILADDRESS1 =  "id=email.address";//person.emails[0].address
	public static final String UPDATE_CUSTOMER_INFORMATION_BUTTON_CONTINUE=  "id=continue";
	public static final String UPDATE_CUSTOMER_INFORMATION_REMOVE_CONTINUE= "id=removeContinueButton";
	public static final String UPDATE_CUSTOMER_INFORMATION_TXT_ORGALIAS =  "id=orgName.name";
    public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_DRIVERSLICENSENUMBERQB =  "id=bestDriversLicense.number";
    public static final String UPDATE_CUSTOMER_INFORMATION_LIST_DRIVERSLICENSELOCATIONQB= "id=person.driversLicense[0].location";
    public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_DRIVERSLICENSENUMBER =  "id=person.driversLicense[0].number";
    public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_SSN =  "id=person.tin.number";
    public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_SIN =  "id=person.sin.number";
    public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MASKSIN =  "id=person.sin.maskedNumber";
    public static final String UPDATE_CUSTOMER_INFORMATION_TEXT_MASKSSN =  "id=person.tin.maskedNumber";
    public static final String UPDATE_CUSTOMER_INFORMATION_ACCOUNT_POLICIES =  "id=gridAgreements";
	
	
		
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final ListBox LIST_TITLE =  new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_TITLE); //AllowedTitles //personName.titleCode
		public static final TextField TEXT_FIRSTNAME =  new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_FIRSTNAME); //.id:  fName //personName.firstName
		public static final TextField TEXT_LASTNAME =  new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_LASTNAME); //.id:  lName //personName.lastName
		public static final Button BUTTON_SAVE  = new Button(UPDATE_CUSTOMER_INFORMATION_BUTTON_SAVE);
		public static final Button BUTTON_CLOSE = new Button(UPDATE_CUSTOMER_INFORMATION_BUTTON_CLOSE);
		public static final Button BUTTON_CANCEL = new Button(UPDATE_CUSTOMER_INFORMATION_BUTTON_CANCEL);
		public static final TextField TEXT_EMPLOYERNAME = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_EMPLOYERNAME);
		public static final ListBox LIST_OCCUPATION = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_OCCUPATION);
		public static final TextField TEXT_OCCUPATIONOTHER = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_OCCUPATIONOTHER);
		public static final ListBox LIST_OCCUPATIONSTATUS = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_OCCUPATIONSTATUS);
		public static final ListBox LIST_JOBTITLE = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_JOBTITLE);
		public static final TextField TEXT_JOBTITLEOTHER = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_JOBTITLEOTHER);
		public static final TextField TEXT_ASOFDATE_EMP = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_ASOFDATE_EMP);
		public static final RadioButton RADIO_US = new RadioButton(UPDATE_CUSTOMER_INFORMATION_RADIO_US);
		public static final CheckBox CHECKBOX_USAGEBUSINESSEMPLOYER = new CheckBox(UPDATE_CUSTOMER_INFORMATION_CHECKBOX_USAGEBUSINESSEMPLOYER);
		public static final ListBox LIST_LIFEEVENT1 = new ListBox("id=lifeEvent.lifeEventCode");
		public static final TextField TEXT_EVENTDATE1 = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_EVENTDATE1);
		public static final ListBox LIST_LIVINGARRANGEMENTS = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_LIVINGARRANGEMENTS);
		public static final ListBox LIST_CITIZENSHIP = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_CITIZENSHIP);
		public static final TextField TEXT_FIRSTYEARWITHSF = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_FIRSTYEARWITHSF);
		public static final TextField TEXT_CUSTOMERCATEGORY = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_CUSTOMERCATEGORY);
		public static final ListBox LIST_HOUSEHOLDINCOME= new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_HOUSEHOLDINCOME);
		public static final TextField TEXT_ASOFDATE_PERSONALINFO = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_ASOFDATE_PERSONALINFORMATION);
		public static final TextField TEXT_DEATHDATE = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_DEATHDATE);
		public static final TextField TEXT_BIRTHDATE = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_BIRTHDATE);
		public static final RadioButton RADIO_MALE = new RadioButton(UPDATE_CUSTOMER_INFORMATION_RADIO_MALE);
		public static final ListBox LIST_ASSIGNEDSTAFF = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_ASSIGNEDSTAFF);
		public static final ListBox LIST_MARITALSTATUS = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_MARITALSTATUS);
		public static final CheckBox CHECKBOX_PRIMARKCONTACT= new CheckBox(UPDATE_CUSTOMER_INFORMATION_CHECKBOX_PRIMARKCONTACT);
		public static final CheckBox CHECKBOX_DEATHNOTERECEIVED= new CheckBox(UPDATE_CUSTOMER_INFORMATION_CHECKBOX_DEATHNOTERECEIVED);
		public static final RadioButton RADIO_FOREIGN =  new RadioButton(UPDATE_CUSTOMER_INFORMATION_RADIO_FOREIGN);
		public static final TextField TEXT_MSTREET1 =  new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_MSTREET1);
		public static final TextField TEXT_MCITY =  new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_MCITY);
		public static final ListBox LIST_MSTATE=  new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_MSTATE);
		public static final TextField TEXT_MCOUNTRY =  new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_MCOUNTRY);
		public static final TextField TEXT_MZIPANDPOSTAL =  new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_MZIPANDPOSTAL);
		public static final CheckBox CHECKBOX_USAGEMAILING=new CheckBox(UPDATE_CUSTOMER_INFORMATION_CHECKBOX_USAGEMAILING);
		public static final Link LINK_ADDNOTES = new Link(UPDATE_CUSTOMER_INFORMATION_LINK_ADDNOTES);
		public static final CheckBox CHECKBOX_USAGERESIDENCE = new CheckBox(UPDATE_CUSTOMER_INFORMATION_CHECKBOX_USAGERESIDENCE);
		public static final TextField TEXT_CUSTOMERINTEREST1 = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_CUSTOMERINTEREST1); 
		public static final TextField TEXT_HOMEPHONE = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_HOMEPHONE); //".id=person.phones[0].number";
		public static final ListBox LIST_CALLINGPREFERENCEDAYWORK = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_CALLINGPREFERENCEDAYWORK);//".name=person.phones[1].phoneAvailability";
		public static final ListBox LIST_FROMTIMECELL = new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_FROMTIMECELL);//".name=person.phones[2].availabilityStartTime";
		public static final ListBox LIST_TOTIMECELL =new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_TOTIMECELL);// ".name=person.phones[2].availabilityEndTime";
		public static final TextField TEXT_EMAILADDRESS1 = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_EMAILADDRESS1);//person.emails[0].address
		public static final Button  BUTTON_CONTINUE= new Button(UPDATE_CUSTOMER_INFORMATION_BUTTON_CONTINUE);
		public static final Button REMOVE_CONTINUE=new Button(UPDATE_CUSTOMER_INFORMATION_REMOVE_CONTINUE);
		public static final TextField TXT_ORGALIAS = new TextField(UPDATE_CUSTOMER_INFORMATION_TXT_ORGALIAS);
	    public static final TextField TEXT_DRIVERSLICENSENUMBERQB = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_DRIVERSLICENSENUMBERQB);
	    public static final ListBox LIST_DRIVERSLICENSELOCATIONQB=new ListBox(UPDATE_CUSTOMER_INFORMATION_LIST_DRIVERSLICENSELOCATIONQB);
	    public static final TextField TEXT_DRIVERSLICENSENUMBER = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_DRIVERSLICENSENUMBER);
	    public static final TextField TEXT_SSN = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_SSN);
	    public static final TextField TEXT_SIN = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_SIN);
	    public static final TextField TEXT_MASKSIN = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_MASKSIN);
	    public static final TextField TEXT_MASKSSN = new TextField(UPDATE_CUSTOMER_INFORMATION_TEXT_MASKSSN);
	    public static final Div ACCOUNT_POLICIES = new Div(UPDATE_CUSTOMER_INFORMATION_ACCOUNT_POLICIES);
	}
}
