package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;


public class OOB_EnterpriseView_Agent49 extends BaseScript {
	
String query = "select * from OOB_EnterpriseView_Agent49";

	public void executeScript() throws Exception{
		oobIndividualTasks.clickCustomerTab();
		oobIndividualTasks.clickOutOfBookAndIndividualRadioButton();
		oobIndividualTasks.isOOBIndividualPageExists();
		oobIndividualTasks.enterNameSectionInOOBIndividualPage();
		oobIndividualTasks.enterVerificationDataOOBIndividualPage();
		oobIndividualTasks.enterMovingToDataInOOBIndividualPage();
		oobIndividualTasks.clickSearch();
	   ssnSINTasks.validateAccountandPoliciesTwistyNotPresent();
}
	
public void scriptMain()  {
	
	try {
		transferObject=setTestDataObject(transferObject);
		transferObject.setDbQuery(query);
		
		dbresultSet =databaseUtil.getCoreData(transferObject);
		
		while(dbresultSet.next()){
			clientE2ETO = databaseUtil.loadTestAgentOOBIndScenario18(dbresultSet,clientE2ETO);
			
			oobIndividualTasks = new OOBIndividualTasks(clientE2ETO);
			ssnSINTasks = new SSNSINTasks(clientE2ETO);
			
			launcher = new LaunchApplication(getWATConfig());
			launcher.launchUser(scriptName());
			
			oobIndividualTasks.createResultsFile(resultsFileName(),scriptName());
			
			executeScript();
			
		}
		
		
	} 
		catch (Exception e) {
		e.printStackTrace();
	}
}
}
