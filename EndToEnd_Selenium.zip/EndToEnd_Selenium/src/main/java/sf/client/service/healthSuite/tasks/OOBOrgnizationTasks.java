package sf.client.service.healthSuite.tasks;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.common.appObjects.ABSPortalTestObjects;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.AutoPolicyViewPageObjects;
import sf.client.service.healthSuite.appObjects.HouseholdActivitiesPageObjects;
import sf.client.service.healthSuite.appObjects.OutOfBookConformationPageObjects;
import sf.client.service.healthSuite.appObjects.OutOfBookPoliciesAndAccountsPageObjects;
import sf.client.service.healthSuite.appObjects.OutOfBookSearchPageObjects;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.TextField;
import statefarm.widget.manager.Verify;

/**
 * @author u7kv
 * 
 */
public class OOBOrgnizationTasks extends HouseHoldTasks {
	/**
	 * Empty Constructor
	 */
	public OOBOrgnizationTasks() {

	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param clientE2ETO
	 */
	public OOBOrgnizationTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}

	/**
	 * Click on Out Of Book radio button.
	 * 
	 * @throws ScriptException
	 */
	public void clickSearchOOB() throws ScriptException,
			sf.client.service.common.helpers.ScriptException {
		waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON,20);
		if (OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON.click();
			Verify.verifyTrue(true,
					MessageUtility.RADIOBUTTON_OUTOFBOOK_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_OUTOFBOOK_NOTFOUND);
		}
	}

	/**
	 * This method is used to launch the OOB Search Page.
	 * <p>
	 * This method will do, i) Call the method to click on Out Of Book radio
	 * button. ii)Call the method to click on Organization radio button.
	 */
	public void clickOutOfBookAndOrganizationRadioButton() {
		try {
			if (isPortalSearchPageExist()) {
				clickSearchOOB();
				clickSearchOrg();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}

	}

	/**
	 * Click on Organization radio button.
	 * 
	 * @throws ScriptException
	 */
	public void clickSearchOrg() throws ScriptException {
		waitForTime(3);
		if (OutOfBookSearchPageObjects.WidgetInfos.RADIOBUTTON_SELECTORGANIZATION.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.RADIOBUTTON_SELECTORGANIZATION.click();
			Verify.verifyTrue(true,
					MessageUtility.RADIOBUTTON_ORGANIZATION);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_ORGANIZATION_NOTFOUND);
		}
	}

	/**
	 * Enter the Organization name in the OOB Search page.
	 * 
	 * @throws ScriptException
	 */
	public void enterOrganizationName() throws ScriptException {
		if (clientE2ETO.getOrgName() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.setText(clientE2ETO
						.getOrgName());
				Verify.verifyTrue(true, clientE2ETO.getOrgName() + MessageUtility.ORGANIZATIONNAME_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_ORGNAME_NOTFOUND);
			}
		}
	}

	/**
	 * This method is used to verify the OOB Search page existence.
	 * 
	 * @return returns true if OOB Search page exists.
	 */
	public boolean isOOBOrganizationPageExists() {
		waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME, 10);
		if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method is used to select the Province from the OOB Search page for
	 * Organization in name Section.
	 */
	public void selectStateOrProvince() {
		try {
			if (clientE2ETO.getState() != null) {
				if (OutOfBookSearchPageObjects.WidgetInfos.LIST_STATEPROV.exists()) {
					OutOfBookSearchPageObjects.WidgetInfos.LIST_STATEPROV
							.selectItem(clientE2ETO.getState());
					Verify.verifyTrue(true, MessageUtility.STATEORPROVINCE);
				} else {
					Verify.verifyTrue(false, MessageUtility.STATEORPROVINCE);
				}
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * This method is used to select the Province from the OOB Search page for
	 * Organization in Verification data section.
	 * 
	 * @throws ScriptException
	 */
	public void selectVerificationState() throws ScriptException {
		if (clientE2ETO.getPolicyStateOrProv() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.LIST_VERIFICATIONSTATEPROV.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.LIST_VERIFICATIONSTATEPROV
						.selectItem(clientE2ETO.getPolicyStateOrProv());
				Verify.verifyTrue(true, MessageUtility.VERIFICATIONSTATE);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.VERIFICATIONSTATE_NOTFOUND);
			}
		}
	}

	/**
	 * This method is used to select the Province from the OOB Search page for
	 * Organization in the Moving Section.
	 * 
	 * @throws ScriptException
	 */
	public void selectMoveState() throws ScriptException {
		if (clientE2ETO.getMovingState() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.LIST_MOVINGTOSTATEPROV.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.LIST_MOVINGTOSTATEPROV
						.selectItem(clientE2ETO.getMovingState());
				Verify.verifyTrue(true, MessageUtility.MOVINGZIP);
			} else {
				Verify.verifyTrue(false, MessageUtility.MOVINGZIP_NOTFOUND);
			}
		}
	}

	/**
	 * Enter the Moving City for Organization.
	 * 
	 * @throws ScriptException
	 */
	public void enterMoveCity() throws ScriptException {
		if (clientE2ETO.getMovingCity() != null) {
			if ((OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBCITYMOVE).exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBCITYMOVE.setText(clientE2ETO
						.getMovingCity());
				Verify.verifyTrue(true, MessageUtility.MOVINGCITY);
			} else {
				Verify.verifyTrue(false, MessageUtility.MOVINGCITY_NOTFOUND);
			}
		}
		enterMandatoryfieldtoEnablebutton(
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME,
				clientE2ETO.getOrgName());
	}

	/**
	 * Enter the City for Organization in the Name Section.
	 * 
	 * @throws ScriptException
	 */
	public void enterCity() throws ScriptException {
		if (clientE2ETO.getCity() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_CITY.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_CITY.setText(clientE2ETO
						.getCity());
				Verify.verifyTrue(true, MessageUtility.CITY_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_CITY);
			}
		}
	}

	/**
	 * Enter Postal code in Moving To section.
	 * 
	 * @throws ScriptException
	 */
	public void enterZip() throws ScriptException {
		if (clientE2ETO.getZip() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_POSTALCODE.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_POSTALCODE.setText(clientE2ETO
						.getZip());
				Verify.verifyTrue(true,  clientE2ETO.getZip()
						+ MessageUtility.ZIP);
			} else {
				Verify.verifyTrue(false,  MessageUtility.TEXT_ZIP);
			}
		}
	}

	/**
	 * This method is used to select the Line Of Business From the Verification
	 * Data section in OOB Search page.
	 * 
	 * @throws ScriptException
	 */
	public void selectLOB() throws ScriptException {
		if (clientE2ETO.getLob() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.LIST_VERIFICATIONLOB.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.LIST_VERIFICATIONLOB
						.selectItem(clientE2ETO.getLob());
				Verify.verifyTrue(true, MessageUtility.LINEOFBUSINESS);
			} else {
				Verify.verifyTrue(false, MessageUtility.LINEOFBUSINESS_NOTFOUND);
			}
		}
	}

	/**
	 * Enter the Policy Number in the Verification data Section.
	 * 
	 * @throws ScriptException
	 */
	public void enterAccountPolicyNum() throws ScriptException {
		if (clientE2ETO.getPolicyNumber() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_ACCOUNTPOLICYNUMBER.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_ACCOUNTPOLICYNUMBER
						.setText(clientE2ETO.getPolicyNumber());
				Verify.verifyTrue(true, MessageUtility.POLICYNUMBER);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_POLICYNUMBER_NOTFOUND);
						
			}
		}
	}

	/**
	 * Enter the Moving POstal in the OOB Search page.
	 * @throws ScriptException
	 */
	public void enterMVPostal() throws ScriptException {
		if (clientE2ETO.getMovingZip() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBPOSTALCODEMOVE.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBPOSTALCODEMOVE
						.setText(clientE2ETO.getMovingZip());
				Verify.verifyTrue(true, clientE2ETO.getMovingZip() + MessageUtility.MVZIP);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_MVZIP_NOTFOUND);
			}
		}
		enterMandatoryfieldtoEnablebutton(
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME,
				clientE2ETO.getOrgName());
	}
/**
 * Click on Search button in the OOB Search page.
 * @throws ScriptException
 */
	public void clickSearch() throws ScriptException {
		if (OutOfBookSearchPageObjects.WidgetInfos.BUTTON_SEARCHSUBMIT.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.BUTTON_SEARCHSUBMIT.click();
			Verify.verifyTrue(true, MessageUtility.BUTTON_SEARCH);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_SEARCH_NOTFOUND);
		}
	}
/**
 * Verify whether Searched Customer is exists in the OOB Search page.
 * @throws ScriptException
 */
	public void verifySearch() throws ScriptException {
		waitForTime(3);
		boolean custFlag = isCustomerExists(clientE2ETO.getCustomerOneData());
		if (custFlag) {
			Verify.verifyTrue(true, clientE2ETO.getCustomerOneData() + MessageUtility.CUSTOMER_FOUND);
		} else {
			Verify.verifyTrue(false, clientE2ETO.getCustomerOneData() + MessageUtility.CUSTOMER_NOTFOUND);
		}
	}
/**
 * Verify the Given Customer name link exists in the Search table.
 * @param cName name to verify
 * @return return true if the given Customer name link exists.
 */
	public boolean isCustomerExists(String cName) {

		Link CUSTOMER_NAME_LINK = new Link("text=" + cName);
		waitForPageLoad(CUSTOMER_NAME_LINK, 20);
		if (CUSTOMER_NAME_LINK.exists()) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * this method is used to Click on the Customer name link in the OOB Search results
	 * and verify the OOB Policies launched.
	 * @throws ScriptException
	 */
	public void verifyOOBPolicyPageNavigation() throws ScriptException {
		try {
			clickCustomerMCLBTable();
			setTopFrame();
			outOfBookConfirmationPage();
			verifyOOBPolicyPageLaunched();

		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Click on the Customer name link if it exists
 * @throws ScriptException
 */
	public void clickCustomerMCLBTable() throws ScriptException {
		Link link = new Link("text=" + clientE2ETO.getCustomerOneData());
		waitForPageLoad(link, 20);
		if (link.exists()) {
			link.click();
			setWindow("Out of Book Confirmation",20,2);
		} else {
			Verify.verifyTrue(false, clientE2ETO.getCustomerOneData() + MessageUtility.CUSTOMER_NOTFOUND);
		}
	}
	public void clickCustomerMCLBTableSW() throws ScriptException {
		Link link = new Link("text=" + clientE2ETO.getCustomerOneData());
		waitForPageLoad(link, 20);
		if (link.exists()) {
			link.click();
			setWindow("Select CIMS 2.0 Version",10,5);
		} else {
			Verify.verifyTrue(false, clientE2ETO.getCustomerOneData() + MessageUtility.CUSTOMER_NOTFOUND);
		}
	}
/**
 * Click on Clear button in the OOB Search page.
 * @throws ScriptException
 */
	public void clearData() throws ScriptException {
		waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT, 15);
		if (OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT.click();
		}
	}
/**
 * verify the Organization name is empty in the OOB Search page. 
 * @throws ScriptException
 */
	public void verifyClear() throws ScriptException {
		waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.TEXT_ORGNAME, 20);
		String orgNameFromCSPageForAuto = OutOfBookSearchPageObjects.WidgetInfos.TEXT_ORGNAME
				.getText();
		if (orgNameFromCSPageForAuto.isEmpty())
			Verify.verifyTrue(true, MessageUtility.OOBSEARCHPAGE_REFRESH);
		else
			Verify.verifyTrue(false, MessageUtility.OOBSEARCHPAGE_NOTREFRESHED);
	}
/**
 * Enter Organization name, postal code,province and city in the OOB Search page.
 */
	public void enterNameSectionInOOBOrganizationPage() {
		try {
			if (isOOBOrganizationPageExists()) {
				clickSearchOrg();
				enterOrganizationName();
				enterZip();
				selectStateOrProvince();
				enterCity();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.OUTOFBOOKORGANIZATIONSEARCHPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Enter verification data in OOB Search page.
 * <p>
 * 1)Line of Business
 * 2)Policy Number
 * 3)Verification State.
 */
	public void enterVerificationDataInOOBOrganizationPage() {
		try {
			if (isOOBOrganizationPageExists()) {
				selectLOB();
				enterAccountPolicyNum();
				selectVerificationState();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.OUTOFBOOKORGANIZATIONSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Enter Moving to Data in OOB Organization Search page.
 * <p>
 * 1)Moving State
 * 2)Moving City
 * 3)Moving Postal
 */
	public void enterMovingToDataInOOBOrganizationPage() {
		try {
			if (isOOBOrganizationPageExists()) {
				selectMoveState();
				enterMoveCity();
				enterMVPostal();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.OUTOFBOOKORGANIZATIONSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Verify whether OOB Confirmation page is launched.
 * @throws ScriptException
 */
	public void outOfBookConformationLaunched() throws ScriptException {
		waitForTime(5);
		if (OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.OUTOFBOOKPAGE_LAUNCHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.OUTOFBOOKPAGE_NOTLAUNCHED);
			isErrorPage("Out of Book Confirmation");
		}
	}
/**
 * Check Customer Permission Over 18 from the Out Of Book  policies page.
 * @throws ScriptException
 */
	public void selectCustomerPermissionOver18() throws ScriptException {
		if (isOutOfBookConformationLaunched()) {
			waitForTime(3);
			if (OutOfBookConformationPageObjects.WidgetInfos.CHECKBOX_SEARCHEDCUSTOMERPERMISSIONOVER18
					.exists()) {
				OutOfBookConformationPageObjects.WidgetInfos.CHECKBOX_SEARCHEDCUSTOMERPERMISSIONOVER18
						.click();
				Verify.verifyTrue(true,
						MessageUtility.SEARCHEDCUSTOMERPERMISSIONOVER18_CLICKED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEARCHEDCUSTOMERPERMISSIONOVER18_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.SEARCHEDCUSTOMERPERMISSIONOVER18_NOTFOUND);
		}

	}
/**
 * Select the Reason for Transfer from the OOB policies page
 * @throws ScriptException
 */
	public void selectReasonForTransfer() throws ScriptException {
		if (isOutOfBookConformationLaunched()) {
			if (OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1
					.exists()) {
				OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1
						.click();
				Verify.verifyTrue(true,
						MessageUtility.REASONFORTRANSFER);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.REASONFORTRANSFER_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.REASONFORTRANSFER_NOTFOUND);
		}
	}
	/**
	 * verify the OOB Confirmation is launched.
	 * @return returns true if the OOB Confirmation is launched.
	 * @throws ScriptException
	 */
	public boolean isOutOfBookConformationLaunched() throws ScriptException {
		waitForTime(3);
		if (OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1
				.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.OUTOFBOOKPAGE_LAUNCHED);
			return true;
		} else {
			return false;
		}
	}
/**
 * Check the Movemember checkbox.
 * @throws ScriptException
 */
	public void selectMoveHHMember() throws ScriptException {
		if (OutOfBookConformationPageObjects.WidgetInfos.CHECKBOX_MOVEHHMEMBER.exists()) {
			OutOfBookConformationPageObjects.WidgetInfos.CHECKBOX_MOVEHHMEMBER.click();
			Verify.verifyTrue(true,
					MessageUtility.HHMEMBER_SELECTED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.HHMEMBER_NOTSELECTED);
		}
	}
/**
 * Click on Next link in OOB Policies page.
 * @throws ScriptException
 */
	public void clickNextOOC() throws ScriptException {
		waitForTime(3);
		if (OutOfBookConformationPageObjects.WidgetInfos.LINK_NEXT.exists()) {
			OutOfBookConformationPageObjects.WidgetInfos.LINK_NEXT.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_NEXT);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_NEXT_NOTCLICKED);
		}
	}
	/**
	 * Verify the Auto Policy page launched.
	 * @throws ScriptException
	 */
	public void isAutoPolicyViewLaunched() throws ScriptException {
		waitForPageLoad(AutoPolicyViewPageObjects.WidgetInfos.DIV_AUTOPOLICYHEADER);
		if (AutoPolicyViewPageObjects.WidgetInfos.DIV_AUTOPOLICYHEADER.exists())
			Verify.verifyTrue(true,
					MessageUtility.AUTOFLEETPOLICY_LAUNCHED);
		else
			Verify.verifyTrue(false,
					MessageUtility.AUTOFLEETPOLICY_NOTLAUNCHED);
	}
	/**
	 * Verify the Fire Policy page launched.
	 * @throws ScriptException
	 */
	public void isFirePolicyViewLaunched() throws ScriptException {
		waitForPageLoad(AutoPolicyViewPageObjects.WidgetInfos.SPAN_VIEWFIREHEADER);
		if (AutoPolicyViewPageObjects.WidgetInfos.SPAN_VIEWFIREHEADER.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.FIREPOLICYCPAR_LAUNCHED);
		} else
			Verify.verifyTrue(false,
					MessageUtility.FIREPOLICYCPAR_NOTLAUNCHED);

	}

	/**
	 * Click on Close button 
	 * @throws ScriptException
	 */
	public void clickCloseButton() throws ScriptException {
		Button closeButton = new Button("name=Close");
		if (closeButton.exists()) {
			closeButton.click();
			Verify.verifyTrue(true, MessageUtility.BUTTON_CLOSE);
		} else
			Verify.verifyTrue(false, MessageUtility.BUTTON_CLOSE_NOTFOUND);
	}
/**
 * Enter the first name in the First Name text field.
 * @throws ScriptException
 */
	public void enterPortalFirstName() throws ScriptException {
		if (clientE2ETO.getFirstNameSearchpage() != null) {
			if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME.exists()) {
				Verify.verifyTrue(true, clientE2ETO.getFirstNameSearchpage()
						+ MessageUtility.FIRSTNAME_VALUE);
				ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME.setText(clientE2ETO
						.getFirstNameSearchpage());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.TEXT_FIRSTNAME);
			}
		}
	}
	/**
	 * Enter the data for Auto in the OOB Search page and verify the result in the MCLB table
	 * and Click on Clear button.
	 * 
	 */
	public void fetchOrgDataAuto() {
		try {
			clickOutOfBookAndOrganizationRadioButton();
			clearData();
			verifyClear();
			enterNameSectionInOOBOrganizationPage();
			enterVerificationDataInOOBOrganizationPage();
			enterMovingToDataInOOBOrganizationPage();
			clickSearch();
			verifySearch();
			clearData();
			verifyClear();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Enter the data for Fire in the OOB Search page and verify the result in the MCLB table
 * and Click on Clear button.
 */
	public void fetchOrgDataFire() {
		try {
			enterNameSectionInOOBOrganizationPage();
			enterVerificationDataInOOBOrganizationPage();
			enterMovingToDataInOOBOrganizationPage();
			clickSearch();
			verifySearch();
			clearData();
			verifyClear();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * Enter the data in the OOB Search page and verify the result in the MCLB table
	 * and verify the OOB Policies page launched. 
	 */
	public void fetchData() throws ScriptException {
		try {
			clickOutOfBookAndOrganizationRadioButton();
			enterNameSectionInOOBOrganizationPage();
			enterVerificationDataInOOBOrganizationPage();
			enterMovingToDataInOOBOrganizationPage();
			clickSearch();
			verifySearch();
			verifyOOBPolicyPageNavigation();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * This method is written for SupportWrite portal,this will do the following
	 * <p>
	 * 1)Enter User Alias{@link #enterUserAlias() enterUserAlias} 
	 * 2)Enter the Name section OOB Search page{@link #enterNameSectionInOOBOrganizationPage() enterNameSectionInOOBOrganizationPage} 
	 * 3)Enter the Verification data in OOB Search Page{@link #enterVerificationDataInOOBOrganizationPage() enterVerificationDataInOOBOrganizationPage}
	 * 4)Enter Moving To Data in OOB Search Page {@link #enterMovingToDataInOOBOrganizationPage() enterMovingToDataInOOBOrganizationPage} 
	 * 5)Click on Search button in the OOB Search page{@link #clickSearch() clickSearch} 
	 * 6)verify the Search Page
	 * 7)Click on the Customer name link OOB Search results.
	 * 8)Verify whether OOB Confirmation page launched
	 * @throws ScriptException
	 */
	public void fetchDataOOBSW() throws ScriptException {
		try {
			enterUserAlias();
			clickOutOfBookAndOrganizationRadioButton();
			enterNameSectionInOOBOrganizationPage();
			enterVerificationDataInOOBOrganizationPage();
			enterMovingToDataInOOBOrganizationPage();
			clickSearch();
			verifySearch();
			clickCustomerMCLBTableSW();
			handleCimsVersion();
			outOfBookConformationLaunched();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	
	public void fetchDataOOBProd() throws ScriptException {
		try {
			enterUserAlias();
			clickOutOfBookAndOrganizationRadioButton();
			enterNameSectionInOOBOrganizationPage();
			enterVerificationDataInOOBOrganizationPage();
			enterMovingToDataInOOBOrganizationPage();
			clickSearch();
			verifySearch();
			clickCustomerMCLBTable();
			handleCimsVersion();
			outOfBookConformationLaunched();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Verify the OOB POlicies launched and Select the mandatory fields in the 
 * OOB policies page and Click on Next link.
 */
	public void outOfBookConfirmationPage() {
		try {
			outOfBookConformationLaunched();
			selectReasonForTransfer();
			selectCustomerPermissionOver18();
			selectMoveHHMember();
			clickNextOOC();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * Launching the Fire policy from the OOB POlicies Page.
	 */
	public void oobFirePolicy() {
		try {
			handleCimsVersion();
			verifyOOBPolicyPageLaunched();
			launchFirePolicyNumbers();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Verify the OOB POlicy page is launched.
	 * @throws ScriptException
	 */
	public void verifyOOBPolicyPageLaunched() throws ScriptException {
		waitForTime(3);
		if (OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE.exists()) {
			Verify.verifyTrue(true, MessageUtility.OUTOFBOOKPOLICIESPAGE_LAUCNHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.OUTOFBOOKPOLICIESPAGE_NOTLAUCNHED);
			isErrorPage("Out of Book Policies and Accounts");
		}
	}
	/**
	 * Click on the Fire policy number link from OOB policy page.
	 * @throws ScriptException
	 */
	public void launchFirePolicyNumbers() throws ScriptException {
		if (isOOBPolicyPageLaunched()) {
			int c = 1;
			boolean flag = true;
			while (flag) {
				try {
					WebElement policyDescription = getWebDriverInstance().findElement(By.xpath("//div[@id='policiesAccountsNumberLink']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[1]"));
					
					if (policyDescription.getText().equalsIgnoreCase("Fire")) {
						while (flag) {
							c++;
							WebElement policiesAccountsNumberLink = getWebDriverInstance().findElement(By.xpath("//div[@id='policiesAccountsNumberLink']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[2]"));
							if(policiesAccountsNumberLink.isDisplayed()) {
								String policyNumber = policiesAccountsNumberLink.getText(); 
								Link policyNumbers = new Link("text="
										+ policyNumber);
								if (policyNumbers.exists()) {
									click(policyNumbers,
											policyNumber
													+ " "
													+ policyDescription
													+ MessageUtility.FIREPOLICY_CLICKED);
									isFirePolicyViewLaunched();
									clickCloseButton();
									isErrorPage("Out of Book Policies and Accounts ");
									flag = false;
								}
							} else {
								break;
							}
						}
					}
					c++;
				} catch (Exception e) {
					break;
				}
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.FIREPOLICY_NOTFOUND);
		}
	}
	/**
	 * Click on the Go To Household page link in the OOB policy page.
	 * @return
	 * @throws ScriptException
	 */
	public boolean isOOBPolicyPageLaunched() throws ScriptException {
		waitForPageLoad(
				OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE, 10);
		if (OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE.exists()) {
			return true;

		} else {
			return false;
		}
	}
	/**
	 * This method will do the Following,
	 * <p>
	 * 1)Verify the OOB policy page is launched {@link #verifyOOBPolicyPageLaunched() verifyOOBPolicyPageLaunched}
	 * 2)Launch Auto Policy from the OOB Search page {@link #launchAutoPolicyNumbers() launchAutoPolicyNumbers}
	 */
	public void oobAutoPolicy() {
		try {
			verifyOOBPolicyPageLaunched();
			launchAutoPolicyNumbers();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Launch the Auto policy from the OOB policy page
 * @throws ScriptException
 */
	public void launchAutoPolicyNumbers() throws ScriptException {
		if (isOOBPolicyPageLaunched()) {
			int c = 1;
			boolean flag = true;
			while (flag) {
				try {
					WebElement policyDescription = getWebDriverInstance().findElement(By.xpath("//div[@id='policiesAccountsNumberLink']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
							+ c + "]/td[1]"));
					if (policyDescription.getText().equalsIgnoreCase("Auto")) {
						while (flag) {
							c++;
							WebElement policiesAccountsNumberLink = getWebDriverInstance().findElement(By.xpath("//div[@id='policiesAccountsNumberLink']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[2]"));
							if(policiesAccountsNumberLink.isDisplayed()) {
								String policyNumber = policiesAccountsNumberLink.getText();
								Link policyNumbers = new Link("text="
										+ policyNumber);
								if (policyNumbers.exists()) {
									click(policyNumbers,
											policyNumber
													+ " "
													+ policyDescription
													+ MessageUtility.AUTOPOLICY_CLICKED);
									isAutoPolicyViewLaunched();
									clickCloseButton();
									flag = false;
								}
							} else {
								break;
							}
						}
					}
					c++;
				} catch (Exception e) {
					break;
				}
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.AUTOPOLICY_NOTFOUND);
		}
	}


/**
 * Launch and Verify Activity List from Activity List in HH Page
 */
	public void oobActivityListPage() {
		try {
			clickGoToHHPage();
			handleCimsVersion();
			hhpageLaunched();
			launchCMPageFromHHPage("innerText=Activities",
					"innerText=Activity List");
			handleCimsVersion();
			isHouseholdActivitiesPageLaunched();
			verifyActivity();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Click on Go To Household Page Link.
 * @throws ScriptException
 */
	public void clickGoToHHPage() throws ScriptException {
		if (isOOBPolicyPageLaunched()) {
			waitForPageLoad(
					OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE, 15);
			if (OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE
					.exists()) {
				OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE.click();
				Verify.verifyTrue(true,
						MessageUtility.GOTOHHPAGE_CLICKED);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.GOTOHHPAGE_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.GOTOHHPAGE_NOTFOUND);
		}
	}
/**
 * Verify the Activity list from HH Page
 * @throws ScriptException
 */
	public void verifyActivity() throws ScriptException {
		if (isHouseholdActivitiesPageLaunched()) {
			waitForPageLoad(
					HouseholdActivitiesPageObjects.WidgetInfos.SPAN_HOUSEHOLD_ACTIVITIES, 10);
			WebElement householdActivities = getWebDriverInstance().findElement(By.xpath("//div[@id='contentArea']"
					+ "/div[@id='activityListControl']"
					+ "/div[@class='scrollTable']"
					+ "/div[@class='scrollTableBody']"
					+ "/table[@class='sfFontSizeSmall mytest']"
					+ "/tbody/tr[1]/td[8]"));

			if (householdActivities.isDisplayed()) {
				String c = householdActivities.getText();
				if (c.equalsIgnoreCase("C")) {
					Verify.verifyTrue(true, "Complete Activity");
				}
			} else {
				Verify.verifyTrue(true, " InComplete Activity");
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.ACTIVITYPAGE_LAUCNHED);
			if (isErrorPage("Household Activities")) {
				clickHHPageCustomer();
			}
		}
	}

/**
 * Verify whether Household Activities Page launched.
 * @return returns true if Household Activities Page launched.
 * @throws ScriptException
 */
	public boolean isHouseholdActivitiesPageLaunched() throws ScriptException {
		waitForPageLoad(HouseholdActivitiesPageObjects.WidgetInfos.SPAN_HOUSEHOLD_ACTIVITIES,
				10);
		if (HouseholdActivitiesPageObjects.WidgetInfos.SPAN_HOUSEHOLD_ACTIVITIES.exists()) {
			return true;
		} else {
			return false;
		}

	}
/**
 *Check for prospect customer.  
 */
	public void oobProspectCustomer() {
		try {
			clickHouseholdLink();
			handleCimsVersion();
			hhpageLaunched();
			prospectCustomer();
			setParentWindow();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Verify whether the HH Page is Launched
 * @throws ScriptException
 */
	public void hhpageLaunched() throws ScriptException {
		if (isHHpageLaunched()) {
			waitForPageLoad(HouseholdActivitiesPageObjects.WidgetInfos.LINK_MEMBER_ACTIONS, 20);
			if (HouseholdActivitiesPageObjects.WidgetInfos.LINK_MEMBER_ACTIONS.exists()) {
				Verify.verifyTrue(true, MessageUtility.HOUSEHOLDPAGE_LAUNCHED);
			} else {
				Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
				isErrorPage("Household");
			}
		} else {
			Verify.verifyTrue(false,
					 MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		}

	}
/**
 * verify whether the Household page is launched
 * @return returns true if Household is launched
 * @throws ScriptException
 */
	public boolean isHHpageLaunched() throws ScriptException {
		waitForPageLoad(HouseholdActivitiesPageObjects.WidgetInfos.LINK_MEMBER_ACTIONS, 20);
		if (HouseholdActivitiesPageObjects.WidgetInfos.LINK_MEMBER_ACTIONS.exists()) {
			return true;
		} else {
			return false;
		}

	}
/**
 * Check for Prospect Customer 
 * @throws ScriptException
 */
	public void prospectCustomer() throws ScriptException {
		if (isHHpageLaunched()) {
			selectHouseHoldMemHHpage(clientE2ETO.getPresentHHMember());
			setChildWindow(3);
			handleCimsVersion();
			hhpageLaunched();
			Verify.verifyTrue(true, MessageUtility.PROSPECTCUSTOMER_LAUNCHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.PROSPECTCUSTOMER_NOTLAUNCHED);
		}
	}
/**
 * Click on Name radio button in the Customer Search page.
 * @throws ScriptException
 */
	public void clickNameRadioButton() throws ScriptException {
		waitForPageLoad(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_AGENT_NAME_SERACH, 10);
		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_AGENT_NAME_SERACH.exists()) {
			ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_AGENT_NAME_SERACH.click();
			Verify.verifyTrue(true, MessageUtility.RADIOBUTTON_NAME);
		} else {
			Verify.verifyTrue(false, MessageUtility.RADIOBUTTON_NAME_NOTDISPLAYED);
		}
	}
/**
 * Enter the User alias if it exists
 */
	public void enterUserAlias() {
		try {
			TextField userAlias = new TextField("name=simulateUser");
			Button searchButton = new Button(name = "submitSimulate");
			waitForPageLoad(userAlias, 15);
			if (clientE2ETO.getUserAlias() != null) {
				if (userAlias.exists()) {
					setTextInTextbox(userAlias, clientE2ETO.getUserAlias(),
							 MessageUtility.ALIAS);
					enterMandatoryfieldtoEnablebutton(userAlias,
							clientE2ETO.getUserAlias());
					Verify.verifyTrue(true, MessageUtility.ALIAS);
					searchButton.click();
				}
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
/**
 * Enter the last name in the Customer Search page.
 * @throws ScriptException
 */
	public void enterPortalLastName() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 10);
		if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME.exists()) {
			if (clientE2ETO.getLastNameSearchpage() != null) {
				if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME.exists()) {
					enterMandatoryfieldtoEnablebutton(
							ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME,
							clientE2ETO.getLastNameSearchpage());
					Verify.verifyTrue(
							true,
							clientE2ETO.getLastNameSearchpage()
									+ MessageUtility.LASTNAME_VALUE);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.TEXT_LASTNAME);
				}
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);
		}
	}
/**
 * verify whether searching customer found in the search result
 * @return
 * @throws ScriptException
 */
	public boolean isSearchedCustomerFound() throws ScriptException {
		Link searchedCust = new Link("text=" + clientE2ETO.getCustomerTwoData());
		waitForPageLoad(searchedCust, 10);
		if (searchedCust.exists()) {
			return true;
		} else {
			return false;
		}
	}

/**
 * This method is for SupportWrite portal to verify Activity List Page from Customer Search page.
 * 
 */
	public void oobActivityListPageFromCustomerSearchPage() {
		try {
			clickNameRadioButton();
			enterUserAlias();
			if (isPortalSearchPageExist()) {
				enterPortalLastName();
				enterPortalFirstName();
				clickPortalSeacrhButton();
				isSearchedCustomerFound();
				clickActionsSearchPage();
				isActionDropdownExists();
				clickActionsActivitityList();
				setChildWindow(4);
				handleCimsVersion();
				handleActMgtVersion();
				isHouseholdActivitiesPageLaunched();
				verifyActivity();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

}
