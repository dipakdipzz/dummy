package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class AHQB_SearchIndCust_Scenario16 extends BaseScript {

	String query = "select * from AHQB_SearchIndCust_Scenario16";
	
	public void executeScript() throws Exception {
		scenarioTasks.clickLaunchAHQBOnline();
		scenarioTasks.clickGreetingOk();
		scenarioTasks.setWindow("Q & B Online", 10, 2);
		scenarioTasks.setCRCTopFrame();
		
		/**
		 * Launching HH Page
		 */
		scenarioTasks.launchHHPageFromCRCAHQBCustSearchPage();

		/**
		 * Validate the inactive Policies tab in HH Page
		 */
		hhNavigationTasks.validateInactivePoliciesTabInHHPage();

		/**
		 * Validate Combine/separate and Household Moves hyperlinks  in HH Page
		 */
		hhNavigationTasks.validateHHMovesAndCustomerCombineInHHPage();

		/**
		 * Validate the ability to add Additional Individual for a customer
		 *//*
		createCustTasks.addAndVerifyIndCustFromMemberActionsForAHQB();

		*//**
		 * Validate the ability to add Additional Organization for a customer
		 *//*
		scenarioTasks.addOrganizationinHouseholdPageForAHQB();*/

		/** Navigate to Customer Info Page */
		scenarioTasks.launchCustInfoPageFromHHPage();
		/**CASL CANADA Scenarios Tc1-Tc4*//*
		productTasks.EmessageOnlySendWithCASLFieldY();*/
		/**CASL CANADA Scenarios Tc5-Tc8*/
		//productTasks.doNotsendEmessageWithCASLFieldY();
		/**CASL US Scenarios Tc9-Tc10*/
		//productTasks.verifyEmessageFieldWithCASLFieldN();
		/**CASL US Scenarios Tc11-Tc12*/
		//productTasks.verifyEmessageFieldWithCASLFieldY();
		/**CASL US Scenarios Tc13-Tc14*/
		//productTasks.changingFromOnlyEmessageToUnsubscribe();

		/** Add an Alias - Name (Regular Characters). Update this Alias -(RegularCharacters). */
		updateTasks.addUpdateAliasCRC();
		scenarioTasks.removeIndUpdateName();

		/** Validate that Address cannot be added */
		scenarioTasks.validateAddAddressLinkNotDisplayedForQB();

		scenarioTasks.launchAndCancelInCOA();
		scenarioTasks.setWindow(EndToEndConstants.CUSTOMER_INFORMATION, 10, 2);
		scenarioTasks.setCRCDefaultFrame();
		/*
		*//**
		 * Validate Change Address
		 *//*
		scenarioTasks.launchCRCAddAddressInCOA();*/

		/**
		 * Add,Update and Remove Work Phone
		 */
		updateTasks.removeAllPhonesFromCustomerInfo_CRC();
		updateTasks.addWorkPhoneCustomerInfo_CRC();
		//updateTasks.updateWorkPhoneCustomerInfo();
	/*	createCustTasks.removePhoneCustomerInfo_CRC(clientE2ETO
				.getUpdatePhoneNumber());
*/
		/**
		 * Add,Update,Remove Email with Regular characters & International
		 * characters
		 */
		updateTasks.addEmailCustomerInfo_CRC();
		updateTasks.updateEmail_CRC();
		updateTasks.removeEmail_CRC();

		/** Validate that Customer Interests link NOT available */
		scenarioTasks.validateCustomerInterestLink();

		/** Add,Update & Delete Life Events */
		scenarioTasks.lifeEventsAddEventSC1_CRC();
		updateTasks.lifeEventsUpdate_CRC();
		updateTasks.lifeEventsRemove();

		/**
		 * Add,Update & Delete Employment
		 * 
		 */
		updateTasks.updateEmploymentAddEmployment_CRC();
		updateTasks.updateEmploymentUpdate_CRC();
		updateTasks.updateEmploymentRemove();

		/**
		 * Validate that policies are displayed in the Account/Policies section
		 * for the Active Customer
		 * 
		 */
		scenarioTasks.printAccountsAndPolicesFromCustomerInfoPage();
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil
						.loadTestDataAHQBSearchIndCustScenario16(dbresultSet,
								clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);

				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());

				scenarioTasks
						.createResultsFile(resultsFileName(), scriptName());

				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}