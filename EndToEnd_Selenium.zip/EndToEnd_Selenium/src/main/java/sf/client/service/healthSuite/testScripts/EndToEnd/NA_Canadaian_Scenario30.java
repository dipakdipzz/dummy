package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.to.ClientE2ETO;

public class NA_Canadaian_Scenario30 extends BaseScript {

	int count = 0;
	String query = "select * from SupportWrite_Ind_Sear_Scenario4";
	ClientE2ETO clientE2ETO = new ClientE2ETO();

	public void executeScript(String custType) throws Exception {
		
		createCustTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		createCustTasks.setCustomerSearchTopFrame();
		createCustTasks.waitForTime(3);
		/*createCustTasks.clickCustomer();*/
		//createCustTasks.launchCustomerSearchPage();
		
		/** Canada Scenario 1*//*
		scenarioTasks.canadaNonAgentCannotMimicUSAgent();*/
		
		/** Canada Scenario 3*/
		createCustTasks.canadaNonAgentNotAbleToSearchOnUSBob();
		
		/** Canada Scenario 4*/
		createCustTasks.canadaNonAgentNotAbleToSearchOnUSPolicy();
		
		/** Canada Scenario 5*/
		createCustTasks.canadaNonAgentNotAbleToSearchUSName();
		
		/** Canada Scenario 6*/
		createCustTasks.canadaNonAgentNotAbleToSearchUSPhone();
		
		
		/*createCustTasks.launchHHPageABS();
		createCustTasks.validateUSSSNCNSINDriversLicenseCustomerInfo(custType);*/
	}

	public void scriptMain() {

		try {

			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {

				clientE2ETO = databaseUtil.loadTestDataNACanadaianScenario30(
						dbresultSet, clientE2ETO);
				
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());

				createCustTasks
						.createResultsFile(resultsFileName(), scriptName());

				String custType = clientE2ETO.getCustomerType();
				count++;
				System.out.println("-------count---------" + count);
				executeScript(custType);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
