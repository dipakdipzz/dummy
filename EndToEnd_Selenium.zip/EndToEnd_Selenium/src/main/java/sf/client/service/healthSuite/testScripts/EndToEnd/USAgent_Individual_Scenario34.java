package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;

public class USAgent_Individual_Scenario34 extends BaseScript {

	int count = 0;
	String query = "select * from USAgent_Individual_Scenario34";
	public void executeScript() throws Exception {
		createCustTasks.createCustomerAndAddUpdateSSNAndSIN();
		createCustTasks.enterSSNAndSINaddInd();
		combineTasks.combineselectCustOneSSN();
		combineTasks.combineSelectCustTwoSSN();
		combineTasks.combineSelectNewSSN();
		if (clientE2ETO.getType().equalsIgnoreCase("moveSSN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPage();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("moveSSN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("moveSIN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPage();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("moveSIN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("moveSSNSIN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPage();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("moveSSNSIN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("newSSN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPage();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("newSSN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("newSIN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPage();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("newSIN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("newSSNSIN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPage();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("newSSNSIN");
		}
		

	}

	public void scriptMain() {

		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			launcher = new LaunchApplication(getWATConfig());
			launcher.launchUser(this.getClass().getSimpleName());
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataUSAgentIndividualScenario34(dbresultSet, clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				if(count==0){ 
					  createCustTasks.createResultsFile(resultsFileName(), scriptName());
					  createCustTasks.launchCustomerSeachPage();
					  createCustTasks.clickCreateIndividual();
					  count++; 
				  }
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
