package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.OOBOrgnizationTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;

public class SupportWrite_Portal_OOB47 extends BaseScript{

	int count=0;
	String query = "select * from SupportWrite_Portal_OOB47";
	public void executeScript(){
	try {
		
		/**
		 * OOB_ORG_Validations_ SW - 01 ==> Verify that  Non Agent user able to do OOB Organization search with auto Policy information 
		 */
		oobOrgnizationTasks.fetchDataOOBSW();
		
		/**
		 * OOB_ORG_Validations_SW- 02 ==> To launch Out of Book Policies and Accounts page from OOB Conformation page
		 */
		oobOrgnizationTasks.outOfBookConfirmationPage();
		
		/**
		 * OOB_ORG_Validations_SW - 03 ==> Launching Fire Policy details page from Policies and Accounts page by clicking on Fire policy link 
		 */
	
		oobOrgnizationTasks.oobFirePolicy();
		
		/**
		 * OOB_ORG_Validations_SW - 04 ==> Launching Auto Policy details page from Policies and Accounts page by clicking on Auto policy link
		 */
		
		oobOrgnizationTasks.oobAutoPolicy();
		
		/**
		 * OOB_ORG_Validations_SW - 05 ==> Launch Activities from HH page
		 */
		oobOrgnizationTasks.oobActivityListPage();
		
		
		/**
		 * OOB_ORG_Validations_SW - 06 ==> Verify Prospect customer relationship
		 */
		oobOrgnizationTasks.oobProspectCustomer();
		
		/**
		 * OOB_ORG_Validations_SW - 07 ==> Verify Activities from Action drop from Customer search results table
		 */
		oobOrgnizationTasks.oobActivityListPageFromCustomerSearchPage();
	    
		
	} catch (ScriptException e) {
		oobOrgnizationTasks.scriptError(e);
	}
	
	}
	
	
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataSupportWritePortalOOB47(dbresultSet,clientE2ETO);
				oobOrgnizationTasks = new OOBOrgnizationTasks(clientE2ETO);
				ssnSINTasks = new SSNSINTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				oobOrgnizationTasks.createResultsFile(resultsFileName(),scriptName());
				ssnSINTasks.launchCustomerSeachPage();
				executeScript();
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}
