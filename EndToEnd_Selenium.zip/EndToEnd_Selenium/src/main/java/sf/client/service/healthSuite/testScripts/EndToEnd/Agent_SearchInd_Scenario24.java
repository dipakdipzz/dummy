package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class Agent_SearchInd_Scenario24 extends BaseScript {
	String query = "select * from Agent_SearchInd_Scenario24";

	public void executeScript() {
		/**
		 * Launching HH Page
		 */
		createCustTasks.launchHouseholdpageFromPortal();
		/**
		 * Launch Customer Info from HH page.
		 *//*
		createCustTasks.launchCustomerInfoPageFromHHPage();
		*//**
		 * Add alias with International Characters
		 *//*
		updateTasks.addFirstAlias();
		*//**
		 * Remove Alias
		 *//*
		updateTasks.selectNameVersionAndRemove();
		*//**
		 * Add US address with International characters
		 *//*
		updateTasks.addAddressCustomerInfo();
		*//**
		 * Delete the Above added address
		 *//*
		updateTasks.searchandRemoveAddress(clientE2ETO.getmStreet());
		*//**
		 * Add,Delete Email
		 *//*
		updateTasks.addEmailCustomerInfo();
		*//**
		 * Update Email
		 *//*
		updateTasks.updateEmail();
		*//**
		 * Remove Email
		 *//*
		updateTasks.removeEmail();
		*//**
		 * Adding a Dummy Email
		 *//*
		updateTasks.addDummyEmail();
		*//**
		 * Remove all Phones From Customer Info Page to add
		 *//*
		updateTasks.removeAllPhonesFromCustomerInfo();
		*//**
		 * Add Home Phone number
		 *//*
		updateTasks.addHomePhoneCustomerInfo();
		*//**
		 * Add Mobile number
		 *//*
		updateTasks.addMobilePhoneCustomerInfo();
		*//**
		 * Validate the Text icon(Mobile phone icon) in the Phone section and
		 * send text by click on the mobile icon. (Send Text Pop-up window
		 * opens. Fill details and click SEND)//
		 *//*
		updateTasks.validateSentTextInCustomerInfo();
		*//**
		 * Validate that the new Phone changes/updates are displayed in the
		 * Active Customer Bar
		 *//*
		updateTasks.getWebDriverInstance().switchTo().defaultContent();
		updateTasks.validatePhoneNumbersDisplayedActiveCustomerBar();
		*//**
		 * Delete Mobile Number
		 *//*
		scenarioTasks.setTopFramewithDefaultContent();
		createCustTasks.removePhoneCustomerInfo(clientE2ETO
				.getCellPhoneNumber());
		*//**
		 * Update Personal Information All Fields
		 *//*
		updateTasks.updatePersonalInformation();
		*//**
		 * Customer Interest
		 *//*
		updateTasks.addCustomerInterestsCustomerInfo();
		*//**
		 * Employment
		 *//*
		scenarioTasks.updateEmploymentAddEmployment();
		*//**
		 * Life events
		 *//*
		scenarioTasks.lifeEventsAddEventSC1();
		*//**
		 * Validate that the Policy details for the selected Active Customer are
		 * displayed in the Account/Policy Roles section in the Cust Info screen
		 *//*
		combineTasks.accountPoliciesTableCustomerInfo();
		*//**
		 * navigate back to HH page.
		 *//*
		combineTasks.clickHHPageCustomer();
		combineTasks.setTopFrame();
		combineTasks.selectAgentSelection();
		*//**
		 * Select Add Policies With Others from Products Actions Drop down
		 *//*
		hhNavigationTasks.validateAddProductsWithOthersfromHHPage();*/
		/**
		 * Click on the 'Customer Profile Print' option in the Action drop down
		 * button for a Customer in the Household member section. Navigates to
		 * Cust Info page. Navigate back to Household page
		 */
		scenarioTasks.clickCustomerProfilePrintFromActionsDropdown();
		/**
		 * Click on the N link in the Internet Enabled column in the Household
		 * members section for a customer and launch the ISCC screen (Select a
		 * customer having N )
		 */
		scenarioTasks.clickIsInternetEnabledNOption();
		/**
		 * Click Products Inactive tab in HH page.
		 *//*
		scenarioTasks.clickProductsInactive();
		scenarioTasks.validatePhoenixLinkNotDisplayedInProductsInactivePage();
		*//**
		 * Validate that the Life App is launched, when the life App policy
		 * number is clicked in the Product Inactive page
		 *//*
		scenarioTasks.launchLifeAppfromProductsInactivePage();
		scenarioTasks.closeLifeAppScreen();
		*//**
		 * Search and Select Two Customers and Click on Next link.
		 *//*
		combineTasks.verifyAndSearchandSelectTwoCustomersPage();
		*//**
		 * Navigate to Customer Combine screen using the CUSTOMER menu option
		 * and combine two customers.
		 *//*
		combineTasks.verifyInfoandClickCombine();
		*//**
		 * Search and Select Customer from Search and Select one Customer Page.
		 *//*
		separateCustTasks.verifySearchandSelectOneCustomerPage();
		*//**
		 * Separating a Customer.
		 *//*
		separateCustTasks.separateCustomer();
		*//**
		 * Validate that all the Policies belonging to this Enterprise Customer
		 * (associated in all the regions - Enterprisewde) is displayed in the
		 * Account Policies section onn HH page
		 */
		scenarioTasks.clickInsurancePolicies();
		scenarioTasks.displayInsurancePolicies();
		/**
		 * Click on MR ICON
		 */
		productTasks.validateInsuranceAccountPolicies();
		/**
		 * launchAndVerifyMRIcon Close HH page
		 */
		combineTasks.closeHHPage();
		/**
		 * Payment option in the ACTION drop menu for AUTO policy
		 */
		combineTasks.setWindow("ABS Customer Search 1.1", 10, 2);
		combineTasks.launchPaymentAutoPolicy();
		/**
		 * REPORT A LOSS option in the ACTION drop menu for Fire policy
		 */
		combineTasks.launchReportALossFirePolicy();

	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil
						.loadTestDataAgentSearchIndScenario24(dbresultSet,
								clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				productTasks = new ProductTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				scenarioTasks
						.createResultsFile(resultsFileName(), scriptName());
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
