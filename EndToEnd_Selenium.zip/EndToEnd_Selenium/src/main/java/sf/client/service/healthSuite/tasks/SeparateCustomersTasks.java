package sf.client.service.healthSuite.tasks;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.CWAgentCSObjects;
import sf.client.service.healthSuite.appObjects.CWNonAgentCSObjects;
import sf.client.service.healthSuite.appObjects.CustomerSeparateAppObj;
import sf.client.service.healthSuite.appObjects.HouseHoldMove_PageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.SSNSINObjects;
import sf.client.service.healthSuite.appObjects.SearchSelectCustomerAppObj;
import sf.client.service.healthSuite.appObjects.Update_IND_CustomerInfo_PageObjects;
import sf.client.service.healthSuite.appObjects.VerifyTheFollowingAppObj;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.gui.Div;
import statefarm.widget.manager.Verify;

public class SeparateCustomersTasks extends HouseHoldTasks {
	public String cellsData = null;
	/**
	 * Empty Constructor
	 */
	public SeparateCustomersTasks() {
	}
	/**
	 * Parameterized Constructor
	 * 
	 * @param clientE2ETO
	 */
	public SeparateCustomersTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}
	
	/**
	 * Verify Phone data Exists or not in separate customer page.
	 * @throws ScriptException
	 * @return
	 */
	public void movePhonesData() throws ScriptException {
		waitForPageLoad(CustomerSeparateAppObj.WidgetInfos.DIV_PHONES, 5);
		if (CustomerSeparateAppObj.WidgetInfos.DIV_PHONES.exists()) {
			WebElement phonesData = getWebDriverInstance().findElement(By.xpath("//div[@id='clientOnePhones']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr[1]/td[3]"));
			phonesData.click();
			CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEPHONE.click();
		}

	}
	
	
	/**
	 * Move data in separate customer page from customer one to customer two.
	 * @throws ScriptException
	 * @param coreWidget
	 * @param prop
	 * @param button
	 * @param tableName
	 * @param buttonName 
	 */
	
	/**
	 * Move Email data in separate customer page.
	 * @throws ScriptException
	 */
public void moveEmailsData() throws ScriptException {
		waitForTime(3);
		if (CustomerSeparateAppObj.WidgetInfos.DIV_EMAILS.exists()) {
			WebElement emailsData = getWebDriverInstance().findElement(By.xpath("//div[@id='clientOneEmails']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr[1]/td[3]"));
			emailsData.click();
			CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEEMAIL.click();
		}

	}
	/**
	 * Move Address data in separate customer page.
	 * @throws ScriptException
	 */




	/**
	 * Move Driver License data in separate customer page.
	 * @throws ScriptException
	 */


	/**
	 * Click SSN move button for customer one in separate customer page.
	 */
		
	public void moveSSNToCustomerOne() {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.BUTTON_CANCELBUTTON.exists()) {
				click(CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONESSN,
						MessageUtility.BUTTON_CUSTONESSN);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}

	}
	/**
	 * Click SSN move button for customer Two in separate customer page.
	 */
		
	public void moveSSNToCustomerTwo() {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.BUTTON_CANCELBUTTON.exists()) {
				click(CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTTWOSSN,
						MessageUtility.BUTTON_CUSTTWOSSN);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}

	}
	/**
	 * Click SIN move button for customer one in separate customer page.
	 */
	
	public void moveSINToCustomerOne() throws ScriptException {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.BUTTON_CANCELBUTTON.exists()) {
				click(CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONESIN,
						MessageUtility.BUTTON_CUSTONESIN);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * Click SIN move button for customer Two in separate customer page.
	 */
	public void moveSINToCustomerTwo() throws ScriptException {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.BUTTON_CANCELBUTTON.exists()) {
				click(CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTTWOSIN,
						MessageUtility.BUTTON_CUSTTWOSIN);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * Enter SIN for customer Two in separate customer page.
	 */
	public void setSINToCustomerTwo() {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.TEXT_NEWCLIENTSIN.exists()) {
				setTextInTextbox(CustomerSeparateAppObj.WidgetInfos.TEXT_NEWCLIENTSIN,
						clientE2ETO.getSINCustomerTwo(),
						MessageUtility.BUTTON_CUSTTWOSIN_VALUE);

			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	
	/**
	 * Enter Birth Date for customer One in separate customer page.
	 */
	public void setBirthDateToCustomerOne() {

		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTBIRTHDATE.exists()) {
				setTextInTextbox(
						CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTBIRTHDATE,
						clientE2ETO.getBirthDateCustomerOne(),
						MessageUtility.CUSTONE_BIRTHDATE_VALUE);
			}
		} catch (ScriptException e) {
			scriptError(e);

		}

	}
	/**
	 * Enter Birth Date for customer Two in separate customer page.
	 */
		
	public void setBirthDateToCustomerTwo() {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.TEXT_NEWCLIENTBIRTHDATE.exists()) {
				setTextInTextbox(
						CustomerSeparateAppObj.WidgetInfos.TEXT_NEWCLIENTBIRTHDATE,
						clientE2ETO.getBirthDateCustomerTwo(),
						MessageUtility.CUSTTWO_BIRTHDATE_VALUE);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * Launch Verify Info Page from separate customer page.
	 * @throws ScriptException
	 */
	public void launchVerifInfoPage() throws ScriptException {
		waitForTime(3);
		if (CustomerSeparateAppObj.WidgetInfos.LINK_NEXT.exists()) {
			click(CustomerSeparateAppObj.WidgetInfos.LINK_NEXT,
					MessageUtility.LINK_NEXT);
		} else {
			Verify.verifyTrue(false, "Next Link not available");
		}
	}
	/**
	 * validate Client One Account&Policies Table.
	 * @throws ScriptException
	 */
	public void validateVerifyPageClientOneAccountPoliciesTables()
	throws ScriptException {

try {

	waitForTime(3);
	String header = "";
	String row = "";
	String formatter = "                             || ";
	String border = "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

	String borderHeader = "==========================================================================================================================================================================================================================================================================================================================";

	int rowCount = 0;
	int count = 0;
	int columncount = 0;

	if (VerifyTheFollowingAppObj.WidgetInfos.DIV_CUSTOMERONE_ACCOUNT_POLICIES.exists()) {

		int c = 1;
		while (true) {
			try {
				String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneagreements']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
						+ c + "]/td[3]"))
						.getText();
				rowCount++;
				c++;
			} catch (Exception e) {
				break;
			}
		}
		if (rowCount >= 1) {
			columncount = 10;
			String[] s = { "Line", "Role", "Name", "Acct/Pol Number",
					"Description", "From", "To", "Address" };
			for (int i = 0; i < s.length; i++) {
				header += s[i].trim()
						+ formatter.substring(s[i].length());
			}

			resultsFile
					.write("\r\n  *  Verify info ClientOne  Accounts-Policies table  \r\n");
			resultsFile.write(border.substring(0, header.length())
					+ " \r\n");
			resultsFile.write(header + "\r\n");
			resultsFile
					.write(borderHeader.substring(0, header.length())
							+ "\r\n");
			while (count < rowCount) {

				for (int i = 3; i <= columncount; i++) {
					try {
						cellsData = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneagreements']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
								+ (count + 1)
								+ "]/td["
								+ i
								+ "]"))
								.getText();
						if (cellsData.length() < (formatter.length() - 4)) {
							row += cellsData
									+ formatter.substring(cellsData
											.length());
						} else {
							row += cellsData.substring(0,
									formatter.length() - 3)
									+ "|| ";
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				resultsFile.write(row + "\r\n");
				row = "";
				count += 1;

			}
			count = 0;
			resultsFile.write(border.substring(0, header.length())
					+ "\r\n\r\n");
			Verify.verifyTrue(true,
					MessageUtility.CLIENTONEACCOUNTSPOLICIESTABLE_DISPLAYED);
		} else {
			Verify.verifyTrue(true, MessageUtility.ACCOUNTSPOLICIESTABLE_CLIENTONE);
		}
		header = "";
		row = "";

	} else {
		Verify.verifyTrue(false, MessageUtility.CLIENTONEACCOUNTSPOLICIESTABLE_NOTDISPLAYED);
	}

} catch (IOException i) {
	Verify.verifyTrue(false, i.getMessage());
}
}
	/**
	 * validate Client Two Account&Policies Table.
	 * @throws ScriptException
	 */
	public void validateVerifyPageClientTwoAccountPoliciesTables()
	throws ScriptException {

try {

	String header = "";
	cellsData = "";
	String row = "";
	String formatter = "                                || ";
	String border = "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

	String borderHeader = "===========================================================================================================================================================================================================================================================================================================================";

	int rowCount = 0;
	int count = 0;
	int columncount = 0;

	if (VerifyTheFollowingAppObj.WidgetInfos.DIV_CUSTOMERTWO_ACCOUNT_POLICIES.exists()) {

		int c = 1;
		while (true) {
			try {
				String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoagreements']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
						+ c + "]/td[3]"))
						.getText();
				rowCount++;
				c++;
			} catch (Exception e) {
				break;
			}
		}
		if (rowCount >= 1) {
			columncount = 10;
			String[] s = { "Line", "Role", "Name", "Acct/Pol Number",
					"Description", "From", "To", "Address" };
			for (int i = 0; i < s.length; i++) {

				header += s[i].trim()
						+ formatter.substring(s[i].length());
			}
			resultsFile
					.write("\r\n  *  Verify info  ClientTwo   Accounts-Policies table  \r\n");
			resultsFile.write(border.substring(0, header.length())
					+ " \r\n");
			resultsFile.write(header + "\r\n");
			resultsFile
					.write(borderHeader.substring(0, header.length())
							+ "\r\n");
			while (count < rowCount) {
				for (int i = 3; i <= columncount; i++) {
					try {
						cellsData = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoagreements']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
								+ (count + 1)
								+ "]/td["
								+ i
								+ "]"))
								.getText();
						if (cellsData.length() < (formatter.length() - 4)) {
							row += cellsData
									+ formatter.substring(cellsData
											.length());
						} else {
							row += cellsData.substring(0,
									formatter.length() - 3)
									+ "|| ";
						}
					} catch (Exception e) {

						e.printStackTrace();
					}
				}
				resultsFile.write(row + "\r\n");
				row = "";
				count += 1;
			}
			count = 0;
			resultsFile.write(border.substring(0, header.length())
					+ "\r\n\r\n");
			Verify.verifyTrue(true,
					MessageUtility.CLIENTTWOACCOUNTSPOLICIESTABLE_DISPLAYED);
		} else {
			Verify.verifyTrue(true,
					MessageUtility.ACCOUNTSPOLICIESTABLE_CLIENTTWO);
		}
		header = "";
		row = "";
	} else {
		Verify.verifyTrue(false,
				MessageUtility.CLIENTTWOACCOUNTSPOLICIESTABLE_NOTDISPLAYED);
	}

} catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
}
}
	/**
	 * Close result file.
	 * @param msg
	 */
	public void closeResultFile(String msg) {
		resultsFile = null;
	}
	
	/**
	 * Move customer one name to customer two in separate customer page.
	 * @throws ScriptException
	 */

public void moveCustomerNameOne1() throws ScriptException {
		
		waitForPageLoad(CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEALLNAME, 5);
		if (CustomerSeparateAppObj.WidgetInfos.TABLE_MOVECLIENTONEALLNAMES.exists()) {
			WebElement namesData = getWebDriverInstance().findElement(By.xpath("//div[@id='clientOneAllNames']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr[1]/td[3]"));
			namesData.click();
			CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEALLNAME.click();
		} else {
			Verify.verifyTrue(false, MessageUtility.CUSTNAMES_NOTAVAILABLE);
		}

	}

	/**
	 * Verify Client One Drivers License table.
	 * @throws ScriptException
	 */
public void verifyClientOneDriversLicenseTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.DIV_DRI_LIC.exists()) {
			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneDriversLicenses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]"))
							.getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}
			if (rowCount >= 1) {
				columnCount = 5;
				header = " Type                                 || Number                                || Location                              || ";
				resultsFile
						.write("\r\n  *  Verify info ClientOne  driverLicense table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneDriversLicenses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
										+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTONEDRIVERLICENSETABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,MessageUtility.DRIVERLICENSETABLE_CLIENTONE);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CLIENTONEDRIVERLICENSETABLE_NOTDISPLAYED);
		}

	} catch (IOException i) {
			Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client One Email table.
	 * @throws ScriptException
	 */
public void verifyClientOneEmailsTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.DIV_EMAILS.exists()) {

			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneEmails']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]")).getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}
			if (rowCount >= 1) {
				header = "Email                                 ||";
				columnCount = 4;
				resultsFile
						.write("\r\n  *  Verify info ClientOne  Emails table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str =  getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneEmails']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
								+ (count + 1) + "]/td[" + i + "]")).getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTONEEMAILSTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.EMAILSTABLE_CLIENTONE);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false, MessageUtility.CLIENTONEEMAILSTABLE_NOTDISPLAYED);
		}

	} catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client One names table.
	 * @throws ScriptException
	 */
public void verifyClientOneNamesTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.TABLE_MOVECLIENTONEALLNAMES.exists()) {
			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneAllNames']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]")).getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}
			if (rowCount >= 1) {
				header = "Names                                 || ";
				columnCount = 3;
				resultsFile
						.write("\r\n  *  Verify info ClientOne  Names table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneAllNames']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
								+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTONENAMESTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.NAMESTABLE_CLIENTONE);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false, MessageUtility.CLIENTONENAMESTABLE_NOTDISPLAYED);
		}

	} catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client One Non Policy Address table.
	 * @throws ScriptException
	 */
public void verifyClientOneNonPolicyAddressTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.DIV_NON_POLICY.exists()) {

			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneOtherAddresses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]"))
							.getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}
			if (rowCount >= 1) {
				header = "Address                               || ";
				columnCount = 3;
				resultsFile
						.write("\r\n  *  Verify info  ClientOne PolicyAddress table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOneOtherAddresses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
								+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTONEPOLICYADDRESSTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.POLICYADDRESSTABLE_CLIENTONE);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CLIENTONEPOLICYADDRESSTABLE_NOTDISPLAYED);
		}

	} catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client One Phone table.
	 * @throws ScriptException
	 */
public void verifyClientOnephonesTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.DIV_PHONES.exists()) {
			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOnePhones']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]"))
							.getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}
			if (rowCount >= 1) {
				header = "Usage                                 || Number                                || Extn/PIN                              || Type                                  || ";
				columnCount = 5;
				resultsFile
						.write("\r\n  *  Verify info ClientOne  phones table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientOnePhones']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
										+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTONEPHONESTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.PHONESTABLE_CLIENTONE);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false, MessageUtility.CLIENTONEPHONESTABLE_NOTDISPLAYED);
		}

	} catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client Two Drivers License table.
	 * @throws ScriptException
	 */
public void verifyClientTwoDriversLicenseTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.DIV_DRI_LIC2.exists()) {
			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoDriversLicenses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]"))
							.getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}
			if (rowCount >= 1) {
				header = " Type                                 || Number                                || Location                              || ";
				columnCount = 5;
				resultsFile
						.write("\r\n  *  Verify info ClientTwo  driverLicense table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoDriversLicenses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
										+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTTWODRIVERLICENSETABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.DRIVERLICENSETABLE_CLIENTTWO);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CLIENTTWODRIVERLICENSETABLE_NOTDISPLAYED);
		}

	} catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client Two Email table.
	 * @throws ScriptException
	 */
public void verifyClientTwoEmailsTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.DIV_EMAILS2.exists()) {
			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoEmails']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]"))
							.getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}
			columnCount = 4;

			if (rowCount >= 1) {
				header = "Email                                 ||";
				columnCount = 4;
				resultsFile
						.write("\r\n  *  Verify info ClientTwo  Emails table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoEmails']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
										+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTTWOEMAILSTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.EMAILSTABLE_CLIENTTWO);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false, MessageUtility.CLIENTTWOEMAILSTABLE_NOTDISPLAYED);
		}

	}catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client Two name table.
	 * @throws ScriptException
	 */
public void verifyClientTwoNamesTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.TABLE_MOVECLIENTONEALLNAMES2.exists()) {
			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoAllNames']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]"))
							.getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}

			if (rowCount >= 0) {

				header = "Names                                 || ";
				columnCount = 3;
				resultsFile
						.write("\r\n  *  Verify info ClientTwo  Names table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoAllNames']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
										+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTTWONAMESTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.NAMESTABLE_CLIENTTWO);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false, MessageUtility.CLIENTTWONAMESTABLE_NOTDISPLAYED);
		}

	} catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client Two Non Policy Address table.
	 * @throws ScriptException
	 */
public void verifyClientTwoNonPolicyAddressTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.DIV_NON_POLICY2.exists()) {
			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoOtherAddresses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]"))
							.getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}

			if (rowCount >= 1) {
				header = "Address                               ||";
				columnCount = 3;
				resultsFile
						.write("\r\n  *  Verify info  ClientTwo PolicyAddress table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoOtherAddresses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
										+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTTWOPOLICYADDRESSTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.POLICYADDRESSTABLE_CLIENTTWO);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CLIENTTWOPOLICYADDRESSTABLE_NOTDISPLAYED);
		}

	}catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Verify Client Two phone table.
	 * @throws ScriptException
	 */
public void verifyClientTwophonesTable() throws ScriptException {

	try {

		String header = "";
		String row = "";
		String formatter = "                                      || ";
		String border = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

		String borderHeader = "========================================================================================================================================================================================";

		int rowCount = 0;
		int count = 0;
		int columnCount = 0;

		if (CustomerSeparateAppObj.WidgetInfos.DIV_PHONES2.exists()) {
			int c = 1;
			while (true) {
				try {
					String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoPhones']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
									+ c + "]/td[3]"))
							.getText();
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}

			if (rowCount >= 1) {
				header = "Usage                                 || Number                                || Extn/PIN                              || Type                                  || ";
				columnCount = 5;
				resultsFile
						.write("\r\n  *  Verify info ClientTwo  phones table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile
						.write(borderHeader.substring(0, header.length())
								+ "\r\n");
				while (count < rowCount) {
					for (int i = 3; i <= columnCount; i++) {
						String str = getWebDriverInstance().findElement(By.xpath("xpath=//div[@id='clientTwoPhones']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
										+ (count + 1) + "]/td[" + i + "]"))
								.getText();
						if (str != null) {
							cellsData = str;
							if (cellsData.length() < (formatter.length() - 3)) {
								row += cellsData
										+ formatter.substring(cellsData
												.length());
							} else {

								row += cellsData.substring(0,
										formatter.length() - 3)
										+ "|| ";
							}
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.CLIENTTWOPHONESTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.PHONESTABLE_CLIENTTWO);
			}
			header = "";
			row = "";
		} else {
			Verify.verifyTrue(false, MessageUtility.CLIENTTWOPHONESTABLE_NOTDISPLAYED);
		}

	} catch (IOException i) {
		Verify.verifyTrue(false, i.getMessage());
	}
}
	/**
	 * Click separate button in verify info page.
	 * @throws ScriptException
	 */
	public void clickSeparateButton() throws ScriptException {
		waitForPageLoad(VerifyTheFollowingAppObj.WidgetInfos.BUTTON_SEPARATE, 15);
		if (VerifyTheFollowingAppObj.WidgetInfos.BUTTON_SEPARATE.exists()) {
			click(VerifyTheFollowingAppObj.WidgetInfos.BUTTON_SEPARATE,
					MessageUtility.BUTTON_SEPARATE_CLICKED);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_SEPARATE_NOTFOUND);
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CANCEL.exists()) {
				Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CANCEL.click();
			}
		}
	}
	/**
	 * verify Customer one information should include SSN only and 
	 * Customer Two information displayed without SSN and SIN in verify info page.
	 * @throws ScriptException
	 */
	public void verifyInfoPageUSSSNOnlyCustomerOne() throws ScriptException {
		if (isSeparateCustomerPageExists()) {
			WebElement custOneInfo = getWebDriverInstance().findElement(By.xpath("//div[@class='threeColumnPage1 columnWidth45Percent']"));
			if (custOneInfo.getText().contains("US SSN:")
					&& !(custOneInfo.getText().contains("CN SIN:"))) {
				Verify.verifyTrue(true,
						MessageUtility.CUSTONE_SSN);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTONE_SSN_NOTFOUND);
			}

			WebElement custTwoInfo = getWebDriverInstance().findElement(By.xpath("//div[@class='threeColumnPage3 columnWidth45Percent']"));
			if (!(custTwoInfo.getText().contains("US SSN:") && custTwoInfo.getText().contains("CN SIN:")))
			{
				Verify.verifyTrue(true,
						MessageUtility.CUSTTWO_SSNSIN_NOTDISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTTWO_SSNSIN_DISPLAYED);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
		}

	}
	/**
	 * verify Customer one information should include SSN only in verify info page.
	 * @throws ScriptException
	 */
	public void verifyInfoPageUSSSNCustomerOne() throws ScriptException {
		if (isSeparateCustomerPageExists()) {
			WebElement custOneInfo = getWebDriverInstance().findElement(By.xpath("//div[@class='threeColumnPage1 columnWidth45Percent']"));
			if (custOneInfo.getText().contains("US SSN:")) {
				Verify.verifyTrue(true,
						MessageUtility.CUSTONE_SSN);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTONE_SSN_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
		}
	}
	/**
	 * verify Customer Two information is displayed with US SSN in verify info page.
	 * @throws ScriptException
	 */
	public void verifyInfoPageUSSSNCustomerTwo() throws ScriptException {
		if (isSeparateCustomerPageExists()) {
			WebElement custTwoInfo = getWebDriverInstance().findElement(By.xpath("//div[@class='threeColumnPage3 columnWidth45Percent']"));
			if (custTwoInfo.getText().contains("US SSN:")) {
				Verify.verifyTrue(true,
						MessageUtility.CUSTTWO_SSNSIN_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.CUSTTWO_SSNSIN_NOTDISPLAYED);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
		}
	}
	/**
	 * verify Customer one information should include SIN only and
	 * Customer Two information displayed without SSN and SIN in verify info page.
	 * @throws ScriptException
	 */

	public void verifyInfoPageCNSINOnlyCustomerOne() throws ScriptException {
			if (isSeparateCustomerPageExists()) {
				WebElement custOneInfo = getWebDriverInstance().findElement(By.xpath("//div[@class='threeColumnPage1 columnWidth45Percent']"));
				if ((custOneInfo.getText().contains("CN SIN:") && !(custOneInfo.getText()
						.contains("US SSN:")))) {
					Verify.verifyTrue(true,
							MessageUtility.CUSTONE_SIN);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTONE_SIN_NOTFOUND);
				}

				WebElement custTwoInfo = getWebDriverInstance().findElement(By.xpath("//div[@class='threeColumnPage3 columnWidth45Percent']"));
				if (!(custTwoInfo.getText().contains("US SSN:") && custTwoInfo.getText().contains("CN SIN:")))
					 {
					Verify.verifyTrue(true,
							MessageUtility.CUSTTWO_SSNSIN_NOTDISPLAYED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTTWO_SSNSIN_DISPLAYED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
			}
		}
	/**
	 * verify Customer one information should include SIN only in verify info page.
	 * @throws ScriptException
	 */

	public void verifyInfoPageCNSINCustomerOne() throws ScriptException {
			if (isSeparateCustomerPageExists()) {
				WebElement custOneInfo = getWebDriverInstance().findElement(By.xpath("//div[@class='threeColumnPage1 columnWidth45Percent']"));
				if ((custOneInfo.getText().contains("CN SIN:"))) {
					Verify.verifyTrue(true,
							MessageUtility.CUSTONE_SIN);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTONE_SIN_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
			}
		}
	/**
	 * verify Customer Two information displayed with SIN in verify info page.
	 * @throws ScriptException
	 */
	public void verifyInfoPageCNSINCustomerTwo() throws ScriptException {
		if (isSeparateCustomerPageExists()) {
			WebElement custTwoInfo = getWebDriverInstance().findElement(By.xpath("//div[@class='threeColumnPage3 columnWidth45Percent']"));
			if (custTwoInfo.getText().contains("CN SIN:")) {
				Verify.verifyTrue(true,
						MessageUtility.CUSTTWO_SIN);
			} else {
				Verify.verifyTrue(true,
						MessageUtility.CUSTTWO_SIN_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
		}
	}
	/**
	 * Enter TIN To Customer One in separate customer page.
	 * @throws ScriptException
	 */
	public void setTINToCustomerOne() throws ScriptException {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTTIN.exists()) {
				setTextInTextbox(CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTTIN,
						clientE2ETO.gettINCustomerOne(),
						MessageUtility.CUSTONE_TIN);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * Enter TIN To Customer Two in separate customer page.
	 * @throws ScriptException
	 */
	public void setTINToCustomerTwo() throws ScriptException {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.TEXT_NEWCLIENTTIN.exists()) {
				setTextInTextbox(CustomerSeparateAppObj.WidgetInfos.TEXT_NEWCLIENTTIN,
						clientE2ETO.gettINCustomerTwo(),
						MessageUtility.CUSTTWO_TIN);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	/**
	 * Search for a customer from Search and Select One Customer page for support write.
	 * @throws ScriptException
	 */
	public void accessNonAgentSS1CPageIndividual() throws ScriptException {
		waitForTime(3);
		if (CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.SEPARATECUSTOMERSPAGE_LAUNCHED);
			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBY_TYPE_ENTERPRISENA,
					MessageUtility.RADIOBUTTON_SEARCHBYTYPE);
			selectRadioButton(
					CWNonAgentCSObjects.WidgetInfos.RADIOBUTTON_ENTERPRISE_NAME_SEARCH_IND,
					MessageUtility.RADIOBUTTON_ENTERPRISENAMESEARCH);
			if (clientE2ETO.getLastNameSearchpage_sept() != null)
				enterMandatoryfieldtoEnablebutton(
						CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_LASTNAME,
						clientE2ETO.getLastNameSearchpage_sept());
			if (clientE2ETO.getFirstNameSearchpage_sept() != null)
				CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_FIRSTNAME
						.setText(clientE2ETO.getFirstNameSearchpage_sept());
			if (clientE2ETO.getZipSearchPage_sept() != null)
				CWNonAgentCSObjects.WidgetInfos.TEXT_ENTERPRISE_NAMESEARCH_ZIP
						.setText(clientE2ETO.getZipSearchPage_sept());
			if (clientE2ETO.getStateSearchPage_sept() != null)
				selectFromListbox(
						CWNonAgentCSObjects.WidgetInfos.LIST_ENTERPRISENAMESEARCHCRIT_STATE,
						clientE2ETO.getStateSearchPage_sept(),
						MessageUtility.STATE);
			if (CWNonAgentCSObjects.WidgetInfos.BUTTON_SEARCH.exists()) {
				click(CWNonAgentCSObjects.WidgetInfos.BUTTON_SEARCH,
						MessageUtility.BUTTON_SEARCH);
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
		}
	}
	/**
	 * Search for a customer from Search and Select One Customer page for Agent.
	 * @throws ScriptException
	 */
	public void accessAgentSS1CustomerPage() throws ScriptException {
		waitForTime(3);
		if (CWAgentCSObjects.WidgetInfos.TEXT_AGENTNAME_SEARCH_LASTNAME.exists()) {
			if (clientE2ETO.getOrgName() != null) {
				{
					selectRadioButton(
							CWAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBYTYPE_AGENTNAME,
							MessageUtility.RADIOBUTTON_SEARCHBYTYPE);
				}
				enterMandatoryfieldtoEnablebutton(
						CWAgentCSObjects.WidgetInfos.TEXT_AGENTNAME_SEARCH_LASTNAME,
						clientE2ETO.getOrgName());
				click(CWAgentCSObjects.WidgetInfos.BUTTON_AGENT_SEARCH,
						MessageUtility.RADIOBUTTON_ENTERPRISENAMESEARCH);
			} else {
				if (CWAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBYTYPE_AGENTNAME
						.exists()) {
					{
						selectRadioButton(
								CWAgentCSObjects.WidgetInfos.RADIOBUTTON_SEARCHBYTYPE_AGENTNAME,
								MessageUtility.RADIOBUTTON_SEARCHBYTYPE);
					}
					if (clientE2ETO.getLastNameSearchpage_sept() != null) {
						enterMandatoryfieldtoEnablebutton(
								CWAgentCSObjects.WidgetInfos.TEXT_AGENTNAME_SEARCH_LASTNAME,
								clientE2ETO.getLastNameSearchpage_sept());
					}
					if (clientE2ETO.getFirstNameSearchpage_sept() != null) {
						CWAgentCSObjects.WidgetInfos.TEXT_AGENTNAME_SEARCH_FIRSTNAME
								.setText(clientE2ETO
										.getFirstNameSearchpage_sept());
					}
					if (clientE2ETO.getZipSearchPage_sept() != null) {
						CWAgentCSObjects.WidgetInfos.TEXT_AGENTNAME_SEARCH_ZIP
								.setText(clientE2ETO.getZipSearchPage_sept());
					}
					if (CWAgentCSObjects.WidgetInfos.BUTTON_AGENT_SEARCH.exists()) {
						click(CWAgentCSObjects.WidgetInfos.BUTTON_AGENT_SEARCH,
								MessageUtility.BUTTON_SEARCH);
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
				}

			}
		}
	}
	/**
	 * Select searched customer from Select One Customer page for Agent.
	 * @throws ScriptException
	 * @return
	 */
	public boolean searchAndSelectCustFromTable(String customerSearchPage)
	throws ScriptException {

		boolean flag = false;
		waitForTime(2);
		try {
			getWebDriverInstance().findElement(By.xpath("//td[contains(text(),'" + customerSearchPage					
					+ "')]")).click();
			flag = true;
			Verify.verifyTrue(true, customerSearchPage + MessageUtility.CUSTOMER_FOUND);
		} catch (Exception e) { 
			flag = true;
			Verify.verifyTrue(false, MessageUtility.CUSTOMER_NOTFOUND);
		}
		return flag;
	}
	/**
	 * Verify Search and Select One Customer page Launched or not.
	 * @throws ScriptException
	 * @return
	 */
	public boolean isSearchandSelectOneCustomerPageExists()
			throws ScriptException {
		waitForTime(3);
		if (SearchSelectCustomerAppObj.WidgetInfos.BUTTON_SEARCH.exists()) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * Verify Separate Customer Page Launched or not.
	 * @throws ScriptException
	 * @return
	 */
	public boolean isMoveCustomerInfoPageExists() throws ScriptException {
		waitForTime(5);
		if (SearchSelectCustomerAppObj.WidgetInfos.DIV_PAGE_MOVE_DATA.exists()) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * Verify Separate Customer Page Launched or not.
	 * @throws ScriptException
	 * @return
	 */
	public boolean isSeparateCustomerPageExists() throws ScriptException {
		waitForTime(3);
		if (SearchSelectCustomerAppObj.WidgetInfos.DIV_SEPARATE_CUSTOMER_PAGE.exists()) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * step1:search and select customer from Search and Select One Customer page.
	 * step2:move data from customer one to customer two in separate customer page and launch verify info page.
	 * step3:click separate button from verify info page 
	 */
	public void separateCustomer() {
		boolean flag = false;
		try {
			selectSS1CCustomerOneFromMCLB();
			launchSeparateCustomerPage();
			isErrorPage("MoveCustomerInfoPage");
			if (isMoveCustomerInfoPageExists()) {
				moveCustomerNameOne1();
				movePhonesData();
				moveEmailsData();
				moveNonPolicyAddressData();
				moveDriverLicenseData();
				setSSNToCustomerOne();
				setSSNToCustomerTwo();
				launchVerifInfoPage();
				if (isSeparateCustomerPageExists()) {
					clickSeparateButton();
					if (isHHPageLaunched()) {
						flag = true;
						Verify.verifyTrue(true,
								MessageUtility.HOUSEHOLDPAGE_LAUNCHED);
					} else {
						verifyConflictAndContinueToHHPage();
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.MOVEDATACUSTSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		} finally {
			if (!flag) {
				clickHHPageCustomer();
				handleCimsVersion();
			}
		}
	}
	
	public void moveNonPolicyAddressData() throws ScriptException {
		waitForPageLoad(CustomerSeparateAppObj.WidgetInfos.BUTTON_CANCELBUTTON, 5);
		if (CustomerSeparateAppObj.WidgetInfos.DIV_NON_POLICY.exists()) {
			WebElement nonPolicyAddressesData = getWebDriverInstance().findElement(By.xpath("//div[@id='clientOneOtherAddresses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr[1]/td[3]"));
			nonPolicyAddressesData.click();
			CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEOTHERADDRESS.click();
		}

	}
	public void moveDriverLicenseData() throws ScriptException {
		waitForPageLoad(CustomerSeparateAppObj.WidgetInfos.BUTTON_CANCELBUTTON, 5);
		if (CustomerSeparateAppObj.WidgetInfos.DIV_DRI_LIC.exists()) {
			WebElement driverLicensesData = getWebDriverInstance().findElement(By.xpath("//div[@id='clientOneDriversLicenses']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr[1]/td[3]"));
			driverLicensesData.click();
			CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEDRIVERSLICENSE.click();
		}

	}
	/**
	 * Enter or move SSN/SIN/BIRTHDATE for customer one and two in separate customer page.
	 * @param ab
	 */
	public void separateCustomerWithUSSSNCNSINValues(String ab) {
		try {
			selectSS1CCustomerOneFromMCLB();
			launchSeparateCustomerPage();
			isErrorPage("MoveCustomerInfoPage");
			if (isMoveCustomerInfoPageExists()) {
				moveCustomerNameOne1();
				if (ab.equalsIgnoreCase("moveSSN")) {
					setSSNToCustomerOne();
					setSSNToCustomerTwo();
					setBirthDateToCustomerOne();
					setBirthDateToCustomerTwo();
					launchVerifInfoPage();
					checkErrorMessage();
					clickPreviousLink();
					waitForTime(2);
					selectSS1CCustomerOneFromMCLB();
					launchSeparateCustomerPage();
					moveCustomerNameOne1();
					moveSSNToCustomerOne();
					setBirthDateToCustomerOne();
					setBirthDateToCustomerTwo();
					launchVerifInfoPage();
					verifyInfoPageUSSSNOnlyCustomerOne();
				}
				if (ab.equalsIgnoreCase("moveSIN")) {
					moveSINToCustomerOne();
					setBirthDateToCustomerOne();
					setBirthDateToCustomerTwo();
					launchVerifInfoPage();
					verifyInfoPageCNSINOnlyCustomerOne();
				}
				if (ab.equalsIgnoreCase("moveSSNSIN")) {
					moveSSNToCustomerOne();
					setSINToCustomerTwo();
					launchVerifInfoPage();
					verifyInfoPageUSSSNCustomerOne();
					verifyInfoPageCNSINCustomerTwo();
				}
				if (ab.equalsIgnoreCase("newSSN")) {
					moveSSNToCustomerOne();
					setSSNToCustomerTwo();
					launchVerifInfoPage();
					verifyInfoPageUSSSNCustomerOne();
					verifyInfoPageUSSSNCustomerTwo();
				}
				if (ab.equalsIgnoreCase("newSIN")) {
					moveSINToCustomerOne();
					setSINToCustomerTwo();
					launchVerifInfoPage();
					verifyInfoPageCNSINCustomerOne();
					verifyInfoPageCNSINCustomerTwo();
				}
				if (ab.equalsIgnoreCase("newSSNSIN")) {
					setSSNToCustomerOne();
					moveSSNToCustomerTwo();
					setSINToCustomerOne();
					setSINToCustomerTwo();
					launchVerifInfoPage();
					verifyInfoPageUSSSNCustomerOne();
					verifyInfoPageUSSSNCustomerTwo();
					verifyInfoPageCNSINCustomerOne();
					verifyInfoPageCNSINCustomerTwo();
				}
				if (isSeparateCustomerPageExists()) {
					clickSeparateButton();

					if (isHHPageLaunched()) {
						Verify.verifyTrue(true,
								MessageUtility.HOUSEHOLDPAGE_LAUNCHED);
					} else {
						verifyConflictAndContinueToHHPage();
						clickHHPageCustomer();
						handleCimsVersion();
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
					clickHHPageCustomer();
					handleCimsVersion();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.MOVEDATACUSTSEARCHPAGE_NOTLAUNCHED);
				clickHHPageCustomer();
				handleCimsVersion();
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception i) {
			Verify.verifyTrue(false, i.getMessage());
		}
	}

	/**
	 * step1:search and select customer from Search and Select One Customer page and launch separate customer page.
	 * step2:move data from customer one to customer two in separate customer page and launch verify info page.
	 * step3:Enter or move SSN/SIN/BIRTHDATE for customer one and two in separate customer page.
	 */
	public void setAndValidateSeparateCustomerPageOne() {
		try {
			selectSS1CCustomerOneFromMCLB();
			launchSeparateCustomerPage();
			isErrorPage("MoveCustomerInfoPage");
			if (isMoveCustomerInfoPageExists()) {
				moveCustomerNameOne1();
				movePhonesData();
				moveEmailsData();
				moveNonPolicyAddressData();
				moveDriverLicenseData();
				if (CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTSSN.exists()
						&& CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTSIN
								.exists()) {
					setSSNToCustomerOne();
					setSSNToCustomerTwo();
					setSINToCustomerOne();
					setSINToCustomerTwo();
					setBirthDateToCustomerOne();
					setBirthDateToCustomerTwo();
				} else {
					setTINToCustomerOne();
					setTINToCustomerTwo();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.MOVEDATACUSTSEARCHPAGE_NOTLAUNCHED);
				clickHHPageCustomer();
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception i) {
			Verify.verifyTrue(false, i.getMessage());
		}
	}
	/**
	 * verify Customer one and two Name/Email/NonPolicyAddress/phones/DriversLicense Tables in Separate Customer Page.
	 */
	public void verifyCustomersTablesinSeparateCustomerPageOne() {
		try {
			if (isMoveCustomerInfoPageExists()) {
				verifyClientOneEmailsTable();
				verifyClientOneNamesTable();
				verifyClientOneNonPolicyAddressTable();
				verifyClientOnephonesTable();
				if (CustomerSeparateAppObj.WidgetInfos.DIV_DRI_LIC.exists()) {
					verifyClientOneDriversLicenseTable();
					verifyClientTwoDriversLicenseTable();
				}
				verifyClientTwoEmailsTable();
				verifyClientTwoNamesTable();
				verifyClientTwoNonPolicyAddressTable();
				verifyClientTwophonesTable();
				launchVerifInfoPage();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.MOVEDATACUSTSEARCHPAGE_NOTLAUNCHED);
				clickHHPageCustomer();
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}  catch (Exception i) {
			Verify.verifyTrue(false, i.getMessage());
		}
	}
	/**
	 * verify Customer one and two SSN/SIN/BirthDate/Account$Policies Tables in Separate Customer Page.
	 */
	public void validatePersonalInfoinSeparateCustomerPage() {
		try {
			if (isSeparateCustomerPageExists()) {
				validateSSNSINandBirthDateforCustomerOne();
				validateSSNSINandBirthDateforCustomerTwo();
				validateVerifyPageClientOneAccountPoliciesTables();
				validateVerifyPageClientTwoAccountPoliciesTables();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
				clickHHPageCustomer();
			}

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * verify Customer one and two TIN/Account$Policies Tables in Separate Customer Page.
	 */
	public void validateOrganizationInfoinSeparateCustomerPage() {
		try {
			if (isSeparateCustomerPageExists()) {
				validateTINforCustomerOneandTwo();
				validateVerifyPageClientOneAccountPoliciesTables();
				validateVerifyPageClientTwoAccountPoliciesTables();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
				clickHHPageCustomer();
			}

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Validate and click Print Additional Separate information link in Separate Customer Page.
	 */
	public void validatePrintAdditionalCustomerInformation() {
		try {
			if (isSeparateCustomerPageExists()) {
				if (SSNSINObjects.WidgetInfos.LINK_PRINT_ADDITIONAL_SEPARATE_INFO.exists()) {
					click(SSNSINObjects.WidgetInfos.LINK_PRINT_ADDITIONAL_SEPARATE_INFO,
							MessageUtility.LINK_PRINTADDITIONALSEPARATEINFO);
				} else
					Verify.verifyTrue(false,
							MessageUtility.LINK_PRINTADDITIONALSEPARATEINFO_NOTDISPLAYED);
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
			}

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Validate SSN/SIN and BirthDate for CustomerOne in Separate Customer Page.
	 */
	public void validateSSNSINandBirthDateforCustomerOne() {
		try {
			if (isSeparateCustomerPageExists()) {
				String verifySSN = null;
				WebElement element1 = getWebDriverInstance().findElement(By.xpath("//form[@name='separateClientVerifyForm']/fieldset/fieldset/div/div/div[@class='fieldToAlignPad36']/label")); 
				if (element1.isDisplayed())
					verifySSN = element1
							.getText();
				String unMaskedSSN = clientE2ETO.getSSNCustomerOne().substring(
						0, 3)
						+ "-"
						+ clientE2ETO.getSSNCustomerOne().substring(3, 5)
						+ "-" + clientE2ETO.getSSNCustomerOne().substring(5);
				if (verifySSN.contains(unMaskedSSN))
					Verify.verifyTrue(
							true, MessageUtility.CUSTONESSN_DISPLAYED);
				else
					Verify.verifyTrue(false,
							MessageUtility.CUSTONESSN_NOTDISPLAYED);

				String verifySIN = null;
				WebElement element2 = getWebDriverInstance().findElement(By.xpath("//form[@name='separateClientVerifyForm']/fieldset/fieldset/div/div[1]/div[3]/label")); 
				if (element2.isDisplayed())
					verifySIN = element2
							.getText();
				String unMaskedSIN = clientE2ETO.getSINCustomerOne().substring(
						0, 3)
						+ "-"
						+ clientE2ETO.getSINCustomerOne().substring(3, 5)
						+ "-" + clientE2ETO.getSINCustomerOne().substring(5);
				if (verifySIN.contains(unMaskedSIN))
					Verify.verifyTrue(
							true, MessageUtility.CUSTONESIN_DISPLAYED);
				else
					Verify.verifyTrue(false,
							 MessageUtility.CUSTONESIN_NOTDISPLAYED);

				String verifyBirthDate = null;
				WebElement element3 = getWebDriverInstance().findElement(By.xpath("//form[@name='separateClientVerifyForm']/fieldset/fieldset/div/div/div[@class='fieldToAlignPad32']/label")); 
				if (element3.isDisplayed())
					verifyBirthDate = element3
							.getText();
				String birthDate = clientE2ETO.getBirthDateCustomerOne();
				if (verifyBirthDate.contains(birthDate))
					Verify.verifyTrue(
							true, MessageUtility.CUSTONEBIRTHDATE_DISPLAYED);
				else
					Verify.verifyTrue(false,
							MessageUtility.CUSTONEBIRTHDATE_NOTDISPLAYED);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
				clickHHPageCustomer();
			}

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}  catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Validate SSN/SIN and BirthDate for Customer Two in Separate Customer Page.
	 */
	public void validateSSNSINandBirthDateforCustomerTwo() {
		try {
			if (isSeparateCustomerPageExists()) {
				String verifySSN = null;
				WebElement element1 = getWebDriverInstance().findElement(By.xpath("//form[@name='separateClientVerifyForm']/fieldset/fieldset/div/div[2]/div[2]/label")); //label[text()='US SSN:']
				
				if (element1.isDisplayed())
					verifySSN = element1.getText();
				String unMaskedSSN = clientE2ETO.getSSNCustomerTwo().substring(
						0, 3)
						+ "-"
						+ clientE2ETO.getSSNCustomerTwo().substring(3, 5)
						+ "-" + clientE2ETO.getSSNCustomerTwo().substring(5);
				if (verifySSN.contains(unMaskedSSN))
					Verify.verifyTrue(
							true, MessageUtility.CUSTTWOSSN_DISPLAYED);
				else
					Verify.verifyTrue(true, MessageUtility.CUSTTWOSSN_NOTDISPLAYED);

				String verifySIN = null;
				WebElement element2 = getWebDriverInstance().findElement(By.xpath("//form[@name='separateClientVerifyForm']/fieldset/fieldset/div/div[2]/div[3]/label"));
				if (element2.isDisplayed())
					verifySIN = element2.getText();
				String unMaskedSIN = clientE2ETO.getSINCustomerTwo().substring(
						0, 3)
						+ "-"
						+ clientE2ETO.getSINCustomerTwo().substring(3, 5)
						+ "-" + clientE2ETO.getSINCustomerTwo().substring(5);
				if (verifySIN.contains(unMaskedSIN))
					Verify.verifyTrue(
							true, MessageUtility.CUSTTWOSIN_DISPLAYED);
				else
					Verify.verifyTrue(false,
							MessageUtility.CUSTTWOSIN_NOTDISPLAYED);

				String verifyBirthDate = null;
				WebElement element3 = getWebDriverInstance().findElement(By.xpath("//form[@name='separateClientVerifyForm']/fieldset/fieldset/div/div[2]/div[4]/label"));
				if (element3.isDisplayed())
					verifyBirthDate = element3.getText();
				String birthDate = clientE2ETO.getBirthDateCustomerTwo();
				if (verifyBirthDate.contains(birthDate))
					Verify.verifyTrue(
							true, MessageUtility.CUSTTWOBIRTHDATE_DISPLAYED);
				else
					Verify.verifyTrue(false,
							MessageUtility.CUSTTWOBIRTHDATE_NOTDISPLAYED);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
				clickHHPageCustomer();
			}

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}  catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Validate TIN for Customer One and Two in Separate Customer Page.
	 */
	public void validateTINforCustomerOneandTwo() {
		try {
			if (isSeparateCustomerPageExists()) {
				String verifyTINOne = null;
				WebElement element1 = getWebDriverInstance().findElement(By.xpath("//form[@name='separateClientVerifyForm']/fieldset/fieldset/div/div[1]/div[2]/label"));
				if (element1.isDisplayed())
					verifyTINOne = element1.getText();
				String unMaskedTINOne = clientE2ETO.gettINCustomerOne()
						.substring(0, 2)
						+ "-"
						+ clientE2ETO.gettINCustomerOne().substring(2);
				if (verifyTINOne.contains(unMaskedTINOne))
					Verify.verifyTrue(
							true, MessageUtility.CUSTONETIN_DISPLAYED);
				else
					Verify.verifyTrue(false,
							MessageUtility.CUSTONETIN_NOTDISPLAYED);

				String verifyTINTwo = null;
				WebElement element2 = getWebDriverInstance().findElement(By.xpath("//form[@name='separateClientVerifyForm']/fieldset/fieldset/div/div[2]/div[2]/label"));
				if (element2.isDisplayed())
					verifyTINTwo = element2.getText();
				String unMaskedTINTwo = clientE2ETO.gettINCustomerTwo()
						.substring(0, 2)
						+ "-"
						+ clientE2ETO.gettINCustomerTwo().substring(2);
				if (verifyTINTwo.contains(unMaskedTINTwo))
					Verify.verifyTrue(
							true, MessageUtility.CUSTTWOTIN_DISPLAYED);
				else
					Verify.verifyTrue(false,
							 MessageUtility.CUSTTWOTIN_NOTDISPLAYED);

			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
				clickHHPageCustomer();
			}

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Validate Separate Function is successful or not.
	 */
	public void validateSeparateFunction() {
		try {
			if (isSeparateCustomerPageExists()) {
				clickSeparateButton();
				if (isHHPageLaunched()) {
					Verify.verifyTrue(true,
							MessageUtility.HOUSEHOLDPAGE_LAUNCHED);
				} else {
					verifyConflictAndContinueToHHPage();
					clickHHPageCustomer();
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
				clickHHPageCustomer();
			}

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * Verify Search and Select One Customer Search Page Not Launched for agent.
	 */
	public void verifySearchandSelectOneCustomerPage() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldTestObjects.WidgetInfos.CUSTOMER_LINK, HouseHoldTestObjects.WidgetInfos.LINK_CUSTOMER_UNDERCOMBINESEPARATE_CRC);
				if (isCustomerMaintanancePage()) {
					launchSS1CPageFromCMPage();
					if (isSearchandSelectOneCustomerPageExists()) {
						accessAgentSS1CustomerPage();

					} else {
						Verify.verifyTrue(false,
								MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTMAINTAINENCEPAGE_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Verify Search and Select One Customer Search Page Not Launched for Support Write.
	 */
	public void verifySearchandSelectOneCustomerPageABS() {
		try {
			if (isHHPageLaunched()) {
				launchCMPageFromHHPage(HouseHoldMove_PageObjects.HOUSEHOLDMOVE_CUSTOMERTAB,
						HouseHoldMove_PageObjects.HOUSEHOLDMOVE_COMBINESEPARATE);
				if (isCustomerMaintanancePage()) {
					launchSS1CPageFromCMPage();
					if (isSearchandSelectOneCustomerPageExists()) {
						accessNonAgentSS1CPageIndividual();

					} else {
						Verify.verifyTrue(false,
								MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.CUSTMAINTAINENCEPAGE_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}
	
	public void checkErrorMessage() throws ScriptException
	{
		Div errorMessage = new Div("id=messageSummary");
		if(errorMessage.getText().contains(EndToEndConstants.ERROR_MESSAGE))
			Verify.verifyTrue(true, MessageUtility.ERRORMESSAGE_DISPLAYED);
		else
			Verify.verifyTrue(false, MessageUtility.ERRORMESSAGE_NOTDISPLAYED);
	}

	public void clickPreviousLink() throws ScriptException {
		
		waitForPageLoad(CustomerSeparateAppObj.WidgetInfos.LINK_PREVIOUS, 15);
		if (CustomerSeparateAppObj.WidgetInfos.LINK_PREVIOUS.exists()) {
			click(CustomerSeparateAppObj.WidgetInfos.LINK_PREVIOUS,
					MessageUtility.LINK_PREVIOUSREVIEW_CLICKED);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_PREVIOUSREVIEW_NOTDISPLAYED);
		}
	}
}