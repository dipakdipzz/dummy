/*package sf.client.service.common.helpers;

import sf.client.service.healthSuite.baseScripts.BaseScript;
import statefarm.widget.manager.Verify;

public class StartSeleniumServerScript extends BaseScript{
	
	LaunchApplication launcher = null;
	public void scriptMain() {
		launcher = new LaunchApplication(getWATConfig());
		String launchCntnr = getWATConfig().getUserConfigContainer().getField("launchCntnr");
		try {
			launcher.launchSeleniumServerForGivenCntnr(launchCntnr);
		}catch(Exception e){
			Verify.verifyTrue(false, "Failed to start selenium server "+e.getMessage());
			System.exit(0);
		}
		
	}
}
*/