package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class ProdTeam_Portal_Scenario21 extends BaseScript {
	String query = "select * from ProdTeam_Portal_Scenario21";
	public void executeScript() {
		/**Launch Customer Search Page */
		createCustTasks.launchCustomerSeachPage();
		
		/**Enter User Alias */
		scenarioTasks.enterAgentAliasinCustomerSearchPage();
		
		/**Verify Create Individual and Organization links. */
		scenarioTasks.verifyCreateIndOrg();
		
		/**Click on Create Individual link. */
		createCustTasks.clickCreateIndividualProdTeamPortal();
		
		/**Handle CIMS Version */
		createCustTasks.handleCimsVersion();
		
		/**Create Individual Customer. */
		createCustTasks.createIndividualCustomer();
		
		/**Handle CIMS Version */
		createCustTasks.handleCimsVersion();
		
		/** Remove From Book */
		removeFromBookTasks.validateRemoveFromBookPageLaunhed();
		
		scenarioTasks.closeHHPage();
		
		/**Set Window */
		scenarioTasks.setWindow(EndToEndConstants.AGENT_BUSINESS_SYSTEM, 15, 10);
		
		/**customer search */
		createCustTasks.launchPortalCustomerSearchPage();
		
		/**Click on the Customer name link in search page. */
		createCustTasks.launchPortalHHPage();
		
		/**Navigating to Customer Information Page */
 		createCustTasks.launchCustomerInfoPageFromHHPage();
 		
 		 /**Add alias with Regular Characters */
 		updateTasks.addFirstAlias();
 		
        /**Remove Alias */
		updateTasks.selectNameVersionAndRemove();
		
		/**  Add US address with International characters */
		updateTasks.addAddressCustomerInfo();
		
		/**  Delete the Above added address */
		updateTasks.searchandRemoveAddress(clientE2ETO.getmStreet());
		
		/** Add,Delete Email */
		updateTasks.addEmailCustomerInfo();
		
		/** Update Email */
		updateTasks.updateEmail();
		
		/** Remove Email */
		updateTasks.removeEmail();
		
		/** Remove all Phones From Customer Info Page to add */
		updateTasks.removeAllPhonesFromCustomerInfo();
		
		/** Add Mobile number */
		updateTasks.addMobilePhoneCustomerInfo();
		
		/** Update Mobile number */
		updateTasks.updatePhoneUpdatePhone();
		
		/** Delete Mobile Number */
		createCustTasks.removePhoneCustomerInfo(clientE2ETO.getPhoneNumber());
		
		/** Update Personal Information All Fields */
		updateTasks.updatePersonalInformation();
		
		/** Launch and validate Customer Profile Print */
	    updateTasks.launchAndValidateCustomerProfilePrint();
	    
	    /** click Active Customer Bar. */
	    updateTasks.clickHHPageCustomer();
	    
	    /** Handle CIMS Version */
	    updateTasks.handleCimsVersion();
	    
	    /**  Verifying Presentation Kit */
	    productTasks.verifyPresentationKit();	
 		
 		/** Validate Product Inactive page */ 	
 		scenarioTasks.clickInactivePolicies();
	    scenarioTasks.printInactivePolicies();
	    
		/** Validate Bank policies */ 
        scenarioTasks.clickBankPolicies();
        scenarioTasks.displayBankPolicies();
        
        /** Validate Mutual Funds policies */  
        scenarioTasks.clickMutualFundsPolicies();
        scenarioTasks.displayMutualFundPolicies();
        
        /** Validate SFPP policies  */
        scenarioTasks.clickSfppPolicies();
        scenarioTasks.displaySfppPolicies();
        
        /** Adding policy */
        productTasks.createAutoPolicesWithOthers();
 		
 		/** Refresh HH page */
        productTasks.refreshHHPage();
		
 		/** Verify Created Auto policy */
        productTasks.verifyCreatedAutoPoliciy();
 		
		/** Add Comments */
		scenarioTasks.validateCommentsSectionHHPage();
		
		/** Add New Organization */
	    scenarioTasks.addOrganizationinHouseholdPage();
	    
		/**  Click on the 'View Customer Information' option in the Action and Navigates to Cust Info page. Navigate back to Household page */
		scenarioTasks.clickActionsViewCustomerInfo();
		
		/** Click on the N link in the Internet Enabled column in the Household members section for a customer and launch the ISCC screen (Select a customer having N ) */
		scenarioTasks.clickIsInternetEnabledNOption();
		
		/** Search and Select Two Customers and Click on Next link. */ 
		combineTasks.verifySearchandSelectTwoCustomersPageABS();
		
		/**  Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers. */
		combineTasks.verifyInfoandClickCombine();
		
		/**  Move members to a new household */
		hhNavigationTasks.verifyHHMovesMoveMembersToNewHousehold();
		
		/** Adding Previous & Next Review Dates */
		hhNavigationTasks.addReviewDates();
		
		/** Search and Select Customer from Search and Select one Customer Page. */
		separateCustTasks.verifySearchandSelectOneCustomerPageABS();
		
		/**  Separating a Customer. */
		separateCustTasks.separateCustomer();
		
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataProdTeamPortalScenario21(dbresultSet, clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				scenarioTasks=new ScenarioTasks(clientE2ETO);
				hhNavigationTasks=new HHnavigationTasks(clientE2ETO);
				removeFromBookTasks=new RemoveFromBookTasks(clientE2ETO);
				updateTasks=new UpdateCustomersTasks(clientE2ETO);
				productTasks=new ProductTasks(clientE2ETO);
				combineTasks=new CombineCustomersTasks(clientE2ETO);
				separateCustTasks=new SeparateCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				scenarioTasks.createResultsFile(resultsFileName(), scriptName());
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
