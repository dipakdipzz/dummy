package sf.client.service.common.helpers;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import javax.imageio.ImageIO;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import statefarm.wat.script.data.IDataContainer;
import statefarm.wat.util.KeyboardUtility;
import statefarm.wat.util.WATConfiguration;
import statefarm.widget.Stopwatch;
import statefarm.widget.WidgetInfo;
import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Browser;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.GUIWidget;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.TableEx;
import statefarm.widget.gui.TextField;
import statefarm.widget.manager.IWidgetManager;
import statefarm.widget.manager.Verify;
import statefarm.widget.manager.WidgetManagerFactory;
import statefarm.widget.selenium.SeleniumWidgetManager;
import statefarm.widget.webdriver.core.WebDriverWidgetManager;

public class WatUtility {
	@WidgetIDs
	public static class WidgetInfos {
		public static final TextField DOMAIN = new TextField("id=domain");
		public static final ListBox DOMAINFQDN = new ListBox("id=domainFqdn");
		public static final CheckBox errorCheck = new CheckBox("id=check");
		public static final Button LAUNCH = new Button("id=launchButton");
		public static final TextField PASSWORD = new TextField("id=password");
		public static final TextField URL = new TextField("id=param");
		public static final TextField USER = new TextField("id=user");
	}
	
	public static final String currentProjects = System.getProperty("user.dir");
	public static final String dataFilePath = currentProjects + "\\src\\main\\java\\com\\sf\\dc5\\sams\\auth\\toolbox\\data";
	
	private static final int CHECK_EXISTS_MAX_RETRIES = 5;

	private static final int CHECK_EXISTS_RETRY_INTERVAL_SEC = 1;

	private static final int CLICK_MAX_RETRIES = 120;

	private static final boolean DEFAULT_LOG_TO_SYSTEM_OUT = true;

	public static String filePath = null;

	private static final String JDBC_DRIVER_MICROSOFT_ACCESS_NAME_POSTFIX = ";DriverID=22;READONLY=false}";

	private static final String JDBC_DRIVER_MICROSOFT_ACCESS_NAME_PREFIX = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=";

	private static final String LOG_WARNING = "WARNING: ";

	private static final int MS_IN_SECOND = 100;

	private static final double PAGELOAD_DEFAULT_MAX_WAITTIME_SEC = 120;

	private static final double PAGELOAD_DEFAULT_RETRY_INTERVAL_SEC = 0.5D;

	private static final int PARENT_WINDOW_TITLE_ELEMENT = 0;

	public static String projectName = null;

	private static final String RESULT_FILE_HEADER = "===========================================================================\r\n"
			+ "------------------------    TESTCASE START   ------------------------------\r\n"
			+ "===========================================================================";

	public static String resultfilename = null;

	public static BufferedWriter resultsFile = null;

	private static final String TEST_CASE_BOTTOM_SEPARATOR = "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\r\n";

	private static final String TEST_CASE_TOP_SEPARATOR = "\r\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\r\n";

	public static String testcasename = null;

	private static final int WAITCOUNT_FIFTEEN_SEC = 25;
	
	public static WebDriverWidgetManager webDriverManager;
	
	

	/**
	 * 
	 * @return
	 */
	public static IWidgetManager getWidgetManagerInstance() {
		WidgetManagerFactory managerFactory = new WidgetManagerFactory();
		return managerFactory.getWidgetManagerInstance();
	}

	

	public WebDriver getWebDriverInstance() {

		webDriverManager = (WebDriverWidgetManager) getWidgetManagerInstance();
		return webDriverManager.getCurrentDomain();
	}

	/**
	 * Waits 20 seconds.
	 */
	public static void waitForBrowserToClose() {
		try {
			Thread.sleep(20000);
		} catch (Exception e) {
		}
	}

	public Browser browser = new Browser();

	public int count = 0;
	public int tab_count = 1;

	/**
	 * This method helpful to load the state or region specific test data based
	 * on the input provided in mdb.properties. Ex: mdb=IL With the help of this
	 * method We can reuse the same scripts for different states or regions .
	 * 
	 * @return
	 */
	public String currentProject = System.getProperty("user.dir");
	public ResultSet dbresultSet = null;
	public BufferedWriter failedResultsFile = null;
	protected KeyboardUtility keyboard = new KeyboardUtility();
	public String name = null;

	IDataContainer rollout = null;

	public SeleniumWidgetManager sel = null;
	
	public WebDriverWidgetManager webDriver = null;

	public ITransferObject transferObject = null;

	protected WATConfiguration watConfig = null;

	/**
	 * Default constructor.
	 */
	public WatUtility() {
		transferObject = new TestDataObject();
		this.watConfig = getWATConfig();
		rollout = watConfig.getUserConfigContainer().getContainer("RollOut");
		webDriver = (WebDriverWidgetManager) new WidgetManagerFactory().getWidgetManagerInstance();
	}

	public WatUtility(WATConfiguration config) {
		transferObject = new TestDataObject();
		this.watConfig = config;
		rollout = watConfig.getUserConfigContainer().getContainer("RollOut");
		webDriver = (WebDriverWidgetManager) new WidgetManagerFactory()
				.getWidgetManagerInstance();
	}

	/**
	 * Appends the failed test case header to outputMessage.
	 * 
	 * @param outputMessage
	 *            the StringBuilder to append to
	 * @return outputMessage (to allow method chaining)
	 */
	private StringBuilder appendIndividualFailedTestCaseHeader(
			StringBuilder outputMessage) {
		outputMessage.append("Test Case Name   : " + testcasename + "\r\n");
		outputMessage.append("Date and Time    : " + getFormattedDate()
				+ "\r\n");
		if (transferObject.getUrl() != null) {
			outputMessage.append("URL              : "
					+ transferObject.getUrl().replace("#", "") + "\r\n");
		}
		if (transferObject.getUserID() != null) {
			outputMessage.append("User ID          : "
					+ transferObject.getUserID() + "\r\n");
		}
		if (transferObject.getBussinessRole() != null) {
			outputMessage.append("Business Role:   : "
					+ transferObject.getBussinessRole() + "\r\n");
		}
		outputMessage
				.append("===========================================================================\r\n\r\n");

		return outputMessage; // Allow method changing
	}

	/**
	 * Appends the test case footer to outputMessage.
	 * 
	 * @param outputMessage
	 *            the StringBuilder to append to
	 * @return outputMessage (to allow method chaining)
	 */
	private StringBuilder appendIndividualTestCaseFooter(
			StringBuilder outputMessage) {
		outputMessage.append(TEST_CASE_BOTTOM_SEPARATOR);

		return outputMessage; // Allow method chaining
	}

	/**
	 * Appends the test case header to outputMessage.
	 * 
	 * @param outputMessage
	 *            the StringBuilder to append to
	 * @param result
	 *            the boolean that indicates whether the test was successful
	 * @param message
	 *            the String that describes what was (or will be) tested
	 * @return outputMessage (to allow method chaining)
	 */
	private StringBuilder appendIndividualTestCaseHeader(
			StringBuilder outputMessage, boolean result, String message) {
		outputMessage.append(TEST_CASE_TOP_SEPARATOR);
		outputMessage.append("What is Tested ?     : " + message + "\r\n");
		outputMessage.append("Test Result          : "
				+ (result ? "SUCCESS" : "FAILED") + "\r\n");

		return outputMessage; // Allow method chaining
	}

	/**
	 * Append message to System.out and also to this.resultsFile (if resultsFile
	 * is not null).
	 * 
	 * @param message
	 *            the String to append to Systems.out and to resultsFile
	 * @throws ScriptException
	 */
	public void appendMessage(String message) {
		try {
			if (resultsFile != null) {
				resultsFile.write("\r\n" + message + "\r\n");
				resultsFile.flush();
			}
		} catch (Exception e) {
			throw new RuntimeException(
			"Error trying to write message to results file.");
		}
	}

	/**
	 * Append message to System.out and also to this.resultsFile (if resultsFile
	 * is not null). This method does NOT throw ScriptException.
	 * 
	 * @param message
	 *            the String to append to Systems.out and to resultsFile
	 */
	private void appendMessageNoThrows(String message) {
		if (resultsFile != null) {
			try {
				resultsFile.write("\r\n" + message + "\r\n");
				resultsFile.flush();
			} catch (IOException e) {
				throw new RuntimeException(
						"Error trying to write message to results file.");
			}
		}
	}

	/**
	 * Writes the test case results, automatically including a screen shot for a
	 * failed test case. The results are written to System.out, the already
	 * created TestCase result file, and for a failed test case, to a failed
	 * result file specifically for the failed test case. The test case results
	 * file info looks like:
	 * 
	 * � What is Tested ? : ex:Customer Verification. � Test Result :
	 * SUCCESS/FAILED
	 * 
	 * @param result
	 *            the boolean that indicates whether the test was successful
	 * @param message
	 *            the String that describes what was (or will be) tested
	 * @throws ScriptException
	 */
	public void appendToResultFile(boolean result, String message)
			throws ScriptException {
		StringBuilder outputMessage = new StringBuilder();
		StringBuilder failedMessage = new StringBuilder();
		appendIndividualTestCaseHeader(outputMessage, result, message);

		try {
			if (result) {
				Verify.verifyTrue(result,message);
				appendIndividualTestCaseFooter(outputMessage);
				logMessage(outputMessage.toString());
			} else {
				Verify.verifyTrue(result,message);
				transferObject.setFailCount(transferObject.getFailCount() + 1);

				// Create failed results file with test case header
				if (transferObject.getFailCount() == 1) {
					createFailedResultFile();
					appendIndividualFailedTestCaseHeader(failedMessage);
					logErrorMessage(failedMessage.toString(), false);
				}

				// Log results
				logErrorMessage(outputMessage.toString());
				logMessage(outputMessage.toString(), false);

				String imageFileName = getScreenShotBaseFilename();
				getErrorScreenShot(imageFileName);
				logScreenShot(imageFileName);

				logErrorMessage(TEST_CASE_BOTTOM_SEPARATOR);
				logMessage(TEST_CASE_BOTTOM_SEPARATOR, false);
			}
			if (resultsFile != null)
				resultsFile.flush();

			if (failedResultsFile != null)
				failedResultsFile.flush();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Logs message to the already created TestCase result file.
	 * 
	 * @param message
	 *            the String to append to the results file
	 * @throws ScriptException
	 */
	public void appendToResultFile(String message){
		try {
			resultsFile.write(message);
		} catch (IOException e) {
			throw new RuntimeException(
			"Error trying to write message to results file.");		}
	}

	/**
	 * Calculates the default file path for saving results to. The default is
	 * based on the current date and project name.
	 * 
	 * @return the default file path for saving results to
	 */
	private String calcDefaultFilePath() {
		return currentProject + "\\src\\results\\" + getCompleteDate()
				+ projectName + "\\testlogs";
	}

	/**
	 * Calculates the project name based on testcaseName.
	 * 
	 * @param testcaseName
	 * @return the project name (based on testcaseName)
	 */
	private String calcProjectNameFromTestcaseName(String testcaseName) {
		String aProjectName = null;
		String[] s = ("@".concat(testcaseName.replace(".", "@"))).split("@");
		if (s != null && s.length > 1) {
			int length = s.length;
			for (int i = 3; i < length - 1; i++) {
				if ((s[i] != null && !s[i].equalsIgnoreCase(" "))) {
					if (aProjectName == null) {
						aProjectName = "\\" + s[i];
					} else {
						aProjectName += "\\" + s[i];
					}
				}
			}
		}
		return aProjectName;
	}


	/**
	 * Checks, up to CLICK_MAX_RETRIES times, to see if guiWidget is present. If
	 * guiWidget is present, it then clicks it. If guiWidget is found, logs as a
	 * success, if not found then logs as failed. Note that this does NOT verify
	 * that the click itself did whatever it was intended to do.
	 * 
	 * @param guiWidget
	 *            the GUIWidget to click
	 * @param message
	 *            the String to append to the results file. If guiWidget is not
	 *            found, then "NOT" is prefixed to the message when logged to
	 *            the results file.
	 * @throws ScriptException
	 */
	public void click(GUIWidget guiWidget, String message)
			throws ScriptException {
		boolean found = false;
		// TODO: Why is the retry logic in here. Before calling this, caller's
		// should verify that guiWidget exists
		for (int i = 1; i < CLICK_MAX_RETRIES && !found; i++) {
			if (guiWidget.exists()) {
				found = true;
				guiWidget.click();
				Verify.verifyTrue(found, message);
			}
		}
		if (!found) {
			Verify.verifyTrue(found, "Not" + message);
		}
	}

	/**
	 * Closes all windows in this.browser.
	 */
	public void closeAllWindows() {
		browser.closeAllWindows();
	}

	/**
	 * If this.resultsFile is open, then try to close it.
	 */
	public void closeResultsFile() {
		if (resultsFile != null) {
			try {
				resultsFile.close();
			} catch (IOException e) {
			}
		}
	}

	/**
	 * Try to create the failed results file, in the failedTestCases folder. If
	 * that folder does not exist, then create it prior to creating the file.
	 */
	private void createFailedResultFile() {
		String failedFilePath = filePath + "\\failedTestCases\\";
		new File(failedFilePath).mkdirs();

		String failedFileSpec = failedFilePath
				+ resultfilename.replace(".txt", "F.txt");

		try {
			failedResultsFile = new BufferedWriter(new FileWriter(
					failedFileSpec));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Creates a result file, in a location based on testcasename, named based
	 * on resultsFileName. Created result file header contains the below
	 * information: � Test Case Name � Execution Date and Time � Application URL
	 * (if available) � User ID (if available) � Domain (if available) �
	 * Business Role (if available)
	 * 
	 * @param resultsFileName
	 *            the String that contains the name of the file to create. When
	 *            the file is created, ".txt" is appended to resultsFileName (so
	 *            don't include an extension as part of resultsFileName).
	 */
	public void createResultsFile(String resultsFileName, String testcaseName) {
		WatUtility.testcasename = testcaseName;
		WatUtility.resultfilename = resultsFileName + ".txt";
		projectName = calcProjectNameFromTestcaseName(testcaseName);

		try {
			File resultFile = null;
			filePath = calcDefaultFilePath();
			resultFile = new File(filePath);
			resultFile.mkdirs();
			resultsFile = new BufferedWriter(new FileWriter(filePath + "\\"
					+ resultfilename));
			StringBuilder outputMessage = new StringBuilder();
			outputMessage.append("Test Case Name : " + testcaseName + "\r\n");
			outputMessage.append("Date and Time  : " + getFormattedDate()
					+ "\r\n");
			if (transferObject.getUrl() != null) {
				outputMessage.append("URL            : "
						+ transferObject.getUrl().replace("#", "") + "\r\n");
			}
			if (transferObject.getUserID() != null) {
				outputMessage.append("User ID        : "
						+ transferObject.getUserID() + "\r\n");
			}
			if (transferObject.getDomain() != null) {
				outputMessage.append("Domain      	: "
						+ transferObject.getDomain() + "\r\n");
			}
			if (transferObject.getBussinessRole() != null) {
				outputMessage.append("Business Role	: "
						+ transferObject.getBussinessRole() + "\r\n");
			}
			outputMessage.append(RESULT_FILE_HEADER + "\r\n");

			logMessage(outputMessage.toString());
			resultsFile.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Types textToType in textField. Then, fires "keyup" (to help enable a
	 * button?).
	 * 
	 * @param textField
	 *            the TextField to type textToType into
	 * @param textToType
	 *            the String to type into textField
	 */
	public void enterMandatoryfieldtoEnablebutton(TextField textField,
			String textToType) {
		
		String textname = null;
		if(textField.exists()){
		textname =textField.getAttribute("name");
		textField.setText(textToType);
		Verify.verifyTrue(true, textToType+" is entered in "+textname);	
		}
	}

	/**
	 * Returns the attribute value (req=requested?, as in requested when the
	 * object was created) for widgetInfo. The supported attribute names are:
	 * "name", "id", "text", and "title". For example, for new
	 * Link("id=testing"), this would return "testing". If widgetInfo has more
	 * than one of the supported attribute names, then the first one (based on
	 * the order listed in this description) is returned.
	 * 
	 * @param widgetInfo
	 *            the WidgetInfo to get the attribute from
	 * @return the attribute value from widgetInfo. If widgetInfo has more than
	 *         one of the supported attribute names, then the first one (based
	 *         on the order listed in this description) is returned.
	 */
	public String fetchReqAttr(WidgetInfo widgetInfo) {
		String str = widgetInfo.getAttributeValue("name");
		if (str == null) {
			str = widgetInfo.getAttributeValue("id");
		}
		if (str == null) {
			str = widgetInfo.getAttributeValue("text");
		}
		if (str == null) {
			str = widgetInfo.getAttributeValue("title");
		}
		if (str == null) {
			str = "";
		}

		return str;
	}


	/**
	 * Returns the current date.
	 * 
	 * @return current date in MM-dd-yy format
	 */
	public String getCompleteDate() {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
		return simpleDateFormat.format(new Date()).toString();
	}

	/**
	 * @deprecated Use {@link #getCoreData(ITransferObject)} instead
	 * 
	 * @param transferObject
	 *            the ITransferObject to get the data for
	 * @return same as {@link #getCoreData(ITransferObject)}
	 * @throws Exception
	 */
	public ResultSet getConnection(ITransferObject transferObject)
			throws Exception {
		return getCoreData(transferObject);
	}

	/**
	 * Returns the core data object for dataObject.
	 * 
	 * @param dataObject
	 *            the ITransferObject to return the core data for
	 * @return the ResultSet the represents the core data for dataObject
	 * @throws Exception
	 */
	public ResultSet getCoreData(ITransferObject dataObject) throws Exception {
		ResultSet dbResultSet = null;
		String dbFilename = dataObject.getDbFilePath()
				+ dataObject.getDbFileName();
		String fileNamePrefix = JDBC_DRIVER_MICROSOFT_ACCESS_NAME_PREFIX;
		String fileNameSuffix = JDBC_DRIVER_MICROSOFT_ACCESS_NAME_POSTFIX;

		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); 
			Connection dbConnection = DriverManager.getConnection(
					fileNamePrefix + dbFilename + fileNameSuffix, "", "");
			Statement dbStatement = dbConnection.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);

			dbResultSet = dbStatement.executeQuery(dataObject.getDbQuery());
		} catch (SQLException e) {
			throw new RuntimeException("SQLException occured , Unable to execute "
					+ dataObject.getDbQuery());
		}

		return dbResultSet;
	}

	public ResultSet getDbresultSet() {
		return dbresultSet;
	}

	/**
	 * Captures a screenshot, of the entire screen, and writes the screenshot to
	 * the failedTestCases folder.
	 * 
	 * @param imageName
	 *            the String for the name of the image. "F.png" is automatically
	 *            appended to imageName. So, do not include an extension as part
	 *            of imageName.
	 */
	public void getErrorScreenShot(String imageName) {

		String errorImage = filePath.replace("testlogs", "screenshots")
				+ "\\failedTestCases" + "\\" + imageName + "F.png";

		String filePath = calcDefaultFilePath();
		WatUtility.filePath = filePath;

		new File(filePath.replace("testlogs", "screenshots")
				+ "\\failedTestCases").mkdirs();

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Rectangle rectangle = new Rectangle(0, 0, screenSize.width,
				screenSize.height);

		try {
			Robot robot = new Robot();
			BufferedImage bufferedImage = robot.createScreenCapture(rectangle);
			ImageIO.write(bufferedImage, "png", new File(errorImage));
		} catch (AWTException e) {
			appendMessageNoThrows("AWTException occured while taking Screenshot in getErrorScreenShot(); ignoring it");
		} catch (IOException e) {
			appendMessage("IOException occured while taking Screenshot");
		}
	}

	/**
	 * Returns the current date and time using the default formatting style
	 * (normally MMM d, yyyy H:mm:ss AM/PM) for the default locale.
	 * 
	 * @return a String that is the current date and time formatted using the
	 *         default formatting style for the default locale
	 */
	public String getFormattedDate() {
		return DateFormat.getDateTimeInstance().format(new Date());
	}

	/**
	 * Looks up value of propertyKey in the MDB properties file. If propertyKey
	 * is found, then uses the value as a new key and looks up it's value. The
	 * return value of that second lookup is what is returned. The MDB
	 * properties file is located in the src\common\data and is named
	 * mdb.properties.
	 * 
	 * @param propertyKey
	 *            the String for the name of the property. If <code>null</code>
	 *            is passed in, then "mdb" is used as the propertyKey.
	 * @return the String value of the property from the second lookup, null if
	 *         not found. Refer to the description for more information.
	 */
	public String getMDBName(String propertyKey) {
		String value = null;

		File propertyFile = new File(currentProject
				+ "\\src\\common\\data\\mdb" + ".properties");
		try {
			if (propertyFile.exists()) {
				Properties properties = new Properties();
				properties.load(new FileInputStream(propertyFile));
				if (propertyKey != null)
					value = properties.getProperty(propertyKey);
				else {
					value = properties.getProperty("mdb");
				}

				System.out.println("MDB"
						+ ((propertyKey != null) ? " (key = " + propertyKey
								+ ")" : "") + " specified as : " + value);
				if (value != null) {
					value = properties.getProperty(value);
				}
				if (value == null) {
					System.err
							.println("Specified mdb does not have Corresponding MDB file");
				}
			} else {
				System.out.println("properties File not found!");
			}
		} catch (FileNotFoundException ex) {
			System.err
					.println("FileNotFoundException occured while loading properties file");
		} catch (IOException ex) {
			System.err
					.println("IOException occured while loading properties file");
		}

		return value;
	}

	/**
	 * Returns the current date/time in the format MM-dd (for example 10-23 for
	 * October 23rd).
	 * 
	 * @return the current Date in MM-dd format
	 */
	public String getMonthAndDate() {

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd");
		return simpleDateFormat.format(new Date()).toString();

	}


	/**
	 * In the &lt;div&gt; that has an ID of divID and a class of
	 * "tableContainer", returns the number of rows in the table.
	 * 
	 * @param divID
	 *            the String that contains the ID of the &lt;div&gt; that
	 *            contains the table.
	 * @return an int that is the number of rows in the table.
	 */
	public int getRowCountFromXpathDivId(String divID) {
		return getRowCountFromXpathDivId(divID, "tableContainer");
	}

	/**
	 * In the &lt;div&gt; that has an ID of divID and a class of tableClass,
	 * returns the number of rows in the table.
	 * 
	 * @param divID
	 *            the String that contains the ID of the &lt;div&gt; that
	 *            contains the table.
	 * @param tableClass
	 *            the String that contains the class of the &lt;div&gt; that
	 *            contains the table.
	 * @return an int that is the number of rows in the table.
	 */
	public int getRowCountFromXpathDivId(String divID, String tableClass) {
		int c = 1;
		int rowCount = 0;
		while (true) {
			try {
				WebElement elementXpathcount = getWebDriverInstance()
				.findElement(
						By.xpath("//div[@id='"
								+ divID
								+ "']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
								+ c + "]/td[1]"));
				if(elementXpathcount.isDisplayed())
				{
					rowCount++;
					c++;
				}
			} catch (Exception e) {
				break;
			}
		}

		return rowCount;
	}

	/**
	 * Builds and returns a screen shot image file name using resultsfilename,
	 * month and day (MM-dd), and time (HH-mm-ss).
	 * 
	 * @return a String containing the imageNameFile updated with date and time.
	 */
	public String getScreenShotBaseFilename() {
		String imageFileName = resultfilename;
		imageFileName += "_" + getMonthAndDate() + "_" + getTime();
		return imageFileName;
	}

	/**
	 * Builds and returns an xpath for table container (a &lt;div&gt;) with an
	 * id of divID, and an inner &lt;div&gt; with a class of "tableContainer".
	 * 
	 * @param divID
	 *            The String with the ID for the &lt;div&gt;.
	 * @return The String containing the xpath.
	 */
	public String getTableXPathFromDivId(String divID) {
		return getTableXPathFromDivId(divID, "tableContainer");
	}

	/**
	 * Builds and returns an xpath for table container (a &lt;div&gt;) with an
	 * id of divID, and an inner &lt;div&gt; with a class of tableCtr.
	 * 
	 * @param divID
	 *            The String with the ID for the &lt;div&gt;.
	 * @param tableCtr
	 *            The String containing the table container name.
	 * @return The String containing the xpath.
	 */
	public String getTableXPathFromDivId(String divID, String tableCtr) {
		return "//div[@id='"
				+ divID
				+ "']"
				+ "/div[@class='"
				+ tableCtr
				+ "']/table[@class='scrollTable']/tbody[@class='scrollContent']";
	}

	/**
	 * Builds and returns an xpath for row rowNumber in the address table.
	 * 
	 * @param divID
	 *            The ID for the &lt;div&gt; containing the address table.
	 * @param rowNumber
	 *            The int representing a row in the address table.
	 * @return The String containing the xpath.
	 */
	public String getTableXPathFromDivIdforAddress(String divID, int rowNumber) {
		return "xpath=//div[@id='"
				+ divID
				+ "']/div[@id='gridAddress']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div[@gridRowIndex='"
				+ rowNumber + "']/table/tbody";
	}

	/**
	 * Returns the current date in "HH-mm-ss" format.
	 * 
	 * @return a String with the current date in HH-mm-ss format.
	 */
	public String getTime() {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH-mm-ss");
		return simpleDateFormat.format(new Date()).toString();
	}

	/**
	 * @return the dataObject
	 */
	public ITransferObject gettransferObject() {
		return transferObject;
	}

	/**
	 * Returns an instance of WATConfiguration
	 * 
	 * @return a WATConfiguration
	 */
	public WATConfiguration getWATConfig() {
		return WATConfiguration.getInstance();
	}

	/**
	 * Checks for CIMS version link in the first child window. Click it if it
	 * exists.
	 */
	public void handleCimsVersion() {
		try{
			Link link = new Link("text=CIMS 2.0 Version "
					+ rollout.getField("cimsVersion"));
			waitForPageLoad(link,15);
			if (link.exists()) {
				link.click();
			}
			selectAgentSelection();
		}catch(WebDriverException webDriverException){
			appendMessage("webDriverException Occured while handling CimsVersion link");
		}catch(Exception exception){
			appendMessage("Exception Occured while handling CimsVersion link");
		}
	}
	/**
	 * Click on Agent Selection Button if exists
	 * 
	 */
	public void selectAgentSelection() {
		try{
			waitForPageLoad(ABSCustomerSearchTestObjects.WidgetInfos.LIST_AGENT_SELECTION, 5);
			if (ABSCustomerSearchTestObjects.WidgetInfos.LIST_AGENT_SELECTION.exists()) {
				ABSCustomerSearchTestObjects.WidgetInfos.LIST_AGENT_SELECTION
						.selectItemAtIndex(0);
				if (ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_AGENTSELECTION.exists()) {
					ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_AGENTSELECTION.click();
					Verify.verifyTrue(true,
							"Continue button Clikced Successfully in Agent Selection Page");
				}
			}
			}catch(Exception exception){
				appendMessage("Exception Occured In Agent Selection Page");
			}
}

	/**
	 * Writes message to the error log and to System.out if
	 * DEFAULT_LOG_TO_SYSTEM_OUT = true. No trailing newline is automatically
	 * added; if you want a newline, include it as part of the message.
	 * 
	 * @param message
	 *            String containing the message to be logged.
	 * @param alsoLogToSystemOut
	 *            Boolean indicating if message is to be logged to System.out.
	 * @throws ScriptException
	 */
	protected void logErrorMessage(String message) throws ScriptException {
		logErrorMessage(message, DEFAULT_LOG_TO_SYSTEM_OUT);
	}

	/**
	 * Writes message to the error log and optionally to System.out. No trailing
	 * newline is automatically added; if you want a newline, include it as part
	 * of the message.
	 * 
	 * @param message
	 *            String containing the message to be logged.
	 * @param alsoLogToSystemOut
	 *            Boolean indicating if message is to be logged to System.out.
	 */
	protected void logErrorMessage(String message, boolean alsoLogToSystemOut) {
		if (alsoLogToSystemOut) {
			System.out.print(message);
		}

		try {
			if (failedResultsFile != null) {
				failedResultsFile.write(message);
				failedResultsFile.flush();
			} else {
				System.out
						.println(LOG_WARNING
								+ this.getClass().getSimpleName()
								+ ".logErrorMessage() called but this.failedResultsFile == null");
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Writes error message to the "normal" log and to System.out if
	 * DEFAULT_LOG_TO_SYSTEM_OUT = true. No trailing newline is automatically
	 * added; if you want a newline, include it as part of the message.
	 * 
	 * @param message
	 *            The String containing the message to be logged.
	 */
	protected void logMessage(String message) {
		logMessage(message, DEFAULT_LOG_TO_SYSTEM_OUT);
	}

	/**
	 * Writes message to the "normal" log and optionally to System.out No
	 * trailing newline is automatically added; if you want a newline, include
	 * it as part of the message.
	 * 
	 * @param message
	 *            The String with the message to log.
	 * @param alsoLogToSystemOut
	 *            The boolean indicating whether to log to System.out, in
	 *            addition to the results file.
	 */
	protected void logMessage(String message, boolean alsoLogToSystemOut) {
		if (alsoLogToSystemOut) {
			System.out.print(message);
		}

		try {
			if (resultsFile != null) {
				resultsFile.write(message);
				resultsFile.flush();
			} else {
				System.out.println(LOG_WARNING
						+ this.getClass().getSimpleName()
						+ ".logMessage() called but this.resultsFile == null");
			}
		} catch (IOException e) {
			System.err.println("IOException occurred. Unable to write message ("
					+ message + ") to output file.");
	throw new RuntimeException(e);
		}
	}

	/**
	 * Logs the screen shot information to the error log, to the "normal" log,
	 * and to Systems.out.
	 * 
	 * @param imageFileName
	 *            The String containing the file name of the image used in the
	 *            log message.
	 * @throws ScriptException
	 */
	private void logScreenShot(String imageFileName) throws ScriptException {
		String screenShotMessage = "Error Screen shot path : " + imageFileName
				+ "\r\n";
		logErrorMessage(screenShotMessage);

		screenShotMessage = "Error Screen shot path : "
				+ filePath.replace("\\testlogs\\", "\\screenshots\\")
				+ "\\failedTestCases\\" + imageFileName + "F.png\r\n";
		logMessage(screenShotMessage, false);
	}

	/**
	 * In the &lt;div&gt; that has an id of householdMembers2, looks through the
	 * table in rows 1-2, looking in column 2 for customer. If found, clicks the
	 * item in column 3 (selects the customer) and then clicks button.
	 * 
	 * @param prop
	 *            Not used in this method.
	 * @param button
	 *            Button that is clicked when customer is found and selected.
	 * @param customer
	 *            String containing customer to try to find.
	 * @return Boolean returned indicating if the customer was found.
	 * @throws ScriptException
	 *             The exception thrown when an exception occurs in this method.
	 */
	public boolean moveCustomer2DataMoveFunction(WidgetInfo prop,
			Button button, String customer) throws ScriptException {
		boolean selected = false;
		TableEx tab = new TableEx(
				"xpath=//div[@id='householdMembers2']/div[@class='tableContainer']/table[@class='scrollTable']");

		System.out.println("--------tab--------" + tab);
		for (int rowNumber = 1; rowNumber <= 2; rowNumber++) {
			String xpath="//div[@id='householdMembers2']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
				+ rowNumber + "]/td[2]";
			if(getWebDriverInstance().findElement(By.xpath(xpath)).isDisplayed()){
			String str = getWebDriverInstance().findElement(By.xpath(xpath)).getText();
			if (customer.equalsIgnoreCase(str)) {
				getWebDriverInstance().findElement(By.xpath("//div[@id='householdMembers2']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr["
						+ rowNumber + "]/td[3]")).click();
				selected = true;
				break;
			}
		}
		}

		if (selected) {
			click(button, " button clicked Successfully");
			waitForTime(2);
			
		}else{
			getWebDriverInstance().findElement(By.cssSelector("div#householdMembers2>div.tableContainer>table tbody.scrollContent>tr:nth-child(1)")).click();
			click(button, " button clicked Successfully");
			waitForTime(2);
		}

		return selected;
	}
	
	public boolean selectCustomerFromTable(String customerSearchPage)
	throws ScriptException {
		boolean flag = false;
		
	TableEx custNamesTable = new TableEx(
			"xpath=//div[@class='fixed-table-container']/div/table");
	int rowCount = custNamesTable.getBodyRowCount();
	for (int i = 0; i < rowCount; i++) {		
		String custName = custNamesTable.getBodyCellText(i, 14);
		System.out.println("praveen custName:"+custName); 
		System.out.println("praveen customerSearchPage:"+customerSearchPage);
		System.out.println("Praveenx:"+i);
		//if (custName.equalsIgnoreCase(customerSearchPage.trim())) {
			if ("COLLINS, MICHELLE".equalsIgnoreCase("COLLINS, MICHELLE")) {
			System.out.println("Praveen:"+i);
			custNamesTable.clickBodyCell(i, 14);
			Verify.verifyTrue(true, "The Customer " + customerSearchPage + "is selected"); 
			flag = true;
			return flag;
		}
		System.out.println("flag:"+flag);
	}
	return flag;
	}

	/**
	 * Checks for customer link. If found, clicks the link and appends
	 * "selected customer found" message to result file, and returns true. If
	 * not found, appends "selected customer is NOT found" message to result
	 * file, and returns false.
	 * 
	 * @param customerSearchPage
	 *            The String containing the customer link to try to find.
	 * @return The boolean indicating the existence of the customer link.
	 * @throws ScriptException
	 *             The exception thrown when an exception occurs in this method.
	 */
	public boolean selectCustomerFromTableCRC(String customerSearchPage)
			throws ScriptException {
		boolean flag = false;
		Link Customer = new Link("text=" + customerSearchPage);
		if (Customer.exists()) {
			click(Customer,
					"Customer Link Clicked Successfully from Search results table");
			Verify.verifyTrue(true, "selected customer found");
			flag = true;
		} else {
			Verify.verifyTrue(false, "selected customer is NOT found");
		}
		return flag;
	}

	/**
	 * Checks for listbox until it is found or until the check has been
	 * performed the number of times in CLICK_MAX_RETRIES. If found, selects the
	 * item in the listbox that matches the value parameter, appends a 'found'
	 * message to the result file, and logs verification point with 'found'
	 * message. If not found, appends a 'not found' message to the result file,
	 * and logs verification point with 'not found' message.
	 * 
	 * @param listbox
	 *            The ListBox that contains the listbox to try to find.
	 * @param value
	 *            The String containing the value of the item to select in the
	 *            listbox.
	 * @param message
	 *            The String containing the message that is appended to the
	 *            result file.
	 * @throws ScriptException
	 *             The exception thrown when an exception occurs in this method.
	 */
	public void selectFromListbox(ListBox listbox, String value, String message)
			throws ScriptException {
		boolean found = false;
		for (int i = 1; i < CLICK_MAX_RETRIES && !found; i++) {
			if (listbox.exists()) {
				found = true;
				if (isSelectListItemPresent(listbox, value)) {
					listbox.selectItem(value);
				} else {
					Verify.verifyTrue(false, value + " not found in list box");
				}
				Verify.verifyTrue(found, message);
				Verify.verifyTrue(found, message);
			}
		}
		if (!found) {
			Verify.verifyTrue(found, "Not" + message);
			Verify.verifyFalse(found, "Not" + message);
		}
	}

	public boolean isSelectListItemPresent(ListBox listbox, String value){
		if (listbox.containsItem(value)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Checks for radiobutton until it is found or until the check has been
	 * performed the number of times in CLICK_MAX_RETRIES. If found, selects the
	 * radiobutton, clicks it, appends a 'found' message to the result file, and
	 * logs verification point with 'found' message. If not found, appends a
	 * 'not found' message to the result file, and logs verification point with
	 * 'not found' message.
	 * 
	 * @param radiobutton
	 *            The RadioButton that contains the radio button to try to find.
	 * @param message
	 *            The String containing the message that is appended to the
	 *            result file.
	 * @throws ScriptException
	 *             The exception thrown when an exception occurs in this method.
	 */
	public void selectRadioButton(RadioButton radiobutton, String message)
			throws ScriptException {
		boolean found = false;
		for (int i = 1; i < CLICK_MAX_RETRIES && !found; i++) {
			if (radiobutton.exists()) {
				found = true;
				radiobutton.select();
				radiobutton.click();
				Verify.verifyTrue(found, message);
				Verify.verifyTrue(found, message);
			}
		}
		if (!found) {
			Verify.verifyTrue(found, "Not" + message);
			Verify.verifyTrue(found, "Not" + message);
		}
	}

	/**
	 * Waits for WAITCOUNT_FIFTEEN_SEC. Opens a new browser and sets the browser
	 * active window to number - 1, which represents a child window. Maximizes
	 * the window.
	 * 
	 * @param number
	 *            The int of the index of the window to activate.
	 * @throws ScriptException
	 *             The exception thrown when an exception occurs in this method.
	 */
	public void setChildWindow(int number) throws ScriptException,WebDriverException {
		setWindow(WAITCOUNT_FIFTEEN_SEC, number - 1);
		browser.getActiveWindow().maximize();
	}

	

	/**
	 * Waits for WAITCOUNT_FIFTEEN_SEC. Opens a new browser and sets the browser
	 * active window to PARENT_WINDOW_TITLE_ELEMENT.
	 */
	public void setParentWindow() {
		setWindow(WAITCOUNT_FIFTEEN_SEC, PARENT_WINDOW_TITLE_ELEMENT);
	}

	/**
	 * Sets actualResult and resultStatus in transferObject.
	 * 
	 * @param flag
	 *            The Boolean to which the transferObject resultStatus is set.
	 * @param msg
	 *            The String containing the message to which actualResult is
	 *            set.
	 */
	public void setStatus(boolean flag, String msg) {
		transferObject.setActualResult(msg);
		transferObject.setResultStatus(flag);
	}

	/**
	 * Sets database file name in transferObject if transferObject is not null,
	 * and the database file name is null. Sets database file path in
	 * transferObject if transferObject is not null, and the database file path
	 * is null.
	 * 
	 * @param transferObject
	 *            The ITransferObject whose database file name and path are
	 *            being updated.
	 * @return The updated ITransferObject.
	 */
	public ITransferObject setTestDataObject(ITransferObject transferObject) {
		if (transferObject != null && transferObject.getDbFileName() == null) {
			transferObject.setDbFileName(getMDBName(null) + ".mdb");
		}
		if (transferObject != null && transferObject.getDbFilePath() == null) {
			transferObject.setDbFilePath(currentProject
					+ "\\src\\Common\\data\\");
		}

		return transferObject;
	}

	/**
	 * Checks for textField until it is found or until the check has been
	 * performed the number of times in CLICK_MAX_RETRIES. If found, set the
	 * text in textField to the value in the text parameter, append a 'found'
	 * message to the result file, and logs verification point with 'found'
	 * message. If not found, append a 'not found' message to the result file,
	 * and logs verification point with 'not found' message.
	 * 
	 * @param textField
	 *            The TextField whose existence is being verified.
	 * @param text
	 *            The String that contains the text to be set in textField.
	 * @param message
	 *            The String containing the message that is appended to the
	 *            result file.
	 * @throws ScriptException
	 *             The exception thrown when an exception occurs in this method.
	 */
	public void setTextInTextbox(TextField textField, String text,
			String message) throws ScriptException {
		boolean found = false;
		for (int i = 1; i < CLICK_MAX_RETRIES && !found; i++) {
			if (textField.exists()) {
				found = true;
				textField.setText(text);
				Verify.verifyTrue(found, message);
				Verify.verifyTrue(found, message);
			}
		}
		if (!found) {
			Verify.verifyTrue(found, "Not" + message);
			Verify.verifyTrue(found, "Not" + message);
		}
	}

	/**
	 * Waits for waitCount time in seconds. Instantiates a new Browser. Sets the
	 * browser active window to titleToActivate.
	 * 
	 * @param waitCount
	 *            This int contains a time in seconds.
	 * @param titleToActivateElement
	 *            This int contains a number representing a window title to
	 *            activate in the browser.
	 */
	public void setWindow(int waitCount, int titleToActivateElement) {
		try{
			waitforBrowserisLoading(titleToActivateElement, waitCount, CHECK_EXISTS_RETRY_INTERVAL_SEC);
			String titleToActivate = null; 
			List<String> windowTitleList = browser.getAllWindowTitles();
			if (windowTitleList.size() > titleToActivateElement) {
				titleToActivate = windowTitleList.get(titleToActivateElement);
				browser.setActiveWindow(titleToActivate);
			} else {
			}
		}catch (ScriptException e) {
			scriptError(e);
		}catch(Exception exception){
			appendMessage("Exception when selecting the Window");
		}
	}

	/**
	 * Checks for text "Permission to text:" in the &lt;div&gt; with the ID
	 * equal to "additionalPhoneWrapper". If the text is found, append 'found'
	 * message to the result file. If the text is not found, append 'not found'
	 * message to the result file.
	 * 
	 * @throws ScriptException
	 *             The exception thrown, if any exception occurs in this method.
	 */
	public void validatePermissionToTextInAdditionalPhone()
			throws ScriptException {
		Div DIV_PTT_ADD = new Div("id=additionalPhoneWrapper");
		if (!DIV_PTT_ADD.getText().contains("Permission to text:")) {
			Verify.verifyTrue(true,
					"Permission to text is NOT displayed in Additional Phone section");
		} else {
			Verify.verifyTrue(false,
					"Permission to text is displayed in Additional Phone section");
		}
	}

	/**
	 * Checks for text "Permission to text:" in the &lt;div&gt; with the ID
	 * equal to "homePhoneWrapper". If the text is found, append 'found' message
	 * to the result file. If the text is not found, append 'not found' message
	 * to the result file.
	 * 
	 * @throws ScriptException
	 *             The exception thrown, if any exception occurs in this method.
	 */
	public void validatePermissionToTextInHomePhone() throws ScriptException {
		Div DIV_PTT_HOME = new Div("id=homePhoneWrapper");
		if (!DIV_PTT_HOME.getText().contains("Permission to text:")) {
			Verify.verifyTrue(true,
					"Permission to text is NOT displayed in Home Phone section");
		} else {
			Verify.verifyTrue(false,
					"Permission to text is displayed in Home Phone section");
		}
	}


	public void verifyTestCase(String testCaseName) throws ScriptException {
		Method[] method = this.getClass().getMethods();
		for (int i = 0; i < method.length; i++) {

			try {
				if (method[i] != null) {

					if (method[i].getName().equalsIgnoreCase(testCaseName)) {
						method[i].invoke(this);
						break;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				throw new ScriptException("Exception occured while calling  :"
						+ testCaseName);
			}
		}
	}

	/**
	 * Checks to see if guiWidget exists on a page until a CIMS error exists,
	 * the guiWidget is found, or PAGELOAD_DEFAULT_MAX_WAITTIME_SEC is reached
	 * or exceeded. While no CIMS error, guiWidget not found, and
	 * PAGELOAD_DEFAULT_MAX_WAITTIME_SEC not reached, sleep for length of
	 * PAGELOAD_DEFAULT_RETRY_INTERVAL_SEC before checking again.
	 * 
	 * @param guiWidget
	 *            The WidgetInfo whose existence is being verified.
	 * @return The boolean returned, indicating the existence of guiWidget.
	 */
	public boolean waitForPageLoad(WidgetInfo guiWidget) {
		return waitForPageLoad(guiWidget, PAGELOAD_DEFAULT_MAX_WAITTIME_SEC,
				PAGELOAD_DEFAULT_RETRY_INTERVAL_SEC);
	}

	/**
	 * Checks to see if guiWidget exists on a page until a CIMS error exists,
	 * the guiWidget is found, or timeoutSec is reached or exceeded. While no
	 * CIMS error, guiWidget not found, and timeoutSec not reached, sleep for
	 * length of PAGELOAD_DEFAULT_RETRY_INTERVAL_SEC before checking again.
	 * 
	 * @param guiWidget
	 *            The WidgetInfo whose existence is being verified.
	 * @param timeoutSec
	 *            The maximum time in seconds the check for the existence of the
	 *            guiWidget will last, before timing out.
	 * @return The boolean returned, indicating the existence of guiWidget.
	 */
	public boolean waitForPageLoad(WidgetInfo guiWidget, double timeoutSec) {
		return waitForPageLoad(guiWidget, timeoutSec,
				PAGELOAD_DEFAULT_RETRY_INTERVAL_SEC);
	}

	/**
	 * Checks to see if widget exists on a page, until a CIMS error exists, the
	 * widget is found, or maxTimeSec is reached or exceeded. While no CIMS
	 * error, widget not found, and maxTimeSec not reached, sleep for length of
	 * sleepIntervalSec before checking again.
	 * 
	 * @param widget
	 *            The WidgetInfo whose existence is being verified.
	 * @param maxTimeSec
	 *            The maximum time in seconds the check for the existence of
	 *            widget will last.
	 * @param sleepIntervalSec
	 *            The time in seconds to wait for the page to load before
	 *            checking for the existence of the widget.
	 * @return doesWidgetExist The boolean returned, indicating the existence of
	 *         the widget.
	 */
	public boolean waitForPageLoad(WidgetInfo widget, double maxTimeSec,
			double sleepIntervalSec) {
		boolean doesWidgetExist = false;
		boolean doesCimsErrorExist = false;
		long sleepIntervalMs = (long) (sleepIntervalSec * 1000);
		Stopwatch timer = new Stopwatch();
		timer.start();

		do {
			try {
				doesCimsErrorExist = WidgetInfos.errorCheck.exists();
				doesWidgetExist = getWidgetManagerInstance().widgetExists(
						widget, 1, 0); // Exception will be thrown if Page is in
										// Loading process.
			} catch (Exception e) {
			}
			if (!doesWidgetExist && !doesCimsErrorExist) {
				try {
					Thread.sleep(sleepIntervalMs);
				} catch (InterruptedException e) {
					appendMessage("");
				}
			}
		} while (!doesWidgetExist && !doesCimsErrorExist
				&& timer.getTimeInMillis() < (long) (maxTimeSec * 1000));

		return doesWidgetExist;
	}

	/**
	 * Sleep for length of timeSec.
	 * 
	 * @param timeSec
	 *            The integer representing time in seconds.
	 */
	public void waitForTime(int timeSec) {
		try {
			Thread.sleep(timeSec * MS_IN_SECOND);
		} catch (InterruptedException e) {
			appendMessage("InterruptedException Occured in waitForTime(); ignoring it");
		}
	}

	/**
	 * Checks to see if string exists. Casts string to WidgetInfo. If widgetInfo
	 * exists, append success message to result file. If does not exist, append
	 * fail message to result file.
	 * 
	 * @param string
	 *            The String whose existence is being verified.
	 * @return The boolean returned, indicating the existence of the String.
	 */
	public boolean widgetExists(String string) {
		WidgetInfo widgetInfo = new WidgetInfo(string);
		return widgetExists(widgetInfo, null);
	}

	/**
	 * Checks to see if widgetInfo exists. If exists, append success message to
	 * result file. If does not exist, append fail message to result file.
	 * 
	 * @param widgetInfo
	 *            The WidgetInfo whose existence is being verified.
	 * @return The boolean returned, indicating the existence of the widgetInfo.
	 */
	public boolean widgetExists(WidgetInfo widgetInfo) {
		return widgetExists(widgetInfo, null);
	}

	/**
	 * Checks to see if widgetInfo exists. If exists, append success message to
	 * result file. If does not exist, append fail message to result file.
	 * 
	 * @param widgetInfo
	 *            The WidgetInfo whose existence is being verified.
	 * @param message
	 *            The String containing the message that is appended to the
	 *            result file. If the message is null, and the widgetInfo
	 *            exists, successMsg is appended to the result file. If the
	 *            message is null, and the widgetInfo doesn't exist, failMsg is
	 *            appended to the result file.
	 * @return exists The boolean returned, indicating the existence of the
	 *         widgetInfo.
	 */
	public boolean widgetExists(WidgetInfo widgetInfo, String message) {
		boolean exists = false;
		String widgetAttributes = fetchReqAttr(widgetInfo);
		String failMsg = (message != null) ? message : widgetAttributes
				+ " Widget not Found.";
		String successMsg = (message != null) ? message : widgetAttributes
				+ " Widget Found successfully.";
		try {
			if (sel.widgetExists(widgetInfo, CHECK_EXISTS_MAX_RETRIES,
					CHECK_EXISTS_RETRY_INTERVAL_SEC)) {
				exists = true;
				Verify.verifyTrue(exists, successMsg);
			} else {
				exists = false;
				Verify.verifyTrue(exists, failMsg);
			}
		} catch (ScriptException e) {
			appendMessageNoThrows("Received ScriptException in widgetExists(); ignoring it.");
		}
		return exists;
	}

	public boolean widgetExists_UIObjects(WidgetInfo widgetInfo) {
		boolean exists = false;
		String str = fetchReqAttr(widgetInfo);
		try {
			if (sel.widgetExists(widgetInfo, 5, 1)) {
				exists = true;
				Verify.verifyTrue(true, str + " Widget Found successfully.");
			} else {
				exists = false;
				appendMessage(str + " Widget not Found.");
			}
		} catch (ScriptException e) {
			appendMessageNoThrows("Exception Occurred while trying to verify if widget exists");
		}
		return exists;
	}

	public void handleActMgtVersion() {
		Link link = new Link("text=Activity Management Version "
				+ rollout.getField("mgtVersion") + ".0");
		if (link.exists(20)) {
			link.click();
		}
	}

	
	public void waitforBrowserisLoading(String titleToActivate, int waitCount,
			int sleepIntervalSec){
		Stopwatch timer = new Stopwatch();
		timer.start();
		long sleepIntervalMs = (long) (sleepIntervalSec * 1000);
		do{
		if (!isBrowserTitleExists(titleToActivate)) {
			try {
				Thread.sleep(sleepIntervalMs);
			} catch (InterruptedException e) {
				appendMessageNoThrows("InterruptedException in waitforBrowserisLoading(); ignoring it");
			}
		}
		}while(!isBrowserTitleExists(titleToActivate) && timer.getTimeInMillis() < (long) (waitCount * 1000));
	}
	
	public void waitforBrowserisLoading(int windowNum, int waitCount,
			int sleepIntervalSec){
		Stopwatch timer = new Stopwatch();
		timer.start();
		long sleepIntervalMs = (long) (sleepIntervalSec * 1000);
		List<String> windowTitleList = browser.getAllWindowTitles();
		do{
		if (windowTitleList.size()<windowNum) {
			try {
				Thread.sleep(sleepIntervalMs);
			} catch (InterruptedException e) {
				appendMessageNoThrows("InterruptedException in waitforBrowserisLoading(); ignoring it");
			}
		}
		}while(windowTitleList.size()<windowNum && timer.getTimeInMillis() < (long) (waitCount * 1000));
	}

	
	public boolean isBrowserTitleExists(String titleToActivate) {
		List<String> listBrowsers = browser.getAllWindowTitles();
		boolean flag = false;
		for (String browserTitle : listBrowsers) {
			if (browserTitle.contains(titleToActivate)) {
				flag = true;
				break;
			} 
		}
		return flag;
		
	}
	
	public String getActualBrowserTitle(String titleToActivate) {
		List<String> listBrowsers = browser.getAllWindowTitles();
		String browserActualTitle = null;
		for (String browserTitle : listBrowsers) {
			if (browserTitle.contains(titleToActivate)) {
				browserActualTitle= browserTitle;
			} 
		}
		return browserActualTitle;
	}
	
	public int getAllWindowTitlesCount() {
		List<String> listBrowsers = browser.getAllWindowTitles();
		return listBrowsers.size();
	}
	
	/**
	 * Method to click the text box and set the value through key stroke.  
	 * @param textField
	 * @param text
	 * @param message
	 * @throws ScriptException
	 */
	public void setTextInAutoCompleteTextbox(TextField textField, String text,
			String message) throws ScriptException {
		boolean textFieldindicator = true;
		for (int i = 1; i < 120; i++) {

			if (!textField.exists()) {
				try {
					textFieldindicator = false;
					if (i == 119) {
						Verify.verifyTrue(textFieldindicator, "Not" + message);
						Verify.verifyTrue(textFieldindicator, "Not" + message);
					}
				} catch (Exception e) {
					appendMessageNoThrows("Exception in setTextInAutoCompleteTextbox(); ignoring it");
				}
			} else {
				textField.click();
				textField.clearText();
				KeyboardUtility.sendKeys(text);
				Verify.verifyTrue(textFieldindicator, message);
				Verify.verifyTrue(textFieldindicator, message);
				break;
			}
		}
	}

	public void scriptError(ScriptException e) {
		appendMessage(e.getMessage());
	}
	
	/*public void setWindow(String requiredWindow) throws ScriptException
	{
		Set<String> windows = getWebDriverInstance().getWindowHandles();
		for (String window : windows)
		{
			getWebDriverInstance().switchTo().window(window).manage().window()
					.maximize();
			if ((getWebDriverInstance().getTitle().contains(requiredWindow)
			|| getWebDriverInstance().getCurrentUrl().contains(requiredWindow)))
				break;
		}
	}*/
	
	/**
	 * Waits for waitCount time in seconds. Instantiates a new Browser. Sets the
	 * browser active window to titleToActivate.
	 * 
	 * @param waitCount
	 *            This int contains a time in seconds.
	 * @param titleToActivateElement
	 *            This int contains a number representing a window title to
	 *            activate in the browser.
	 */
	public void setWindow(String titleToActivate, int waitCount,
			int sleepIntervalSec) throws ScriptException {
		waitforBrowserisLoading(titleToActivate, waitCount, sleepIntervalSec);		
		if(isBrowserTitleExists(titleToActivate))	{
			Set<String> windows = getWebDriverInstance().getWindowHandles();
			for (String window : windows)
			{
				getWebDriverInstance().switchTo().window(window).manage().window()
						.maximize();
				String t = getWebDriverInstance().getTitle();
				if ((getWebDriverInstance().getTitle().contains(titleToActivate)
				|| getWebDriverInstance().getCurrentUrl().contains(titleToActivate)))
					break;
			}
		}
	}
	
	


	public void setTopFrame() throws NoSuchFrameException
	{
		waitForTime(10);
		getWebDriverInstance().switchTo().frame("IFApplication");
	}
	
	public void setTopFramewithDefaultContent() throws NoSuchFrameException
	{
		waitForTime(10);
		getWebDriverInstance().switchTo().defaultContent();
		getWebDriverInstance().switchTo().frame("IFApplication");
	}
	
	public void setCustomerSearchTopFrame() throws NoSuchFrameException
	{
		getWebDriverInstance().switchTo().frame("theIFrame");
	}
	public void setIFrame() throws NoSuchFrameException
	{
		waitForTime(2);
		getWebDriverInstance().switchTo().frame("addUpdateDialogIframe");
		waitForTime(2);
	}
	

	public void setCRCTopFrame() throws NoSuchFrameException
	{
		getWebDriverInstance().switchTo().frame("TopFrame");
		setTopFrame();
		setCustomerSearchTopFrame();
	}
	
	public void setCRCDefaultFrame() throws NoSuchFrameException
	{
		getWebDriverInstance().switchTo().defaultContent();
		getWebDriverInstance().switchTo().frame("TopFrame");
		setTopFrame();
	}
	
	public void setCRCFrame() throws NoSuchFrameException
	{
		getWebDriverInstance().switchTo().defaultContent();
		getWebDriverInstance().switchTo().frame("TopFrame");
	}
	
	/**
	 *Closes the current browser
	 * 
	 */
	public void closeParentWindow() {
		getWebDriverInstance().close();
	}

	public void setIFramewithDefaultContent() throws NoSuchFrameException
	{
		getWebDriverInstance().switchTo().defaultContent();
		getWebDriverInstance().switchTo().frame("TopFrame");
		getWebDriverInstance().switchTo().frame("IFApplication");
	}

	
}
