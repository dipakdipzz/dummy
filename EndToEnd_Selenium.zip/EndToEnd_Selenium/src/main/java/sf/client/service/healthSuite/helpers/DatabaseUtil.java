package sf.client.service.healthSuite.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import sf.client.service.common.helpers.ITransferObject;
import sf.client.service.healthSuite.to.ClientE2ETO;

public class DatabaseUtil {

	public ClientE2ETO loadTestDataHousehold(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setLastNameSearchpage(dbResultSet
					.getString("SearchLastName"));
			clientTO.setFirstNameSearchpage(dbResultSet
					.getString("SearchFirstName"));
			clientTO.setStateSearchPage(dbResultSet.getString("StateAdd"));
			clientTO.setCustomerSearchpage(dbResultSet
					.getString("customerSearchpage"));
			clientTO.setOrgNameSearchpage(dbResultSet
					.getString("orgNameSearchpage"));
			clientTO.setZipSearchPage(dbResultSet.getString("zipSearchPage"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ResultSet getCoreData(ITransferObject dataObject) throws Exception {
		Connection dbConnectionurl;
		Statement dbStatementurl;

		ResultSet dbResultSetURL = null;
		try {
			String sFilename = dataObject.getDbFilePath()
					+ dataObject.getDbFileName();
			String sFileNamePrefix = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=";
			String sFileNameSuffix = ";DriverID=22;READONLY=false}";
			System.out.println("kkkkkkk" + sFilename);
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			dbConnectionurl = DriverManager.getConnection(sFileNamePrefix
					+ sFilename + sFileNameSuffix, "", "");
			dbStatementurl = dbConnectionurl.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			System.out.println("qury" + dataObject.getDbQuery());
			dbResultSetURL = dbStatementurl.executeQuery(dataObject
					.getDbQuery());
		} catch (SQLException e) {
			System.err.println("SQLException occured , Unable to execute "
					+ dataObject.getDbQuery());
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return dbResultSetURL;
	}

	/**
	 * This method helpful to load the state or region specific test data based
	 * on the input provided in mdb.properties. Ex: mdb=IL With the help of this
	 * method We can reuse the same scripts for different states or regions .
	 * 
	 * @return
	 */
	public String currentProject = System.getProperty("user.dir");
	int rowCount = 0;

	public ClientE2ETO loadTestDataAgentIndMRScenario2(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentCreateOrgCustScenario12(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			loadCreateOrgData(dbResultSet, clientTO);
			loadAddAtionalIndCreateData(dbResultSet, clientTO);
			loadAddAtionalOrgCreateData(dbResultSet, clientTO);
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
			clientTO.setmStreet1(dbResultSet.getString("mStreet1"));
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadCustInfoAddAliasOrgData(dbResultSet, clientTO);
			loadCustInfoAddSecondAliasOrgData(dbResultSet, clientTO);
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setUpdateEmailAddress(dbResultSet
					.getString("updateEmailAddress"));
			clientTO.setLastName2(dbResultSet.getString("lastName2"));
			clientTO.setFirstName2(dbResultSet.getString("firstName2"));
			loadRelationshipAddIndividual_MemberInsideData(dbResultSet,
					clientTO);
			loadCustInfoOrganizationPersonalInfoData(dbResultSet, clientTO);

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}


	public ClientE2ETO loadTestDataSWCreateOrgValidtnScenario26(
				ResultSet dbResultSet, ClientE2ETO clientTO) {
			try {
				launchHousehold(dbResultSet, clientTO);
				loadAddAtionalAddressCreateData(dbResultSet, clientTO);
				loadCreateData(dbResultSet, clientTO);
				loadTestDataHomePhoneData(dbResultSet, clientTO);
				loadTestDataMobilePhoneData(dbResultSet, clientTO);
				loadTestDataAdditionalPhoneData(dbResultSet, clientTO);
				loadTestDataAddUpdateEmailCustomerInfo(dbResultSet, clientTO);
				loadCustInfoAddAliasData(dbResultSet, clientTO);
				loadRelationshipAddIndividual_MemberInsideData(dbResultSet,
						clientTO);
				loadCustInfoPersonalInfoData(dbResultSet, clientTO);
				loadCombineData(dbResultSet, clientTO);
				loadSeparateData(dbResultSet, clientTO);
				loadConnectData(dbResultSet, clientTO);
				loadTestDataFaxPhoneData(dbResultSet, clientTO);
				clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
				clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
				clientTO.setClientID(dbResultSet.getString("clientID"));
				clientTO.setLinkedClients(dbResultSet.getString("linkedClients"));
				clientTO.setAgentCode(dbResultSet.getString("agentCode"));
				clientTO.setHhOrganizationName(dbResultSet
						.getString("hhOrganizationName"));
				clientTO.setWorkPhoneNumber(dbResultSet
						.getString("workPhoneNumber"));
				clientTO.setOrgEmailAddress1(dbResultSet
						.getString("orgEmailAddress1"));
				clientTO.setPermissionText(dbResultSet.getString("permissionText"));
				clientTO.setOrganizationName(dbResultSet
						.getString("organizationName"));
				clientTO.setMostimportanttoyou(dbResultSet
						.getString("mostImportantToYou"));
				clientTO.setHearAboutOffice(dbResultSet
						.getString("hearAboutOffice"));
				
			} catch (Exception e) {
				System.err.println("Unable to connect to  database ");
				System.err.println(e.getMessage());
				e.printStackTrace();
			}

			return clientTO;
		}

	public ClientE2ETO loadTestDataSupportWriteOrgScenario19(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadCreateOrgData(dbResultSet, clientTO);
			loadTestDataAddUpdateEmailCustomerInfo(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadMoveMemberBetweenTwoHouseholdsData(dbResultSet, clientTO);
			loadTestDataAgentAddProductsWithOthers(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setCellPhoneNumber(dbResultSet
					.getString("cellPhoneNumber"));
			clientTO.setPhoneNumber(dbResultSet.getString("phoneNumber"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataUSAgentIndividualScenario34(
			ResultSet dbResultSet, ClientE2ETO clientTO) {

		try {
			clientTO.setSsnNum(dbResultSet.getString("ssnNum"));
			clientTO.setSinNum(dbResultSet.getString("sinNum"));
			clientTO.setAgentCode(dbResultSet.getString("AgentCode"));
			clientTO.setmStreet(dbResultSet.getString("mStreet"));
			clientTO.setmCity(dbResultSet.getString("mCity"));
			clientTO.setMzip(dbResultSet.getString("mzip"));
			clientTO.setMstate(dbResultSet.getString("mstate"));
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
			clientTO.setHhCity(dbResultSet.getString("hhCity"));
			clientTO.setHhZip(dbResultSet.getString("hhZip"));
			clientTO.setSINCustomerOne(dbResultSet.getString("sINCustomerOne"));
			clientTO.setSINCustomerTwo(dbResultSet.getString("sINCustomerTwo"));
			clientTO.setHhSSN(dbResultSet.getString("hhSSN"));
			clientTO.setHhSIN(dbResultSet.getString("hhSIN"));
			clientTO.setType(dbResultSet.getString("type"));
			clientTO.setBirthDateCustomerOne(dbResultSet
					.getString("birthDateCustomerOne"));
			clientTO.setBirthDateCustomerTwo(dbResultSet
					.getString("birthDateCustomerTwo"));

			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadCreateIndNameData(dbResultSet, clientTO);
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataCNIndividualScenario36(
			ResultSet dbResultSet, ClientE2ETO clientTO) {

		try {
			clientTO.setSsnNum(dbResultSet.getString("ssnNum"));
			clientTO.setSinNum(dbResultSet.getString("sinNum"));
			clientTO.setAgentCode(dbResultSet.getString("AgentCode"));
			clientTO.setmStreet(dbResultSet.getString("mStreet"));
			clientTO.setmCity(dbResultSet.getString("mCity"));
			clientTO.setMzip(dbResultSet.getString("mzip"));
			clientTO.setMstate(dbResultSet.getString("mstate"));
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
			clientTO.setHhCity(dbResultSet.getString("hhCity"));
			clientTO.setHhZip(dbResultSet.getString("hhZip"));
			clientTO.setSINCustomerOne(dbResultSet.getString("sINCustomerOne"));
			clientTO.setSINCustomerTwo(dbResultSet.getString("sINCustomerTwo"));
			clientTO.setHhSSN(dbResultSet.getString("hhSSN"));
			clientTO.setHhSIN(dbResultSet.getString("hhSIN"));
			clientTO.setType(dbResultSet.getString("type"));
			clientTO.setBirthDateCustomerOne(dbResultSet
					.getString("birthDateCustomerOne"));
			clientTO.setBirthDateCustomerTwo(dbResultSet
					.getString("birthDateCustomerTwo"));

			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadCreateIndNameData(dbResultSet, clientTO);
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataSWIndividualScenario38(
			ResultSet dbResultSet, ClientE2ETO clientTO) {

		try {
			clientTO.setSsnNum(dbResultSet.getString("ssnNum"));
			clientTO.setSinNum(dbResultSet.getString("sinNum"));
			clientTO.setAgentCode(dbResultSet.getString("AgentCode"));
			clientTO.setmStreet(dbResultSet.getString("mStreet"));
			clientTO.setmCity(dbResultSet.getString("mCity"));
			clientTO.setMzip(dbResultSet.getString("mzip"));
			clientTO.setMstate(dbResultSet.getString("mstate"));
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
			clientTO.setHhCity(dbResultSet.getString("hhCity"));
			clientTO.setHhZip(dbResultSet.getString("hhZip"));
			clientTO.setSINCustomerOne(dbResultSet.getString("sINCustomerOne"));
			clientTO.setSINCustomerTwo(dbResultSet.getString("sINCustomerTwo"));
			clientTO.setHhSSN(dbResultSet.getString("hhSSN"));
			clientTO.setHhSIN(dbResultSet.getString("hhSIN"));
			clientTO.setType(dbResultSet.getString("type"));
			clientTO.setBirthDateCustomerOne(dbResultSet
					.getString("birthDateCustomerOne"));
			clientTO.setBirthDateCustomerTwo(dbResultSet
					.getString("birthDateCustomerTwo"));

			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadCreateIndNameData(dbResultSet, clientTO);
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestEnterpriseAgentIndScenario6(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestSWAgentIndScenario5(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			clientTO.setAgentAlias(dbResultSet.getString("agentAlias"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataEnterpriseSWIndScenario7(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			clientTO.setClientID(dbResultSet.getString("clientID"));
			clientTO.setLinkedClients(dbResultSet.getString("linkedClients"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataEnterpriseProdIndScenario8(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadConnectData(dbResultSet, clientTO);
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentIndSearchScenario1(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadTestDataDatesInHHPage(dbResultSet, clientTO);
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
			clientTO.setHhCity(dbResultSet.getString("hhCity"));
			clientTO.setHhZip(dbResultSet.getString("hhZip"));
			clientTO.setAgentName(dbResultSet.getString("agentName"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataSupportWrite_Ind_Sear_Scenario4(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadAdditionalIndividualMembersData(dbResultSet, clientTO);
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}
	public ClientE2ETO loadTestDataAgent_OOB_Ind_Scenario51(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			loadOobSearchData(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
			return clientTO;
	}
	public ClientE2ETO loadTestDataAgent_OOB_Org_Scenario52(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			loadOobSearchDataOrg(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
			return clientTO;
	}
	
	public ClientE2ETO loadTestAgentOOBIndScenario18(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			loadOobSearchData(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoAddSecondAliasData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadCustInfoCustomerInterestsData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadLifeEventData(dbResultSet, clientTO);
			loadTestDataAddEmploymentCustomerInfo(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setHomePhoneNumber(dbResultSet
					.getString("homePhoneNumber"));
			clientTO.setCallingPref(dbResultSet.getString("callingPref"));
			clientTO.setCellPhoneNumber(dbResultSet
					.getString("cellPhoneNumber"));
			clientTO.setSpecificDays(dbResultSet.getString("specificDays"));//
			clientTO.setPermissionText(dbResultSet.getString("permissionText"));
			clientTO.setFromTime(dbResultSet.getString("fromTime"));
			clientTO.setToTime(dbResultSet.getString("toTime"));
			clientTO.setmStreet(dbResultSet.getString("mstreet"));
			clientTO.setmCity(dbResultSet.getString("mCity"));
			clientTO.setMstate(dbResultSet.getString("mstate"));
			clientTO.setMzip(dbResultSet.getString("mzip"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}
	
	public ClientE2ETO loadTestNonAgentOOBIndScenario50(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			loadOobSearchData(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoAddSecondAliasData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadCustInfoCustomerInterestsData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadLifeEventData(dbResultSet, clientTO);
			loadTestDataAddEmploymentCustomerInfo(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setHomePhoneNumber(dbResultSet
					.getString("homePhoneNumber"));
			clientTO.setCallingPref(dbResultSet.getString("callingPref"));
			clientTO.setCellPhoneNumber(dbResultSet
					.getString("cellPhoneNumber"));
			clientTO.setSpecificDays(dbResultSet.getString("specificDays"));//
			clientTO.setPermissionText(dbResultSet.getString("permissionText"));
			clientTO.setFromTime(dbResultSet.getString("fromTime"));
			clientTO.setToTime(dbResultSet.getString("toTime"));
			clientTO.setmStreet(dbResultSet.getString("mstreet"));
			clientTO.setmCity(dbResultSet.getString("mCity"));
			clientTO.setMstate(dbResultSet.getString("mstate"));
			clientTO.setMzip(dbResultSet.getString("mzip"));
			clientTO.setAgentAlias(dbResultSet.getString("agentAlias"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataUSAgentOrgScenario35(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setTaxIdNumber(dbResultSet.getString("tin"));
			clientTO.setType(dbResultSet.getString("type"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setMailingType(dbResultSet.getString("hhMailing"));
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadCreateOrgData(dbResultSet, clientTO);

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataSWOrgScenario39(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		return loadTestDataUSAgentOrgScenario35(dbResultSet, clientTO);
	}

	public ClientE2ETO loadTestDataCNAgentOrgScenario37(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		return loadTestDataUSAgentOrgScenario35(dbResultSet, clientTO);
	}

	public ClientE2ETO loadTestDataAgentCanadaianScenario29(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			clientTO.setCustomerType(dbResultSet.getString("customerType"));
			clientTO.setPolicyNumber(dbResultSet.getString("policyNumber"));
			clientTO.setPhoneNumber(dbResultSet.getString("phoneNumber"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setAgentAlias(dbResultSet.getString("agentAlias"));
			clientTO.setPhoneNumber1(dbResultSet.getString("phoneNumber1"));
			
			clientTO.setLastName(dbResultSet.getString("lastName"));
			clientTO.setFirstName(dbResultSet.getString("firstName"));
			clientTO.setState(dbResultSet.getString("state"));
			clientTO.setCity(dbResultSet.getString("city"));
			clientTO.setPolicyStateOrProv(dbResultSet.getString("policyStateOrProv"));
			clientTO.setMovingState(dbResultSet.getString("movingState"));
			clientTO.setMovingCity(dbResultSet.getString("movingCity"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentScenario31(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		return loadTestDataAgentCanadaianScenario29(dbResultSet, clientTO);
	}

	public ClientE2ETO loadTestDataNACanadaianScenario30(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		return loadTestDataAgentCanadaianScenario29(dbResultSet, clientTO);
	}

	public ClientE2ETO loadTestDataNAScenario32(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		return loadTestDataAgentCanadaianScenario29(dbResultSet, clientTO);
	}

	public ClientE2ETO loadTestDataSharedAgentScenario33(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataSingleAgentScenario33(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public void launchHousehold(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setCsLastName(dbResultSet.getString("csLastName"));
		clientTO.setCsOrgName(dbResultSet.getString("csOrgName"));
		clientTO.setCsFirstName(dbResultSet.getString("csFirstName"));
		clientTO.setCsZip(dbResultSet.getString("csZip"));
		clientTO.setCustomerOneData(dbResultSet.getString("customerOneData"));
	}

	public void loadCombineData(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setLastNameSS2CSecondCust(dbResultSet
				.getString("lastNameSS2CSecondCust"));
		clientTO.setFirstNameSS2CSecondCust(dbResultSet
				.getString("firstNameSS2CSecondCust"));
		clientTO.setLastNameSS2CFirstCust(dbResultSet
				.getString("lastNameSS2CFirstCust"));
		clientTO.setFirstNameSS2CFirstCust(dbResultSet
				.getString("firstNameSS2CFirstCust"));
		clientTO.setCity(dbResultSet.getString("city"));
		clientTO.setState(dbResultSet.getString("state"));
		clientTO.setZipSS2C(dbResultSet.getString("zipSS2C"));
		clientTO.setCombineCust1Name(dbResultSet.getString("combineCust1Name"));
		clientTO.setCombineCust2Name(dbResultSet.getString("combineCust2Name"));
		clientTO.setZip(dbResultSet.getString("zip"));
	}

	public void loadConnectData(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setOrgNameSearchpage(dbResultSet
				.getString("orgNameSearchpage"));
		clientTO.setZipSearchPage(dbResultSet.getString("zipSearchPage"));
		clientTO.setStateSearchPage(dbResultSet.getString("stateSearchPage"));
		clientTO.setrCity(dbResultSet.getString("rCity"));
		clientTO.setLastNameSearchpage(dbResultSet
				.getString("lastNameSearchpage"));
		clientTO.setFirstNameSearchpage(dbResultSet
				.getString("firstNameSearchpage"));
		clientTO.setMiddleName(dbResultSet.getString("middleName"));
		clientTO.setSs2cFirstCustomer(dbResultSet
				.getString("ss2cFirstCustomer"));
		clientTO.setOrgName2(dbResultSet.getString("OrgName2"));
		clientTO.setZip2(dbResultSet.getString("zip2"));
		clientTO.setState2(dbResultSet.getString("State2"));
		clientTO.setCity2(dbResultSet.getString("City2"));
		clientTO.setLastName2(dbResultSet.getString("lastName2"));
		clientTO.setFirstName2(dbResultSet.getString("firstName2"));
		clientTO.setMiddleName2(dbResultSet.getString("middleName2"));
		clientTO.setSs2cSecondCustomer(dbResultSet
				.getString("ss2cSecondCustomer"));

	}

	public void loadCreateData(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setFirstName(dbResultSet.getString("firstName"));
		clientTO.setLastName(dbResultSet.getString("lastName"));
		clientTO.setmStreet(dbResultSet.getString("mstreet"));
		clientTO.setmCity(dbResultSet.getString("mCity"));
		clientTO.setMstate(dbResultSet.getString("mstate"));
		clientTO.setMzip(dbResultSet.getString("mzip"));
		clientTO.setAddressUsage(dbResultSet.getString("addressUsage"));
	}

	public void loadCreateIndNameData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setFirstName(dbResultSet.getString("firstName"));
		clientTO.setLastName(dbResultSet.getString("lastName"));
	}

	public void loadCreateOrgData(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setOrganizationType(dbResultSet.getString("orgType"));
		clientTO.setOrganizationName(dbResultSet.getString("organizationName"));
		clientTO.setmStreet(dbResultSet.getString("mstreet"));
		clientTO.setmCity(dbResultSet.getString("mCity"));
		clientTO.setMstate(dbResultSet.getString("mstate"));
		clientTO.setMzip(dbResultSet.getString("mzip"));
	}

	public void loadAddAtionalIndCreateData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setAddAddlIndFirstName(dbResultSet
				.getString("addAddlIndFirstName"));
		clientTO.setAddAddlIndLastName(dbResultSet
				.getString("addAddlIndLastName"));
	}

	public void loadAddAtionalOrgCreateData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setAddAddlOrgName(dbResultSet.getString("addAddlOrgName"));
	}

	public void loadAddAtionalAddressCreateData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
		clientTO.setHhCity(dbResultSet.getString("hhCity"));
		clientTO.setHhState(dbResultSet.getString("hhState"));
		clientTO.setHhZip(dbResultSet.getString("hhZip"));

	}

	public void loadCustInfoAddAliasData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setTitle(dbResultSet.getString("title"));
		clientTO.setAliasLastName(dbResultSet.getString("aliasLastName"));
		clientTO.setAliasFirstName(dbResultSet.getString("aliasFirstName"));
		clientTO.setUpdateLastName(dbResultSet.getString("updateLastName"));
	}

	public void loadCustInfoAddAliasOrgData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {

		clientTO.setAliasLastName(dbResultSet.getString("aliasLastName"));
	}

	public void loadCustInfoAddSecondAliasData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setSecondAliasLastName(dbResultSet
				.getString("secondAliasLastName"));
		clientTO.setSecondAliasFirstName(dbResultSet
				.getString("secondAliasFirstName"));
	}

	public void loadCustInfoAddSecondAliasOrgData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setSecondAliasLastName(dbResultSet
				.getString("secondAliasLastName"));
		clientTO.setOrganizationName(dbResultSet.getString("orgName1"));
	}

	public void loadCustInfoPersonalInfoData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setBirthDate(dbResultSet.getString("birthDate"));
		clientTO.setDrivingLicense(dbResultSet.getString("drivingLicense"));
		clientTO.setLicensedStateOrProv(dbResultSet
				.getString("licensedStateOrProv"));
		clientTO.setMaritalStatus(dbResultSet.getString("maritalStatus"));
		clientTO.setSsnNum(dbResultSet.getString("ssn"));
		clientTO.setLivingArrangements(dbResultSet
				.getString("livingArrangements"));
		clientTO.setCustomerCategory(dbResultSet.getString("customerCategory"));
		clientTO.setCitizenship(dbResultSet.getString("citizenship"));
		clientTO.setFirstYrWithSF(dbResultSet.getString("firstYrWithSF"));
		clientTO.setPersonalInfoAsOfDate(dbResultSet
				.getString("personalInfoAsOfDate"));
		clientTO.setDeathDate(dbResultSet.getString("deathDate"));
		// clientTO.setAssignedStaff(dbResultSet.getString("assignedStaff"));
	}

	public void loadCustInfoOrganizationPersonalInfoData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setOrganizationType(dbResultSet.getString("organizationType"));
		clientTO.setTaxIdNumber(dbResultSet.getString("taxIdNumber"));
		clientTO.setIndustry(dbResultSet.getString("industry"));
		clientTO.setIndustryOther(dbResultSet.getString("IndustryOther"));
		clientTO.setNumberOfEmployees(dbResultSet
				.getString("numberOfEmployees"));
		clientTO.setOrganizationRevenue(dbResultSet
				.getString("organizationRevenue"));
		clientTO.setFirstYrWithSF(dbResultSet.getString("firstYrWithSF"));
		clientTO.setCustomerCategory(dbResultSet.getString("customerCategory"));
		clientTO.setHearAboutOffice(dbResultSet.getString("hearAboutOffice"));
		clientTO.setMostimportanttoyou(dbResultSet
				.getString("mostimportanttoyou"));

	}

	public void loadCustInfoCustomerInterestsData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setCustomerInterest(dbResultSet.getString("customerInterest"));

	}

	public void loadErrorValidationsData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setErrorMessageOne(dbResultSet.getString("errorMessageOne"));
		clientTO.setErrorMessageTwo(dbResultSet.getString("errorMessageTwo"));
		clientTO.setIsTest(dbResultSet.getString("isTest"));
		clientTO.setTestCaseName(dbResultSet.getString("testCaseName"));
	}
	public ClientE2ETO loadOobSearchDataOrg(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setOrgName(dbResultSet.getString("orgName"));
			clientTO.setZip(dbResultSet.getString("zip"));
			clientTO.setState(dbResultSet.getString("state"));
			clientTO.setCity(dbResultSet.getString("city"));
			clientTO.setLob(dbResultSet.getString("lob"));
			clientTO.setPolicyNumber(dbResultSet.getString("policyNumber"));
			clientTO.setPolicyStateOrProv(dbResultSet.getString("policyStateOrProv"));
			clientTO.setMovingState(dbResultSet.getString("movingState"));
			clientTO.setMovingCity(dbResultSet.getString("movingCity"));
			clientTO.setMovingZip(dbResultSet.getString("movingZip"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
}
	public ClientE2ETO loadOobSearchData(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setLastName(dbResultSet.getString("lastName"));
			clientTO.setFirstName(dbResultSet.getString("firstName"));
			clientTO.setZip(dbResultSet.getString("zip"));
			clientTO.setState(dbResultSet.getString("state"));
			clientTO.setCity(dbResultSet.getString("city"));
			clientTO.setLob(dbResultSet.getString("lob"));
			clientTO.setPolicyNumber(dbResultSet.getString("policyNumber"));
			clientTO.setPolicyStateOrProv(dbResultSet
					.getString("policyStateOrProv"));
			clientTO.setSSN(dbResultSet.getString("usSsn"));
			clientTO.setMovingState(dbResultSet.getString("movingState"));
			clientTO.setMovingCity(dbResultSet.getString("movingCity"));
			clientTO.setMovingZip(dbResultSet.getString("movingZip"));
			clientTO.setCustomerSearchpage(dbResultSet
					.getString("customerSearchpage"));
			clientTO.setHhMemberAdd1(dbResultSet.getString("hhMemberAdd1"));

		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadLifeEventData(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setLifeEvent(dbResultSet.getString("lifeEvent"));
			clientTO.setLifeEvent2AsOfDate(dbResultSet
					.getString("lifeEvent2AsOfDate"));

		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentCombineCustUSSSNCNSINErrorValidation42(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadErrorValidationsData(dbResultSet, clientTO);
			clientTO.setCnSIN_Combine(dbResultSet.getString("combineCnSIN"));
			clientTO.setUsSSN_Combine(dbResultSet.getString("combineUsSSN"));
			clientTO.setCitizenshipAllowedValues(dbResultSet
					.getString("citizenshipAllowedValues"));
			clientTO.setPreferredLanguagesAllowedValues(dbResultSet
					.getString("preferredLanguagesAllowedValues"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentCreateIndHouseHoldUSSSNCNSINErrorValidation42(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadErrorValidationsData(dbResultSet, clientTO);
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setSsnNum(dbResultSet.getString("ssnNum"));
			clientTO.setSinNum(dbResultSet.getString("sinNum"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentCreateIndCustScenario10(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		try {
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadMoveMemberBetweenTwoHouseholdsData(dbResultSet, clientTO);
			loadCreateData(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadRelationshipAddIndividual_MemberInsideData(dbResultSet,
					clientTO);
			loadAdditionalIndividualMembersData(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadTestDataAddEmploymentCustomerInfo(dbResultSet, clientTO);
			loadTestDataForeignAddress(dbResultSet, clientTO);
			clientTO.setCity2(dbResultSet.getString("city2"));
			clientTO.setState2(dbResultSet.getString("state2"));
			clientTO.setZip2(dbResultSet.getString("zip2"));
			clientTO.setPhoneNumber(dbResultSet.getString("phoneNumber"));
			clientTO.setLastName2(dbResultSet.getString("lastName2"));
			clientTO.setFirstName2(dbResultSet.getString("firstName2"));
			clientTO.setmStreet1(dbResultSet.getString("mstreet1"));
			clientTO.setCsFirstName(dbResultSet.getString("csFirstName"));
			clientTO.setCsLastName(dbResultSet.getString("csLastName"));
			clientTO.setCsZip(dbResultSet.getString("csZip"));
			clientTO.setPortalTestId(dbResultSet.getString("portalTestId"));
			clientTO.setPortalDomain(dbResultSet.getString("portalDomain"));
			clientTO.setPortalPassword(dbResultSet.getString("portalPassword"));
			clientTO.setUrlPortal(dbResultSet.getString("urlPortal"));
			System.out.println("urlPortal:"+clientTO.getUrlPortal());
			clientTO.setTestCaseName(dbResultSet.getString("testCaseName"));
			clientTO.setIsTest(dbResultSet.getString("isTest"));
			System.out.println("isTest:"+clientTO.getIsTest());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataForeignAddress(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setForeignStreet(dbResultSet.getString("foreignStreet"));
		clientTO.setForeignCity(dbResultSet.getString("foreignCity"));
		clientTO.setForeignPostal(dbResultSet.getString("foreignPostal"));
		clientTO.setForeignCountry(dbResultSet.getString("foreignCountry"));
		clientTO.setForeignAddress(dbResultSet.getString("foreignAddress"));
		return clientTO;
	}

	public ClientE2ETO loadRelationshipAddIndividual_MemberInsideData(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		clientTO.setFirstIndName(dbResultSet.getString("firstIndName"));
		clientTO.setLastIndName(dbResultSet.getString("lastIndName"));
		clientTO.setIndStreet(dbResultSet.getString("indStreet"));
		clientTO.setIndcity(dbResultSet.getString("indcity"));
		clientTO.setIndstate(dbResultSet.getString("indstate"));
		clientTO.setIndZip(dbResultSet.getString("indZip"));
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentCreateIndCustScenario11(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		try {
			loadCreateData(dbResultSet, clientTO);
			loadAddAtionalIndCreateData(dbResultSet, clientTO);
			loadAddAtionalOrgCreateData(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoAddSecondAliasData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadCustInfoCustomerInterestsData(dbResultSet, clientTO);
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
			clientTO.setMailingType(dbResultSet.getString("mailingType"));
			clientTO.setmStreet1(dbResultSet.getString("mStreet1"));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataSWIndCustIntlCharScenario14(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		try {
			loadCreateData(dbResultSet, clientTO);
			loadAddAtionalIndCreateData(dbResultSet, clientTO);
			loadAddAtionalOrgCreateData(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			clientTO.setClientID(dbResultSet.getString("clientID"));
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoAddSecondAliasData(dbResultSet, clientTO);
			clientTO.setmStreet1(dbResultSet.getString("mStreet1"));
			clientTO.setLinkedClients(dbResultSet.getString("linkedClients"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataEnterpriseCRCScenario9(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoAddSecondAliasData(dbResultSet, clientTO);
			loadTestDataAddEmploymentCustomerInfo(dbResultSet, clientTO);
			loadTestDataUpdateEmploymentCustomerInfo(dbResultSet, clientTO);
			loadTestDataUpdateLifeEventCustomerInfo(dbResultSet, clientTO);
			loadLifeEventData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			clientTO.setOccupationOther(dbResultSet
					.getString("occupationOther"));
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setCallingPref(dbResultSet.getString("callingPref"));
			clientTO.setJobTitleOther(dbResultSet.getString("jobTitleOther"));
			clientTO.setUpdateEmailAddress(dbResultSet
					.getString("updateEmailAddress"));
			clientTO.setUpdatePhoneNumber(dbResultSet
					.getString("updatePhoneNumber"));
			clientTO.setToTime(dbResultSet.getString("toTime"));
			clientTO.setFromTime(dbResultSet.getString("fromTime"));
			clientTO.setWorkPhoneNumber(dbResultSet
					.getString("workPhoneNumber"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataSWIndCustIntlCharScenario13(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		try {
			loadCreateData(dbResultSet, clientTO);
			loadAddAtionalIndCreateData(dbResultSet, clientTO);
			loadAddAtionalOrgCreateData(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoAddSecondAliasData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadCustInfoCustomerInterestsData(dbResultSet, clientTO);
			loadTestDataAddEmploymentCustomerInfo(dbResultSet, clientTO);
			loadTestDataUpdateEmploymentCustomerInfo(dbResultSet, clientTO);
			loadLifeEventData(dbResultSet, clientTO);
			loadTestDataUpdateLifeEventCustomerInfo(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadMoveMemberBetweenTwoHouseholdsData(dbResultSet, clientTO);
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setUpdateEmailAddress(dbResultSet
					.getString("updateEmailAddress"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
			clientTO.setmStreet1(dbResultSet.getString("mStreet1"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setUpdateCustomerInterest(dbResultSet
					.getString("updateCustomerInterest"));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadMoveMemberBetweenTwoHouseholdsData(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		clientTO.setLastNameHHMOVESearchpage(dbResultSet
				.getString("lastNameHHMOVESearchpage"));
		clientTO.setFirstNameHHMOVESearchpage(dbResultSet
				.getString("firstNameHHMOVESearchpage"));
		clientTO.setZipHHMOVESearchPage(dbResultSet
				.getString("zipHHMOVESearchPage"));
		clientTO.setCityHHMOVESearchPage(dbResultSet
				.getString("cityHHMOVESearchPage"));
		clientTO.setSs2cFirstCustomerHHMOVE(dbResultSet
				.getString("ss2cFirstCustomerHHMOVE"));
		clientTO.setLastNameHHMOVE2Searchpage(dbResultSet
				.getString("lastNameHHMOVE2Searchpage"));
		clientTO.setFirstNameHHMOVE2Searchpage(dbResultSet
				.getString("firstNameHHMOVE2Searchpage"));
		clientTO.setCityHHMOVE2SearchPage(dbResultSet
				.getString("cityHHMOVE2SearchPage"));
		clientTO.setZipHHMOVE2SearchPage(dbResultSet
				.getString("zipHHMOVE2SearchPage"));
		clientTO.setSs2cSecondCustomerHHMOVE(dbResultSet
				.getString("ss2cSecondCustomerHHMOVE"));
		clientTO.setMoveCustomerOneHHMOVE(dbResultSet
				.getString("moveCustomerOneHHMOVE"));
		clientTO.setMoveCustomerTwoHHMOVE(dbResultSet
				.getString("moveCustomerTwoHHMOVE"));
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentCreateIndLinkUSSSNCNSINErrorValidation42(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			loadCreateData(dbResultSet, clientTO);
			loadErrorValidationsData(dbResultSet, clientTO);
			loadSSNSINData(dbResultSet, clientTO);
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public void loadSSNSINData(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setSinNum(dbResultSet.getString("sinNum"));
		clientTO.setSsnNum(dbResultSet.getString("ssnNum"));
	}

	public void loadUSSSNCNSINData(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setUsSSN(dbResultSet.getString("usSSN"));
		clientTO.setCnSIN(dbResultSet.getString("cnSIN"));
	}

	public ClientE2ETO loadTestDataAgentCustInfUSSSNCNSINErrorValidation42(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadErrorValidationsData(dbResultSet, clientTO);
			loadUSSSNCNSINData(dbResultSet, clientTO);
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public void loadTestDataFaxPhoneData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setFaxPhoneNumber(dbResultSet.getString("faxPhoneNumber"));
		clientTO.setFaxSpecificSun(dbResultSet.getString("faxSpecificSun"));
		clientTO.setFaxCallingPref(dbResultSet.getString("faxCallingPref"));
		clientTO.setFaxFromTime(dbResultSet.getString("faxFromTime"));
		clientTO.setFaxToTime(dbResultSet.getString("faxToTime"));
	}

	public void loadTestDataHomePhoneData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setHomePhoneNumber(dbResultSet.getString("homePhoneNumber"));
		clientTO.setCallingPrefDayHome(dbResultSet
				.getString("callingPrefDayHome"));
		clientTO.setHomeFromTime(dbResultSet.getString("homeFromTime"));
		clientTO.setHomeToTime(dbResultSet.getString("homeToTime"));
	}

	public void loadTestDataMobilePhoneData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setCellPhoneNumber(dbResultSet.getString("cellPhoneNumber"));
		clientTO.setCallingPref(dbResultSet.getString("callingPref"));
		clientTO.setFromTime(dbResultSet.getString("fromTime"));
		clientTO.setToTime(dbResultSet.getString("toTime"));
	}

	public void loadTestDataWorkPhoneData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setWorkPhoneNumber(dbResultSet.getString("workPhoneNumber"));
		clientTO.setCallingPrefDayWork(dbResultSet
				.getString("callingPrefDayWork"));
		clientTO.setCallingPrefFromTimeWork(dbResultSet
				.getString("callingPrefFromTimeWork"));
		clientTO.setCallingPrefToTimeWork(dbResultSet
				.getString("callingPrefToTimeWork"));
	}

	public void loadTestDataAdditionalPhoneData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setAdditionalType(dbResultSet.getString("additionalType"));
		clientTO.setAdditionalCallingPref(dbResultSet
				.getString("additionalCallingPref"));
		clientTO.setAdditionalFromTime(dbResultSet
				.getString("additionalFromTime"));
		clientTO.setAdditionalToTime(dbResultSet.getString("additionalToTime"));
		clientTO.setAdditionalPhoneNumber(dbResultSet
				.getString("additionalPhoneNumber"));
	}

	public void loadTestDataMarketingInfo(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setMostimportanttoyou(dbResultSet
				.getString("mostimportanttoyou"));
		clientTO.setHearAboutOffice(dbResultSet.getString("hearAboutOffice"));
	}

	public ClientE2ETO loadTestDataAgentAddProductsWithOthers(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		try {
			clientTO.setLineOfBusiness(dbResultSet.getString("lineOfBusiness"));
			clientTO.setProvince(dbResultSet.getString("province"));
			clientTO.setProductType(dbResultSet.getString("productType"));
			clientTO.setCompany(dbResultSet.getString("company"));
			clientTO.setXdate(dbResultSet.getString("xDate"));
			clientTO.setDetails(dbResultSet.getString("Details"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentCreateOrgScenario23(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		try {
			loadCreateOrgData(dbResultSet, clientTO);
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadTestDataFaxPhoneData(dbResultSet, clientTO);
			loadTestDataAdditionalPhoneData(dbResultSet, clientTO);
			loadTestDataMarketingInfo(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadMoveMemberBetweenTwoHouseholdsData(dbResultSet, clientTO);
			loadTestDataAgentAddProductsWithOthers(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadTestDataForeignAddress(dbResultSet, clientTO);
			clientTO.setWorkPhoneNumber(dbResultSet
					.getString("workPhoneNumber"));
			clientTO.setHomePhoneNumber(dbResultSet
					.getString("homePhoneNumber"));
			clientTO.setPermissionText(dbResultSet.getString("permissionText"));
			clientTO.setSpecificDays(dbResultSet.getString("specificDays"));
			clientTO.setStreet(dbResultSet.getString("street"));
			clientTO.setCity2(dbResultSet.getString("city2"));
			clientTO.setmCountry(dbResultSet.getString("mCountry"));
			clientTO.setState2(dbResultSet.getString("state2"));
			clientTO.setZip2(dbResultSet.getString("zip2"));
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentIndValidtnLinkScenario22(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		try {
			loadCreateData(dbResultSet, clientTO);
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadTestDataHomePhoneData(dbResultSet, clientTO);
			loadTestDataAdditionalPhoneData(dbResultSet, clientTO);
			loadTestDataMarketingInfo(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadTestDataAgentAddProductsWithOthers(dbResultSet, clientTO);
			loadAddAtionalIndCreateData(dbResultSet, clientTO);
			loadRelationshipAddIndividual_MemberInsideData(dbResultSet,
					clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setPermissionText(dbResultSet.getString("permissionText"));
			clientTO.setTemplates(dbResultSet.getString("templates"));
			clientTO.setSpecificDays(dbResultSet.getString("specificDays"));
			clientTO.setLastName2(dbResultSet.getString("lastName2"));
			clientTO.setFirstName2(dbResultSet.getString("firstName2"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhEmailAddress1(dbResultSet.getString("hhEmailAddress1"));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentOrgScenario17(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		try {
			loadCreateOrgData(dbResultSet, clientTO);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentSeparateCustUSSSNCNSINValidation(
			ResultSet dbResultSet, ClientE2ETO clientTO) throws SQLException {
		launchHousehold(dbResultSet, clientTO);
		loadErrorValidationsData(dbResultSet, clientTO);
		loadSeparateData(dbResultSet, clientTO);
		clientTO.setSinOne(dbResultSet.getString("sinOne"));
		clientTO.setSinTwo(dbResultSet.getString("sinTwo"));

		return clientTO;

	}

	public void loadSeparateData(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setLastNameSearchpage_sept(dbResultSet
				.getString("lastNameSearchpage_sept"));
		clientTO.setFirstNameSearchpage_sept(dbResultSet
				.getString("firstNameSearchpage_sept"));
		clientTO.setZipSearchPage_sept(dbResultSet
				.getString("zipSearchPage_sept"));
		clientTO.setSS1CFirstCustomer(dbResultSet
				.getString("SS1CFirstCustomer"));
		clientTO.setCustomer1Name(dbResultSet.getString("customer1Name"));
		clientTO.setSSNCustomerOne(dbResultSet.getString("sSNCustomerOne"));
		clientTO.setSSNCustomerTwo(dbResultSet.getString("sSNCustomerTwo"));
		clientTO.setMoveNameData(dbResultSet.getString("moveNameData"));
	}

	public ClientE2ETO loadTestDataAgentSearchIndScenario24(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCreateData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadCustInfoCustomerInterestsData(dbResultSet, clientTO);
			loadTestDataAddUpdateEmailCustomerInfo(dbResultSet, clientTO);
			loadTestDataAddEmploymentCustomerInfo(dbResultSet, clientTO);
			loadTestDataPhoneSectionCustomerInfo(dbResultSet, clientTO);
			loadTestDataAgentAddProductsWithOthers(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadLifeEventData(dbResultSet, clientTO);
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
			clientTO.setHhCity(dbResultSet.getString("hhCity"));
			clientTO.setHhZip(dbResultSet.getString("hhZip"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataAddUpdateEmailCustomerInfo(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setUpdateEmailAddress(dbResultSet
					.getString("updateEmailAddress"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAddEmploymentCustomerInfo(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			clientTO.setEmployerName(dbResultSet.getString("employerName"));
			clientTO.setOccupation(dbResultSet.getString("occupation"));
			clientTO.setOccupationStatus(dbResultSet
					.getString("occupationStatus"));
			clientTO.setJobTitle(dbResultSet.getString("jobTitle"));
			clientTO.setEmploymentAsOfDate(dbResultSet
					.getString("employmentAsOfDate"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataPhoneSectionCustomerInfo(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			clientTO.setTemplates(dbResultSet.getString("templates"));
			clientTO.setCellPhoneNumber(dbResultSet
					.getString("cellPhoneNumber"));
			clientTO.setHomePhoneNumber(dbResultSet
					.getString("homePhoneNumber"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAHQBIndSrchScenario28(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadTestDataAgentAddProductsWithOthers(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadCreateOrgData(dbResultSet, clientTO);
			loadCreateIndNameData(dbResultSet, clientTO);
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadTestDataHomePhoneData(dbResultSet, clientTO);
			loadTestDataAdditionalPhoneData(dbResultSet, clientTO);
			loadTestDataMarketingInfo(dbResultSet, clientTO);
			loadEmailTestData(dbResultSet, clientTO);
			clientTO.setOrgBusinessPhoneNum(dbResultSet
					.getString("orgBusinessPhoneNum"));
			clientTO.setOrgEmailAddress1(dbResultSet
					.getString("orgEmailAddress1"));
			clientTO.setAddressUsage(dbResultSet.getString("addressUsage"));
			clientTO.setSpecificDays(dbResultSet.getString("specificDays"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setPermissionText(dbResultSet.getString("permissionText"));
			clientTO.setHhEmailAddress1(dbResultSet.getString("hhEmailAddress1"));

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAHQBSearchIndCustScenario16(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadEmailTestData(dbResultSet, clientTO);
			loadAdditionalIndividualMembersData(dbResultSet, clientTO);
			loadTestDataAddEmploymentCustomerInfo(dbResultSet, clientTO);
			loadTestDataUpdateEmploymentCustomerInfo(dbResultSet, clientTO);
			loadTestDataUpdateLifeEventCustomerInfo(dbResultSet, clientTO);
			loadLifeEventData(dbResultSet, clientTO);
			clientTO.setOccupationOther(dbResultSet
					.getString("occupationOther"));
			clientTO.setJobTitleOther(dbResultSet.getString("jobTitleOther"));
			clientTO.setUpdateEmailAddress(dbResultSet
					.getString("updateEmailAddress"));
			clientTO.setUpdatePhoneNumber(dbResultSet
					.getString("updatePhoneNumber"));
			clientTO.setToTime(dbResultSet.getString("toTime"));
			clientTO.setCallingPref(dbResultSet.getString("callingPref"));
			clientTO.setFromTime(dbResultSet.getString("fromTime"));
			clientTO.setWorkPhoneNumber(dbResultSet
					.getString("workPhoneNumber"));
			clientTO.setMailingType(dbResultSet.getString("mailingType"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
			clientTO.setHhState(dbResultSet.getString("hhState"));

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataDatesInHHPage(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setPreviousReviewDate(dbResultSet
					.getString("previousReview"));
			clientTO.setNextReviewDate(dbResultSet.getString("nextReview"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadEmailTestData(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setEmail(dbResultSet.getString("email"));
			clientTO.setEmailMarketing(dbResultSet.getString("emailMarketing"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentOrgSearchScenario3(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadTestDataDatesInHHPage(dbResultSet, clientTO);
			clientTO.setLastNameSearchpage(dbResultSet.getString("lastName"));
			clientTO.setFirstNameSearchpage(dbResultSet.getString("firstName"));
			clientTO.setZipSearchPage(dbResultSet.getString("zip"));
			clientTO.setCitySearchPage(dbResultSet.getString("city"));
			clientTO.setState(dbResultSet.getString("state"));
			clientTO.setAgentName(dbResultSet.getString("agentName"));
			clientTO.setZip(dbResultSet.getString("zip1"));
			clientTO.setOrgName(dbResultSet.getString("orgName"));
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
			clientTO.setHhCity(dbResultSet.getString("hhCity"));
			clientTO.setHhZip(dbResultSet.getString("hhZip"));
			loadSeparateData(dbResultSet, clientTO);
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataOOBEnterpriseViewAgent49(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {

			launchHousehold(dbResultSet, clientTO);

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataOOBEnterpriseViewNonAgent50(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {

			launchHousehold(dbResultSet, clientTO);
			clientTO.setAgentAlias(dbResultSet.getString("agentAlias"));

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataUSAgentCreateFlow40(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			loadCreateData(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setSsnNum(dbResultSet.getString("ssn"));
			clientTO.setSinNum(dbResultSet.getString("sin"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataCanadaAgentCreateFlow41(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			loadCreateData(dbResultSet, clientTO);
			launchHousehold(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setmProvince(dbResultSet.getString("mProvince"));
			clientTO.setMailingType(dbResultSet.getString("mailingType"));
			clientTO.setSsnNum(dbResultSet.getString("ssn"));
			clientTO.setSinNum(dbResultSet.getString("sin"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataSeparateIndCustomerCanada43(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {

			launchHousehold(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			clientTO.setSINCustomerOne(dbResultSet.getString("sINCustomerOne"));
			clientTO.setSINCustomerTwo(dbResultSet.getString("sINCustomerTwo"));
			clientTO.setBirthDateCustomerOne(dbResultSet
					.getString("birthDateCustomerOne"));
			clientTO.setBirthDateCustomerTwo(dbResultSet
					.getString("birthDateCustomerTwo"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataSeparateOrgCustomerCanada44(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			clientTO.settINCustomerOne(dbResultSet.getString("tINCustomerOne"));
			clientTO.settINCustomerTwo(dbResultSet.getString("tINCustomerTwo"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataCRCCreateIndScenario15(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCreateData(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadTestDataAddEmploymentCustomerInfo(dbResultSet, clientTO);
			loadTestDataUpdateEmploymentCustomerInfo(dbResultSet, clientTO);
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setWorkPhoneNumber(dbResultSet
					.getString("workPhoneNumber"));
			clientTO.setUpdatePhoneNumber(dbResultSet
					.getString("updatePhoneNumber"));
			clientTO.setType(dbResultSet.getString("type"));
		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public ClientE2ETO loadTestDataSWSrchIndCustScenario25(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadCreateData(dbResultSet, clientTO);
			loadTestDataHomePhoneData(dbResultSet, clientTO);
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadTestDataAdditionalPhoneData(dbResultSet, clientTO);
			loadTestDataAddUpdateEmailCustomerInfo(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadRelationshipAddIndividual_MemberInsideData(dbResultSet,
					clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			loadConnectData(dbResultSet, clientTO);
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setClientID(dbResultSet.getString("clientID"));
			clientTO.setLinkedClients(dbResultSet.getString("linkedClients"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
			clientTO.setWorkPhoneNumber(dbResultSet
					.getString("workPhoneNumber"));
			clientTO.setHhEmailAddress1(dbResultSet
					.getString("hhEmailAddress1"));

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

		return clientTO;
	}

	public void loadAdditionalIndividualMembersData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
		clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
		clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
		clientTO.setHhCity(dbResultSet.getString("hhCity"));
		clientTO.setHhZip(dbResultSet.getString("hhZip"));
	}

	public ClientE2ETO loadTestDataUpdateEmploymentCustomerInfo(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			clientTO.setUpdateOccupation(dbResultSet
					.getString("updateOccupation"));
			clientTO.setUpdateOccupationOther(dbResultSet
					.getString("updateOccupationOther"));
			clientTO.setUpdateOccupationStatus(dbResultSet
					.getString("updateOccupationStatus"));
			clientTO.setUpdateEmployerName(dbResultSet
					.getString("updateEmployerName"));
			clientTO.setUpdateJobTitle(dbResultSet.getString("updateJobTitle"));
			clientTO.setUpdateJobTitleOther(dbResultSet
					.getString("updateJobTitleOther"));
			clientTO.setUpdateEmploymentAsOfDate(dbResultSet
					.getString("updateEmploymentAsOfDate"));

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataUpdateLifeEventCustomerInfo(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			clientTO.setUpdateLifeEvent(dbResultSet
					.getString("updateLifeEvent"));
			clientTO.setUpdateXDate(dbResultSet.getString("updateXDate"));
			clientTO.setUpdateLifeEventOther(dbResultSet
					.getString("updateLifeEventOther"));

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataAgentIndOOB45(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setTypeName(dbResultSet.getString("TypeName"));
			loadOOBIndSearchData(dbResultSet, clientTO);
			loadOOBMoveSearchData(dbResultSet, clientTO);
			loadOOBNamePolicySearchData(dbResultSet, clientTO);
			clientTO.setCustomerOneData(dbResultSet
					.getString("customerOneData"));
			clientTO.setSSN(dbResultSet.getString("ssn"));
			clientTO.setHhMemberAdd1(dbResultSet.getString("hhMemberAdd1"));
			clientTO.setHhMemberAdd2(dbResultSet.getString("hhMemberAdd2"));

		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public void loadOOBIndSearchData(ResultSet dbResultSet, ClientE2ETO clientTO)
			throws SQLException {
		clientTO.setLastName(dbResultSet.getString("lastName"));
		clientTO.setFirstName(dbResultSet.getString("firstName"));

	}

	public void loadOOBMoveSearchData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setMovingState(dbResultSet.getString("movingState"));
		clientTO.setMovingCity(dbResultSet.getString("movingCity"));
		clientTO.setMovingZip(dbResultSet.getString("movingZip"));

	}

	public void loadOOBNamePolicySearchData(ResultSet dbResultSet,
			ClientE2ETO clientTO) throws SQLException {
		clientTO.setLob(dbResultSet.getString("lob"));
		clientTO.setPolicyNumber(dbResultSet.getString("policyNumber"));
		clientTO.setPolicyStateOrProv(dbResultSet
				.getString("policyStateOrProv"));
		clientTO.setZip(dbResultSet.getString("zip"));
		clientTO.setState(dbResultSet.getString("state"));
		clientTO.setCity(dbResultSet.getString("city"));
	}

	public ClientE2ETO loadTestDataAgentOrgOOB46(ResultSet dbResultSet,
			ClientE2ETO clientTO) {
		try {
			clientTO.setTypeName(dbResultSet.getString("TypeName"));
			clientTO.setOrgName(dbResultSet.getString("orgName"));
			loadOOBMoveSearchData(dbResultSet, clientTO);
			loadOOBNamePolicySearchData(dbResultSet, clientTO);
			clientTO.setCustomerOneData(dbResultSet
					.getString("customerOneData"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataSupportWritePortalOOB47(
			ResultSet dbResultSet, ClientE2ETO clientTO) {

		try {
			clientTO.setOrgName(dbResultSet.getString("orgName"));
			loadOOBMoveSearchData(dbResultSet, clientTO);
			loadOOBNamePolicySearchData(dbResultSet, clientTO);
			clientTO.setCustomerOneData(dbResultSet
					.getString("customerOneData"));
			clientTO.setCustomerTwoData(dbResultSet
					.getString("customerTwoData"));
			clientTO.setUserAlias(dbResultSet.getString("userAlias"));
			clientTO.setLastNameSearchpage(dbResultSet
					.getString("lastNameSearchpage"));
			clientTO.setFirstNameSearchpage(dbResultSet
					.getString("firstNameSearchpage"));
			clientTO.setPresentHHMember(dbResultSet.getString("hhMember"));

		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;

	}

	public ClientE2ETO loadTestDataProdTeamPortalOOB48(ResultSet dbResultSet,
			ClientE2ETO clientTO) {

		try {
			clientTO.setOrgName(dbResultSet.getString("orgName"));
			loadOOBMoveSearchData(dbResultSet, clientTO);
			loadOOBNamePolicySearchData(dbResultSet, clientTO);
			clientTO.setCustomerOneData(dbResultSet
					.getString("customerOneData"));
			clientTO.setCustomerTwoData(dbResultSet
					.getString("customerTwoData"));
			clientTO.setUserAlias(dbResultSet.getString("userAlias"));
			clientTO.setLastNameSearchpage(dbResultSet
					.getString("lastNameSearchpage"));
			clientTO.setFirstNameSearchpage(dbResultSet
					.getString("firstNameSearchpage"));
			clientTO.setPresentHHMember(dbResultSet.getString("hhMember"));

		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataProdTeamPortalScenario21(
			ResultSet dbResultSet, ClientE2ETO clientTO) {

		try {
			launchHousehold(dbResultSet, clientTO);
			loadCreateData(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadTestDataAddUpdateEmailCustomerInfo(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadTestDataHomePhoneData(dbResultSet, clientTO);
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
			clientTO.setAgentAlias(dbResultSet.getString("agentAlias"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setPhoneNumber(dbResultSet.getString("phoneNumber"));

		} catch (Exception exception) {
			System.err.println(exception.getMessage());
			exception.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataCRCCreateIndCustScenario27(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadCreateOrgData(dbResultSet, clientTO);
			loadCreateIndNameData(dbResultSet, clientTO);
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadTestDataHomePhoneData(dbResultSet, clientTO);
			loadTestDataAdditionalPhoneData(dbResultSet, clientTO);
			loadTestDataMarketingInfo(dbResultSet, clientTO);
			loadEmailTestData(dbResultSet, clientTO);
			clientTO.setOrgBusinessPhoneNum(dbResultSet
					.getString("orgBusinessPhoneNum"));
			clientTO.setOrgEmailAddress1(dbResultSet
					.getString("orgEmailAddress1"));
			clientTO.setAddressUsage(dbResultSet.getString("addressUsage"));
			clientTO.setSpecificDays(dbResultSet.getString("specificDays"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setPermissionText(dbResultSet.getString("permissionText"));
			clientTO.setHhEmailAddress1(dbResultSet
					.getString("hhEmailAddress1"));
			clientTO.setHhStreet(dbResultSet.getString("hhStreet"));
			clientTO.setHhCity(dbResultSet.getString("hhCity"));
			clientTO.setHhZip(dbResultSet.getString("hhZip"));
			clientTO.setHhState(dbResultSet.getString("hhState"));
			clientTO.setWorkPhoneNumber(dbResultSet
					.getString("workPhoneNumber"));

		} catch (Exception e) {
			System.err.println("Unable to connect to  database ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return clientTO;
	}

	public ClientE2ETO loadTestDataSupportWritePortalScenario20(
			ResultSet dbResultSet, ClientE2ETO clientTO) {
		try {
			launchHousehold(dbResultSet, clientTO);
			loadCreateData(dbResultSet, clientTO);
			loadCustInfoAddAliasData(dbResultSet, clientTO);
			loadTestDataAddUpdateEmailCustomerInfo(dbResultSet, clientTO);
			loadCustInfoPersonalInfoData(dbResultSet, clientTO);
			loadTestDataHomePhoneData(dbResultSet, clientTO);
			loadTestDataMobilePhoneData(dbResultSet, clientTO);
			loadAddAtionalAddressCreateData(dbResultSet, clientTO);
			loadCombineData(dbResultSet, clientTO);
			loadSeparateData(dbResultSet, clientTO);
			clientTO.setHhFirstName(dbResultSet.getString("hhFirstName"));
			clientTO.setHhLastName(dbResultSet.getString("hhLastName"));
			clientTO.setHhOrganizationName(dbResultSet
					.getString("hhOrganizationName"));
			clientTO.setAgentAlias(dbResultSet.getString("agentAlias"));
			clientTO.setAgentCode(dbResultSet.getString("agentCode"));
			clientTO.setPhoneNumber(dbResultSet.getString("phoneNumber"));
			clientTO.setOrganizationName(dbResultSet
					.getString("organizationName"));
			// clientTO.setAssignedStaff(dbResultSet.getString("assignedStaff"));
		} catch (Exception exception) {
			System.err.println(exception.getMessage());
			exception.printStackTrace();
		}
		return clientTO;
	}
}
