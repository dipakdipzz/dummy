package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.appObjects.CreateIndividualCustomer;
import sf.client.service.healthSuite.appObjects.SSNSINObjects;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;

public class Agent_CreateIndLink_USSSN_CNSIN_ErrorValidation42 extends
BaseScript {
	int rowCount = 0;
	int count = 0;
	String query = "select * from Agent_CreateIndLink_USSSN_CNSIN_Validation";

	public void executeScript() throws Exception {
		/**
		 * Error Validation -01--->Create a Customer with US SSN number & Verify
		 * the Error Message in the Create Customer page.
		 */
		createCustTasks.clickCreateIndividual();
		createCustTasks.enterNameAndAddressCreateIndividual();
		if(CreateIndividualCustomer.WidgetInfos.TEXT_SSNSIN.exists() && SSNSINObjects.WidgetInfos.TEXTFIELD_SIN.exists()) {
		try {
			createCustTasks
					.appendMessage("**********   Started executing test case:  "
							+ clientE2ETO.getTestCaseName() + "  ********* ");
			createCustTasks
					.appendMessage("+++++++++++   Started executing test case:  "
							+ clientE2ETO.getTestCaseName() + " +++++++++++");
			createCustTasks.verifyTestCase(clientE2ETO.getTestCaseName());
			createCustTasks
					.appendMessage("**********  Finished executing test case:  "
							+ clientE2ETO.getTestCaseName() + "  ********* ");
		} catch (Exception e) {
			createCustTasks.appendToResultFile(
					false,
					"Exception occured while accessing "
							+ transferObject.getTestcaseName()
							+ " And the error message is: " + e.getMessage());
			createCustTasks.setStatus(
					false,
					"Exception occured while accessing "
							+ transferObject.getTestcaseName()
							+ " And the error message is: " + e.getMessage());
		}
		}
		else{
			createCustTasks.appendToResultFile(false,"Can Not proceed Create Individual Customer Page USSSN/CNSIN validations as USSSN/CNSIN fields Not found ");
			count++;
		}
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataAgentCreateIndLinkUSSSNCNSINErrorValidation42(
						dbresultSet, clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				if (rowCount == 0) {
					launcher = new LaunchApplication(getWATConfig());
					launcher.launchUser(scriptName());
					createCustTasks.createResultsFile(resultsFileName(),
							scriptName());
					if (createCustTasks.isAgentBusinessSystemExist()) {
						createCustTasks.clickCustomer();
						if (createCustTasks.isPortalSearchPageExist()) {
							createCustTasks.isPortalSearchPageLaunchedOrNot();
						} else {
							createCustTasks.appendToResultFile(false,
									"Agent Customer Search Page Not Launched");
						}
					} else {
						createCustTasks.appendToResultFile(false,
								"Agent Business System Page Not Launched");
					}
					rowCount++;
				}
				if (clientE2ETO.getIsTest().equalsIgnoreCase("1") && (count==0)) {
					executeScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
