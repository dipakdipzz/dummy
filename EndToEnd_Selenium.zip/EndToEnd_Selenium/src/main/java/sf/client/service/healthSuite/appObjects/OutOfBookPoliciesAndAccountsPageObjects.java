package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;

public class OutOfBookPoliciesAndAccountsPageObjects {

	/**
	 * required
	 */
	public static final String  OUTOFBOOKPOLICIES_LINK_GOTOHHPAGE =  "text=Go To Household Page";
	public static final String OUTOFBOOKPOLICIES_ABSRESULT = "id=absResult";
	
	@WidgetIDs
	public static class WidgetInfos{
		public static final Link LINK_GOTOHHPAGE =  new Link(OUTOFBOOKPOLICIES_LINK_GOTOHHPAGE);
		public static final Div ABSRESULT=new Div(OUTOFBOOKPOLICIES_ABSRESULT);
	}
}
