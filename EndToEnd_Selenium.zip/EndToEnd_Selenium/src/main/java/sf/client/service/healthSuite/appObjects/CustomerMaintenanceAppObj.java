package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Link;

public class CustomerMaintenanceAppObj {
	
	/*public static final Link LINK_SEPARATECUSTOMER = new Link("text=Separate Customer");
	public static final Link LINK_COMBINECUSTOMERS = new Link("text=Combine Customers");*/
	
	public static final String LINK_SEPARATECUSTOMER_TEXT="text=Separate Customer";
	public static final String LINK_COMBINECUSTOMERS_TEXT="text=Combine Customers";
	
	@WidgetIDs
	public static class WidgetInfos {
		
		public static final Link LINK_SEPARATECUSTOMER = new Link(LINK_SEPARATECUSTOMER_TEXT);
		public static final Link LINK_COMBINECUSTOMERS = new Link(LINK_COMBINECUSTOMERS_TEXT);
	}
	
	
}
