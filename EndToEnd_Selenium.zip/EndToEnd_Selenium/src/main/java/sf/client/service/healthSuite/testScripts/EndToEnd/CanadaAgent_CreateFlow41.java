package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class CanadaAgent_CreateFlow41 extends BaseScript 
{
	String query = "select * from CanadaAgent_CreateFlow41";
	
	public void executeScript() throws Exception{
		
		  /**
		    * Validate Customer Search Page
		    */
	         createCustTasks.launchCustomerSeachPage();
	         
	         createCustTasks.canadaAgentNotAbleToSearchOnUSData();
			
		    /**Create a Customer with US SSN number in the Create Customer page. 
			 * 
			 */
	        createCustTasks.validateSSNandSINforCreatedCustomerCanada("SSN");
			
			/**Create a Customer with CN SIN number in the Create Customer page. 
			 * 
			 */
			
	        createCustTasks.validateSSNandSINforCreatedCustomerCanada("SIN");
			
			/**Create individual Customer with both US SSN and CN SIN number in the Create Customer page. 
			 * 
			 */
			
	        createCustTasks.validateSSNandSINforCreatedCustomerCanada("Both");
	        
	        
	        /**
			 * Search for a Individual Customer and navigate to HH page - Enterprise Customer
			 */
	        createCustTasks.launchPortalCustomerSearchPage();
	        createCustTasks.launchPortalHHPage();
			
		
			/**
			 * Add an individual household member with US SSN information in Add members page.
			 */
			createCustTasks.validateSSNandSINforAddedIndividual("SSN");
			
			/**
			 * Add an individual household member with CN SIN information in Add members page.
			 */
	 
			createCustTasks.validateSSNandSINforAddedIndividual("SIN");
			
			/**Add an individual household member with both US SSN and CN SIN information in Add members page.
			 * 
			 */
			 
			createCustTasks.validateSSNandSINforAddedIndividual("Both");
			
			/**Verify the system displays both the US SSN and CN SIN field in the Update personal information page
			 * 
			 */
			createCustTasks.launchCustomerInfoPageFromHHPage();
			createCustTasks.clickUpdatePersonalInfo();
			ssnSINTasks.verifySSNPersonalInfo();
			ssnSINTasks.verifySINPersonalInfo();
			
			/**update personal information with US SSN in the Update personal information page.
			 * 
			 */
			createCustTasks.validateSSNandSINinUpdatePersonelInfo("SSN");
					
			/** update personal information with CN SIN in the Update personal information page.
			 * 
			 */
			createCustTasks.validateSSNandSINinUpdatePersonelInfo("SIN");
			
			/**update personal information with both US SSN and CN SIN in the Update personal information page.
			 * 
			 */
			createCustTasks.validateSSNandSINinUpdatePersonelInfo("Both");
			scenarioTasks.clickHHPageCustomer();
		
	
		
	}
	
	public void scriptMain()  {
				
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			
			dbresultSet =databaseUtil.getCoreData(transferObject);
			
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataCanadaAgentCreateFlow41(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				ssnSINTasks = new SSNSINTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				
				executeScript();
				
			}
			
			
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}



