package sf.client.service.healthSuite.testScripts.EndToEnd;


import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;


public class SupportWrite_Portal_Ind_Scenario5 extends BaseScript
{
	int count=0;
	String query = "select * from SW_Agent_Ind_Scenario5";

	 
	 	public void executeScript() throws Exception{ 
	 		//Launch Customer Search Page
			createCustTasks.launchCustomerSeachPage();
			//Enter User Alias
			scenarioTasks.enterAgentAliasinCustomerSearchPage();
			//customer search
			scenarioTasks.launchPortalCustomerSearchPage();
			//Click on the Customer name link in search page.
			scenarioTasks.launchABSPortalHHPage();
			//Click Mr icon for Auto/Fire/Life/Health Policies.
			productTasks.validateInsuranceAccountPolicies();
			//validate Mr icon for Fire/Health Policies when they become Inactive
			//productTasks.validateFireHealthMRIconNotdisplay();
			//validate SFPP icon in the Insurance tab
			productTasks.validateSFPPIconDisplay();
			
			launcher.shutdownServer();
			
	 	}

	 	public void scriptMain() {
			try {
				try {
					transferObject=setTestDataObject(transferObject);
					transferObject.setDbQuery(query);
					
					dbresultSet =databaseUtil.getCoreData(transferObject);
					
					while(dbresultSet.next()){
						clientE2ETO = databaseUtil.loadTestSWAgentIndScenario5(dbresultSet,clientE2ETO);
						createCustTasks=new CreateCustomersTasks(clientE2ETO);
						productTasks =new ProductTasks(clientE2ETO);
						scenarioTasks = new ScenarioTasks(clientE2ETO);
						launcher = new LaunchApplication(getWATConfig());
						launcher.launchUser(this.getClass().getSimpleName());
						productTasks.createResultsFile(resultsFileName(),scriptName());
						executeScript();
					}
				} 
					catch (Exception e) {
					e.printStackTrace();
				}
				} catch (Exception e) {
			e.printStackTrace();
		}
		}
	 }

