package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class SW_IndCustIntlChar_Scenario14 extends BaseScript {
	int count = 0;
	String query = "select * from SW_IndCustIntlChar_Scenario14";

public void executeScript() throws Exception {

		/**
		 * click on Version URL
		 */
		createCustTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		createCustTasks.setCustomerSearchTopFrame();
		/**
		 * Enterprise view operation
		 *//*
		connectCustTasks.launchAndValidateEnterPriseView();
*/
		/**
		 * Create With International Characters.
		 */
		createCustTasks.createIndividualWithAdditionalMembers();
		/**
		 * Close hh page.
		 */
		scenarioTasks.closeHHPage_SW();
		scenarioTasks.setCustomerSearchTopFrame();
		/**
		 * customer search
		 */
		createCustTasks.launchHHPageFromCustomerSearchPage();
		/**
		 * Navigating to Customer Information Page
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();

		/**
		 * Add alias with International Characters
		 */
		updateTasks.addFirstAlias();

		/**
		 * Add alias with International Characters
		 */
		updateTasks.addSecondAlias();

		/**
		 * Add US Address
		 */
		updateTasks.addAddressCustomerInfo();

		/**
		 * Update Address
		 */
		updateTasks.updateAddressCustomerInfo();
	}

	public void scriptMain() {

		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil
						.loadTestDataSWIndCustIntlCharScenario14(dbresultSet,
								clientE2ETO);

				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());

				updateTasks.createResultsFile(resultsFileName(), scriptName());

				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}