package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class Agent_Ind_ValidtnLink_Scenario22 extends BaseScript 
{
	int count=0;
	String query = "select * from Agent_Ind_ValidtnLink_Scenario22";
	
	public void executeScript() throws Exception{
		
		/**
		 * Validate Customer Search Page
		 */
		createCustTasks.launchCustomerSeachPage();		
		
		/**
		 * Verify Links in Search Page
		 */
		scenarioTasks.verifyCreateIndOrgConnectEnterpriseviewLinksPresent();
			
		/**
		 * Click the 'Create Individual'  link
		 */
		createCustTasks.clickCreateIndividual();
		/**
		 * Validate the ability to Create Individual customer
		 */
		createCustTasks.createIndividualCustomerWithPhoneEmailData();
		
		/**
		 * Navigate back to Customer Search and search for existing Customer
		 */
		createCustTasks.navigateToSearchPageFromHH();
		
		/**
		 * Search for a Individual Customer and navigate to HH page - Enterprise Customer
		 */
		createCustTasks.launchPortalCustomerSearchPage();
		createCustTasks.launchPortalHHPage();
		/**
		 * Navigate to the Customer Info page by  selecting the menu Customer Information option in Customer Menu in Household page
		 *//*
		createCustTasks.launchCustomerInfoPageFromHHPage();
		
		*//**
		 * Add an Alias - Name (Regular Characters). Also Add Preferred Name
		 * Update this Alias - Name with International Characters including � & �
		 *//*
		
		updateTasks.addUpdateDeleteAlias();
		
		*//**
		 *  US Address with International Char   
		 *//*
		updateTasks.addAddressCustomerInfo();

		*//**
		 *  Add Personal Email with International Char
		 *//*
		updateTasks.addEmailCustomerInfo();
		
		*//**
		 * Add Mobile Phone Number
		 *//*
		updateTasks.addMobilePhoneCustomerInfo();
		
		*//**
		 * Update Mobile Phone number with Permission to Text 'YES'
		 *//*
		updateTasks.updateMobilePhoneCustomerInfo();
		updateTasks.validatePermissionToTextForHomeAndAdditionalPhone();
		*//**
		 * Add Home Phone number with Calling preferences 
		 *//*
		updateTasks.addHomePhoneCustomerInfo(); 
	
		*//**
		 * Enter Phone details for Additional Type phone
		 *//*
		updateTasks.addAdditionalPhoneCustomerInfo();
		
		
		*//**
		 * Update Personal Information  - D.O.B, GENDER, MARTIAL STATUS, SSN
		 *//*
		updateTasks.updatePersonalInfoInCustomerInfo();
		
		*//**
		 * Validate that the new Phone changes/updates are displayed in the Active Customer Bar  
		 *//* 		 
		
		scenarioTasks.validateActiveCustomerBar();
		updateTasks.validatePhoneNumbersDisplayedActiveCustomerBar();
		
		*//**
		 * Validate the Text icon(Mobile phone icon) in the Phone section and send text by click on the mobile icon. (Send Text Pop-up window opens. Fill details and click SEND)//
		 *//*
		updateTasks.setTopFramewithDefaultContent();
		updateTasks.validateSentTextInCustomerInfo();
		
		*//**
		 * Select Customer bar to navigate to HH page;
		 *//*
		scenarioTasks.clickHHPageCustomer();
		scenarioTasks.setTopFrame();
		*//**
		 * Validate the Relationship hyperlink displayed in under Household Menu in Household page
		 *//*
		hhNavigationTasks.validateAndLaunchRelationshipPage();
		*//**
		 * Verify the Relationship Page Exists and Add Individual in Member Inside and Member Outside the Household
		 *//*
		hhRelationshipTasks.verifyAndAddHouseholdAndNonHouseholdIndInRelationshipPage();
		*/
		/**
		 * Launch Auto Policies from the Household Info section (Select a Customer having all LOB policies)
		 */
		hhNavigationTasks.validateAutoPolicyInHHPage();
		/*		
		*//**
		 * Launch Fire Policies from the Household Info section
		 *//*
		scenarioTasks.launchFireAppfromHHPage();
					
		*//**
		 * Launch Health Policies from the Household Info section
		 *//*
		scenarioTasks.launchHealthAppfromHHPage();
		
		*//**
		 * Launch Mutual Fund Policies from the Household Info section
		 *//*
		scenarioTasks.launchMutualAppfromHHPage();
		
		*//**
		 * Launch SFPP Policies from the Household Info section 
		 *//*
		scenarioTasks.launchSFPPAppfromHHPage();
		
		*//**
		 * Click on the 'Add Products with Others' option in the PRODUCT ACTIONS drop down menu and Add policies others
		 *//*
		hhNavigationTasks.validateAddProductsWithOthersfromHHPage();
		
		*//**
		 * Click on the Comments section and add household comments. Include International Characters other than � & �. Type two lines. Save & close.
		 *//*
		scenarioTasks.validateCommentsSectionfromHHPage();
		
		*//**
		 * Validate the ability to Create Individual customer Through HH Page
		 *//*
		createCustTasks.addAndVerifyIndCustFromMemberActions();
		
		*//**
		 *  Selecting Update Personal Information Option from the Action Drop Down Menu
		 *//*
		scenarioTasks.clickActionsUpdatePersonalInformation();
		
		*//**
		 * Validate that the Internet Enabled column value is displayed & hyperlinked (N)in the Household members section if a Customer has Birthdate
		 *//*
		scenarioTasks.verifyInternetEnabledColumnWithN();
	
		*//**
		 * Search and Select Two Customers and Click on Next link. 
		 *//*
		combineTasks.verifyAndSearchandSelectTwoCustomersPage();
		*//**
		 * Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.
		 *//*
		combineTasks.verifyInfoandClickCombine();
		*//**
		 * Search and Select Customer from Search and Select one Customer Page. 
		 *//*
		separateCustTasks.verifySearchandSelectOneCustomerPage();
		*//**
		 *  Separating a Customer
		 *//*
		separateCustTasks.separateCustomer();
				
		*//**
		 *  Move members to a new household
		 *//*
		hhNavigationTasks.verifyHHMovesMoveMembersToNewHousehold();
		*/
	}
	
	public void scriptMain()  {
				
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			
			dbresultSet =databaseUtil.getCoreData(transferObject);
			
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentIndValidtnLinkScenario22(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				
				executeScript();
				
			}
			
			
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}



