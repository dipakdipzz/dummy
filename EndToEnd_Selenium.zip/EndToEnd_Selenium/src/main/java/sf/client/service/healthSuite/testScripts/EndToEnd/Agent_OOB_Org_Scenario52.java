package sf.client.service.healthSuite.testScripts.EndToEnd;

import com.gargoylesoftware.htmlunit.ScriptException;

import sf.client.service.common.helpers.Constants;
import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;
import sf.client.service.healthSuite.tasks.OOBOrgnizationTasks;

public class Agent_OOB_Org_Scenario52 extends BaseScript{
	private String query="select * from Agent_OOB_Org_Scenario52";
	String id=null;
	String pwd=null;
	String domain=null;
	int i=49;
	boolean isServerLaunched = false;
	public void executeScript() throws Exception{
		if(i==46){
			/**Launch Household page*/
			createCustTasks.launchHouseholdpageFromPortal();
			/**"Activity Actions":Verify that an activity is created for the logging agent*/
			oobIndividualTasks.verifyActivityCreatedForLoggingAgent();
			}else{
			/**Launch Household through OOB search*/
			oobIndividualTasks.clickCustomerTab();
			/**Click on Out Of Book Radio Button*/
			oobOrgnizationTasks.clickSearchOOB();
			/** Fetch OOB Data to launch OOB POlicies Page*/
			oobOrgnizationTasks.fetchData();
			/**Close HH Page*/
			oobOrgnizationTasks.closeHHPage();
			/**Set Window to Agents Business System*/
			oobOrgnizationTasks.setWindow("Agents Business System", 30, 2);
			/**Launch Household page*/
			createCustTasks.launchHouseholdpageFromPortal();
			/**"Activity Actions":Verify that an activity is created for the logging agent*/
			oobIndividualTasks.verifyActivityCreatedForLoggingAgent();
			/**Launch Customer Info from HH page*/
			createCustTasks.launchCustomerInfoPageFromHHPage();
			/**Verify Relationship to Agent in Customer Info page */
			oobIndividualTasks.verifyRelationshipToAgent();
			}
	}
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgent_OOB_Org_Scenario52(dbresultSet,clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				oobOrgnizationTasks = new OOBOrgnizationTasks(clientE2ETO);
				oobIndividualTasks=new OOBIndividualTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				if(i==87){
					//if(!isServerLaunched){
						id=launcher.getDataContainer().getField(Constants.PORTAL_TEST_ID_TWO);
						domain=launcher.getDataContainer().getField(Constants.PORTAL_DOMAIN_TWO);
						shutdownAndStartSeleniumServer();
					//	isServerLaunched=true;
				//	}
					launchUserAndExecuteScript();
					
				}
				if(i==49){
					launcher.shutdownServer();
					launchUserAndExecuteScript();
					executeScript();
					
					i=46;
				}
				if(i==46){
					id=launcher.getDataContainer().getField(Constants.PORTAL_TEST_ID_ONE);
					pwd=launcher.getDataContainer().getField(Constants.PORTAL_PASSWORD);
					domain=launcher.getDataContainer().getField(Constants.PORTAL_DOMAIN_ONE);
					shutdownAndStartSeleniumServer();
					launchUserAndExecuteScript();
				
					i=87;
				}
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void shutdownAndStartSeleniumServer() throws ScriptException{
		launcher.shutdownServer();
		launcher.createSeleniumServerBatchFileForMP(id,domain);
		launcher.setCredintialsToLaunchSeleniumServer(id,pwd);
	}
	public void launchUserAndExecuteScript() throws Exception{
		launcher.launchUser(this.getClass().getSimpleName());
		createCustTasks.createResultsFile(resultsFileName(),scriptName());
		executeScript();
	}
}
