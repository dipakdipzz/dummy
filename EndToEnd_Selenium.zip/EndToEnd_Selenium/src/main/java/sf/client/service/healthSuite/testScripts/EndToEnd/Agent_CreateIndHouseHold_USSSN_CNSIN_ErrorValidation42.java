package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.appObjects.SSNSINObjects;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class Agent_CreateIndHouseHold_USSSN_CNSIN_ErrorValidation42 extends BaseScript {
	int rowCount=0;
	int count=0;
	String query = "select * from Agent_CreateIndHouseHold_USSSN_CNSIN_ErrorValidation";
									
	public void executeScript() {
		createCustTasks.verifyAddMembersPageFromHH();
	}

public void addMembersUSSSNCNSINValidations() throws Exception{
	if(SSNSINObjects.WidgetInfos.TEXTFIELD_SSN_MEMBER.exists() && SSNSINObjects.WidgetInfos.TEXTFIELD_SIN_MEMBER.exists()) {
	try {
		createCustTasks.appendMessage("**********   Started executing test case:  "
				+ clientE2ETO.getTestCaseName() + "  ********* ");
		createCustTasks.appendMessage("+++++++++++   Started executing test case:  "
				+ clientE2ETO.getTestCaseName() + " +++++++++++");
		createCustTasks.verifyTestCase(clientE2ETO.getTestCaseName());
		createCustTasks.appendMessage("**********  Finished executing test case:  "
				+ clientE2ETO.getTestCaseName() + "  ********* ");
	} catch (Exception e) {
		createCustTasks.appendToResultFile(
				false,
				"Exception occured while accessing "
						+ transferObject.getTestcaseName()
						+ " And the error message is: " + e.getMessage());
		createCustTasks.setStatus(false, "Exception occured while accessing "
				+ transferObject.getTestcaseName()
				+ " And the error message is: " + e.getMessage());
	}
	}
	else {
		createCustTasks.appendToResultFile(false,"Unable to proceed Add Additional Individual USSSN/CNSIN Validations as USSSN/CNSIN fields not found");
		count++;
	}
}
public void scriptMain()  {
	try {
		transferObject=setTestDataObject(transferObject);
		transferObject.setDbQuery(query);
		
		dbresultSet =databaseUtil.getCoreData(transferObject);
		
		while(dbresultSet.next()){
			clientE2ETO = databaseUtil.loadTestDataAgentCreateIndHouseHoldUSSSNCNSINErrorValidation42(dbresultSet,clientE2ETO);
			createCustTasks = new CreateCustomersTasks(clientE2ETO);
			combineTasks = new CombineCustomersTasks(clientE2ETO);
			scenarioTasks = new ScenarioTasks(clientE2ETO);
			if(rowCount==0) {
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				createCustTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
				rowCount++;
			}
			
			if (clientE2ETO.getIsTest().equalsIgnoreCase("1") && (count==0)) {
				addMembersUSSSNCNSINValidations();				
			}
		}
	} 
		catch (Exception e) {
		e.printStackTrace();
	}
}
}
