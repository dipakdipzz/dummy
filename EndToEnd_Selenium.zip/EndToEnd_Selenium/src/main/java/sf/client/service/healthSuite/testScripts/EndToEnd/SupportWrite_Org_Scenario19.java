package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class SupportWrite_Org_Scenario19 extends BaseScript {
	
	String query = "select * from SupportWrite_Org_Scenario19";
	

	public void executeScript() throws Exception {

		/**
		 * click on Version URL
		 */
		createCustTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		createCustTasks.setCustomerSearchTopFrame();
						
		/** Create Organization Customer With International Characters
		 * 
		 */
		createCustTasks.clickCreateOrganizationCustomer();
		createCustTasks.createOrgCustomerWithNameAddressData();
		
		/**Validate Remove From Book functionality
		 * 
		 */
		hhNavigationTasks.getHouseholdMembers();

		removeFromBookTasks.clickMenuBar("text=Customer",
				"text=Remove From Book");
		removeFromBookTasks.verifyHHMembersInRemoveFromBook();
		removeFromBookTasks.confirmmRemovalInRFBConfirm();
		
		//productTasks.closeHHPage_SW();
		/** Launch HHPage with Existing Customer
		 * 
		 */
		productTasks.launchHHPageFromCustomerSearchPage();
			
		/**
		 * Navigating to Customer Information Page
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();
		
		/**Add alias with Regular Characters ,Update alias with International Characters
		 * 
		 */
		
 		updateTasks.addFirstAlias();
        scenarioTasks.selectNameVersionAndUpdate();	
        updateTasks.selectUpdatedNameVersionAndRemove();

		/** Add ,Update & Remove Email with International Characters
		 * 
		 */	
        updateTasks.addEmailCustomerInfo();
		updateTasks.updateEmail();
		updateTasks.removeEmail();
	    
	   /** Add, Update & Remove Phone number
	    * 
	    */
		updateTasks.removeAllPhonesFromCustomerInfo();
		updateTasks.addMobilePhoneCustomerInfo();
		updateTasks.updatePhoneUpdatePhone();
		createCustTasks.removePhoneCustomerInfo(clientE2ETO.getPhoneNumber());
       
		/**
		 * Update Personal Information  - D.O.B, GENDER, MARTIAL STATUS, SSN
		 */
		updateTasks.updatePersonalInfoInCustomerInfo();
		
		/**Select Customer bar to navigate to HH page
		 * 
		 */
		scenarioTasks.clickHHPageCustomer();
		scenarioTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		
		/**
		 * Click on the Inactive Policies tab to display the inactive policies, if any
		 */
		hhNavigationTasks.clickInactivePolicies();
		hhNavigationTasks.displayInactivePolicies();

		/**
		 * Launch Auto Policies from the Household Info section
		 */
		scenarioTasks.clickInsurancePolicies();
		scenarioTasks.launchAutoAppfromHHPage();
		scenarioTasks.handleCimsVersion();
		
		/**
		 * Launch Fire Policies from the Household Info section
		 */
		scenarioTasks.launchFireAppfromHHPage();
		scenarioTasks.handleCimsVersion();
		
		//Lack of data
		/**
		 * Launch Health Policies from the Household Info section
		 *//*
		scenarioTasks.launchHealthAppfromHHPage();
		scenarioTasks.handleCimsVersion();*/
		
		/**
		 * Click on the 'Add Products with Others' option in the PRODUCT ACTIONS drop down menu and Add policies others
		 *//*
		hhNavigationTasks.validateAddProductsWithOthersfromHHPage();
		hhNavigationTasks.refreshHHPage_SW();
			
		*//**
		 * Click on Add Organization option in the Member Action drop down and add an Organization to the Household
		 *//*
		scenarioTasks.addOrganizationinHouseholdPage();*/
		
		
		/**Click on the 'View Customer Information' option in the Action
		 * 
		 */
		scenarioTasks.clickActionsViewCustomerInfoABS();
		
		/**
		 * Validate that the Internet Enabled column value is displayed & hyper linked (N)in the Household members section if a Customer has Birthdate
		 */
		scenarioTasks.verifyInternetEnabledColumnWithN();
		
		/**Validate Previous Review & Next Review functionality
		 * 
		 */
		hhNavigationTasks.addReviewDates();
		hhNavigationTasks.refreshHHPage_SW();
		
	/*	*//**
		 * Search and Select Two Customers and Click on Next link. 
		 *//*
		
		combineTasks.verifySearchandSelectTwoCustomersPageABS();
		
		*//**
		 *  Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.
		 *//*
		combineTasks.verifyInfoandClickCombine();			
		
		*//**
		 * Search and Select Customer from Search and Select one Customer Page. 
		 *//*
		
		separateCustTasks.verifySearchandSelectOneCustomerPageABS();
		*//** Validate Separate functionality
		 * 	
		 *//*	
		separateCustTasks.separateCustomer();		
		*//**
		 * Navigate to Household Maintenance screen and perform Household Move transaction.
		 *//*
		
		hhNavigationTasks.verifyHHMovesMoveMemberBetweenTwoHouseholdsABS();*/
		
	}

	public void scriptMain() {

		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataSupportWriteOrgScenario19(dbresultSet, clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				removeFromBookTasks = new RemoveFromBookTasks(clientE2ETO);
				productTasks = new ProductTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				scenarioTasks.createResultsFile(resultsFileName(), scriptName());
				executeScript();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}