package sf.client.service.healthSuite.testScripts.EndToEnd;

public class CAAM_ReadWrite {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
