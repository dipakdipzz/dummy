package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class Agent_Ind_OOB45 extends BaseScript{
	int count=0;
	String query = "select * from Agent_Ind_OOB45";
	
public void executeScript() throws Exception{
		/**
		 * OOB_IND - 01---> OOB Individual search -Policy as Verification data -Auto policy
		 */
	String policyType = clientE2ETO.getTypeName();
		
	if(policyType.equalsIgnoreCase("Auto")){
		oobIndividualTasks.fetchDataAuto();

	}
	
	/**
	 * OOB_IND - 02---> OOB Individual search -Policy as Verification data - Fire policy
	 */
	
	if(policyType.equalsIgnoreCase("Fire")){
		oobIndividualTasks.fetchDataFire();
	}
	
	/**
	 * OOB_IND - 03---> OOB Individual search -Last 4 SSN as Verification data
	 */
	
	if(policyType.equalsIgnoreCase("SSN")){
		oobIndividualTasks.fetchData4SSN();
	}
	
	/**
	 * OOB_IND - 04---> OOB Individual Search - SSN Verification Disabled for Canadian customer Search
	 */
	
	if(policyType.equalsIgnoreCase("SSN_Disable")){
		oobIndividualTasks.fetchDataSSNDisable();
	}
	
	/**
	 * OOB_IND - 05--> Out of Book HH Page - HH Member section- HH members List (Customer and Part of his HH members are selected as part of move)
	 */
	if(policyType.equalsIgnoreCase("Life SF")){
		oobIndividualTasks.fetchDataLifeSF();
	
	}
}

public void scriptMain()  {
	try {
		transferObject=setTestDataObject(transferObject);
		transferObject.setDbQuery(query);
		dbresultSet =databaseUtil.getCoreData(transferObject);
		while(dbresultSet.next()){
			clientE2ETO = databaseUtil.loadTestDataAgentIndOOB45(dbresultSet,clientE2ETO);
			scenarioTasks = new ScenarioTasks(clientE2ETO);
			updateTasks =new UpdateCustomersTasks(clientE2ETO);
			createCustTasks = new CreateCustomersTasks(clientE2ETO);
			hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
			oobIndividualTasks = new OOBIndividualTasks(clientE2ETO);
			ssnSINTasks = new SSNSINTasks(clientE2ETO);
			if(count==0) {
			launcher = new LaunchApplication(getWATConfig());
			launcher.launchUser(scriptName());
			scenarioTasks.createResultsFile(resultsFileName(),scriptName());
			ssnSINTasks.launchCustomerSeachPage();
			}
			executeScript();
			count++;
		}
	} 
		catch (Exception e) {
		e.printStackTrace();
	}
}
}

