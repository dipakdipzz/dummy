package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class SW_SrchIndCust_Scenario25 extends BaseScript {
	String query = "select * from SW_SrchIndCust_Scenario25";
	public void executeScript() throws Exception
	{		
			/**
			 * click on Version URL
			 */
			createCustTasks.setTopFrame();
			scenarioTasks.handleCimsVersion();
			createCustTasks.setCustomerSearchTopFrame();
			/**
			 * Validating the links in the customer search page
			 */
			scenarioTasks.validateLinksDisplayedInCustSearchPage();
			/**
			 * Outdated functionality. No need to execute
			 */
			/**Connect Customer*//*
			connectCustTasks.connectCustomers();*/
			/**Enterprise view operation*//*
			connectCustTasks.launchAndValidateEnterPriseView();*/
			/**Click the 'Create Individual'  link*/
			createCustTasks.clickCreateIndividual();
			/**Create Individual Customer with International Characters*/
			createCustTasks.createIndividualCustomerWithPhoneAndEmail();
			/**Close HH page*/
			productTasks.closeHHPage_SW();
			scenarioTasks.setCustomerSearchTopFrame();
			/**customer search*/
			productTasks.launchHHPageFromCustomerSearchPage();
			/**Adding policy*//*
			productTasks.createAutoFireHealthPolicesWithOthers();
			*//**Refresh HH Page*//*
			productTasks.refreshHHPage_SW();
			*//**Validate count of Auto,Fire and Health Policy with Others*//*
			productTasks.verifyCreatedAutoFireHealthPolicies();
			*//**Add Comments*//*
			scenarioTasks.validateCommentsSectionHHPage();
			*//**Validate Insurance policies*//*  	
	 		scenarioTasks.clickInsurancePolicies();
	        scenarioTasks.displayInsurancePolicies();
	        *//**Validate Bank policies*//* 
	        scenarioTasks.clickBankPolicies();
	        scenarioTasks.displayBankPolicies();
	        *//**Validate Mutual Funds policies*//*  
	        scenarioTasks.clickMutualFundsPolicies();
	        scenarioTasks.displayMutualFundPolicies();
	        *//**Validate SFPP policies*//*  
	        scenarioTasks.clickSfppPolicies();
	        scenarioTasks.displaySfppPolicies();
	        *//**Validate Product Inactive page*//*  	
	        scenarioTasks.clickInactivePolicies();
	        scenarioTasks.printInactivePolicies();*/
	       /* *//**Navigating to Customer Information Page*//*
	 		createCustTasks.launchCustomerInfoPageFromHHPage();
	 		*//**Add alias with Regular Characters*//*
	        updateTasks.addFirstAlias();
	        *//**Update  the Added Alias with International characters*//*
	        scenarioTasks.selectNameVersionAndUpdate();
	        *//**Click on the Change Address hyper link next to the Add address link in the Address section and Add an Address and click SAVE*//*												
	        scenarioTasks.launchAndAddAddressInCOA();
	        *//**Add Email*//* 
			updateTasks.addEmailCustomerInfo();
			*//**Update Email*//*
			updateTasks.updateEmail();
			*//**Remove Email*//*
			updateTasks.removeEmail();
			*//**Remove all Phones From Customer Info Page to add*//* 
			updateTasks.removeAllPhonesFromCustomerInfo();
			*//**Add Home Phone number *//*
			updateTasks.addHomePhoneCustomerInfo(); 
			*//**Click on the Number of a customer and update the Phone Home Number to Cell Phone Number*//* 
			updateTasks.updateHomePhoneToMobilePhoneInCustomerInfo();
			*//**Remove all Phones From Customer Info Page to add*//* 
			updateTasks.removeAllPhonesFromCustomerInfo();
			*//**Enter Mobile Number*//*
			updateTasks.addMobilePhoneCustomerInfo();
			*//**Validate Permission to Text is not displayed for Home Phone Additional Type *//*
			updateTasks.validatePermissionToTextForHomeAndAdditionalPhone();
			*//**work phone*//*
			updateTasks.addWokPhoneCustomerInfo();
			*//**Update Personal Information All Fields*//*
			updateTasks.updatePersonalInformation();
			*//**Navigate back to HH Page*//*
			*//**Validate that the new Phone changes/updates are displayed in the Active Customer Bar*//*
			scenarioTasks.getWebDriverInstance().switchTo().defaultContent();
			updateTasks.validatePhoneNumbersDisplayedActiveCustomerBar();
			
			scenarioTasks.clickHHPageCustomer();
			scenarioTasks.setTopFrame();
			scenarioTasks.handleCimsVersion();*/
			/**validate And Launch Relationship Page*//*
			hhNavigationTasks.validateAndLaunchRelationshipPage();
			*//**Verify the Relationship Page Exists and Add Individual in Member Inside and Member Outside the Household*//*
			hhRelationshipTasks.verifyAndAddHouseholdAndNonHouseholdIndInRelationshipPage();
			scenarioTasks.setTopFramewithDefaultContent();*/
			/**Launch Auto Policies from the Household Info section*/
			scenarioTasks.clickInsurancePolicies();
			scenarioTasks.launchAutoAppfromHHPage();
			scenarioTasks.handleCimsVersion();
			/**Launch Fire Policies from the Household Info section*/
			scenarioTasks.launchFireAppfromHHPage();
			scenarioTasks.handleCimsVersion();
			/*/**Launch Mutual Fund Policies from the Household Info section*//*
			scenarioTasks.launchMutualAppfromHHPage();
			scenarioTasks.handleCimsVersion();
			*//**Launch SFPP Policies from the Household Info section *//*
			scenarioTasks.launchSFPPAppfromHHPage();	
			scenarioTasks.handleCimsVersion();
			*//**Selecting Update Personal Information Option from the Action Drop Down Menu*//*
			updateTasks.updatePersonalInformation_Household();
			*//**Verify isInternetEnable Column*/
			scenarioTasks.verifyInternetEnabledColumnWithYAndN();
			// set appropriate date 
			/**Search and Select Two Customers and Click on Next link. *//*
			combineTasks.verifySearchandSelectTwoCustomersPageABS();
			*//**Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.*//*
			combineTasks.verifyInfoandClickCombine();
			*//**Search and Select Customer from Search and Select one Customer Page. *//*
			separateCustTasks.verifySearchandSelectOneCustomerPageABS();
			*//**Separating a Customer.*//*
			separateCustTasks.separateCustomer();			*/
	}
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataSWSrchIndCustScenario25(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				productTasks=new ProductTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				scenarioTasks=new ScenarioTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				System.out.println("sdsd"+clientE2ETO.getCustomer1Name());
				
				executeScript();
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}		
	}
}

