package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class Enterprise_CRC_Scenario9 extends BaseScript
{
	int count=0;
	String query = "select * from Enterprise_CRC_Scenario9";
	 	public void executeScript() throws Exception{ 
	 		 	
	 		/**
			 *  Launch Customer Search
			 */
	 		scenarioTasks.clickLaunchContactCenterOnlineForQBRole();
		
			/**
			 *  Launch HH page From Customer Search page.
			 */
	 		scenarioTasks.setCRCTopFrame();
	 		scenarioTasks.launchHHPageFromCRCAHQBCustSearchPage();
			/**
			 *  Validate that the Household hyperlink and Non household hyperlinks are not displayed in the Household Menu
			 */
			hhNavigationTasks.validateHouseholdNonHouseholdLinks();
			/**
			 * Verify the Relationship Page Exists and Add Individual in Member Inside and Member Outside the Household
			 */
		    hhRelationshipTasks.verifyAHQBAddHouseholdAndNonHouseholdIndInRelationshipPage();
	
			/**
			 *  Customer Information verifications
			 */
		    createCustTasks.setCRCDefaultFrame();
			createCustTasks.launchCustomerInfoPageFromHHPage();
			/**CASL CANADA Scenarios Tc1-Tc4*//*
			productTasks.EmessageOnlySendWithCASLFieldY();*/
			/**CASL CANADA Scenarios Tc5-Tc8*/
			//productTasks.doNotsendEmessageWithCASLFieldY();
			/**CASL US Scenarios Tc9-Tc10*/
			//productTasks.verifyEmessageFieldWithCASLFieldN();
			/**CASL US Scenarios Tc11-Tc12*/
			//productTasks.verifyEmessageFieldWithCASLFieldY();
			/**CASL US Scenarios Tc13-Tc14*/
			//productTasks.changingFromOnlyEmessageToUnsubscribe();			
			/**
			 *  Add alias with International Characters
			 */
			updateTasks.addFirstAlias_CRC();
			/**
			 *  Add alias with International Characters
			 */
			updateTasks.addSecondAlias_CRC();
			/**
			 *  validate add address/Mailling/Notes links not displayed
			 */
			scenarioTasks.validateAddAddressLinkNotDisplayedForQB();
			scenarioTasks.validateMaillingLink();
			scenarioTasks.validateNotesLink();
			/**Remove all Phones From Customer Info Page to add*/
			updateTasks.removeAllPhonesFromCustomerInfo_CRC();
			/**
			 * Add,Update and Remove Work Phone
			 */
			updateTasks.addWorkPhoneCustomerInfo_CRC();
			updateTasks.updateWorkPhoneCustomerInfo();
			createCustTasks.removePhoneCustomerInfo_CRC(clientE2ETO.getUpdatePhoneNumber());

					
			/**
			 *  Add Email
			 */
			updateTasks.addEmailCustomerInfo_CRC();
			/**
			 *  Update Email
			 */
			updateTasks.updateEmail_CRC();
			/**
			 *  Remove Email
			 */
			updateTasks.removeEmail_CRC();
			/**
			 *  validate Personal Info section update button
			 */
			scenarioTasks.validatePersonalInfoUpdateBtnDisplayed();
			  /**
			 *  Personal Info
			 */
			updateTasks.updatePersonalInfoCustomerInfo_CRC();
			
			/** 
			 * Validate that Customer Interests link NOT available
		     */
			scenarioTasks.validateCustomerInterestLink();
			
			/** 
			 * Add,Update & Delete Life Events 
			 * */
			scenarioTasks.lifeEventsAddEventSC1_CRC();
			updateTasks.lifeEventsUpdate_CRC();
			updateTasks.lifeEventsRemove();

			/**
			 * Add,Update & Delete Employment
			 * 
			 */
			updateTasks.updateEmploymentAddEmployment_CRC();
			updateTasks.updateEmploymentUpdate_CRC();
			updateTasks.updateEmploymentRemove();
				
	 	}
 	public void scriptMain() {
			try {
				try {
					transferObject=setTestDataObject(transferObject);
					transferObject.setDbQuery(query);
					
					dbresultSet =databaseUtil.getCoreData(transferObject);
					
					while(dbresultSet.next()){
						clientE2ETO = databaseUtil.loadTestDataEnterpriseCRCScenario9(dbresultSet,clientE2ETO);
						
						scenarioTasks =new ScenarioTasks(clientE2ETO);
						createCustTasks=new CreateCustomersTasks(clientE2ETO);
						hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
						hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
						updateTasks = new UpdateCustomersTasks(clientE2ETO);
						launcher = new LaunchApplication(getWATConfig());
						launcher.launchUser(this.getClass().getSimpleName());
						scenarioTasks.createResultsFile(resultsFileName(),scriptName());
						executeScript();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
 }

