package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;

public class Agent_Canadaian_Scenario29 extends BaseScript {

	int count = 0;
	String query = "select * from SupportWrite_Ind_Sear_Scenario4";
	
	public void executeScript(){
		//if (createCustTasks.isAgentBusinessSystemExist()) {
			createCustTasks.clickCustomer();
			/** Canada Scenario 2*/
			createCustTasks.canadaAgentNotAbleToSearchOnUSData();
			oobIndividualTasks.canadaAgentNotAbleToSearchOnUSOob();
			/*createCustTasks.launchPortalCustomerSearchPage();
			createCustTasks.launchPortalHHPage();
			createCustTasks.validateUSSSNCNSINDriversLicenseCustomerInfo(custType);
			} else {
			createCustTasks.appendToResultFile(false,
					"Agent Business System Page Not Launched");*/
		//}
		
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataAgentCanadaianScenario29(
							dbresultSet, clientE2ETO);
					scenarioTasks = new ScenarioTasks(clientE2ETO);
					createCustTasks = new CreateCustomersTasks(clientE2ETO);
					oobIndividualTasks = new OOBIndividualTasks(clientE2ETO);
					updateTasks = new UpdateCustomersTasks(clientE2ETO);
					launcher = new LaunchApplication(getWATConfig());
					launcher.launchUser(scriptName());
					createCustTasks
							.createResultsFile(resultsFileName(), scriptName());
					//String custType = clientE2ETO.getCustomerType();
				count++;
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
