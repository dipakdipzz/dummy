package sf.client.service.healthSuite.tasks;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.AddAccountsandPoliciesPopupObjects;
import sf.client.service.healthSuite.appObjects.HHRewriteObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldMove_PageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.PresentationKitPopupObjects;
import sf.client.service.healthSuite.appObjects.ReviewDatePopupObjects;
import sf.client.service.healthSuite.appObjects.SearchSelectCustomerAppObj;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.wat.util.KeyboardUtility;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.TableEx;
import statefarm.widget.manager.Verify;
import org.apache.xerces.impl.dv.util.Base64;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

public class ProductTasks extends HouseHoldTasks {

	int positionOfMR;
	public int autoPolicyCountI = 0;
	public int bankPolicyCountI = 0;
	public int firePolicyCountI = 0;
	public int lifePolicyCountI = 0;
	public int healthPolicyCountI = 0;
	public int mutualPolicyCount = 0;
	int[] countbefore;
	int[] countafter;

	public ProductTasks() {
	}

	public ProductTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}
    /**
     * Clicking cancel button NextReview Page
     */
	public void cancelNextReviewPage() {
		try {
			if (ReviewDatePopupObjects.WidgetInfos.BUTTON_CANCEL.exists()) {
				click(ReviewDatePopupObjects.WidgetInfos.BUTTON_CANCEL,
						MessageUtility.BUTTON_CANCEL);
			}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
    /**
     * Clicking Help On this Page Link
     * @throws ScriptException
     */
	public void launchHelpOnthisPage() throws ScriptException {
		waitForPageLoad(HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE);
		Verify.verifyTrue(true,
				MessageUtility.LINK_HELPONTHISPAGE);
		click(HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE,
				MessageUtility.LINK_HELPONTHISPAGE);
		waitForTime(4);
	}
    /**
     * Adding Auto Policy to Account Policies with Others
     * @throws ScriptException
     */

	public void addAutoAccountPolicies() {
			try {
				waitForPageLoad(AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS,10);
				if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS.exists()) {
					if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS
							.containsItem("Auto")) {
						AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS
								.selectItem("Auto");
						Verify.verifyTrue(true, MessageUtility.LINEOFBUSINESS_AUTO);
					}
					if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY).exists()) {
						selectFromListbox(
								AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY,
								"AIG", MessageUtility.COMPANY);
					} else {
						Verify.verifyTrue(false, MessageUtility.COMPANY_NOTFOUND);
					}
					
				} else {
					Verify.verifyTrue(false, MessageUtility.LINEOFBUSINESS_NOTFOUND);
				}
			} catch (ScriptException scriptException) {
				scriptError(scriptException);
			} catch(Exception e){
				Verify.verifyTrue(false, e.getMessage());
			}

		}

    /**
     * Clicking Save button in Account Policies with Others page
     * @throws ScriptException
     */
	public void clickAddAccPoliciesSave() throws ScriptException {
		waitForPageLoad(AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_SAVE, 10);
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_SAVE.exists()) {
			click(AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_SAVE,
					MessageUtility.BUTTON_SAVE);
			waitForTime(3);
		}
	}
    /**
     * Clicking Close button in Account Policies with Others page
     * @throws ScriptException
     */
	public void closeAddAccountPolicies() throws ScriptException {
		waitForPageLoad(
				AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_CANCEL_AUTO_POLICIES, 5);
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_CANCEL_AUTO_POLICIES.exists()) {
			click(AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_CANCEL_AUTO_POLICIES,
					MessageUtility.BUTTON_CLOSE);
			waitForTime(3);
		}
	}
    /**
     * Clicking Cancel button in Separate Customer page
     * @throws ScriptException
     */
	public void cancelCustomerSeparatePage() throws ScriptException {
		waitForPageLoad(SearchSelectCustomerAppObj.WidgetInfos.BUTTON_CANCEL, 15);
		if (SearchSelectCustomerAppObj.WidgetInfos.BUTTON_CANCEL.exists()) {
			click(SearchSelectCustomerAppObj.WidgetInfos.BUTTON_CANCEL,
					MessageUtility.BUTTON_CANCEL);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
		}
	}
    /**
     * Launching One PDF From Each Section In PresentationKit
     * @throws ScriptException
     */
	public void launchOnePDFFromEachSectionInPresentationKit()
	throws ScriptException {
		
		waitForTime(3);
	setWindow("Presentation Kit",30,2);
	waitForTime(3);
	WebElement custpro = getWebDriverInstance().findElement(By.xpath("//form[@name='presKitForm']/span/span/div[2]/div[3]/table/tbody/tr[1]/td/input"));
	if(custpro.isDisplayed())
	{
		custpro.click();
		Verify.verifyTrue(true, MessageUtility.CUSTOMERPROFILE_CLICKED);
	}
	WebElement naq = getWebDriverInstance().findElement(By.xpath("//form[@name='presKitForm']/span/span/div[2]/div[8]/table/tbody/tr[1]/td/input"));
	if(naq.isDisplayed())
	{
		naq.click();
		Verify.verifyTrue(true, MessageUtility.QUICKNAQ_CLICKED);
	}
	WebElement lifeInsurance = getWebDriverInstance().findElement(By.xpath("//form[@name='presKitForm']/span/span/div[2]/div[9]/table/tbody/tr[1]/td/input"));
	if(lifeInsurance.isDisplayed())
	{
		lifeInsurance.click();
		Verify.verifyTrue(true, MessageUtility.GENERALPURPOSESOFLIFEINSURANCE_CLICKED);
		
	}
	WebElement retireFactFinder = getWebDriverInstance().findElement(By.xpath("//form[@name='presKitForm']/span/span/div[2]/div[4]/table/tbody/tr[1]/td/input"));
	if(retireFactFinder.isDisplayed())
	{
		retireFactFinder.click();
		Verify.verifyTrue(true, MessageUtility.RETIREMENYFACTFINDER_CLICKED);
	}
	
	
		if (PresentationKitPopupObjects.BUTTON_VIEW.exists()) {
			click(PresentationKitPopupObjects.BUTTON_VIEW,
					MessageUtility.BUTTON_VIEW_CLICKED);
			waitForTime(5);

		}
	}


    /**
     * Adding Bank Policy to Account Policies with Others
     */
	public void addBankAccountPolicies()  {
		try {
			waitForPageLoad(AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS,3);
			if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS.exists()) {
				if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS
						.containsItem("Bank")) {
					AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS
							.selectItem("Bank");
					Verify.verifyTrue(true, MessageUtility.LINEOFBUSINESS_BANK);
					waitForTime(3);
				}
				if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY.exists()) {
					selectFromListbox(
							AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY,
							"AMA", MessageUtility.COMPANY);
				} else {
					Verify.verifyTrue(false, MessageUtility.COMPANY_NOTFOUND);
				}
				
			} else {
				Verify.verifyTrue(false, MessageUtility.LINEOFBUSINESS_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
   /**
    * validating  Auto Policy Count
    * @param before
    * @param after
    * @throws ScriptException
    */
	public void validateAutoPolicyCount(int[] before, int[] after)
			throws ScriptException {
		if (after[0] - before[0] == 1) {
			Verify.verifyTrue(true,
					MessageUtility.AUTOPOLICY_INCREMENT);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.AUTOPOLICY_NOTINCREMENT);
		}
	}
    /**
     *  validating  Bank Policy Count
     * @param before
     * @param after
     * @throws ScriptException
     */
	public void validateBankPolicyCount(int[] before, int[] after)
			throws ScriptException {
		if (after[4] - before[4] == 1) {
			Verify.verifyTrue(true,
					MessageUtility.BANKPOLICY_INCREMENT);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BANKPOLICY_NOTINCREMENT);
		}
	}
    /**
     * Removing Bank Policy from Account Policies with Others
     */
	public void removeBankAccountPolicies() {
		try {
			if (HouseHoldPageObjects.WidgetInfos.LINK_UPDATEBANKOTHERS.exists()) {
				click(HouseHoldPageObjects.WidgetInfos.LINK_UPDATEBANKOTHERS,
						MessageUtility.BANKPOLICY_CLICKED);
				setWindow(EndToEndConstants.UPDATE_ACCOUNTSPOLICIES_WITHOTHERS,
						15, 2);
				if (AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_REMOVE.exists()) {
					click(AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_REMOVE,
							MessageUtility.BUTTON_REMOVE_CLICKED);
					waitForTime(10);
				} else {
					Verify.verifyTrue(false, MessageUtility.BUTTON_REMOVE_NOTDISPLAYED);
				}
				isErrorPage("Remove Bank Policy");
			} else {
				Verify.verifyTrue(false, MessageUtility.BANKPOLICY_NOTFOUND);
			}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
    /**
     * Adding Fire Policy to Account Policies with Others
     * @throws ScriptException
     */
	public void addFireAccountPolicies() throws ScriptException {
		try {
			waitForPageLoad(AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS,
					15);
			if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS).exists()) {
				selectFromListbox(
						AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS,
						"Fire", MessageUtility.LINEOFBUSINESS_FIRE);
				if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY).exists()) {
					selectFromListbox(
							AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY,
							"AAA", MessageUtility.COMPANY);
					waitForTime(5);
				} else {
					Verify.verifyTrue(false, MessageUtility.COMPANY_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.LINEOFBUSINESS_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}  catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
    /**
     * Changing ProductType To CV for Account Policies with Others page
     * @throws ScriptException
     */
	public void changeProductTypeToCV() throws ScriptException {
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_PRODUCT_TYPE.exists()) {
			selectFromListbox(AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_PRODUCT_TYPE,
					"Commercial Vehicle", MessageUtility.PRODUCTTYPE_CV);
			waitForTime(3);
		}
	}
   /**
    * Adding Health Policy to Account Policies with Others
    * @throws ScriptException
    */
	public void addHealthAccountPolicies() throws ScriptException {
		try {
			waitForPageLoad(AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS,
					15);
			if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS).exists()) {
				selectFromListbox(
						AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS,
						"Health", MessageUtility.LINEOFBUSINESS_HEALTH);
				if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY).exists()) {
					selectFromListbox(
							AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY,
							"AIG", MessageUtility.COMPANY);
				} else {
					Verify.verifyTrue(false, MessageUtility.COMPANY_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.LINEOFBUSINESS_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
	
		}
	}
    /**
     *  validating  All Policies Count
     * @return
     * @throws ScriptException
     */
	public int[] getPolicyCountForProductsWithOthers() throws ScriptException {
		String countText = HouseHoldPageObjects.WidgetInfos.LABEL_POLICYCOUNT_WithOthers
				.getText();
		String count2Str = countText;
		String autocount = count2Str.substring(count2Str.indexOf("Auto("),
				count2Str.indexOf("Auto(") + 6);
		autoPolicyCountI = Integer.parseInt(autocount.charAt(5) + "");
		Verify.verifyTrue(true, "Auto Count  " + autoPolicyCountI);
		String bankcount = count2Str.substring(count2Str.indexOf("Bank("),
				count2Str.indexOf("Bank(") + 6);
		bankPolicyCountI = Integer.parseInt(bankcount.charAt(5) + "");
		Verify.verifyTrue(true, "Bank Count  " + bankPolicyCountI);
		int[] count = { autoPolicyCountI, firePolicyCountI, lifePolicyCountI,
				healthPolicyCountI, bankPolicyCountI, mutualPolicyCount };
		return count;
	}

	/**
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * validate Insurance Account Policies
	 * @throws ScriptException
	 */
public void validateInsuranceAccountPolicies() {
		
		String productType = null;
		int c = 1;
		while (c < 5) {
		
				WebElement proType = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div/div/div/div["+c+"]/table/tbody/tr/td/span"));
				productType = proType.getText();
				if ((productType.equals("Auto")))
					 {
						c++;
						WebElement mrIcon = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div/div/div/div["+c+"]/table/tbody/tr[2]/td[4]/a/span"));
						mrIcon.click();
						waitForTime(7);
						Verify.verifyTrue(true, MessageUtility.MRICON_AUTO);
						clickHHPageCustomer();
						KeyboardUtility.sendKeys("{ENTER}");
						setTopFrame();
						handleCimsVersion();
						waitForTime(3);
						isHHPageLaunched();
					 }
				if (productType.equals("Fire"))
				{
					c++;
					WebElement mrIcon = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div/div/div/div["+c+"]/table/tbody/tr[2]/td[4]/a/span"));
					mrIcon.click();
					waitForTime(7);
					Verify.verifyTrue(true, MessageUtility.MRICON_FIRE);
					clickHHPageCustomer();
					KeyboardUtility.sendKeys("{ENTER}");
					setTopFrame();
					handleCimsVersion();
					waitForTime(3);
					isHHPageLaunched();
				}
				if (productType.equals("Life")) 
				{
					c++;
					WebElement mrIcon = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div/div/div/div["+c+"]/table/tbody/tr[2]/td[4]/a/span"));
					mrIcon.click();
					waitForTime(7);
					Verify.verifyTrue(true, MessageUtility.MRICON_LIFE);
					clickHHPageCustomer();
					KeyboardUtility.sendKeys("{ENTER}");
					setTopFrame();
					handleCimsVersion();
					waitForTime(3);
					isHHPageLaunched();
				}
					c++;
					
		}				
			
	}

	/**
	 * Validate that the MR Icon should not be displayed on House Hold Page for
	 * Fire and Health Policies when they become Inactive after 30 days. (Only
	 * the MR icon is not displayed on the Household page, but the Fire and
	 * Health are still displayed after 30 days and before 61days on the
	 * household page)
	 * 
	 * @throws ScriptException
	 * 
	 *             Get the Customer who has Fire and Health Policies Inactive
	 *             after 30 days
	 */

public void validateFireHealthMRIconNotdisplay(){
	try {
		if (isHHPageLaunched()) {
			int rowCount = 0;
			int c = 1;
			while (true) {
				try {
					
					WebElement productType = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
									+ c
									+ "]/table[@class='dojoxGridRowTable']/tbody/tr[1]/td[1]"));
					if (productType.getText().equals("Fire")
							|| productType.equals("Health")) {
						c++;
						WebElement mrIcondisplay = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
										+ c
										+ "]/table[@class='dojoxGridRowTable']/tbody/tr[2]/td[3]/a"));
						if (mrIcondisplay.isDisplayed()) {
							Verify.verifyTrue(false, productType + MessageUtility.MRICON_NOTDISPLAYED);
						} else {
							Verify.verifyTrue(true, productType + MessageUtility.MRICON_DISPLAYED);
						}
						rowCount++;

					} else {
						Verify.verifyTrue(false, MessageUtility.PRODUCTTYPE_NOTFOUND);
					}
					c++;
				} catch (Exception e) {
					break;
				}
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		}

	} catch (ScriptException scriptException) {
		scriptError(scriptException);

	}catch(Exception e){
		Verify.verifyTrue(false, e.getMessage());
	}
}
    /**
     * verify  MR Icon in HHPage
     */
	public void verifyMRIconHHPage(){
		try {
			if (isHHPageLaunched()) {
				//validateFireHealthMRIconNotdisplay();
				validateMRSymbolInMutualFundTab();
				validateMRSymbolInBankTab();
				validateMRSymbolInProductsWithOthersTab();
				closeHHPage();
				setWindow(EndToEndConstants.CUSTOMER_SEARCH, 30, 2);
				getWebDriverInstance().switchTo().defaultContent();
				
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}
   /**
    * Validating SFPP Icon is Displayed in HH Page
    * @throws ScriptException
    */
	public void validateSFPPIconDisplay() throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				int c = 1;
				for (int i = 1; i < 10; i++) {
					try {
						WebElement productType = getWebDriverInstance().findElement(By.xpath("//div[@id='policyTabContainer']/div[@class='dijitTabPaneWrapper dijitTabContainerTop-container dijitAlignClient']/div[@id='tempGrid']/div[@id='gridInsurance']/div[@class='dojoxGridMasterView']/div[@id='dojox_grid__View_1']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div[@gridRowIndex='"
										+ i + "']"));
						if (productType.getText().equals("Auto")
								|| productType.getText().equals("Fire")) {
							c++;
							WebElement SFPPIcondisplay = getWebDriverInstance().findElement(By.xpath("//div[@id='policyTabContainer']/div[@class='dijitTabPaneWrapper dijitTabContainerTop-container dijitAlignClient']/div[@id='gridInsurance']/div[@class='dojoxGridMasterView']/div[@class='dojox_grid__View_1']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
											+ c
											+ "]/table[@class='dojoxGridRowTable']/tbody/tr[2]/td[2]/span/span/span"));
							
							if (SFPPIcondisplay.isDisplayed())
								Verify.verifyTrue(true,
										MessageUtility.SFPPICON_DISPLAYED);
							else
								Verify.verifyTrue(false,
										MessageUtility.SFPPICON_NOTDISPLAYED);

							break;

						}
						if(productType.getText().isEmpty())
						{
							Verify.verifyTrue(false,
									MessageUtility.SFPPICON_NOTDISPLAYED);
						}
						c++;
					} catch (Exception e) {
						break;
					}
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}

	}

	/**
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * validate MR Symbol In Mutual Fund Tab
	 * @throws ScriptException
	 */
	public void validateMRSymbolInMutualFundTab() throws ScriptException {
		positionOfMR = clickMutualFundsTab();
		if (positionOfMR <= -1) {
			Verify.verifyTrue(true,
					MessageUtility.MRICON_MUTUALFUNDS_NOTDISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.MRICON_MUTUALFUNDS_DISPLAYED);
		}
	}

	/**
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * click Mutual Funds Tab
	 * @throws ScriptException
	 */

	public int clickMutualFundsTab() throws ScriptException {
		if (HHRewriteObjects.WidgetInfos.MUTUALFUNDTAB.exists()) {
			HHRewriteObjects.WidgetInfos.MUTUALFUNDTAB.click();
			waitForTime(4);
			positionOfMR = HHRewriteObjects.WidgetInfos.GRIDMUTUALFUNDS.getText().indexOf("MR");
			Verify.verifyTrue(true,
					MessageUtility.MUTUALFUNDSTAB_CLICKED);
		} else if (HHRewriteObjects.WidgetInfos.MUTUALFUNDTAB_EMPTY_NEW.exists()) {
			HHRewriteObjects.WidgetInfos.MUTUALFUNDTAB_EMPTY_NEW.click();
			positionOfMR = -1;
			Verify.verifyTrue(
					true,
					MessageUtility.MUTUALFUNDSTAB_NORECORD);
		} else {
			Verify.verifyTrue(false, MessageUtility.MUTUALFUNDSTAB_NOTFOUND);
		}
		return positionOfMR;
	}

	/**
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * validate MRSymbol In BankTab
	 * @throws ScriptException
	 */

	public void validateMRSymbolInBankTab() throws ScriptException {
		positionOfMR = clickBankTab();
		if (positionOfMR <= -1)
			Verify.verifyTrue(true,
					MessageUtility.MRICON_BANK_NOTDISPLAYED);
		else
			Verify.verifyTrue(false, MessageUtility.MRICON_BANK_DISPLAYED);
	}

	/**
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * clicking Bank Tab
	 * @throws ScriptException
	 */

	public int clickBankTab() throws ScriptException {
		if (HHRewriteObjects.WidgetInfos.BANKTAB.exists()) {
			HHRewriteObjects.WidgetInfos.BANKTAB.click();
			positionOfMR = HHRewriteObjects.WidgetInfos.GRIDBANK.getText().indexOf("MR");
			Verify.verifyTrue(true, MessageUtility.BANKTAB_CLICKED);
		} else if (HHRewriteObjects.WidgetInfos.EMPTYBANKTAB.exists()) {
			HHRewriteObjects.WidgetInfos.EMPTYBANKTAB.click();
			positionOfMR = -1;
			Verify.verifyTrue(
					true,
					MessageUtility.BANKTAB_NORECORD);
		} else {
			Verify.verifyTrue(false, MessageUtility.BANKTAB_NOTFOUND);
		}
		return positionOfMR;
	}
    /**
     * Validating MRSymbol In Products With Others Tab
     * @throws ScriptException
     */
	public void validateMRSymbolInProductsWithOthersTab()
			throws ScriptException {
		clickProductsWithOthersTab();
		int positionOfMR = HHRewriteObjects.WidgetInfos.GRIDPRODUCTSWITHOTHERS.getText().indexOf("MR");
		if (positionOfMR <= -1)
			Verify.verifyTrue(true,
					MessageUtility.PRODUCTSWITHOTHERSTAB_NOTDISPLAYED);
		else
			Verify.verifyTrue(false,
					MessageUtility.PRODUCTSWITHOTHERSTAB_DISPLAYED);
	}
    /**
     * Clicking Products With Others Tab
     * @throws ScriptException
     */
	public void clickProductsWithOthersTab() throws ScriptException {
		waitForPageLoad(HHRewriteObjects.WidgetInfos.PRODUCTSWITHOTHERSTAB, 10);
		if (HHRewriteObjects.WidgetInfos.PRODUCTSWITHOTHERSTAB.exists()) {
			HHRewriteObjects.WidgetInfos.PRODUCTSWITHOTHERSTAB.click();
			Verify.verifyTrue(true,
					MessageUtility.PRODUCTSWITHOTHERSTAB_CLICKED);
		} else {
			Verify.verifyTrue(false, MessageUtility.PRODUCTSWITHOTHERSTAB_NOTCLICKED);
		}
	}
    /**
     * Validate for Life,Health,Bank,MutualFunds policies action Drop Down is Not display
     */
	public void validateLifeHealthBankMutualFundsActionDropDownNotdisplay(){
		
		int customerCount = 0;
		TableEx names = new TableEx("id=gridNode");
		int rowCount = names.getBodyRowCount();
		for(int i=0;i<rowCount;i++)
		{
			String custName = names.getBodyCellText(i, 8);
			if(custName.equalsIgnoreCase(clientE2ETO.getCustomerOneData()))
				 customerCount = rowCount;
		}
				int divCount = 1;
				try {
					while(true)
					{
					WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
							"div/div["+divCount+"]/table/tbody/tr[1]/td/strong"));
					if (policyType.getText().contains("Life"))
					{
						divCount++;
						WebElement actionDropDownDisplay = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div[@class='dojoxGrid']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
										+ divCount
										+ "]/table[@class='dojoxGridRowTable']/tbody/tr[2]/td[2]")); 
						String actionDropDownDisplayForLife = actionDropDownDisplay.getText();
						if (actionDropDownDisplayForLife.isEmpty())
							Verify.verifyTrue(true,
									MessageUtility.ACTIONDROPDOWN_NOTDISPLAYED
											+ policyType.getText() + "Policy");
							
						else
							Verify.verifyTrue(false,
									MessageUtility.ACTIONDROPDOWN_DISPLAYED
											+ policyType.getText() + "Policy");
					
					}
					if (policyType.getText().contains("Health"))
					{
						divCount++;
						WebElement actionDropDownDisplay = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div[@class='dojoxGrid']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
										+ divCount
										+ "]/table[@class='dojoxGridRowTable']/tbody/tr[2]/td[2]")); 
						String actionDropDownDisplayForHealth = actionDropDownDisplay.getText();
						if (actionDropDownDisplayForHealth.isEmpty())
							Verify.verifyTrue(true,
									MessageUtility.ACTIONDROPDOWN_NOTDISPLAYED
											+ policyType.getText() + "Policy");
							
						else
							Verify.verifyTrue(false,
									MessageUtility.ACTIONDROPDOWN_DISPLAYED
											+ policyType.getText() + "Policy");
					
					}
					if (policyType.getText().contains("Bank"))
					{
						divCount++;
						WebElement actionDropDownDisplay = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div[@class='dojoxGrid']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
										+ divCount
										+ "]/table[@class='dojoxGridRowTable']/tbody/tr[2]/td[2]")); 
						String actionDropDownDisplayForBank = actionDropDownDisplay.getText();
						if (actionDropDownDisplayForBank.isEmpty())
							Verify.verifyTrue(true,
									MessageUtility.ACTIONDROPDOWN_NOTDISPLAYED
											+ policyType.getText() + "Policy");
							
						else
							Verify.verifyTrue(false,
									MessageUtility.ACTIONDROPDOWN_DISPLAYED
											+ policyType.getText() + "Policy");
					
					}
					if (policyType.getText().contains("MFund"))
						{
							divCount++;
							WebElement actionDropDownDisplay = getWebDriverInstance().findElement(By.xpath("//div[@class='policyDiv']/div[@class='dojoxGrid']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
											+ divCount
											+ "]/table[@class='dojoxGridRowTable']/tbody/tr[2]/td[2]")); 
							String actionDropDownDisplayForMutualFunds = actionDropDownDisplay.getText();
							if (actionDropDownDisplayForMutualFunds.isEmpty())
								Verify.verifyTrue(true,
										MessageUtility.ACTIONDROPDOWN_NOTDISPLAYED
												+ policyType.getText() + "Policy");
								
							else
								Verify.verifyTrue(false,
										MessageUtility.ACTIONDROPDOWN_DISPLAYED
												+ policyType.getText() + "Policy");
							break;
						
						}
					divCount++;
					}
				} catch (Exception e) {
					Verify.verifyTrue(false, e.getMessage());
					
				}
}
	 /**
     * verify PresentationKit Page
     * @throws ScriptException
     */
	public void verifyPresentationKitPage() throws ScriptException {

		waitForPageLoad(PresentationKitPopupObjects.BUTTON_VIEW, 20);

		if ((HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_HELPONTHISPAGE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_HELPONTHISPAGE_NOTDISPLAYED);
		}

		if ((PresentationKitPopupObjects.BUTTON_VIEW).exists()) {
			Verify.verifyTrue(true, MessageUtility.BUTTON_VIEW_DISPLAYED);

		} else {
					Verify.verifyTrue(false, MessageUtility.BUTTON_VIEW_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.BUTTON_CLOSE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.BUTTON_CLOSE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_CLOSE_NOTFOUND);
		}
		if ((PresentationKitPopupObjects.link_agentonlinecatalog).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_AGENTONLINE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_AGENTONLINE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.link_backroomtechnician).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_BACKROOMTECHNICIAN_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_BACKROOMTECHNICIAN_NOTDISPLAYED);
		}
		/*if ((PresentationKitPopupObjects.link_environmenturl).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_ENVIRONMENTURL_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ENVIRONMENTURL_NOTDISPLAYED);
		}*/
		if ((PresentationKitPopupObjects.link_vitalsigns).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_VITALSIGNS_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_VITALSIGNS_NOTDISPLAYED);
		}
		verifyNondisclosure();
		/**
		 * verify check boxes
		 */
		if ((PresentationKitPopupObjects.CHECKBOX_CSON).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.SELECTITEMS);

			Verify.verifyTrue(true,
					MessageUtility.CUSTOMERPROFILE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTOMERPROFILE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CSON_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.POLICYLISTINGPRINT_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.POLICYLISTINGPRINT_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CSON_2).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.HOUSEHOLDOPPORTUNITIES_DISPLAYED);

		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.HOUSEHOLDOPPORTUNITIES_NOTDISPLAYED);
		}
		/*	if ((PresentationKitPopupObjects.CHECKBOX_FTON_6).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.FACTFINDERHEADER_DISPLAYED);

			Verify.verifyTrue(true,
					MessageUtility.LIFEFACTFINDER_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LIFEFACTFINDER_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_FTON_4).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.EDUCATIONSAVINGSFACTFINDER_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.EDUCATIONSAVINGSFACTFINDER_NOTDISPLAYED);
		}*/

		if ((PresentationKitPopupObjects.CHECKBOX_FTON_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.RETIREMENYFACTFINDER_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RETIREMENYFACTFINDER_NOTDISPLAYED);
		}
		/*if ((PresentationKitPopupObjects.CHECKBOX_CGON_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CONVERSATIONGUIDESHEADER);

			Verify.verifyTrue(true,
					MessageUtility.QUICKNAQ_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.QUICKNAQ_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CGON_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.SALESCONVERSATIONMODEL_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.SALESCONVERSATIONMODEL_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CGON_5).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.PYRAMIDOFNEEDS_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.PYRAMIDOFNEEDS_NOTDISPLAYED);
		}

		if ((PresentationKitPopupObjects.checkBox_trOn_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.BACKROOMTECHNICIANREPORTSHEADER);

			Verify.verifyTrue(
					true,
					MessageUtility.CONSIDERATIONSINPURCHASEOFLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.CONSIDERATIONSINPURCHASEOFLIFEINSURANCE_NOTDISPLAYED);
		}*/
		if ((PresentationKitPopupObjects.checkBox_trOn_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.GENERALPURPOSESOFLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.GENERALPURPOSESOFLIFEINSURANCE_NOTDISPLAYED);
		}
		/*if ((PresentationKitPopupObjects.checkBox_trOn_2).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.UNIVERSALLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.UNIVERSALLIFEINSURANCE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn_4).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LONGTERMCARE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LONGTERMCARE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.NEEDFORRESPONSIBLEPLANNING_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.NEEDFORRESPONSIBLEPLANNING_NOTDISPLAYED);
		}*/

	}
/**
 * Verify Previous Review Page
 * @throws ScriptException
 */
	public void verifyPreviousReviewPage() throws ScriptException {
		if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE.exists()) {
			if (ReviewDatePopupObjects.WidgetInfos.LINK_HELPONTHISPAGE.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_HELPONTHISPAGE_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_HELPONTHISPAGE_NOTDISPLAYED);
			}
			if (ReviewDatePopupObjects.WidgetInfos.DIV_REVIEWDATES.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.REVIEWDATE_HEADER_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.REVIEWDATE_HEADER_NOTDISPLAYED);
			}
			if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.PREVIOUSREVIEW_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.PREVIOUSREVIEW_NOTDISPLAYED);
			}
			if (ReviewDatePopupObjects.WidgetInfos.IMAGE_DISPLAY_DATEPICKER.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.PREVIOUSREVIEWDATEPICKER_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.PREVIOUSREVIEWDATEPICKER_NOTDISPLAYED);
			}
			if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE.exists()) {
				Verify.verifyTrue(true, MessageUtility.NEXTREVIEW_DISPLAYED);
			} else {
				Verify.verifyTrue(false,MessageUtility.NEXTREVIEW_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.IMAGE_DISPLAY_DATEPICKER).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.NEXTREVIEWDATEPICKER_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.NEXTREVIEWDATEPICKER_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.LABEL_CREATE).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LABEL_CREATE_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.LABEL_CREATE_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.LINK_FOLLOWUP).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_FOLLOWUP_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_FOLLOWUP_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.LINK_NOTES).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_NOTE_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_NOTE_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.LINK_PRESENTATIONKIT).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_PRESENTATIONKIT_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_PRESENTATIONKIT_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.BUTTON_SAVE).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.BUTTON_SAVE_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.BUTTON_SAVE_NOTFOUND);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.BUTTON_CANCEL).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.BUTTON_CANCEL_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.BUTTON_CANCEL_NOTDISPLAYED);
			}
			verifyNondisclosure();
		}
	}
    /**
     * Clicking cancel button in Previous Review Page
     * @throws ScriptException
     */
	public void cancelPreviousReviewPage() throws ScriptException {
		waitForPageLoad(ReviewDatePopupObjects.WidgetInfos.BUTTON_CANCEL, 5);
		if (ReviewDatePopupObjects.WidgetInfos.BUTTON_CANCEL.exists()) {
			click(ReviewDatePopupObjects.WidgetInfos.BUTTON_CANCEL,
					MessageUtility.BUTTON_CANCEL);
		}
	}
    /**
     * Verify Next Review Page
     * @throws ScriptException
     */
	public void verifyNextReviewPage() throws ScriptException {
		if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE.exists()) {
			if (ReviewDatePopupObjects.WidgetInfos.LINK_HELPONTHISPAGE.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_HELPONTHISPAGE_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_HELPONTHISPAGE_NOTDISPLAYED);
			}
			if (ReviewDatePopupObjects.WidgetInfos.DIV_REVIEWDATES.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.REVIEWDATE_HEADER_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.REVIEWDATE_HEADER_NOTDISPLAYED);
			}
			if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.PREVIOUSREVIEW_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.PREVIOUSREVIEW_NOTDISPLAYED);
			}
			if (ReviewDatePopupObjects.WidgetInfos.IMAGE_DISPLAY_DATEPICKER.exists()) {
				Verify.verifyTrue(true,
						MessageUtility.PREVIOUSREVIEWDATEPICKER_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.PREVIOUSREVIEWDATEPICKER_NOTDISPLAYED);
			}
			if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE.exists()) {
				Verify.verifyTrue(true, MessageUtility.NEXTREVIEW_DISPLAYED);
			} else {
				Verify.verifyTrue(false,MessageUtility.NEXTREVIEW_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.IMAGE_DISPLAY_DATEPICKER).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.NEXTREVIEWDATEPICKER_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.NEXTREVIEWDATEPICKER_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.LABEL_CREATE).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LABEL_CREATE_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.LABEL_CREATE_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.LINK_FOLLOWUP).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_FOLLOWUP_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_FOLLOWUP_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.LINK_NOTES).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_NOTE_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_NOTE_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.LINK_PRESENTATIONKIT).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.LINK_PRESENTATIONKIT_DISPLAYED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.LINK_PRESENTATIONKIT_NOTDISPLAYED);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.BUTTON_SAVE).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.BUTTON_SAVE_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.BUTTON_SAVE_NOTFOUND);
			}
			if ((ReviewDatePopupObjects.WidgetInfos.BUTTON_CANCEL).exists()) {
				Verify.verifyTrue(true,
						MessageUtility.BUTTON_CANCEL_DISPLAYED);
			} else {
				Verify.verifyTrue(false, MessageUtility.BUTTON_CANCEL_NOTDISPLAYED);
			}
			verifyNondisclosure();
		} else {
			Verify.verifyTrue(false, "Next Review Date not launched");
		}
	}
    /**
     * verify Add Account Policies page
     * @throws ScriptException
     */
	public void verifyAddAccountPolicies() throws ScriptException {
		waitForPageLoad(AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS, 5);
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.DIV_ADDACCOUNT_POLICIES.getText().equalsIgnoreCase("Add Accounts/Policies With Others")))
		{
			Verify.verifyTrue(true,
					MessageUtility.ACCOUNTPOLICYHEADER_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.ACCOUNTPOLICYHEADER_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINEOFBUSINESS_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINEOFBUSINESS_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_STATE_PROV).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.STATE_DISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.STATE_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_PRODUCT_TYPE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.PRODUCTTYPE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PRODUCTTYPE_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.COMPANY_DISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.COMPANY_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_TERM_DATE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.EXDATE_DISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.EXDATE_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_ACCOUNT_DETAILS).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.DETAILS_DISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.DETAILS_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_CLOSE).exists()) {
			Verify.verifyTrue(true, MessageUtility.BUTTON_CLOSE_DISPLAYED);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_CLOSE_NOTFOUND);
		}

		verifyNondisclosure();
	}
   /**
    * Verify CreateFollowUp,Help on this page links  And Save button In Add Account Policies page
    */
	public void verifyCreateFollowUpHelpAndSaveInAddAccountPolicies()	{
		try {

			if (AddAccountsandPoliciesPopupObjects.WidgetInfos.CHECKBOX_FOLLOW_UP.exists())
				Verify.verifyTrue(true,
						MessageUtility.CREATEFOLLOWUP_DISPLAYED);
			else
				Verify.verifyTrue(false,
						MessageUtility.CREATEFOLLOWUP_NOTDISPLAYED);

			if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LINK_HELP_ON_PAGE.exists())
				Verify.verifyTrue(true,
						MessageUtility.LINK_HELPONTHISPAGE_DISPLAYED);
			else
				Verify.verifyTrue(false,
						MessageUtility.LINK_HELPONTHISPAGE_NOTDISPLAYED);

			if (AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_SAVE.exists())
				Verify.verifyTrue(true, MessageUtility.BUTTON_SAVE_DISPLAYED);
			else
				Verify.verifyTrue(false, MessageUtility.BUTTON_SAVE_NOTFOUND);

		} catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		}
	}
    /**
     * Getting Added Policy Count For Products With Others
     * @return
     * @throws ScriptException
     */
	public int[] getAddedPolicyCountForProductsWithOthers()
			throws ScriptException {
		waitForPageLoad(HouseHoldPageObjects.WidgetInfos.LABEL_POLICYCOUNT_WithOthers, 10);
		String countText = HouseHoldPageObjects.WidgetInfos.LABEL_POLICYCOUNT_WithOthers
				.getText();
		String count2Str = countText;
		String autocount = count2Str.substring(count2Str.indexOf("Auto("),
				count2Str.indexOf("Auto(") + 6);
		autoPolicyCountI = Integer.parseInt(autocount.charAt(5) + "");
		Verify.verifyTrue(true,
				"Auto Count  " + Integer.parseInt(autocount.charAt(5) + ""));

		String fireCount = count2Str.substring(count2Str.indexOf("Fire("),
				count2Str.indexOf("Fire(") + 6);
		firePolicyCountI = Integer.parseInt(fireCount.charAt(5) + "");
		Verify.verifyTrue(true, "Fire Count  " + firePolicyCountI);

		String bankcount = count2Str.substring(count2Str.indexOf("Bank("),
				count2Str.indexOf("Bank(") + 6);
		bankPolicyCountI = Integer.parseInt(bankcount.charAt(5) + "");
		Verify.verifyTrue(true,
				"Bank Count  " + Integer.parseInt(bankcount.charAt(5) + ""));

		String healthCount = count2Str.substring(count2Str.indexOf("Health("),
				count2Str.indexOf("Health(") + 8);
		healthPolicyCountI = Integer.parseInt(healthCount.charAt(7) + "");
		Verify.verifyTrue(true, "Health Count  " + healthPolicyCountI);

		int[] count = { autoPolicyCountI, firePolicyCountI, lifePolicyCountI,
				healthPolicyCountI, bankPolicyCountI, mutualPolicyCount };
		return count;

	}
    /**
     * Launching Update Auto Policy from Products With Others tab 
     * @throws ScriptException
     */
	public void launchUpdateOthersAuto() throws ScriptException {
		clickProductsWithOthersTab();
		waitForPageLoad(HouseHoldPageObjects.WidgetInfos.LINK_UPDATEAUTOOTHERS, 10);
		if ((HouseHoldPageObjects.WidgetInfos.LINK_UPDATEAUTOOTHERS).exists()) {
			click(HouseHoldPageObjects.WidgetInfos.LINK_UPDATEAUTOOTHERS,
					MessageUtility.LINK_UPDATEAUTOPOLICY);
			setWindow(EndToEndConstants.UPDATE_ACCOUNTSPOLICIES_WITHOTHERS, 15,
					2);
		}
	}
   /**
    * verify Updated Account Policies of Products With Others tab 
    * @throws ScriptException
    */
	public void verifyUpdateAccountPolicies() throws ScriptException {
		waitForPageLoad(AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS);
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.DIV_ADDACCOUNT_POLICIES).getText().equalsIgnoreCase("Update Accounts / Policies With Others")) {
			Verify.verifyTrue(true,
					MessageUtility.UPDATEPOLICYHEADER_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.UPDATEPOLICYHEADER_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINEOFBUSINESS_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINEOFBUSINESS_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_STATE_PROV).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.STATE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.STATE_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_PRODUCT_TYPE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.PRODUCTTYPE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PRODUCTTYPE_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.COMPANY_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.COMPANY_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_TERM_DATE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.EXDATE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.EXDATE_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_ACCOUNT_DETAILS).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.DETAILS_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.DETAILS_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_SAVE).exists()) {
			Verify.verifyTrue(true, MessageUtility.BUTTON_SAVE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_SAVE_NOTFOUND);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_CANCEL).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.BUTTON_CANCEL_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_CANCEL_NOTDISPLAYED);
		}
		if ((AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_REMOVE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.BUTTON_REMOVE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_REMOVE_NOTDISPLAYED);
		}
		verifyNondisclosure();
	}
    /**
     * Validating Bank Policy Count After Removal
     * @param before
     * @param after
     * @throws ScriptException
     */
	public void validateBankPolicyCountAfterRemoval(int[] before, int[] after)
			throws ScriptException {
		if (before[4] - after[4] == 1) {
			Verify.verifyTrue(true,
					MessageUtility.BANKPOLICY_DECREMENT);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BANKPOLICY_NOTDECREMENT);
		}
	}
    /**
     * Clicking AssignedStaff Link
     * @throws ScriptException
     */
	public void clickShowAgentStaff() throws ScriptException {
		if (HHRewriteObjects.WidgetInfos.ASSIGNEDSTAFF.exists()) {
			HHRewriteObjects.WidgetInfos.ASSIGNEDSTAFF.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_ASSIGNEDSTAFF_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ASSIGNEDSTAFF_NOTDISPLAYED);

		}
	}
   /**
    * Verify Assigned Staff Link In HHPage
    */
	public void verifyAssignedStaffLinkInHHPage() {
		try {
			if (isHHPageLaunched()) {
				clickShowAgentStaff();
				verifyShowAgentStaff();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}
    /**
     * Launch And Verify Production Manager Link  In HHPage
     */
	public void launchAndVerifyProductionManagerLinkInHHPage() {
		try {
			if (isHHPageLaunched()) {
				clickProductionManager();
				verifyProductionManager();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
			clickHHPageCustomer();
			setTopFrame();
			handleCimsVersion();
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		}
	}
    /**
     * Verify Assigned Staff Link In HHPage
     */
	public void verifyShowAgentStaff() throws ScriptException {
		waitForPageLoad(HHRewriteObjects.WidgetInfos.ASGNDSTFSAVE, 5);
		if (HHRewriteObjects.WidgetInfos.ASGNDSTFSAVE.exists()) {
			HHRewriteObjects.WidgetInfos.ASGNDSTFSAVE.click();
			Verify.verifyTrue(
					true,
					MessageUtility.ASSIGNEDSTAFFWINDOW_OPEN);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.ASSIGNEDSTAFFWINDOW_NOTOPEN);
		}
	}
   /**
    * Launch And Verify Production Manager Link  In HHPage
    * @throws ScriptException
    */
	public void clickProductionManager() throws ScriptException {
		waitForPageLoad(HHRewriteObjects.WidgetInfos.PRODUCTIONMANAGER, 10);
		if (HHRewriteObjects.WidgetInfos.PRODUCTIONMANAGER.exists()) {
			HHRewriteObjects.WidgetInfos.PRODUCTIONMANAGER.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_PRODUCTIONMANAGER_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_PRODUCTIONMANAGER_NOTDISPLAYED);

		}
	}
   /**
    * Launch And Verify Production Manager Link  In HHPage
    * @throws ScriptException
    */
	public void verifyProductionManager() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.PRODMANAGER, 10);
		if (HouseHoldMove_PageObjects.WidgetInfos.PRODMANAGER.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_PRODUCTIONMANAGER_LAUNCHED);
			HouseHoldMove_PageObjects.WidgetInfos.PRODMANAGER_CLOSE.click();
		} else
			Verify.verifyTrue(false, MessageUtility.LINK_PRODUCTIONMANAGER_NOTLAUNCHED);
	}
	

	/**
	 * Verify Previous Review Date Functionality
	 * 
	 * @throws ScriptException
	 */
	public void verifyPreviousReviewDateFunctionality() {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(ReviewDatePopupObjects.WidgetInfos.LINK_PREVIOUSREVIEWDATE, 2);
				if (ReviewDatePopupObjects.WidgetInfos.LINK_PREVIOUSREVIEWDATE.exists()) {
					clickPreviousReviewLink();
					waitForPageLoad(ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE,5);
					if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE.exists()) {
						verifyPreviousReviewPage();
						setPreviousReviewDate(getPreviousReviewDate());
						isErrorPage("Previous Review Date");
						setTopFramewithDefaultContent();
						refreshHHPage();
					} else {
						isErrorPage("Previous Review Date");
						Verify.verifyTrue(false,
								MessageUtility.PREVIOUSREVIEWDATE_NOTLAUNCHED);
					}
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
				isErrorPage("Previous Review Date");
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch(Exception e){
					Verify.verifyTrue(true, e.getMessage());
		}
	}
	
    /**
     * Verify Next Review Date Functionality
     */
	public void verifyNextReviewDateFunctionality() {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(HouseHoldTestObjects.WidgetInfos.NEXTREVIEWDATE, 2);
				if (HouseHoldTestObjects.WidgetInfos.NEXTREVIEWDATE.exists()) {
					clickNextReviewLink();
					waitForPageLoad(ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE,5);
					if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE.exists()) {
						verifyNextReviewPage();
						setNextReviewDate(getNextReviewDate());
						isErrorPage("Next Review Date");
						setTopFramewithDefaultContent();
						refreshHHPage();
					} else {
						Verify.verifyTrue(false,
								MessageUtility.NEXTREVIEWDATE_NOTLAUNCHED);
						isErrorPage("Next Review Date");
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
				}
			} else {

			}
		} catch (ScriptException exception) {
			exception.printStackTrace();
			scriptError(exception);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}
	
    /**
     * verify Presentation Kit in HH Page
     */
	public void verifyPresentationKit() {
		try {
			if (isHHPageLaunched()) {
				clickPresenationKitinHHpage();
				setWindow(EndToEndConstants.PRESENTATION_KIT, 15, 2);
				if (isPresentationKitPageExists()) {
					verifyPresentationKitPage();
					launchOnePDFFromEachSectionInPresentationKit();
					closePresentationKitPage();
				} else {
					isErrorPage("Presentation Kit");
					closeCurrentPage();
					Verify.verifyTrue(false,
							MessageUtility.PRESENTATIONKITPAGE_CLOSED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}finally {
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 15, 2);
			setTopFramewithDefaultContent();
		}
	}
    /**
     * Verify Accounts Policies With Others
     */
	public void verifyAccountsPoliciesWithOthers() {
		try {
			if (isHHPageLaunched()) {
				clickAddAccPoliciesWithOthersLink();
				setWindow(EndToEndConstants.ADD_ACCOUNTSPOLICIES_WITHOTHERS,
						15, 2);
				if (!isErrorPage(EndToEndConstants.ADD_ACCOUNTSPOLICIES_WITHOTHERS)) {
					verifyAddAccountPolicies();
					verifyCreateFollowUpHelpAndSaveInAddAccountPolicies();
					closeAddAccountPolicies();
				} else {
					closeCurrentPage();
					Verify.verifyTrue(
							false,
							MessageUtility.ADDPOLICIESPAGE_CLOSED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		}  catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}finally{
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 10, 2);
			setTopFramewithDefaultContent();
		}
	}
    /**
     * Adding Auto Policy to Account Policies with Others
     * Adding Bank Policy to Account Policies with Others
     */
	public void createAutoBankPolicesWithOthers() {
		try {
			if (isHHPageLaunched()) {
				countbefore = getAddedPolicyCountForProductsWithOthers();
				clickAddAccPoliciesWithOthersLink();
				setWindow(EndToEndConstants.ADD_ACCOUNTSPOLICIES_WITHOTHERS, 25, 2);
				if (!isErrorPage(EndToEndConstants.ADD_ACCOUNTSPOLICIES_WITHOTHERS)) {
					addAutoAccountPolicies();
					clickAddAccPoliciesSave();
					addBankAccountPolicies();
					clickAddAccPoliciesSave();
					if(isErrorPage(EndToEndConstants.ADD_ACCOUNTSPOLICIES_WITHOTHERS)){
						closeCurrentPage();
					}
					closeAddAccountPolicies();
				} else {
					Verify.verifyTrue(
							false,
							MessageUtility.ADDPOLICIESPAGE_CLOSED);
				}
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
		setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 15, 2);
		setTopFramewithDefaultContent();
	}
    /**
     * Verifying Auto and Bank Policy to Account Policies with Others
     */
	public void verifyCreatedAutoBankPolicies() {
		try {
			if (isHHPageLaunched()) {
				refreshHHPage();
				waitForPageLoad(HouseHoldTestObjects.WidgetInfos.MEMBERDRPDWN, 15);
				countafter = getAddedPolicyCountForProductsWithOthers();
				validateAutoPolicyCount(countbefore, countafter);
				validateBankPolicyCount(countbefore, countafter);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}

	}
  /**
   * Updating Auto Policy to Account Policies with Others
   */
	public void updateAutoPoliciesWithOthers() {
		try {
			if (isHHPageLaunched()) {
				launchUpdateOthersAuto();
				if (!isErrorPage("Add Acc Policies With Others")) {
					verifyUpdateAccountPolicies();
					changeProductTypeToCV();
					clickAddAccPoliciesSave();
					setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 15, 2);
					setTopFramewithDefaultContent();
					refreshHHPage();
				} else {
					closeCurrentPage();
					setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 15, 2);
					setTopFramewithDefaultContent();
					Verify.verifyTrue(
							false,
							MessageUtility.ADDPOLICIESPAGE_CLOSED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}
  /**
   * Removing  Bank Policy to Account Policies with Others
   */
	public void removeBankPoliciesWithOthers() {
		try {
			if (isHHPageLaunched()) {
				int[] countBefore = getPolicyCountForProductsWithOthers();
				clickProductsWithOthersTab();
				removeBankAccountPolicies();
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 15, 2);
				setTopFramewithDefaultContent();
				refreshHHPage();
				isHosuseHoldPageLaunchedOrNot();
				int[] countAfter = getPolicyCountForProductsWithOthers();
				validateBankPolicyCountAfterRemoval(countBefore, countAfter);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException exception) {
			scriptError(exception);
		} catch(Exception e){
					Verify.verifyTrue(false, e.getMessage());
		}
	}
   /**
    * verify Search and select One customer  Page
    * @throws ScriptException
    */


	public void verifyCombineSeparatePage() throws ScriptException {
			try {
				if (isHHPageLaunched()) {
					clickMenuBar(HouseHoldTestObjects.WidgetInfos.CUSTOMER_LINK, HouseHoldTestObjects.WidgetInfos.LINK_CUSTOMER_UNDERCOMBINESEPARATE_CRC);
					launchSS1CPageFromCMPage();
					cancelCustomerSeparatePage();
					isHosuseHoldPageLaunchedOrNot();
				} else {
					Verify.verifyTrue(false,
							MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
				}
			} catch (ScriptException exception) {
				scriptError(exception);
			}catch(Exception e){
				Verify.verifyTrue(false, e.getMessage());
			}
		}

     /**
      * Verify PresentationKit Page is Exists
      * @return
      */
	public boolean isPresentationKitPageExists() {
		waitForPageLoad(PresentationKitPopupObjects.VIEW, 20);
		if (PresentationKitPopupObjects.VIEW.exists()) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * Adding Auto,Fire,Health Policy to Account Policies with Others
	 * @throws ScriptException
	 */
	public void createAutoFireHealthPolicesWithOthers() throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				countbefore = getAddedPolicyCountForProductsWithOthers();
				clickAddAccPoliciesWithOthersLink();
				setWindow("Add Accounts/Policies With Others", 30, 2);
				if (!isErrorPage("Add Acc Policies With Others")) {
					addAutoAccountPolicies();
					clickAddAccPoliciesSave();
					addFireAccountPolicies();
					clickAddAccPoliciesSave();
					addHealthAccountPolicies();
					clickAddAccPoliciesSave();
					closeAddAccountPolicies();
					setWindow("Household Information", 30, 2);
					setTopFramewithDefaultContent();
					refreshHHPage_SW();
				} else {
					closeCurrentPage();
					Verify.verifyTrue(
							false,
							MessageUtility.ADDPOLICIESPAGE_CLOSED);
				}
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
    /**
     * Adding Auto Policy to Account Policies with Others
     */
	public void createAutoPolicesWithOthers() {
		try {
			if (isHHPageLaunched()) {
				countbefore = getAddedPolicyCountForProductsWithOthers();
				clickAddAccPoliciesWithOthersLink();
				setWindow("Add Accounts/Policies With Others", 30, 2);
				if (!isErrorPage("Add Acc Policies With Others")) {
					addAutoAccountPolicies();
					clickAddAccPoliciesSave();
					closeAddAccountPolicies();
				} else {
					closeCurrentPage();
					Verify.verifyTrue(
							false,
							MessageUtility.ADDPOLICIESPAGE_CLOSED);
				}
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}finally {
			setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 20, 2);
			setTopFramewithDefaultContent();
		}
	}
   /**
    * Verifying Added Auto,Fire and Health Policy to Account Policies with Others
    * @throws ScriptException
    */
	public void verifyCreatedAutoFireHealthPolicies() throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				countafter = getAddedPolicyCountForProductsWithOthers();
				validateAutoPolicyCount(countbefore, countafter);
				validateFirePolicyCount(countbefore, countafter);
				validateHealthPolicyCount(countbefore, countafter);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		}
	}
   /**
    * Verifying Added Auto Policy to Account Policies with Others
    */
	public void verifyCreatedAutoPoliciy() {
		try {
			if (isHHPageLaunched()) {
				countafter = getAddedPolicyCountForProductsWithOthers();
				validateAutoPolicyCount(countbefore, countafter);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
    /**
     * Validating Health Policy Count of Account Policies with Others
     * @param before
     * @param after
     * @throws ScriptException
     */
	public void validateHealthPolicyCount(int[] before, int[] after)
			throws ScriptException {
		if (after[3] - before[3] == 1) {
			Verify.verifyTrue(true,
					MessageUtility.HEALTHPOLICY_INCREMENT);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HEALTHPOLICY_NOTINCREMENT);
		}
	}
    /**
     *  Validating Fire Policy Count of Account Policies with Others
     * @param before
     * @param after
     * @throws ScriptException
     */
	public void validateFirePolicyCount(int[] before, int[] after)
			throws ScriptException {
		if (after[1] - before[1] == 1) {
			Verify.verifyTrue(true,
					MessageUtility.BANKPOLICY_INCREMENT);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BANKPOLICY_NOTINCREMENT);
		}
	}
	/**
	 * Validate HelpOnthisPage Link  In CustomerSearchPage
	 */
	public void validateHelpOnthisPageInCustomerSearchPage() {
		try {
			
			/*KeyboardUtility.sendKeys("u59x");
			KeyboardUtility.sendKeys("{TAB}");
			KeyboardUtility.sendKeys(new String(Base64.decode("TmFuZGExMiQ=")).toString());
			KeyboardUtility.sendKeys("{TAB}");
			KeyboardUtility.sendKeys("{ENTER}");*/
			waitForTime(3);
			setWindow("Customer Search Online Help",5,2);
			Button close = new Button("id=close");
			if(close.exists())
			{
				Verify.verifyTrue(true, MessageUtility.HELPONTHISPAGE_LAUNCHED);
				close.click();
			}
			else
				Verify.verifyTrue(false, MessageUtility.HELPONTHISPAGE_NOTLAUNCHED);
			waitForTime(2);
			setWindow(EndToEndConstants.CUSTOMER_SEARCH, 30, 2);
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
		
	}
	
	public void launchHelpOnthisPage_Household() throws ScriptException {
		waitForPageLoad(HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE);
		Verify.verifyTrue(true,
				MessageUtility.LINK_HELPONTHISPAGE_DISPLAYED);
		
		click(HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE,
				MessageUtility.LINK_HELPONTHISPAGE);
		waitForTime(3);
	}
	/**
	 * Validate HelpOnthisPage Link  In Household
	 */
	public void validateHelpOnthisPageInHousehold() {
		try {
			Button close = new Button("id=close");
			if(close.exists())
			{
					Verify.verifyTrue(true, MessageUtility.HELPONTHISPAGE_LAUNCHED);
					close.click();
			}	else
					Verify.verifyTrue(false, MessageUtility.HELPONTHISPAGE_NOTLAUNCHED);
			waitForTime(2);
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
		
	}
	/**
	 * Validate HelpOnthisPage Link  In Add Products with Others Page 
	 */
	public void validateHelpOnthisPageInAddProductsWithOthers() {
		try {
			KeyboardUtility.sendKeys("u59x");
			KeyboardUtility.sendKeys("{TAB}");
			KeyboardUtility.sendKeys(new String(Base64.decode("TmFuZGExMiQ=")).toString());
			KeyboardUtility.sendKeys("{TAB}");
			KeyboardUtility.sendKeys("{ENTER}");
			setWindow("Online Help",3,2);
			Button close = new Button("id=close");
			if(close.exists())
			{
					Verify.verifyTrue(true, MessageUtility.HELPONTHISPAGE_LAUNCHED);
					close.click();
			}	else
					Verify.verifyTrue(false, MessageUtility.HELPONTHISPAGE_NOTLAUNCHED);
			setWindow("Add Accounts/Policies With Others", 5, 2);
			closeAddAccountPolicies();
			setWindow("Household Information",3,2);
			setTopFramewithDefaultContent();
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
		
	}
}