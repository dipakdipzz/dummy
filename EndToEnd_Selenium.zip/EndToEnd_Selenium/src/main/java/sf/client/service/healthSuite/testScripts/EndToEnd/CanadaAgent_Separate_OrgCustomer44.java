package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class CanadaAgent_Separate_OrgCustomer44 extends BaseScript{
	
	String query = "select * from CanadaAgent_Separate_OrgCustomer44";
	public void executeScript() throws Exception{
		
		/**
		 * Validate Customer Search Page
		 */
		createCustTasks.launchCustomerSeachPage();
		
		/**
		 * Search for a Individual Customer and navigate to HH page - Enterprise Customer
		 */
		createCustTasks.launchPortalCustomerSearchPage();
		createCustTasks.launchPortalHHPage();
		
		/**
		 * Search and Select Customer from Search and Select one Customer Page. 
		 */
		separateCustTasks.verifySearchandSelectOneCustomerPage();
		 
		/**
		 * Verify Phone,Email,License,Address,SSN/SIN and Birth date details
		 */
		separateCustTasks.setAndValidateSeparateCustomerPageOne();
		
		/**
		 * Verify Customers Tables in Separate Customer Page One
		 */
		separateCustTasks.verifyCustomersTablesinSeparateCustomerPageOne();
		
		
		/**
		 *  validate PersonalInfo in Separate Customer Page
		 */
		separateCustTasks.validateOrganizationInfoinSeparateCustomerPage();
		
		
		/**
		 *  validate Print Additional Customer information link
		 */
		separateCustTasks.validatePrintAdditionalCustomerInformation();
		 
		 
		 
		/**
		 *  validate Separate Functionality
		 */
		//separateCustTasks.validateSeparateFunction();
		 
		 
		 
}
public void scriptMain()  {
	
	try {
		transferObject=setTestDataObject(transferObject);
		transferObject.setDbQuery(query);
		
		dbresultSet =databaseUtil.getCoreData(transferObject);
		
		while(dbresultSet.next()){
			clientE2ETO = databaseUtil.loadTestDataSeparateOrgCustomerCanada44(dbresultSet,clientE2ETO);
			scenarioTasks = new ScenarioTasks(clientE2ETO);
			updateTasks =new UpdateCustomersTasks(clientE2ETO);
			createCustTasks = new CreateCustomersTasks(clientE2ETO);
			combineTasks = new CombineCustomersTasks(clientE2ETO);
			separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
			launcher = new LaunchApplication(getWATConfig());
			launcher.launchUser(scriptName());
			scenarioTasks.createResultsFile(resultsFileName(),scriptName());
			
			executeScript();
			
		}
		
		
	} 
		catch (Exception e) {
		e.printStackTrace();
	}
}
}


