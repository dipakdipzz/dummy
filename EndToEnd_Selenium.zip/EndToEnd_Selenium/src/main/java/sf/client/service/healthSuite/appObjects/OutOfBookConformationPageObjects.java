package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.RadioButton;

public class OutOfBookConformationPageObjects {
	public static final String OUTOFBOOKCONFORMATION_RADIOBUTTON_SELECTEDREASONAGENTINITI_1 = "id=selectedReasonAgent"; // ToggleGUITestObject
	public static final String OUTOFBOOKCONFORMATION_LINK_NEXT = "text=Next >"; // GuiTestObject
	public static final String OUTOFBOOKCONFORMATION_CHECKBOX_SEARCHEDCUSTOMERPERMISSIONOVER18 = "id=searchedCustomerName"; // ToggleGUITestObject
	public static final String OUTOFBOOKCONFORMATION_CHECKBOX_MOVEHHMEMBER = "name=rowHeaders";
    public static final String OUTOFBOOKCONFORMATION_CIA = "CIA";
    
    @WidgetIDs
    public static class WidgetInfos{
    	public static final RadioButton RADIOBUTTON_SELECTEDREASONAGENTINITI_1 = new RadioButton(OUTOFBOOKCONFORMATION_RADIOBUTTON_SELECTEDREASONAGENTINITI_1); // ToggleGUITestObject
    	public static final Link LINK_NEXT = new Link(OUTOFBOOKCONFORMATION_LINK_NEXT); // GuiTestObject
    	public static final CheckBox CHECKBOX_SEARCHEDCUSTOMERPERMISSIONOVER18 = new CheckBox(OUTOFBOOKCONFORMATION_CHECKBOX_SEARCHEDCUSTOMERPERMISSIONOVER18); // ToggleGUITestObject
    	public static final CheckBox CHECKBOX_MOVEHHMEMBER =new CheckBox(OUTOFBOOKCONFORMATION_CHECKBOX_MOVEHHMEMBER);
        public static final Link CIA =new Link(OUTOFBOOKCONFORMATION_CIA);
    }
}
