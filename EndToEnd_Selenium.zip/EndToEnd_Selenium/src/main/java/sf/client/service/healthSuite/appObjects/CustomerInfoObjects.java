package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Image;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

public class CustomerInfoObjects

{
	/*public static final Div policySection = new Div("id=tempAgreementGrid");
	public static final Image PhoneImage = new Image("id=textingIcon0");
	public static final ListBox LineOfBusiness = new ListBox("id=lineOfBusiness");
	public static final Span templates = new Span("class=dijitReset dijitInline dijitArrowButtonInner");
	public static final TextField  Message =new TextField("name=message");
	public static final Button Send = new Button("id=save");
	public static final Button Cancel = new Button("id=cancel");
	public static final TextField TXT_SSN_SIN = new TextField("id=SSNSIN");
	public static final TextField TXT_MASKED_TIN = new TextField("id=organization.tin.maskedNumber");
	public static final TextField TXT_TIN = new TextField("id=organization.tin.number");
	public static final TextField TXT_MASKED_SSN_SIN = new TextField("id=maskedSSNSIN");
	public static final TextField TXT_MASKED_CNSIN = new TextField("person.sin.maskedNumber");
	public static final TextField TXT_CNSIN = new TextField("person.sin.number");
	public static final TextField TXT_DRI_LIC = new TextField("id=driversLicenseNumber");
	public static final TextField TXT_MASKED_DRI_LIC = new TextField("id=driversLicenseNumberMask");
	public static final Button BTN_CUST_PRO_PRT = new Button("id=customerProfilePrint");
	public static final Link LINK_COA = new Link("text=Change Address");*/
	//Constants related WidgetInfo class
		public static final String POLICYSECTION_ID = "id=tempAgreementGrid";
		public static final String PHONEIMAGE_ID = "id=textingIcon0";
		public static final String LISTBOX_LINEOFBUSINESS_ID ="id=lineOfBusiness";
		public static final String SPAN_TEMPLATES="class=dijitReset dijitInline dijitArrowButtonInner";
		public static final String TEXTFIELD_MESSAGE ="name=message";
		public static final String BUTTON_SAVE ="id=save";
		public static final String BUTTON_CANCEL ="id=cancel";
		public static final String TEXTFIELD_SSNSIN="id=SSNSIN";
		public static final String TEXTFIELD_MASKEDTIN ="id=organization.tin.maskedNumber";
		public static final String TEXTFIELD_TINNUMBER ="id=organization.tin.number";
		public static final String TEXTFIELD_MASKEDSSNSIN="id=maskedSSNSIN";
		public static final String TEXTFIELD_MASKEDNUMBER="person.sin.maskedNumber";
		public static final String TEXTFIELD_SINNUMBER ="person.sin.number";
		public static final String TEXTFIELD_LICENSENUMBER="id=driversLicenseNumber";
		public static final String TEXTFIELD_MASKLICENSENUMBER="id=driversLicenseNumberMask";
		public static final String BUTTON_CUSTOMERPROFILEPRINT ="id=customerProfilePrint";
		public static final String LINK_CHANGEADDRESS="text=Change Address";
		
		public static final String ACC_POLICY="id=gridAgreements";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final Div DIV_POLICYSECTION = new Div(POLICYSECTION_ID);
		public static final Image PHONEIMAGE = new Image(PHONEIMAGE_ID);
		public static final ListBox LINEOFBUSINESS = new ListBox(LISTBOX_LINEOFBUSINESS_ID);
		public static final Span TEMPLATES = new Span(SPAN_TEMPLATES);
		public static final TextField  MESSAGE =new TextField(TEXTFIELD_MESSAGE);
		public static final Button SEND = new Button(BUTTON_SAVE);
		public static final Button CANCEL = new Button(BUTTON_CANCEL);
		public static final TextField TXT_SSN_SIN = new TextField(TEXTFIELD_SSNSIN);
		public static final TextField TXT_MASKED_TIN = new TextField(TEXTFIELD_MASKEDTIN);
		public static final TextField TXT_TIN = new TextField(TEXTFIELD_TINNUMBER);
		public static final TextField TXT_MASKED_SSN_SIN = new TextField(TEXTFIELD_MASKEDSSNSIN);
		public static final TextField TXT_MASKED_CNSIN = new TextField(TEXTFIELD_MASKEDNUMBER);
		public static final TextField TXT_CNSIN = new TextField(TEXTFIELD_SINNUMBER);
		public static final TextField TXT_DRI_LIC = new TextField(TEXTFIELD_LICENSENUMBER);
		public static final TextField TXT_MASKED_DRI_LIC = new TextField(TEXTFIELD_MASKLICENSENUMBER);
		public static final Button BTN_CUST_PRO_PRT = new Button(BUTTON_CUSTOMERPROFILEPRINT);
		public static final Link LINK_COA = new Link(LINK_CHANGEADDRESS);
		
		public static final Div DIV_ACC_POLICY = new Div(ACC_POLICY);
	}
}


