package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class Enterprise_Agent_Ind_Scenario6 extends BaseScript
{
	int count=0;
	String query = "select * from Enterprise_Agent_Ind_Scenario6";
	public void executeScript() throws Exception{
		
		/**
		* Validate Customer Search Page
		*/
		createCustTasks.launchCustomerSeachPage();
		/**
		 * validate Create Ind & Create Org link Exists in Customer Search page.
		 *validate Enterprise connect & Enterprise View link does not Exists in
		 *Customer Search page.
		 */
		scenarioTasks.verifyCreateIndOrgConnectEnterpriseviewLinksPresent();
		/**
		 *  Search For customer.
		 */ 
		scenarioTasks.launchPortalCustomerSearchPage();
		 /**
		 *  Launch hh Page.
		 */
		scenarioTasks.launchPortalHHPage();
		
		/**
		 *  Validate that the Household hyperlink and Non household hyperlinks are not displayed in the Household Menu
		 */
		hhNavigationTasks.validateHouseholdNonHouseholdLinks();
		/**
		 *  Launch Relationship page
		 */
		hhNavigationTasks.validateAndLaunchRelationshipPage();
		/**
		 *  Validate the Contents of Relationship page.
		 */
		hhRelationshipTasks.validateRelationshipPage();
		/**
		 *  Close Relationship page.
		 */
		hhRelationshipTasks.closeRelationshipPage();
		/**
		 *  Validate that the Internet Enabled column is displayed in the Household members section with its field values ('Y' & 'N')
		 */
		scenarioTasks.isInternetEnabledColumnDisplayedforHTMLHHpage();
		
		/**
		 *  Launch Life Policy from HH Page
		 *//*
		scenarioTasks.launchLifePolicyfromHHPage();
		*//**
		 * Validate that the Life App is launhced, when the life App policy number is clicked in the Product Inactive page 
		 *//*
		hhNavigationTasks.validateInactivePoliciesTabInHHPage();
		scenarioTasks.launchLifeAppfromProductsInactivePage();*/
		/**
		 * Validate the Policy Listing Print Page
		 */
		scenarioTasks.validatePolicyListingPrintInHHpage();
	}
	
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestEnterpriseAgentIndScenario6(dbresultSet,clientE2ETO);
				scenarioTasks=new ScenarioTasks(clientE2ETO);
				removeFromBookTasks=new RemoveFromBookTasks(clientE2ETO);
				createCustTasks=new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks=new HHnavigationTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
				}
			
		} catch (ScriptException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
