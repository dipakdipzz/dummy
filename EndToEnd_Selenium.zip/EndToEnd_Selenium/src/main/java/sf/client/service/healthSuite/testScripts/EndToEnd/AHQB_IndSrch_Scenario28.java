package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;
import statefarm.widget.gui.Browser;

public class AHQB_IndSrch_Scenario28 extends BaseScript {
	int count=0;
	Browser browser = new Browser();
	String query = "select * from AHQB_IndSrch_Scenario28";
	
	public void executeScript() throws Exception {
		
		scenarioTasks.clickLaunchAHQBOnline();
		scenarioTasks.clickGreetingOk();
		scenarioTasks.setWindow("Q & B Online", 10, 2);
		/**
		 * Validating the links in the search page
		 */
		scenarioTasks.verifyCreateIndOrgConnectEnterpriseviewLinksExists();
		
		/**
		 * Launching HH Page
		 */
		scenarioTasks.launchHHPageFromCRCAHQBCustSearchPage();
	
		/**
		 * Add Accounts and Policies
		 */
		hhNavigationTasks.addProductsWithOthersfromHHPage();
		scenarioTasks.setCRCDefaultFrame();
		
        /** Navigate to Customer Info Page */
		scenarioTasks.launchCustInfoPageFromHHPage();
        			
		/**
		 * Add an Alias - Name (Regular Characters). Also Add Preferred Name
		 * Update this Alias - Name with International Characters including � & �
		 */
		updateTasks.addUpdateAliasCRC();
		scenarioTasks.removeIndUpdateName();	
		
	    /**
		 *  Personal Info
		 */
		updateTasks.updatePersonalInfoCustomerInfo_CRC();
	   hhNavigationTasks.selectCustomerNameLinkABS();
	   updateTasks.setCRCDefaultFrame();
	   
		/**
		 * Verify the Relationship Page Exists and Add Individual in Member Inside and Member Outside the Household
		 */
	    hhRelationshipTasks.verifyAHQBAddHouseholdAndNonHouseholdIndInRelationshipPage();
		
		/**
		 * Launch Auto Policies from the Household Info section (Select a Customer having all LOB policies)
		 */
		hhNavigationTasks.validateAutoPolicyInHHPage();
				
		/**
		 * Launch Fire Policies from the Household Info section
		 */
		scenarioTasks.launchFireAppfromHHPage();
					
		/**
		 * Launch Health Policies from the Household Info section
		 */
		scenarioTasks.launchHealthAppfromHHPage();
     
		
		/** Launch Update Personal Information */
		scenarioTasks.clickCRCActionsUpdatePersonalInformation();
				
		/**
		 * Validate that the Internet Enabled column is displayed in the Household members section with its field values ('Y' & 'N')
		 */
		scenarioTasks.isInternetEnabledColumnDisplayedforHTMLHHpage();
		scenarioTasks.clickAHQBOnlineLogo();
	
		createCustTasks.clickCreateIndividualCustomer();
		createCustTasks.createIndividualCustomerWithPhoneEmailData_CRC();
		scenarioTasks.clickAHQBOnlineLogo();
		
		createCustTasks.clickCreateOrganizationCustomer_CRC();
		createCustTasks.createOrgCustWithMobileWorkAdditionalEmailData_CRC();
		scenarioTasks.clickAHQBOnlineLogo();
	}
	
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			
			dbresultSet =databaseUtil.getCoreData(transferObject);
			
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAHQBIndSrchScenario28(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());
				
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				
				executeScript();
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}