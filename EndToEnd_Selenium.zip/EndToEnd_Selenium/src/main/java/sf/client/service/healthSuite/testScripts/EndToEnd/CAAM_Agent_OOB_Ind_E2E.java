package sf.client.service.healthSuite.testScripts.EndToEnd;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.OOBIndividualTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class CAAM_Agent_OOB_Ind_E2E extends BaseScript
{
	int count=0;
	String query = "select * from Agent_OOB_Ind_Scenario18";

	public void executeScript() throws Exception{
		/**
		 *  Launch hh page through oob search
		 */
		oobIndividualTasks.clickCustomerTab();
		oobIndividualTasks.fetchDataOob();
	}
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestAgentOOBIndScenario18(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				removeFromBookTasks = new RemoveFromBookTasks(clientE2ETO);
				oobIndividualTasks = new OOBIndividualTasks(clientE2ETO);
				combineTasks=new CombineCustomersTasks(clientE2ETO);
				ssnSINTasks =new SSNSINTasks(clientE2ETO);
				productTasks=new ProductTasks(clientE2ETO);
				//launcher = new LaunchApplication(getWATConfig());
				//launcher.launchUser(this.getClass().getSimpleName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
			}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}



