package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class Agent_CreateIndCust_Scenario10 extends BaseScript {
	String query = "select * from Agent_CreateIndCust_Scenario10";
	public void executeScript() {
		
		/**Validate Customer Search Page*/
		createCustTasks.launchCustomerSeachPage();
		/**validate Create Individual & Create Organization link Exists in Customer Search page.*/
		scenarioTasks.verifyCreateIndOrg();
		/**Click the 'Create Individual'  link */
		createCustTasks.clickCreateIndividual();
		/**Validate the ability to Create Individual customer*/
		createCustTasks.createIndividualCustomer();
		/**Validate the ability to Create Individual customer Through HH Page*/
		 createCustTasks.addAndVerifyIndCustFromMemberActions();
		/**Launch Customer Info From HH page*/
		createCustTasks.launchCustomerInfoPageFromHHPage();
		/**Validate the Add,Update and Delete Address for a customer*/
		updateTasks.addUpdateDelAdressAndAliasInCustInfo();
		/**Remove All Phone from Customer Info Page Phone Section*/
		updateTasks.removeAllPhonesFromCustomerInfo();
		/**Add Mobile number*/
		updateTasks.addMobilePhoneCustomerInfo();
		/**Update Mobile number*/
		updateTasks.updatePhoneUpdatePhone();
		/**Employment*/
	    scenarioTasks.updateEmploymentAddEmployment();
		/**Navigate back to HH Page By Clicking Customer Active Bar.*/
		scenarioTasks.clickHHPageCustomer();
		scenarioTasks.setTopFrame();
		/**Validate that the Household hyperlink and Non household hyperlinks are not displayed in the Household Menu*/
		hhNavigationTasks.validateHouseholdNonHouseholdLinks();
		/**Validate the Relationship hyperlink displayed in under Household Menu in Household page*/
		hhNavigationTasks.validateAndLaunchRelationshipPage();
		/**Verify the Relationship Page Exists and Add Individual in Member Inside and Member Outside the Household*/
		hhRelationshipTasks.verifyAndAddHouseholdAndNonHouseholdIndInRelationshipPage();
		/**Validate that the Internet Enabled column is displayed in the Household members section with its field values ('Y' & 'N')*/
		scenarioTasks.isInternetEnabledColumnDisplayedforHTMLHHpage();
		/**Navigate to Product Inactive page  and validate the screen contents.*/
		//hhNavigationTasks.validateInactivePoliciesTabInHHPage();
		/**Navigate to Household Maintenance screen and perform Household Move transaction*//*
		hhNavigationTasks.verifyHHMovesMoveMemberBetweenTwoHouseholds();
		*//**Search and Select Two Customers and Click on Next link.*//*
		combineTasks.verifyAndSearchandSelectTwoCustomersPage();
		*//**Navigate to Customer Combine screen using the CUSTOMER menu option and combine two customers.*//*
		combineTasks.verifyInfoandClickCombine();*/
		/**Launch HH Page after the 'Combine Customer'*/
		/**CASL US Scenarios Tc23-Tc24*/
		//productTasks.verifyEmessageafterCombine();
		//scenarioTasks.clickHHPageCustomer();
		
	}
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentCreateIndCustScenario10(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);				
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
			}
		}
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}


