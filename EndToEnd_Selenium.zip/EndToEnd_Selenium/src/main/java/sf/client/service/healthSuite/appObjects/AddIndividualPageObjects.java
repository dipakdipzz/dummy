package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

/**
 * This class contains all the page objects related to Add Individual Page
 */
public class AddIndividualPageObjects {
	
	private static final String ADDINDIVIDUAL_TEXTFIELD_FIRSTNAME = "id=fname0";
	private static final String ADDINDIVIDUAL_TEXTFIELD_LASTNAME = "id=lname0";
	private static final String ADDINDIVIDUAL_TEXTFIELD_SSN = "id=ssn0";
	private static final String ADDINDIVIDUAL_TEXTFIELD_SIN = "id=sin0";
	private static final String ADDINDIVIDUAL_CHECKBOX_MAILINGUSAGE = "name=mailingUsage";
	private static final String ADDINDIVIDUAL_RADIOBUTTON_US = "id=address.typeUS";
	private static final String ADDINDIVIDUAL_RADIOBUTTON_CANADA = "value=Canada";
	private static final String ADDINDIVIDUAL_RADIOBUTTON_FOREIGN = "value=Foreign";
	private static final String ADDINDIVIDUAL_RADIOBUTTON_MILITARY = "value=Military";
	private static final String ADDINDIVIDUAL_TEXTFIELD_ADDADDRESSSTREET = "id=street1";
	private static final String ADDINDIVIDUAL_TEXTFIELD_ADDADDRESSSCITY = "id=city";
	private static final String ADDINDIVIDUAL_TEXTFIELD_ADDADDRESSSZIP = "id=zip";
	private static final String ADDINDIVIDUAL_LISTBOX_ADDADDRESSSSTATE = "id=stateComboId";
	private static final String ADDINDIVIDUAL_BUTTON_ADDADDRESSSSAVE= "id=addrStdButton";
	private static final String ADDINDIVIDUAL_CHECKBOX_ADDRESSES0 = "name=addresschkBox00";
	private static final String ADDINDIVIDUAL_BUTTON_SAVE= "id=save";
	private static final String ADDINDIVIDUAL_TEXTFIELD_ORGANIZATIONNAME = "id=orgname0";
	private static final String ADDINDIVIDUAL_BUTTON_CREATEMEMBERSAVE = "id=save";
	private static final String ADDINDIVIDUAL_TEXTFIELD_EMAILADDRESSES = "id=person.emails[0].address";
	private static final String ADDINDIVIDUAL_LISTBOX_PHONE_TYPE = "id=phone.phonePurpose";
	private static final String ADDINDIVIDUAL_BUTTON_HHADDADDRESS= "text=Add Address";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final TextField TEXT_FIRSTNAME = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_FIRSTNAME);
		public static final TextField TEXT_LASTNAME = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_LASTNAME);
		public static final TextField TEXT_SSN = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_SSN);
		public static final TextField TEXT_SIN = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_SIN);
		public static final CheckBox CHECKBOX_MAILINGUSAGE = new CheckBox(
				ADDINDIVIDUAL_CHECKBOX_MAILINGUSAGE);
		public static final RadioButton RADIO_US = new RadioButton(
				ADDINDIVIDUAL_RADIOBUTTON_US);
		public static final RadioButton RADIO_CANADA = new RadioButton(
				ADDINDIVIDUAL_RADIOBUTTON_CANADA);
		public static final RadioButton RADIO_FOREIGN = new RadioButton(
				ADDINDIVIDUAL_RADIOBUTTON_FOREIGN);
		public static final RadioButton RADIO_MILITARY = new RadioButton(
				ADDINDIVIDUAL_RADIOBUTTON_MILITARY);
		public static final TextField TEXT_ADDADDRESSSTREET = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_ADDADDRESSSTREET);
		public static final TextField TEXT_ADDADDRESSSCITY = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_ADDADDRESSSCITY);
		public static final TextField TEXT_ADDADDRESSSZIP = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_ADDADDRESSSZIP);
		public static final ListBox LIST_ADDADDRESSSSTATE = new ListBox(
				ADDINDIVIDUAL_LISTBOX_ADDADDRESSSSTATE);
		public static final Button BUTTON_ADDADDRESSSSAVE = new Button(
				ADDINDIVIDUAL_BUTTON_ADDADDRESSSSAVE);
		public static final CheckBox CHECKBOX_ADDRESSES0 = new CheckBox(
				ADDINDIVIDUAL_CHECKBOX_ADDRESSES0);
		public static final Button BUTTON_SAVE = new Button(
				ADDINDIVIDUAL_BUTTON_SAVE);
		public static final TextField ORGANIZATIONNAME = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_ORGANIZATIONNAME);
		public static final Button BUTTON_CREATEMEMBERSAVE = new Button(
				ADDINDIVIDUAL_BUTTON_CREATEMEMBERSAVE);
		public static final TextField TEXT_EMAILADDRESSES = new TextField(
				ADDINDIVIDUAL_TEXTFIELD_EMAILADDRESSES);
		public static final ListBox LIST_PHONE_TYPE = new ListBox(
				ADDINDIVIDUAL_LISTBOX_PHONE_TYPE);
		public static final Span BUTTON_HHADDADDRESS = new Span(
				ADDINDIVIDUAL_BUTTON_HHADDADDRESS);
	}
}