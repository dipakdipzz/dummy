package sf.client.service.common.helpers;

import java.io.Serializable;
import java.sql.ResultSet;

public interface ITransferObject extends Serializable {

	public String getTestcaseName();

	public void setTestcaseName(String testcaseName);

	/**
	 * @return the failCount
	 */
	public int getFailCount();

	/**
	 * @param failCount
	 *            the failCount to set
	 */
	public void setFailCount(int failCount);

	/**
	 * @return the imageCount
	 */
	public int getImageCount();

	/**
	 * @param imageCount
	 *            the imageCount to set
	 */
	public void setImageCount(int imageCount);

	/**
	 * @return the resultFileName
	 */
	public String getResultFileName();

	/**
	 * @param resultFileName
	 *            the resultFileName to set
	 */
	public void setResultFileName(String resultFileName);

	public String getUserAlias();

	public void setUserAlias(String userAlias);

	public String getDbFileName();

	public void setDbFileName(String dbFileName);

	public String getDbFilePath();

	public void setDbFilePath(String dbFilePath);

	public String getDbQuery();

	public void setDbQuery(String dbQuery);

	public String getDbTableName();

	public void setDbTableName(String dbTableName);

	public ResultSet getDbResultSet();

	public void setDbResultSet(ResultSet dbResultSet);

	public String getDomain();

	public void setDomain(String domain);

	public String getPassword();

	public void setPassword(String password);

	public String getUrl();

	public void setUrl(String url);

	public String getUserID();

	public void setUserID(String userID);

	public String getBussinessRole();

	public void setBussinessRole(String bussinessRole);

	/**
	 * @return the resulFilePath
	 */
	public String getResultFilePath();

	/**
	 * @param resulFilePath
	 *            the resulFilePath to set
	 */
	public void setResultFilePath(String resultFilePath);

	/**
	 * @return the db2DatabaseName
	 */
	public String getDb2DatabaseName();

	/**
	 * @param db2DatabaseName
	 *            the db2DatabaseName to set
	 */
	public void setDb2DatabaseName(String db2DatabaseName);

	/**
	 * @return the db2Password
	 */
	public String getDb2Password();

	/**
	 * @param db2Password
	 *            the db2Password to set
	 */
	public void setDb2Password(String db2Password);

	/**
	 * @return the db2PortNumber
	 */
	public String getDb2PortNumber();

	/**
	 * @param db2PortNumber
	 *            the db2PortNumber to set
	 */
	public void setDb2PortNumber(String db2PortNumber);

	/**
	 * @return the db2User
	 */
	public String getDb2User();

	/**
	 * @param db2User
	 *            the db2User to set
	 */
	public void setDb2User(String db2User);

	public String getDb2Query();

	/**
	 * @param db2Query
	 *            the db2Query to set
	 */
	public void setDb2Query(String db2Query);

	/**
	 * @return the db2InfoTableName
	 */
	public String getDb2InfoTableName();

	/**
	 * @param db2InfoTableName
	 *            the db2InfoTableName to set
	 */
	public void setDb2InfoTableName(String db2InfoTableName);

	public void setActualResult(String actualResult);

	public String getActualResult();

	public void setResultStatus(boolean resultStatus);

	public boolean getResultStatus();

}
