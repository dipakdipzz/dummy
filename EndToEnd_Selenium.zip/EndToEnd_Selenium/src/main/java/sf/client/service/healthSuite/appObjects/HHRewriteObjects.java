package sf.client.service.healthSuite.appObjects;

import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.Span;


public class HHRewriteObjects {
	
	private static final String LINK_ASSIGNED_STAFF = "id=linkStaffName";
	private static final String SPAN_ASSIGNED_STAFF_SAVE = "id=assignStaffSave_label";
	private static final String LINK_CLIENT_NAME = "id=lblClientName";
	private static final String SPAN_CLOSE = "text=Close";
	private static final String DIV_BANK_TAB = "id=policyTabContainer_tablist_tempBankGrid";
	private static final String DIV_EMPTY_BANK_TAB = "id=policyTabContainer_tablist_emptyBankDiv";
	private static final String DIV_MUTUAL_FUND_TAB = "id=policyTabContainer_tablist_tempMutualFundGrid";
	private static final String LINK_PRODUCTION_MANAGER = "text=Production Manager*";
	private static final String DIV_PRODUCTS_OTHER_TAB = "id=policyTabContainer_tablist_tempOtherCompanyGrid";
	private static final String DIV_OTHER_COMPANY_GRID = "id=tempOtherCompanyGrid";
	private static final String LINK_HOUSEHOLD_TAB = "text=Household";
	private static final String LINK_RELATIONSHIPS = "text=Relationships";
	private static final String DIV_NECHO = "id=NECHO_DIV";
	private static final String DIV_MUTUALFUND_GRID = "id=gridMutualFund";
	private static final String DIV_BANK_GRID = "id=gridBank";
	private static final String DIV_EMPTY_MUTUALFUND = "id=policyTabContainer_tablist_emptyMutualFundDiv"; 
	
	private static final String LINK_PRODUCT_ACTIONS = "text=Product Actions";
	private static final String LINK_ADD_PRODUCT_WITH_OTHERS = "text=Add Products with Others";
	
	public static class WidgetInfos {		//CHANGED THE CLASS NAME FROM Wdgt TO WidgetInfos
		public static final Link ASSIGNEDSTAFF = new Link(LINK_ASSIGNED_STAFF);//case changed
		public static final Span ASGNDSTFSAVE = new Span(SPAN_ASSIGNED_STAFF_SAVE);//case changed
		public static final Link CLIENTNAME = new Link(LINK_CLIENT_NAME);//case changed
		public static final Span CLOSE_ACCPOLPAGE = new Span(SPAN_CLOSE);//case changed
		public static final Link HHCUSTOMERTAB = new Link("text=Customer");
		public static final Link HHCUSTOME_PROFILE_PRINT = new Link("text=Customer Profile Print");
		//public static final String HHCUSTOMERTAB = "text=Customer";//case changed
		public static final Link HHCUSTOMERINFORMATION = new Link("text=Customer Information");
		//public static final String HHCUSTOMERINFORMATION = "text=Customer Information";//case changed
		public static final Div BANKTAB = new Div(DIV_BANK_TAB);//case changed
		public static final Div EMPTYBANKTAB = new Div(DIV_EMPTY_BANK_TAB);//case changed
		public static final Div MUTUALFUNDTAB = new Div(DIV_MUTUAL_FUND_TAB);//case changed
		public static final Link PRODUCTIONMANAGER = new Link(LINK_PRODUCTION_MANAGER);//case changed
		public static final Div PRODUCTSWITHOTHERSTAB = new Div(DIV_PRODUCTS_OTHER_TAB);//case changed
		public static final Div GRIDPRODUCTSWITHOTHERS = new Div(DIV_OTHER_COMPANY_GRID);//case changed
		public static final Link HHHOUSEHOLDTAB = new Link(LINK_HOUSEHOLD_TAB);//case changed
		public static final Link HHHOUSEHOLDTAB_POLICYLISTING = new Link("text=Policy Listing Print");//case changed
		public static final Link HHHOUSEHOLDRELATIONSHIPS = new Link(LINK_RELATIONSHIPS);//case changed
		public static final Div NECHOSCREEN = new Div(DIV_NECHO);//case changed
		public static final Div GRIDMUTUALFUNDS = new Div(DIV_MUTUALFUND_GRID);//case changed
		public static final Div GRIDBANK = new Div(DIV_BANK_GRID);//case changed
		public static final Div MUTUALFUNDTAB_EMPTY_NEW = new Div(DIV_EMPTY_MUTUALFUND);
		
		public static final Link PRODUCT_ACTIONS = new Link(LINK_PRODUCT_ACTIONS);
		public static final Link ADD_PRODUCT_WITH_OTHERS = new Link(LINK_ADD_PRODUCT_WITH_OTHERS);
	}
}
