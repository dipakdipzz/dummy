package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class Agent_Scenario31 extends BaseScript {

	int count = 0;
	String query = "select * from Agent_Scenario31";

	public void executeScript(String custType) throws Exception {
		if (createCustTasks.isAgentBusinessSystemExist()) {
			createCustTasks.clickCustomer();
			createCustTasks.launchPortalCustomerSearchPage();
			createCustTasks.launchPortalHHPage();
			createCustTasks.validateUSSSNCNSINDriversLicenseCustomerInfo(custType);
			} else {
			createCustTasks.appendToResultFile(false,
					"Agent Business System Page Not Launched");
		}
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataAgentScenario31(
						dbresultSet, clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				createCustTasks.createResultsFile(resultsFileName(),
						scriptName());
				String custType = clientE2ETO.getCustomerType();
				count++;
				System.out.println("-------count---------" + count);
				executeScript(custType);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
