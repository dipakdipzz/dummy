package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

public class CreateOrganizationCustomerAppObj {

	/*
	 * public static final Button BUTTON_OK = new Button("id=ok"); public static
	 * final TextField TEXT_HHORGANIZATIONNAME = new TextField(
	 * "name=*.householdMemberOrg.householdMemberOrgName.orgName"); public
	 * static final RadioButton RADIOBUTTON_MUS = new RadioButton(
	 * "id=organization.addresses[0].typeUS"); public static final TextField
	 * TEXT_MSTREET1 = new TextField( "id=organization.addresses[0].street1");
	 * public static final TextField TEXT_MCITY = new TextField(
	 * "id=organization.addresses[0].city"); public static final TextField
	 * TEXT_MZIPANDPOSTAL = new TextField(
	 * "id=organization.addresses[0].zipPostalCode"); public static final
	 * TextField TEXT_SSN = new TextField( "name=householdMembers[0].tin");
	 * public static final TextField TEXT_ORGANIZATIONNAME = new TextField(
	 * "id=organization.bestName.name"); public static final Button
	 * BUTTON_CREATEMEMBERSAVE = new Button("id=save"); public static final
	 * TextField TEXT_TAXIDNUMBER = new TextField(
	 * "id=organization.tin.number"); public static final ListBox
	 * LIST_CELLCALLINGPREFERENCEDAY = new ListBox(
	 * "name=organization.phones[0].phoneAvailability"); public static final
	 * ListBox LIST_CELLFROMTIME = new ListBox(
	 * "name=organization.phones[0].availabilityStartTime"); public static final
	 * ListBox LIST_CELLTOTIME = new ListBox(
	 * "name=organization.phones[0].availabilityEndTime"); public static final
	 * ListBox LIST_FAXCALLINGPREFERENCEDAY = new ListBox(
	 * "name=organization.phones[2].phoneAvailability"); public static final
	 * ListBox LIST_FAXFROMTIME = new ListBox(
	 * "name=organization.phones[2].availabilityStartTime"); public static final
	 * ListBox LIST_FAXTOTIME = new ListBox(
	 * "name=organization.phones[2].availabilityEndTime"); public static final
	 * ListBox LIST_ADDITIONALCALLINGPREFERENCEDAY = new ListBox(
	 * "name=organization.phones[3].phoneAvailability"); public static final
	 * ListBox LIST_ADDITIONALFROMTIME = new ListBox(
	 * "name=organization.phones[3].availabilityStartTime"); public static final
	 * ListBox LIST_ADDITIONALTOTIME = new ListBox(
	 * "name=organization.phones[3].availabilityEndTime"); public static final
	 * TextField TEXT_BUSINESSPHONENUM = new TextField(
	 * "id=organization.phones[1].number"); public static final TextField
	 * TEXT_FAXPHONENUM = new TextField( "id=organization.phones[2].number");
	 * public static final TextField TEXT_ADDITIONALPHONENUM = new TextField(
	 * "id=organization.phones[3].number"); public static final RadioButton
	 * RADIOBUTTON_PUBLISHEMAIL = new RadioButton(
	 * "id=organization.emails[0].marketingIndicatorYes"); public static final
	 * CheckBox CHECKBOX_KEEPNONSTANDARD = new CheckBox( "id=keepNonStandard");
	 * public static final Link LINK_CREATEORGANIZATION = new Link(
	 * "text=Create Organization"); public static final CheckBox
	 * CHECKBOX_MAILINGUSAGE = new CheckBox( "name=mailingUsage"); public static
	 * final TextField TEXT_ADDADDRESSSTREET = new TextField( "id=street1");
	 * public static final TextField TEXT_ADDADDRESSCITY = new
	 * TextField("id=city"); public static final TextField TEXT_ADDADDRESSZIP =
	 * new TextField("id=zip"); public static final Button BUTTON_ADDADDRESSSAVE
	 * = new Button( "id=addrStdButton"); public static final Button
	 * BUTTON_ADDADDITIONALIND = new Button( "id=addIndividual"); public static
	 * final TextField TEXT_ORGEMAILADDRESS = new TextField(
	 * "id=organization.emails[0].address"); public static final TextField
	 * TEXT_HEARABOUTOFFICE = new TextField(
	 * "id=organization.agent.hearAboutOfficeCode"); public static final
	 * TextField TEXT_MOSTIMPORTANTTOYOU = new TextField(
	 * "id=organization.agent.agentMarketingInfo.importanceFactorCode"); public
	 * static final Span SPAN_ADDADDRESSES = new Span( "id=plusAddressButton*");
	 * public static final Span BUTTON_TAB_ADDADDITIONALORG = new Span(
	 * "id=orgButton"); public static final TextField TEXT_MOBILEPHONENUM = new
	 * TextField( "id=organization.phones[0].number"); public static final
	 * CheckBox FAX_MONDAY = new CheckBox(
	 * "id=organization.phones[2].availableMon"); public static final CheckBox
	 * FAX_SUNDAY = new CheckBox( "id=organization.phones[2].availableSun");
	 * public static final CheckBox FAX_TUESDAY = new CheckBox(
	 * "id=organization.phones[2].availableTue"); public static final CheckBox
	 * FAX_WEDNESDAY = new CheckBox( "id=organization.phones[2].availableWed");
	 * public static final CheckBox FAX_THURSDAY = new CheckBox(
	 * "id=organization.phones[2].availableThu"); public static final CheckBox
	 * FAX_FRIDAY = new CheckBox( "id=organization.phones[2].availableFri");
	 * public static final CheckBox FAX_SATURDAY = new CheckBox(
	 * "id=organization.phones[2].availableSat"); public static final Link
	 * LINK_MOBILE_CALLING_PREFERENCE = new Link(
	 * "onclick=*mobileCallingPrefLabelDiv*"); public static final Link
	 * LINK_FAX_CALLING_PREFERENCE = new Link(
	 * "onclick=*faxCallingPrefLabelDiv*"); public static final Link
	 * LINK_ADDLTYPE_CALLING_PREFERENCE = new Link(
	 * "onclick=*additionalCallingPrefLabelDiv*"); public static final Link
	 * LINK_CREATEORGCUSTOMER = new Link( "text=Create organization customer");
	 * public static final TextField TEXT_AGENTCODE = new
	 * TextField("id=stAgtCode"); public static final Link
	 * LINK_CREATEORGANIZATIONCUSTOMER = new Link(
	 * "text=Create organization customer"); public static final TextField
	 * TEXT_HHADDITIONALORGANIZATIONNAME = new TextField( "id=orgname*"); public
	 * static final TextField STATE_AGENT_CODE= new
	 * TextField("id=txtAgentCode");
	 */
	// Constants related WidgetInfo class
	public static final String BUTTON_OK_ID = "id=okB";
	public static final String TEXTFIELD_ORG_BESTNAME = "id=organization.bestName.name";
	public static final String TEXTFIELD_HH_TIN = "name=householdMembers[0].tin";
	public static final String TEXTFIELD_ORG_FIRSTADDRESS_POSTALCODE = "id=organization.addresses[0].zipPostalCode";
	public static final String TEXTFIELD_ORG_FIRSTADDRESS_CITY = "id=organization.addresses[0].city";
	public static final String TEXTFIELD_ORG_FIRSTADDRESS_STREET = "id=organization.addresses[0].street1";
	public static final String RADIOBUTTON_ORG_FIRSTADDRESS_USTYPE = "id=organization.addresses[0].typeUS";
	public static final String BUTTON_SAVE_ID = "id=save";
	public static final String TEXTFIELD_ORG_TINNUMBER = "id=organization.tin.number";
	public static final String LISTBOX_ORG_FIRSTPHONEAVAILABILITY = "name=organization.phones[0].phoneAvailability";
	public static final String LISTBOX_ORG_FIRST_AVAILABILITYSTARTTIME = "name=organization.phones[0].availabilityStartTime";
	public static final String LISTBOX_ORG_FIRST_AVAILABILITYENDTIME = "name=organization.phones[0].availabilityEndTime";
	public static final String LISTBOX_ORG_THIRDPHONEAVAILABILITY = "name=organization.phones[2].phoneAvailability";
	public static final String LISTBOX_ORG_THIRDPHONE_AVAILABILITYSTARTTIME = "name=organization.phones[2].availabilityStartTime";
	public static final String LISTBOX_ORG_THIRDPHONE_AVAILABILITYENDTIME = "name=organization.phones[2].availabilityEndTime";
	public static final String LISTBOX_ORG_FOURTHPHONEAVAILABILITY = "name=organization.phones[3].phoneAvailability";
	public static final String LISTBOX_ORG_FOURTHPHONE_AVAILABILITYSTARTTIME = "name=organization.phones[3].availabilityStartTime";
	public static final String LISTBOX_ORG_FOURTHPHONE_AVAILABILITYENDTIME = "name=organization.phones[3].availabilityEndTime";
	public static final String TEXTFIELD_ORG_SECONDPHONE = "id=organization.phones[1].number";
	public static final String TEXTFIELD_ORG_THIRDPHONE = "id=organization.phones[2].number";
	public static final String TEXTFIELD_ORG_FOURTHPHONE = "id=organization.phones[3].number";
	public static final String RADIOBUTTON_ORG_MARKETINGINDICATORYES = "id=organization.emails[0].marketingIndicatorYes";
	public static final String CHECKBOX_KEEPNONSTANDARD_ID = "id=keepNonStandard";
	public static final String LINK_CREATEORGANIZATION_TEXT = "text=Create Organization";
	public static final String CHECKBOX_MAILINGUSAGE_NAME = "id=mailingUsage";
	public static final String TEXT_ADDADDRESSSTREET_ID = "id=street1";
	public static final String TEXT_ADDADDRESSCITY_ID = "id=city";
	public static final String TEXT_ADDADDRESSZIP_ID = "id=zip";
	public static final String BUTTON_ADDADDRESSSAVE_ID = "id=addrStdButton";
	public static final String BUTTON_ADDINDIVIDUAL_ID = "id=addIndividual";
	public static final String TEXTFIELD_ORGEMAILADDRESS = "id=organization.emails[0].address";
	public static final String TEXTFIELD_HEARABOUTOFFICE = "id=organization.agent.hearAboutOfficeCode";
	public static final String TEXTFIELD_MOSTIMPORTANTTOYOU = "id=organization.agent.agentMarketingInfo.importanceFactorCode";
	public static final String SPAN_ADDADDRESSES_ID = "id=plusAddressButton*";
	public static final String BUTTON_TAB_ADDADDITIONALORG_ID = "id=orgButton";
	public static final String TEXT_MOBILEPHONENUM_ID = "id=organization.phones[0].number";
	public static final String CHECKBOX_FAX_MONDAY_ID = "id=organization.phones[2].availableMon";
	public static final String CHECKBOX_FAX_SUNDAY_ID = "id=organization.phones[2].availableSun";
	public static final String CHECKBOX_FAX_TUESDAY_ID = "id=organization.phones[2].availableTue";
	public static final String CHECKBOX_FAX_WEDNESDAY_ID = "id=organization.phones[2].availableWed";
	public static final String CHECKBOX_FAX_THURSDAY_ID = "id=organization.phones[2].availableThu";
	public static final String CHECKBOX_FAX_FRIDAY_ID = "id=organization.phones[2].availableFri";
	public static final String CHECKBOX_FAX_SATURDAY_ID = "id=organization.phones[2].availableSat";
	public static final String LINK_MOBILECALLINGPREFERENCE_METHOD = "onclick=*mobileCallingPrefLabelDiv*";
	public static final String LINK_FAXCALLINGPREFERENCE_METHOD = "onclick=*faxCallingPrefLabelDiv*";
	public static final String LINK_ADDLTYPECALLINGPREFERENCE_METHOD = "onclick=*additionalCallingPrefLabelDiv*";
	public static final String LINK_CREATEORGCUSTOMER_TEXT = "text=Create organization customer";
	public static final String TEXTFIELD_AGENTCODE = "id=stAgtCode";
	public static final String LINK_CREATEORGANIZATIONCUSTOMER_TEXT = "text=Create organization customer";
	public static final String TEXTFIELD_HHADDITIONALORGANIZATIONNAME = "id=orgname1";
	public static final String STATE_AGENT_CODE_ID = "id=txtAgentCode";
	public static final String TEXTFIELD_HHORGNAME = "id=pageHeading";

	@WidgetIDs
	public static class WidgetInfos {
		public static final Button BUTTON_OK = new Button(BUTTON_OK_ID);
		public static final TextField TEXT_HHORGANIZATIONNAME = new TextField(
				TEXTFIELD_HHORGNAME);
		public static final RadioButton RADIOBUTTON_MUS = new RadioButton(
				RADIOBUTTON_ORG_FIRSTADDRESS_USTYPE);
		public static final TextField TEXT_MSTREET1 = new TextField(
				TEXTFIELD_ORG_FIRSTADDRESS_STREET);
		public static final TextField TEXT_MCITY = new TextField(
				TEXTFIELD_ORG_FIRSTADDRESS_CITY);
		public static final TextField TEXT_MZIPANDPOSTAL = new TextField(
				TEXTFIELD_ORG_FIRSTADDRESS_POSTALCODE);
		public static final TextField TEXT_SSN = new TextField(TEXTFIELD_HH_TIN);
		public static final Button BUTTON_CREATEMEMBERSAVE = new Button(
				BUTTON_SAVE_ID);
		public static final TextField TEXT_TAXIDNUMBER = new TextField(
				TEXTFIELD_ORG_TINNUMBER);
		public static final ListBox LIST_CELLCALLINGPREFERENCEDAY = new ListBox(
				LISTBOX_ORG_FIRSTPHONEAVAILABILITY);
		public static final ListBox LIST_CELLFROMTIME = new ListBox(
				LISTBOX_ORG_FIRST_AVAILABILITYSTARTTIME);
		public static final ListBox LIST_CELLTOTIME = new ListBox(
				LISTBOX_ORG_FIRST_AVAILABILITYENDTIME);
		public static final ListBox LIST_FAXCALLINGPREFERENCEDAY = new ListBox(
				LISTBOX_ORG_THIRDPHONEAVAILABILITY);
		public static final ListBox LIST_FAXFROMTIME = new ListBox(
				LISTBOX_ORG_THIRDPHONE_AVAILABILITYSTARTTIME);
		public static final ListBox LIST_FAXTOTIME = new ListBox(
				LISTBOX_ORG_THIRDPHONE_AVAILABILITYENDTIME);
		public static final ListBox LIST_ADDITIONALCALLINGPREFERENCEDAY = new ListBox(
				LISTBOX_ORG_FOURTHPHONEAVAILABILITY);
		public static final ListBox LIST_ADDITIONALFROMTIME = new ListBox(
				LISTBOX_ORG_FOURTHPHONE_AVAILABILITYSTARTTIME);
		public static final ListBox LIST_ADDITIONALTOTIME = new ListBox(
				LISTBOX_ORG_FOURTHPHONE_AVAILABILITYENDTIME);
		public static final TextField TEXT_BUSINESSPHONENUM = new TextField(
				TEXTFIELD_ORG_SECONDPHONE);
		public static final TextField TEXT_FAXPHONENUM = new TextField(
				TEXTFIELD_ORG_THIRDPHONE);
		public static final TextField TEXT_ADDITIONALPHONENUM = new TextField(
				TEXTFIELD_ORG_FOURTHPHONE);
		public static final RadioButton RADIOBUTTON_PUBLISHEMAIL = new RadioButton(
				RADIOBUTTON_ORG_MARKETINGINDICATORYES);
		public static final CheckBox CHECKBOX_KEEPNONSTANDARD = new CheckBox(
				CHECKBOX_KEEPNONSTANDARD_ID);
		public static final Link LINK_CREATEORGANIZATION = new Link(
				LINK_CREATEORGANIZATION_TEXT);
		public static final CheckBox CHECKBOX_MAILINGUSAGE = new CheckBox(
				CHECKBOX_MAILINGUSAGE_NAME);
		public static final TextField TEXT_ADDADDRESSSTREET = new TextField(
				TEXT_ADDADDRESSSTREET_ID);
		public static final TextField TEXT_ADDADDRESSCITY = new TextField(
				TEXT_ADDADDRESSCITY_ID);
		public static final TextField TEXT_ADDADDRESSZIP = new TextField(
				TEXT_ADDADDRESSZIP_ID);
		public static final Button BUTTON_ADDADDRESSSAVE = new Button(
				BUTTON_ADDADDRESSSAVE_ID);
		public static final Button BUTTON_ADDADDITIONALIND = new Button(
				BUTTON_ADDINDIVIDUAL_ID);
		public static final TextField TEXT_ORGEMAILADDRESS = new TextField(
				TEXTFIELD_ORGEMAILADDRESS);
		public static final TextField TEXT_HEARABOUTOFFICE = new TextField(
				TEXTFIELD_HEARABOUTOFFICE);
		public static final TextField TEXT_MOSTIMPORTANTTOYOU = new TextField(
				TEXTFIELD_MOSTIMPORTANTTOYOU);
		public static final Span SPAN_ADDADDRESSES = new Span(
				SPAN_ADDADDRESSES_ID);
		public static final Span BUTTON_TAB_ADDADDITIONALORG = new Span(
				BUTTON_TAB_ADDADDITIONALORG_ID);
		public static final TextField TEXT_MOBILEPHONENUM = new TextField(
				TEXT_MOBILEPHONENUM_ID);
		public static final CheckBox FAX_MONDAY = new CheckBox(
				CHECKBOX_FAX_MONDAY_ID);
		public static final CheckBox FAX_SUNDAY = new CheckBox(
				CHECKBOX_FAX_SUNDAY_ID);
		public static final CheckBox FAX_TUESDAY = new CheckBox(
				CHECKBOX_FAX_TUESDAY_ID);
		public static final CheckBox FAX_WEDNESDAY = new CheckBox(
				CHECKBOX_FAX_WEDNESDAY_ID);
		public static final CheckBox FAX_THURSDAY = new CheckBox(
				CHECKBOX_FAX_THURSDAY_ID);
		public static final CheckBox FAX_FRIDAY = new CheckBox(
				CHECKBOX_FAX_FRIDAY_ID);
		public static final CheckBox FAX_SATURDAY = new CheckBox(
				CHECKBOX_FAX_SATURDAY_ID);
		public static final Link LINK_MOBILE_CALLING_PREFERENCE = new Link(
				LINK_MOBILECALLINGPREFERENCE_METHOD);
		public static final Link LINK_FAX_CALLING_PREFERENCE = new Link(
				LINK_FAXCALLINGPREFERENCE_METHOD);
		public static final Link LINK_ADDLTYPE_CALLING_PREFERENCE = new Link(
				LINK_ADDLTYPECALLINGPREFERENCE_METHOD);
		public static final Link LINK_CREATEORGCUSTOMER = new Link(
				LINK_CREATEORGCUSTOMER_TEXT);
		public static final TextField TEXT_AGENTCODE = new TextField(
				TEXTFIELD_AGENTCODE);
		public static final Link LINK_CREATEORGANIZATIONCUSTOMER = new Link(
				LINK_CREATEORGANIZATIONCUSTOMER_TEXT);
		public static final TextField TEXT_HHADDITIONALORGANIZATIONNAME = new TextField(
				TEXTFIELD_HHADDITIONALORGANIZATIONNAME);
		// kp2j
		public static final TextField TEXT_HHADDITIONALORGANIZATIONTYPE = new TextField(
				"id=orgname0");
		public static final TextField STATE_AGENT_CODE = new TextField(
				STATE_AGENT_CODE_ID);

		public static final TextField TEXTFIELD_ORG_NAME = new TextField(
				TEXTFIELD_ORG_BESTNAME);
		public static final TextField TEXT_ORGNAME = new TextField(
				TEXTFIELD_ORG_BESTNAME);

		public static final Div TEXT_ORGANIZATIONNAME = new Div(
				TEXTFIELD_HHORGNAME);
	}

}
