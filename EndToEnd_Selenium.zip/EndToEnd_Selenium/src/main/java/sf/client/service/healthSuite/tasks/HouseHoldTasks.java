package sf.client.service.healthSuite.tasks;

import static sf.client.service.healthSuite.appObjects.HHRewriteObjects.WidgetInfos.NECHOSCREEN;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.common.appObjects.ABSPortalTestObjects;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.common.tasks.EndToEndCommonTasks;
import sf.client.service.healthSuite.appObjects.AddIndividualPageObjects;
import sf.client.service.healthSuite.appObjects.CWNonAgentCSObjects;
import sf.client.service.healthSuite.appObjects.ConflictCustomerInfoAppObj;
import sf.client.service.healthSuite.appObjects.CreateIndividualCustomer;
import sf.client.service.healthSuite.appObjects.CreateOrganizationCustomerAppObj;
import sf.client.service.healthSuite.appObjects.CustomerInfoObjects;
import sf.client.service.healthSuite.appObjects.CustomerMaintenanceAppObj;
import sf.client.service.healthSuite.appObjects.CustomerSeparateAppObj;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.PresentationKitPopupObjects;
import sf.client.service.healthSuite.appObjects.RelationshipsScreenTestObjects;
import sf.client.service.healthSuite.appObjects.ReviewDatePopupObjects;
import sf.client.service.healthSuite.appObjects.SSNSINObjects;
import sf.client.service.healthSuite.appObjects.SearchSelectCustomerAppObj;
import sf.client.service.healthSuite.appObjects.Update_IND_CustomerInfo_PageObjects;
import sf.client.service.healthSuite.appObjects.Update_Misc_Objects;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.wat.util.KeyboardUtility;
import statefarm.widget.WidgetInfo;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;
import statefarm.widget.manager.Verify;
import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.SeleniumException;

public class HouseHoldTasks extends EndToEndCommonTasks {

	public HouseHoldTasks() {
	}

	public HouseHoldTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}
	/**
	 * 
	 * Verify Page is Error
	 * @param title
	 * @return
	 * @throws ScriptException
	 */

	public boolean isErrorPage(String title) {
		Span CLICK_CLOSE = new Span("title=Cancel");
		Div CIMS_ERROR = new Div("id=displayError");
		Button CLOSE_BUTTON = new Button("id=closeButton");
		String text = "";
		waitForPageLoad(CIMS_ERROR, 5);
		boolean flag = false;
		try {
			text = getWebDriverInstance().getTitle();
			if (text.contains("Error") || CIMS_ERROR.exists()
					|| CLOSE_BUTTON.exists() || text.contains("Not Found")) {
				CheckBox ERROR = new CheckBox("id=check");
				if (ERROR.exists()) {
					ERROR.click();
				}
				if (CLICK_CLOSE.exists()) {
					CLICK_CLOSE.click();
					WebElement reviewDates = getWebDriverInstance()
							.findElement(
									By.cssSelector("div[\"title=Add Review Dates\"] span:nth-child(2)"));
					if (reviewDates.isDisplayed()) {
						reviewDates.click();
					}
				}
				Verify.verifyTrue(false, title + " is not Success");
				flag = true;
			}
		} catch (SeleniumException seleniumException) {
			Verify.verifyTrue(false, seleniumException.getMessage());
		}  catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
		return flag;
	}

    /**
     * Closing Current Page
     */
	public void closeCurrentPage() {
		getWebDriverInstance().close();
		
	}
    /**
     * launching Customer Search Page
     */
	public void launchCustomerSeachPage() {
		try {
			waitForTime(10);
			KeyboardUtility.sendKeys("{ESC}");
			waitForTime(10);
			KeyboardUtility.sendKeys("{ESC}");
			waitForTime(10);
			KeyboardUtility.sendKeys("{ESC}");
			if (isAgentBusinessSystemExist()) {
				browser.getActiveWindow().maximize();
				
				clickCustomer();
			} else {
				Verify.verifyTrue(false, MessageUtility.ABSPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
    /**
     * Verify Portal Search Page is Launched Or Not
     * @throws ScriptException
     */
	public void isPortalSearchPageLaunchedOrNot() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 20);
		if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME.exists()) {
			Verify.verifyTrue(true, MessageUtility.CUSTSEARCH_PORTAL);
		} else {
			Verify.verifyTrue(false, MessageUtility.CUSTSEARCH_PORTAL_NOTLAUNCHED);
		}
	}
    /**
     * Verify Customer Search Page is Launched Or Not
     * @throws ScriptException
     */
	public void isCustomerSearchPageLaunchedOrNot() throws ScriptException {
		
		setChildWindow(2);
		waitForPageLoad(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ORGANIZATION_SEARCH);
		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ORGANIZATION_SEARCH.exists()) {

			Verify.verifyTrue(true,
					MessageUtility.CUSTOMERSEARCHPAGE);
		}

		else {
			Verify.verifyTrue(false, MessageUtility.CUSTOMERSEARCHPAGE_NOTLAUNCHED);
		}

	}
    /**
     * Verify Portal Customer Search Page is Launched Or Not
     * @throws ScriptException
     */
	public void isPortalCustomerSearchPageLaunchedOrNot()
			throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 20);
		if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CUSTSEARCH_PORTAL);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTSEARCH_PORTAL_NOTLAUNCHED);
		}
	}
    /**
     * click Portal Clear Button Search Page
     * @throws ScriptException
     */
	public void clickPortalClearButtonSearchPage() throws ScriptException {
		if (ABSPortalTestObjects.WidgetInfos.BUTTON_CLEAR.exists()) {
			ABSPortalTestObjects.WidgetInfos.BUTTON_CLEAR.click();
			Verify.verifyTrue(true, MessageUtility.BUTTON_CLEAR);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_CLEAR_NOTFOUND);
		}
	}
    /**
     * click Name Radio Button Search Page
     * @throws ScriptException
     */
	public void clickNameRadioButtonSearchPage() throws ScriptException {
		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_SEARCH_NAME.exists()) {
			click(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_SEARCH_NAME,
					MessageUtility.RADIOBUTTON_NAME);
		} else {
			Verify.verifyTrue(false, MessageUtility.RADIOBUTTON_NAME_NOTDISPLAYED);
		}
	}
    /**
     * click Individual Radio Button Search Page
     * @throws ScriptException
     */
	public void clickIndividualRadioButtonSearchPage() throws ScriptException {
		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_INDIVIDUAL__SEARCH.exists()) {
			click(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_INDIVIDUAL__SEARCH,
					MessageUtility.RADIOBUTTON_INDIVIDUAL);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_INDIVIDUAL_NOTFOUND);
		}
	}
    /**
     * click Organization Radio Button Search Page
     * @throws ScriptException
     */
	public void clickOrganizationRadioButtonSearchPage() throws ScriptException {
		if (ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ORGANIZATION_SEARCH.exists()) {
			click(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ORGANIZATION_SEARCH,
					MessageUtility.RADIOBUTTON_ORGANIZATION);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_ORGANIZATION_NOTFOUND);
		}
	}
    /**
     * Entering Portal LastName in Search Page
     * @throws ScriptException
     */
	public void enterPortalLastNameSearchPage() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 10);
		if (clientE2ETO.getLastNameSearchpage() != null) {
			if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME.exists()) {
				enterMandatoryfieldtoEnablebutton(
						ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME,
						clientE2ETO.getLastNameSearchpage());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.TEXT_LASTNAME);
			}
		}
	}
    /**
     * Entering Portal OrgName in Search Page
     * @throws ScriptException
     */
	public void enterOrgNameSearchPage() throws ScriptException {
		if (clientE2ETO.getOrgNameSearchpage() != null) {
			if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ORGANIZTION_NAME.exists()) {

				Verify.verifyTrue(true, clientE2ETO.getOrgNameSearchpage()+ MessageUtility.ORGANIZATIONNAME_VALUE);
				enterMandatoryfieldtoEnablebutton(
						ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ORGANIZTION_NAME,
						clientE2ETO.getOrgNameSearchpage());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.TEXT_ORGNAME_NOTFOUND);
			}
		}

	}
    /**
     * Entering Portal FirstName in Search Page
     * @throws ScriptException
     */
	public void enterPortalFirstNameSearchPage() throws ScriptException {
		if (clientE2ETO.getFirstNameSearchpage() != null) {
			if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME.exists()) {
				Verify.verifyTrue(true, clientE2ETO.getFirstNameSearchpage()
						+ MessageUtility.FIRSTNAME_VALUE);
				ABSPortalTestObjects.WidgetInfos.TEXTFIELD_FIRSTNAME.setText(clientE2ETO
						.getFirstNameSearchpage());
			} else {
				Verify.verifyTrue(false,
						MessageUtility.TEXT_FIRSTNAME);
			}
		}
	}
    /**
     * Entering Portal Zip in Search Page
     * @throws ScriptException
     */
	public void enterPortalZipSearchPage() throws ScriptException {
		if (ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POSTALCODE.exists()) {
			Verify.verifyTrue(true,
					 MessageUtility.ZIP_VALUE);
			ABSPortalTestObjects.WidgetInfos.TEXTFIELD_POSTALCODE.setText(clientE2ETO
					.getZipSearchPage());
		} else {
			Verify.verifyTrue(false,  MessageUtility.TEXT_ZIP);
		}
	}
    /**
     * click Portal Search Button in Seach Page
     * @throws ScriptException
     */
	public void clickPortalSearchButtonSeachPage() throws ScriptException {
		if (ABSPortalTestObjects.WidgetInfos.BUTTON_SUBMITSEARCH.exists()) {
			ABSPortalTestObjects.WidgetInfos.BUTTON_SUBMITSEARCH.click();
			Verify.verifyTrue(true,  MessageUtility.BUTTON_SEARCH);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_SEARCH_NOTFOUND);
		}

	}
	/**
	 * select Portal Customer From Table
	 * @throws ScriptException
	 */
	public void selectPortalCustomerFromTable() throws ScriptException {
		Link link = new Link("text=" + clientE2ETO.getCustomerSearchpage());
		waitForPageLoad(link, 20);
		if (link.exists()) {
			link.click();
		} else {
			Verify.verifyTrue(false,MessageUtility.CUSTOMER_NOTFOUND);
		}

	}
	/**
	 * Verify Connect Client is Clicked new url
	 * @throws ScriptException
	 */
	public void isConnectClientClickednewurl() throws ScriptException {
		waitForPageLoad(ABSCustomerSearchTestObjects.WidgetInfos.RADIO_BUTTON_ORGANIZATION_SEARCH);
		if (CWNonAgentCSObjects.WidgetInfos.LINK_CONNECT_CLIENTS.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.LINK_CONNECT_CLIENTS,
					"Connect Clients Link clicked successfully");
			Verify.verifyTrue(true, "Connect Client Link clicked Successfully");
		}

		else {
			Verify.verifyTrue(false, "Connect Client Link not clicked");
		}
	}
	/**
	 * validate HouseHoldLink Not Displayed
	 * @throws ScriptException
	 */
	public void validateHouseHoldLinkNotDisplayed() throws ScriptException {
		HouseHoldTestObjects.WidgetInfos.HOUSEHOLD_LINK.click();
		if (!CWNonAgentCSObjects.WidgetInfos.LINK_HOUSEHOLD.exists()) {
			Verify.verifyTrue(true, MessageUtility.LINK_HOUSEHOLD_NOTDISPLAYED);

		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_HOUSEHOLD_DISPLAYED);
		}
	}
    /**
     * validate Non HouseHoldLink Not Displayed
     * @throws ScriptException
     */
	public void validateNonHouseHoldLinkNotDisplayed() throws ScriptException {
		if (!CWNonAgentCSObjects.WidgetInfos.LINK_NONHOUSEHOLD.exists()) {
			Verify.verifyTrue(true, MessageUtility.LINK_NONHOUSEHOLD_NOTDISPLAYED);

		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_NONHOUSEHOLD_DISPLAYED);
		}
	}
    /**
     * validate Relationships Link is Displayed
     * @throws ScriptException
     */
	public void validateRelationshipsLinkDisplayed() throws ScriptException {
		CWNonAgentCSObjects.WidgetInfos.LINK_HOUSEHOLD.click();
		if (RelationshipsScreenTestObjects.WidgetInfos.LINK_RELATIONSHIP.exists()) {
			RelationshipsScreenTestObjects.WidgetInfos.LINK_RELATIONSHIP.click();
			Verify.verifyTrue(true, MessageUtility.LINK_RELATIONSHIPS_DISPLAYED);

		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_RELATIONSHIPS_NOTDISPLAYED);
		}
	}
   /**
    * Adding Individual
    * @throws ScriptException
    */
	public void addIndividual() throws ScriptException {
		waitForPageLoad(AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME, 15);
		if (AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME.exists()
				&& clientE2ETO.getHhFirstName() != null) {
			setTextInTextbox(AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME,
					clientE2ETO.getHhFirstName(), clientE2ETO.getHhFirstName()
							+ " First Name Text Box value entered as expected");
			if (AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME.exists()
					&& clientE2ETO.getHhLastName() != null) {
				setTextInTextbox(
						AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME,
						clientE2ETO.getHhLastName(),
						clientE2ETO.getHhLastName()
								+ MessageUtility.LASTNAME_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_LASTNAME);
			}
			selectAddAddress();
			AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME.click();
			AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME.click();
			waitForPageLoad(
					CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_CREATEMEMBERSAVE,
					10);
			if (CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_CREATEMEMBERSAVE
					.exists()) {
				click(CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_CREATEMEMBERSAVE,
						MessageUtility.BUTTON_CREATEMEMBER);
			} else {
				Verify.verifyTrue(false, MessageUtility.BUTTON_CREATEMEMBER_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.ADDINDIVIDUAL_NOTLAUNCHED);
		}
	}
    /**
     * click And Select a Address
     */
	public void clickAndChooseSelectAddress() {
		try {
			if (getWebDriverInstance().findElement(By.cssSelector("span[id=\"dijit_form_DropDownButton_0\"]")).isDisplayed()) {
				getWebDriverInstance().findElement(By.cssSelector("span[id=\"dijit_form_DropDownButton_0\"]")).click();
			}
			
			if (getWebDriverInstance().findElement(By.cssSelector("input[name=\"addresschkBox00\"]")).isDisplayed()) {
				getWebDriverInstance().findElement(By.cssSelector("input[name=\"addresschkBox00\"]")).click();
			}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
    /**
     * verify Added Individual and Organization Customer In HH Page
     * @param addedCustomer
     */
	public void verifyAddedIndOrgCustomerInHHPage(String addedCustomer){
		try {
			if (isHHPageLaunched()) {
				waitForTime(3);
				String css = "css=div#hhmembersTitlePane_pane";
				String text = "";
				boolean flag = false;
				flag = selenium.isElementPresent(css);
				if (flag) {
					text = getWebDriverInstance().findElement(By.cssSelector(css)).getText();
					if (text.contains(addedCustomer.toUpperCase())) {
						Verify.verifyTrue(true,
								MessageUtility.MEMBER_ADDED);
					} else {
						Verify.verifyTrue(false,
								MessageUtility.MEMBER_NOTADDED);
					}
				}

			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}

	}
    /**
     * Verify ABSCustomer Search Page is Exist
     * @return
     * @throws ScriptException
     */
	public boolean isABSCustomerSearchPageExist() throws ScriptException {
		waitForPageLoad(ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME, 30);
		if (ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME.exists()) {
			return true;
		} else {
			return false;
		}
	}
	
	 /**
     * Clicking CustomerName Link from AHQB page
     * @throws ScriptException
     */
	public void selectCustomerNameLinkAHQB() throws ScriptException {
		setTopFramewithDefaultContent();
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.CUSTOMERNAME_LINK_AHQB, 10);
		if (CWNonAgentCSObjects.WidgetInfos.CUSTOMERNAME_LINK_AHQB.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.CUSTOMERNAME_LINK_AHQB,
					MessageUtility.ACTIVECUSTOMERBARNAME);
		} else {
			Verify.verifyTrue(false, MessageUtility.ACTIVECUSTOMERBARNAME_NOTFOUND);
		}
	}

	/**
     * verify MR Icon
     */
	public void verifyMRIcon() {
		/** ********* MR Symbol ********* */
		try {
			KeyboardUtility.sendKeys("{ESC}");
			KeyboardUtility.sendKeys("{ESC}");
			if (!NECHOSCREEN.exists()) {
				Verify.verifyTrue(false, MessageUtility.MRNECHOSCREEN_NOTLAUNCHED);
				clickHHPageCustomer();
				handleCimsVersion();
			} else {
				Verify.verifyTrue(true, MessageUtility.MRNECHOSCREEN_LAUNCHED);
				clickHHPageCustomer();
				handleCimsVersion();
			}
		} catch (SeleniumException e) {
			e.printStackTrace();
			Verify.verifyTrue(false, "Exception Occured while trying to navigate to Household from Necho Screen");
		} catch(Exception e){
			e.printStackTrace();
			Verify.verifyTrue(false, e.getMessage());
		}
		
	}
    /**
     * click Connect Button
     * @throws ScriptException
     */
	public void clickConnectButton() throws ScriptException {

		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.BUTTON_CONNECT);
		if (CWNonAgentCSObjects.WidgetInfos.BUTTON_CONNECT.exists())
			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_CONNECT,
					"Connect Button clicked successfully");
		else
			Verify.verifyTrue(false,
					" Connect Button is not displayed as expected");
	}
    /**
     * Click close button
     * @throws ScriptException
     */
	public void closeStikmanPage() throws ScriptException {
		if (CWNonAgentCSObjects.WidgetInfos.BUTTON_CLOSE.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_CLOSE,
					"Close Button Clicked Successfully");
		}
	}
    /**
     * verify Added Individual Customer
     * @param addedCustomer
     * @throws ScriptException
     */
	public void verifyAddedIndCustomer(String addedCustomer)
	throws ScriptException {
if (isHHPageLaunched()) {
	String css = "div#hhmembersTitlePane_pane";
	String text = "";
	boolean flag = false;
	flag = getWebDriverInstance().findElement(By.cssSelector(css)).isDisplayed();
	if (flag) {
		text = getWebDriverInstance().findElement(By.cssSelector(css)).getText();
		if (text.contains(addedCustomer)) {
			Verify.verifyTrue(true, "Individual" + addedCustomer
					+ MessageUtility.MEMBER_ADDED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.MEMBER_NOTADDED);
		}
	}

} else {
	Verify.verifyTrue(false,
			MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
}
	
}
    /**
     * validate Added HouseHold Member
     * @throws ScriptException
     */
	public void validateAddedOrganizationHouseHoldMember() throws ScriptException {
		String wholetext = "";
		if (isHHPageLaunched()) {
			Div memData = new Div("id=hhmembersTitlePane_pane");
			if (memData.exists()) {
				wholetext = memData.getText();
					if (wholetext.indexOf(clientE2ETO.getAddAddlOrgName()
							.toUpperCase()) >= 0) {
						Verify.verifyTrue(true,
								MessageUtility.ORGANIZATIONMEMBER_ADDED);
					} else {
						Verify.verifyTrue(false,
								MessageUtility.ORGANIZATIONMEMBER_NOTADDED);
					}
				}
			}
		 else {
			Verify.verifyTrue(false,
					MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		}
	}
	
	public void validateAddedIndividualHouseHoldMember() throws ScriptException {
	String wholetext = "";
	if (isHHPageLaunched()) {
		Div memData = new Div("id=hhmembersTitlePane_pane");
		if (memData.exists()) {
			wholetext = memData.getText();
				if (wholetext != null) {
					if (wholetext.indexOf(clientE2ETO.getAddAddlIndLastName().toUpperCase()) >= 0) {
						Verify.verifyTrue(true, MessageUtility.INDIVIDUALMEMBER_ADDED);
					}
					else 
						Verify.verifyTrue(false,MessageUtility.INDIVIDUALMEMBER_NOTADDED);
				}
		
		}
	}
	 else 
			Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
	}
		
    /**
     * select Calling Preference Day for additional phone
     * @throws ScriptException
    */ 
	public void selectCallingPrefDayaddtl() throws ScriptException {

		if ((CreateIndividualCustomer.WidgetInfos.LIST_CALLINGPREFERENCEDAYADDTl).exists()) {
			selectFromListbox(
					CreateIndividualCustomer.WidgetInfos.LIST_CALLINGPREFERENCEDAYADDTl,
					clientE2ETO.getAdditionalCallingPref(),
					"Additional Calling preference"
							+ clientE2ETO.getAdditionalCallingPref()
							+ "is displayed as expected");
			if (clientE2ETO.getAdditionalCallingPref().equalsIgnoreCase(
					"Specific")) {
				if (clientE2ETO.getSpecificDays().contains("SUNDAY")) {
					CheckBox specificSunday = new CheckBox(
							"id=person.phones[3].availableSun");
					specificSunday.click();
				} else if (clientE2ETO.getSpecificDays().contains("MONDAY")) {
					CheckBox specificMonday = new CheckBox(
							"id=person.phones[3].availableMon");
					specificMonday.click();
				} else if (clientE2ETO.getSpecificDays().contains("TUESDAY")) {
					CheckBox specificTuesday = new CheckBox(
							"id=person.phones[3].availableTue");
					specificTuesday.click();
				} else if (clientE2ETO.getSpecificDays().contains("WEDNESDAY")) {
					CheckBox specificWednesday = new CheckBox(
							"id=person.phones[3].availableWed");
					specificWednesday.click();
				} else if (clientE2ETO.getSpecificDays().contains("THURSDAY")) {
					CheckBox specificThursday = new CheckBox(
							"id=person.phones[3].availableThu");
					specificThursday.click();
				} else if (clientE2ETO.getSpecificDays().contains("FRIDAY")) {
					CheckBox specificFriday = new CheckBox(
							"id=person.phones[3].availableFri");
					specificFriday.click();
				} else if (clientE2ETO.getSpecificDays().contains("SATURDAY")) {
					CheckBox specificSaturday = new CheckBox(
							"id=person.phones[3].availableSat");
					specificSaturday.click();
				}
			}
			Verify.verifyTrue(true, "'" + clientE2ETO.getSpecificDays()
					+ "' is selected");
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LISTBOX_ADDITIONALCALLINGPREFERENCE);
		}
	}
    /**
     * select Calling Preference From time for additional phone
     * @throws ScriptException
     */
	public void selectCallingPrefFromTimeAddtl() throws ScriptException {
		selectFromListbox(
				CreateIndividualCustomer.WidgetInfos.LIST_FROMTIMEADDTl,clientE2ETO.getAdditionalFromTime(),MessageUtility.ADDITIONALFROMTIME);
	}
    /**
     * select Calling Preference To time for additional phone
     * @throws ScriptException
     */
	public void selectCallingPrefToTimeAdddtl() throws ScriptException {
		selectFromListbox(CreateIndividualCustomer.WidgetInfos.LIST_TOTIMEADDTl,clientE2ETO.getAdditionalToTime(), MessageUtility.ADDITIONALTOTIME);

	}
    /**
     * selecting Email Tab
     * @throws ScriptException
     */
	public void selectEmailTab() throws ScriptException {
		if (CreateIndividualCustomer.WidgetInfos.LINK_emailTab.exists()) {
			click(CreateIndividualCustomer.WidgetInfos.LINK_emailTab,
					MessageUtility.EMAILTAB_CLICKED);
		} else {
			Verify.verifyTrue(true, MessageUtility.EMAILTAB_NOTFOUND);
		}
	}
    /**
     * setting MarketingIndicator
     * @throws ScriptException
     */
	public void setMarketingIndicator() throws ScriptException {
		try {
			CreateIndividualCustomer.WidgetInfos.RADIO_PUBLISHEMAIL.click();
			Verify.verifyTrue(true,
					MessageUtility.MARKETINGINDICATOR_YES_SELECTED);
		} catch (Exception e) {
			Verify.verifyTrue(true,
					MessageUtility.MARKETINGINDICATOR_YES_NOTSELECTED);
		}
	}
    /**
     * selecting HHOrganization Type
     * @param count
     * @throws ScriptException
     */
	public void selectHHOrganizationType(int count) throws ScriptException {
			
			WebElement org = getWebDriverInstance()
			.findElement(
					By.xpath("//div/fieldset[1]/table/tbody/tr[2]/td[1]/div/div[1]/input"));
			org.click();
			
			Link orgType = new Link("id=orgtype1_popup3");
			if (orgType.exists())
			{
				orgType.click();
				Verify.verifyTrue(true, MessageUtility.ORGANIZATIONTYPE);
			}
			else{
				Verify.verifyTrue(false, MessageUtility.ORGANIZATIONTYPE_NOTSELECTED);
			
			}
		}
	
	public void selectHHAddOrganization(int count) throws ScriptException {
			
			WebElement org = getWebDriverInstance()
			.findElement(
					By.xpath("//div/fieldset[1]/table/tbody/tr[2]/td[1]/div/div[1]/input"));
			org.click();
			
			Link orgType = new Link("id=orgtype0_popup3");
			if (orgType.exists())
			{
				orgType.click();
				Verify.verifyTrue(true, MessageUtility.ORGANIZATIONTYPE);
			}
			else{
				Verify.verifyTrue(false, MessageUtility.ORGANIZATIONTYPE_NOTSELECTED);
			
			}
		}
    /**
     * setting HH Add Member Data for Organization
     * @throws ScriptException
     */
	public void setHHAddMemberDataOrganization() throws ScriptException {
		enterMandatoryfieldtoEnablebutton(
				CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HHADDITIONALORGANIZATIONTYPE,
				clientE2ETO.getHhOrganizationName());
		CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HHADDITIONALORGANIZATIONTYPE
				.click();
	}
    /**
     * select and Adding Address
     * @throws ScriptException
     */
	public void selectAddAddress() throws ScriptException {
		clickAddAddresses();
		waitForTime(5);
		if (CreateOrganizationCustomerAppObj.WidgetInfos.CHECKBOX_MAILINGUSAGE.exists()) {
			selectUsage();
			selectAddressType();
			enterAddAddressStreet();
			enterAddAddressCity();
			selectAddressStatProvforCreate();
			enterAddAddressZip();
			clickAddAddressSave();
		} else {
			Verify.verifyTrue(false,
					MessageUtility.ADDADDRESSPAGE_NOTLAUNCHED);
		}
	}
	
public void selectAddressStatProvforCreate() throws ScriptException {
		
	WebElement state = getWebDriverInstance()
	.findElement(
			By.xpath("//div[@id='addresscontent']/table[2]/tbody/tr[2]/td[6]/div/div[1]/input"));
	state.click();
	
	Link stateTitle = new Link("id=stateComboId_popup13");
	if (stateTitle.exists())
	{
		stateTitle.click();
		Verify.verifyTrue(true, MessageUtility.LISTBOX_MAILINGSTATE);
	}
	else
		Verify.verifyTrue(false, MessageUtility.STATE_NOTSELECTED);
	
	}
    /**
     * Click Create Members Button
     * @throws ScriptException
     */
	public void clickCreateMember() throws ScriptException {
		waitForPageLoad(AddIndividualPageObjects.WidgetInfos.BUTTON_SAVE, 3);
		if ((AddIndividualPageObjects.WidgetInfos.BUTTON_SAVE).exists()) {
			click(AddIndividualPageObjects.WidgetInfos.BUTTON_SAVE,
					MessageUtility.BUTTON_CREATEMEMBER);
		}
	}
	public void clickAddOrgCreateMember() throws ScriptException {
		waitForTime(3);
		CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_HHADDITIONALORGANIZATIONTYPE.click();
		
		if ((AddIndividualPageObjects.WidgetInfos.BUTTON_SAVE).exists()) {
			click(AddIndividualPageObjects.WidgetInfos.BUTTON_SAVE,
					MessageUtility.BUTTON_CREATEMEMBER);
			waitForTime(3);
		}
	}
    /**
     * click Name Field to Enable Create Button
     * @throws ScriptException
     */
	public void clickNameFieldtoEnableCreateButton() throws ScriptException {
		if ((AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME).exists())
			AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME.click();
		if ((AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME).exists())
			AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME.click();
	}
    /**
     * click Add Addresses
     * @throws ScriptException
     */
	public void clickAddAddresses() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.SPAN_ADDADDRESSES.exists()) {
			CreateOrganizationCustomerAppObj.WidgetInfos.SPAN_ADDADDRESSES.click();
			Verify.verifyTrue(true,
					MessageUtility.BUTTON_ADDADDRESS_DISPLAYED);
		} else {
			Verify.verifyTrue(true,
					MessageUtility.BUTTON_ADDADDRESS_NOTDISPLAYED);
		}
	}
    /**
     * Select Address Usage
     * @throws ScriptException
     */
	public void selectUsage() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.CHECKBOX_MAILINGUSAGE.exists()) {
			if(CreateOrganizationCustomerAppObj.WidgetInfos.CHECKBOX_MAILINGUSAGE.isChecked())
			{
			}
			else
				click(CreateOrganizationCustomerAppObj.WidgetInfos.CHECKBOX_MAILINGUSAGE,
					MessageUtility.CHECKBOX_MAILINGUSAGE);
		}
	}
    /**
     * select Address Type
     * @throws ScriptException
     */
	public void selectAddressType() throws ScriptException {
		waitForPageLoad(AddIndividualPageObjects.WidgetInfos.RADIO_US,25);
		if ("US".equalsIgnoreCase(clientE2ETO.getMailingType())) {
			if ((AddIndividualPageObjects.WidgetInfos.RADIO_US).exists()) {
				if((AddIndividualPageObjects.WidgetInfos.RADIO_US).isShowing()){
				}
				else{
				selectRadioButton(AddIndividualPageObjects.WidgetInfos.RADIO_US,
						MessageUtility.ADDRESSTYPE_US);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.ADDRESSTYPE_US_NOTSELECTED);
			}
		} else if ("CANADA".equalsIgnoreCase(clientE2ETO.getMailingType())) {
			if ((AddIndividualPageObjects.WidgetInfos.RADIO_CANADA).exists()) {
				selectRadioButton(AddIndividualPageObjects.WidgetInfos.RADIO_CANADA,
						MessageUtility.ADDRESSTYPE_CANADA);
			} else {
				Verify.verifyTrue(false, MessageUtility.ADDRESSTYPE_CANADA_NOTSELECTED);
			}
		} else if ("FOREIGN".equalsIgnoreCase(clientE2ETO.getMailingType())) {
			if ((AddIndividualPageObjects.WidgetInfos.RADIO_FOREIGN).exists()) {
				selectRadioButton(AddIndividualPageObjects.WidgetInfos.RADIO_FOREIGN,
						MessageUtility.ADDRESSTYPE_FOREIGN);
			} else {
				Verify.verifyTrue(false, MessageUtility.ADDRESSTYPE_FOREIGN_NOTSELECTED);
						
			}
		} else if ("MILITARY".equalsIgnoreCase(clientE2ETO.getMailingType())) {
			if ((AddIndividualPageObjects.WidgetInfos.RADIO_MILITARY).exists()) {

				selectRadioButton(AddIndividualPageObjects.WidgetInfos.RADIO_MILITARY,
						MessageUtility.ADDRESSTYPE_MILITARY);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ADDRESSTYPE_MILITARY_NOTSELECTED);
			}
		}
	}
	/**
	 * Entering Street in Add Address page
	 * @throws ScriptException
	 */
	public void enterAddAddressStreet() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDADDRESSSTREET.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDADDRESSSTREET,
					clientE2ETO.getHhStreet(), clientE2ETO.getHhStreet()
							+ MessageUtility.STREET_VALUE);
		}
	}
	/**
	 * Entering City in Add Address page
	 * @throws ScriptException
	 */
	public void enterAddAddressCity() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDADDRESSCITY.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDADDRESSCITY,
					clientE2ETO.getHhCity(), clientE2ETO.getHhCity()
							+ MessageUtility.CITY);
		}
	}
    /**
     * Entering Zip in Add Address page
     * @throws ScriptException
     */
	public void enterAddAddressZip() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDADDRESSZIP.exists()) {
			setTextInTextbox(
					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_ADDADDRESSZIP,
					clientE2ETO.getHhZip(), clientE2ETO.getHhZip()
							+ MessageUtility.ZIP);
		} 
	}
    /**
     * Clicking save button in Add Address page
     * @throws ScriptException
     */
	public void clickAddAddressSave() throws ScriptException {
		if (CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_ADDADDRESSSAVE.exists()) {
			click(CreateOrganizationCustomerAppObj.WidgetInfos.BUTTON_ADDADDRESSSAVE,
					MessageUtility.BUTTON_SAVE);
		}
	}
    /**
     * verify Added Organization Customer
     * @param OrgName
     */
	public void verifyAddedOrgCustomer(String OrgName) { 
		try {
			if (isHHPageLaunched()) {
				WebElement hhMembersTitle = getWebDriverInstance()
						.findElement(By.cssSelector("div#hhmembersTitlePane_pane"));
				String text = "";
				boolean flag = false;
				flag = hhMembersTitle.isDisplayed();
				if (flag && OrgName != null) {
					text = hhMembersTitle.getText();
					if (text.contains(OrgName.toUpperCase())) {
						Verify.verifyTrue(true, "Organization " + OrgName
								+ MessageUtility.MEMBER_ADDED);
					} else {
						Verify.verifyTrue(false,
								MessageUtility.MEMBER_NOTADDED);
					}
				}

			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}

    /**
     * Clicking CustomerName Link from ABS page
     * @throws ScriptException
     */
	public void selectCustomerNameLinkABS() throws ScriptException {
		
		getWebDriverInstance().switchTo().defaultContent();
		getWebDriverInstance().switchTo().frame("TopFrame");
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.CUSTOMERNAME_LINK_SUPPORTWRITE, 10);
		if (CWNonAgentCSObjects.WidgetInfos.CUSTOMERNAME_LINK_SUPPORTWRITE.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.CUSTOMERNAME_LINK_SUPPORTWRITE,
					MessageUtility.ACTIVECUSTOMERBARNAME);
		} else {
			Verify.verifyTrue(false, MessageUtility.ACTIVECUSTOMERBARNAME_NOTFOUND);
		}
	}
	
    /**
     * validating CustomerProfilePrint
     * @param windowNum
     * @throws ScriptException
     * @throws InterruptedException
     */
	public void validateCustomerProfilePrint(int windowNum)
	throws ScriptException, InterruptedException {
try {
	List<String> browsersTitles = null;
	for (int i = 0; i < 15; i++) {
		browsersTitles = browser.getAllWindowTitles();
			if (browsersTitles.get(windowNum - 1).contains(
					EndToEndConstants.CIMS_ERROR_PAGE)) {
				browser.setActiveWindow(EndToEndConstants.CIMS_ERROR_PAGE);
				setWindow("urlRedirect.do?", 3, 2);
				WebElement element = getWebDriverInstance()
						.findElement(By.cssSelector("input[id='check']"));
				element.click();						
				getWebDriverInstance().close();
				Verify.verifyTrue(true,
						MessageUtility.CUSTOMERPROFILE);
				break;
			}
		Thread.sleep(500);
	}
} catch(Exception e){
	Verify.verifyTrue(false, e.getMessage());
}
}

    /**
     * verify Address Standardization
     */
	public void verifyAddressStandzation() {
		try {
			waitForPageLoad(
					CreateIndividualCustomer.WidgetInfos.CheckBox_KEEPNOT_STANDARD, 25);
			if (CreateIndividualCustomer.WidgetInfos.CheckBox_KEEPNOT_STANDARD.exists()) {
				CreateIndividualCustomer.WidgetInfos.CheckBox_KEEPNOT_STANDARD.click();
				Verify.verifyTrue(true,
						MessageUtility.CHECKBOX_NONSTANDARDADDRESS);
			}
			if (CreateIndividualCustomer.WidgetInfos.BUTTON_OK_ADDRESSSTANDARDIZATION
					.exists()) {
				CreateIndividualCustomer.WidgetInfos.BUTTON_OK_ADDRESSSTANDARDIZATION
						.click();
				Verify.verifyTrue(true,
						MessageUtility.BUTTON_OK);
			}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
    /**
     * verify PersonalInfo page is launched
     * @return
     */
	public boolean isPersonalInfolaunched() {
		waitForPageLoad(Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_BIRTHDATE, 20);
		if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_BIRTHDATE.exists()) {
			return true;
		} else {
			return false;
		}
	}
    /**
     * clicking PresenationKit in HHpage
     * @throws ScriptException
     */
	public void clickPresenationKitinHHpage() throws ScriptException {
		waitForPageLoad(HouseHoldTestObjects.WidgetInfos.MARKETING_LINK, 15);
		HouseHoldTestObjects.WidgetInfos.MARKETING_LINK.click();
		try {
			click(HouseHoldTestObjects.WidgetInfos.PRESENATIONKIT_LINK,
					MessageUtility.LINK_PRESENTATIONKIT);
			Verify.verifyTrue(true,
					MessageUtility.LINK_PRESENTATIONKIT);
		} catch (ScriptException e) {
			Verify.verifyTrue(false,
					MessageUtility.LINK_PRESENTATIONKIT_NOTFOUND);
		}
	}
    /**
     * verify PresentationKit Page
     * @throws ScriptException
     */
	public void verifyPresentationKitPage() throws ScriptException {

		waitForPageLoad(PresentationKitPopupObjects.BUTTON_VIEW, 20);

		if ((HouseHoldPageObjects.WidgetInfos.LINK_HELPONTHISPAGE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_HELPONTHISPAGE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_HELPONTHISPAGE_NOTDISPLAYED);
		}

		if ((PresentationKitPopupObjects.BUTTON_VIEW).exists()) {
			Verify.verifyTrue(true, MessageUtility.BUTTON_VIEW_DISPLAYED);

		} else {
					Verify.verifyTrue(false, MessageUtility.BUTTON_VIEW_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.BUTTON_CLOSE).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.BUTTON_CLOSE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_CLOSE_NOTFOUND);
		}
		if ((PresentationKitPopupObjects.link_agentonlinecatalog).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_AGENTONLINE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_AGENTONLINE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.link_backroomtechnician).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_BACKROOMTECHNICIAN_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_BACKROOMTECHNICIAN_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.link_environmenturl).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_ENVIRONMENTURL_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ENVIRONMENTURL_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.link_vitalsigns).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_VITALSIGNS_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_VITALSIGNS_NOTDISPLAYED);
		}
		verifyNondisclosure();
		/**
		 * verify check boxes
		 */
		if ((PresentationKitPopupObjects.CHECKBOX_CSON).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.SELECTITEMS);

			Verify.verifyTrue(true,
					MessageUtility.CUSTOMERPROFILE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTOMERPROFILE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CSON_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.POLICYLISTINGPRINT_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.POLICYLISTINGPRINT_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CSON_2).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.HOUSEHOLDOPPORTUNITIES_DISPLAYED);

		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.HOUSEHOLDOPPORTUNITIES_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_FTON_6).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.FACTFINDERHEADER_DISPLAYED);

			Verify.verifyTrue(true,
					MessageUtility.LIFEFACTFINDER_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LIFEFACTFINDER_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_FTON_4).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.EDUCATIONSAVINGSFACTFINDER_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.EDUCATIONSAVINGSFACTFINDER_NOTDISPLAYED);
		}

		if ((PresentationKitPopupObjects.CHECKBOX_FTON_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.RETIREMENYFACTFINDER_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RETIREMENYFACTFINDER_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CGON_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.CONVERSATIONGUIDESHEADER);

			Verify.verifyTrue(true,
					MessageUtility.QUICKNAQ_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.QUICKNAQ_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CGON_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.SALESCONVERSATIONMODEL_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.SALESCONVERSATIONMODEL_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.CHECKBOX_CGON_5).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.PYRAMIDOFNEEDS_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.PYRAMIDOFNEEDS_NOTDISPLAYED);
		}

		if ((PresentationKitPopupObjects.checkBox_trOn_1).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.BACKROOMTECHNICIANREPORTSHEADER);

			Verify.verifyTrue(
					true,
					MessageUtility.CONSIDERATIONSINPURCHASEOFLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(
					false,
					MessageUtility.CONSIDERATIONSINPURCHASEOFLIFEINSURANCE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn_3).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.GENERALPURPOSESOFLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.GENERALPURPOSESOFLIFEINSURANCE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn_2).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.UNIVERSALLIFEINSURANCE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.UNIVERSALLIFEINSURANCE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn_4).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LONGTERMCARE_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LONGTERMCARE_NOTDISPLAYED);
		}
		if ((PresentationKitPopupObjects.checkBox_trOn).exists()) {
			Verify.verifyTrue(true,
					MessageUtility.NEEDFORRESPONSIBLEPLANNING_DISPLAYED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.NEEDFORRESPONSIBLEPLANNING_NOTDISPLAYED);
		}

	}
    /**
     * Clicking Check boxes in PresentationKit Page
     * @throws ScriptException
     */
	public void accessPresentationKitPage() throws ScriptException {
		click(PresentationKitPopupObjects.CHECKBOX_CSON,
				MessageUtility.CUSTOMERPROFILE_CLICKED);
		click(PresentationKitPopupObjects.CHECKBOX_CGON_2,
				MessageUtility.QUICKNAQ_CLICKED);
		click(PresentationKitPopupObjects.checkBox_trOn_3,
				MessageUtility.GENERALPURPOSESOFLIFEINSURANCE_CLICKED);
		click(PresentationKitPopupObjects.BUTTON_VIEW,
				MessageUtility.BUTTON_VIEW_CLICKED);
	}
    /**
     * verify Non disclosure link
     * @throws ScriptException
     */
	public void verifyNondisclosure() throws ScriptException {
		if (HouseHoldPageObjects.WidgetInfos.HTML_NONDISCLOSE.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.NONDISCLOSURE_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.NONDISCLOSURE_NOTDISPLAYED);
		}
	}
   /**
    * Closing PresentationKitPage
    * @throws ScriptException
    */
	
	
	public void closePresentationKitPage() throws ScriptException {
		waitForPageLoad(PresentationKitPopupObjects.BUTTON_CLOSE, 10);
		if (PresentationKitPopupObjects.BUTTON_CLOSE.exists()) {
			click(PresentationKitPopupObjects.BUTTON_CLOSE,
					MessageUtility.BUTTON_CLOSE);
		}
	}
    /**
     * validate PermissionToText Radio button is Hidden
     * @throws ScriptException
     */
	public void validatePermissionToTextHidden() throws ScriptException {
		Div PERMISSION_TEXT = new Div("style=*visible*");
		if (!PERMISSION_TEXT.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.PERMISSIONTOTEXT_NOTDISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.PERMISSIONTOTEXT_DISPLAYED);
		}
	}
   /**
    * clicking Inactive Policies tab
    */
	public void clickInactivePolicies() {
		try {
			waitForPageLoad(HouseHoldPageObjects.WidgetInfos.INACTIVEPOLICIES, 5);
			if (HouseHoldPageObjects.WidgetInfos.INACTIVEPOLICIES.exists()) {
				HouseHoldPageObjects.WidgetInfos.INACTIVEPOLICIES.click();
				Verify.verifyTrue(true,
						MessageUtility.INACTIVEPOLICIES_CLICKED);
			} else {
				Verify.verifyTrue(false, MessageUtility.INACTIVEPOLICIES_NOTFOUND);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}  catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
    /**
     * printing Inactive Policies
     */
	public void printInactivePolicies() {
		try {
				Div inactivePolicies = new Div("id=tempInactiveProductGrid");
				if (inactivePolicies.exists()) {
					Verify.verifyTrue(true, inactivePolicies.getText().trim());
				} else {
					Verify.verifyTrue(false, MessageUtility.INACTIVEPOLICIES_NOTAVAILABLE);
				}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}  catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}

	}

	/**
	 * Get the Customer who has at least One Insurance
	 * Policy(Auto,Fire,Health,Life)
	 * 
	 * @throws ScriptException
	 */
	public void displayInsurancePolicies() {
		try {
			if (isHHPageLaunched()) {
				Verify.verifyTrue(true, MessageUtility.INSURANCEPOLICIES_BEGIN);
				WebElement policyInfo = getWebDriverInstance().findElement(By.cssSelector("div#gridInsurance div.dojoxGridView div.dojoxGridScrollbox div.dojoxGridContent>div"));
				if (policyInfo.isDisplayed()) {
					String insurancePolInfo = getWebDriverInstance().findElement(By.cssSelector("div#gridInsurance div.dojoxGridView div.dojoxGridScrollbox div.dojoxGridContent>div")).getText();
					Verify.verifyTrue(true,insurancePolInfo + "\n");
				} else {
					Verify.verifyTrue(true, MessageUtility.POLICIES_NOTFOUND);
				}
				Verify.verifyTrue(true, MessageUtility.INSURANCEPOLICIES_END);

			} else
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}  catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());	
		}
	}
    /**
     * Displaying Inactive Policies
     * @throws ScriptException
     */
	public void displayInactivePolicies() throws ScriptException {
		if (CWNonAgentCSObjects.WidgetInfos.DIV_INACTIVE_POLICIES.exists()) {
			int rowCount = 0;
			String inactivePolicies = "";
			int c = 1;
			while (true) {
				try {
					inactivePolicies = getWebDriverInstance()
							.findElement(By.xpath("//div[@class='dojoxGridScrollbox']/div["
									+ c + "]")).getText();									
					rowCount++;
					c++;
				} catch (Exception e) {
					break;
				}
			}
			if (rowCount > 1) {
				Verify.verifyTrue(true, MessageUtility.INACTIVEPOLICIES_BEGIN);
				Verify.verifyTrue(true,inactivePolicies);
				Verify.verifyTrue(true, MessageUtility.INACTIVEPOLICIES_END);
			} else {
				Verify.verifyTrue(true, MessageUtility.INACTIVEPOLICIES_NOTAVAILABLE);
			}
		} else
			Verify.verifyTrue(false, MessageUtility.INACTIVEPOLICIES_NOTAVAILABLE);
	}

    /**
     * validate Phoenix policy Link is Not Displayed In Products Inactive Page
     */
	public void validatePhoenixLinkNotDisplayedInProductsInactivePage() {
		try {
			if (CWNonAgentCSObjects.WidgetInfos.DIV_INACTIVE_POLICIES.exists()) {
				String customerData = getTableXPathFromDivId("inactivePoliciesAccounts");
				String lifePolicyNum = null;
				if (customerData != null) {
					String phoenixData = customerData.substring(customerData
							.indexOf("PNX"));
					String[] lifeData = phoenixData.split(" ");
					lifePolicyNum = lifeData[4];
				}

				if (lifePolicyNum != null
						&& widgetExists(new Link(lifePolicyNum))) {
					Verify.verifyTrue(false,
							MessageUtility.LINK_PHOENIXPOLICY_DISPLAYED);
				} else {
					Verify.verifyTrue(true,
							MessageUtility.LINK_PHOENIXPOLICY_NOTDISPLAYED);
				}

			} else {
				Verify.verifyTrue(true, MessageUtility.INACTIVEPOLICIES_NOTAVAILABLE);
			}
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		}
	}
   /**
    * clicking InsurancePolicies tab
    */
	public void clickInsurancePolicies() {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(HouseHoldPageObjects.WidgetInfos.INSURANCEPOLICIES, 10);
				if (HouseHoldPageObjects.WidgetInfos.INSURANCEPOLICIES.exists()) {
					HouseHoldPageObjects.WidgetInfos.INSURANCEPOLICIES.click();
					Verify.verifyTrue(true,
							MessageUtility.INSURANCEPOLICIES_CLICKED);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.INSURANCEPOLICIES_NOTFOUND);
				}
			} else
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());	
		}
	}
    /**
     * Launching Auto Policy from HHPage
     */
	public void launchAutoAppfromHHPage() {
		try {
			int divCount = 1;
			Div policies = new Div("id=gridInsurance");
			if (policies.exists()) {
			while(true)
			{		
				WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[1]/td[1]/span"));
				if (policyType.getText().equalsIgnoreCase("Auto")) {
					divCount++;
					WebElement autoPolicy = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
							"div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
					if(autoPolicy.isDisplayed())
					{
						autoPolicy.click();
						waitForTime(10);
						Verify.verifyTrue(true,MessageUtility.AUTOPOLICY_CLICKED);
						isAutoPoliciesPageLaunched();
						clickHHPageCustomer();
						setTopFrame();
						break;
					
					}
			}
				divCount++;
		} 
			}
		}
		 catch (NoSuchElementException e) {
			 Verify.verifyTrue(false,"Auto policy is not found");
		}
	}
	
	public void launchFireAppfromHHPage() {
		try {
			int divCount = 1;
			Div policies = new Div("id=gridInsurance");
			if (policies.exists()) {
			while(true)
			{		
				WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[1]/td[1]/span"));
				if (policyType.getText().equalsIgnoreCase("Fire")) {
				divCount++;
				WebElement firePolicy = getWebDriverInstance().findElement(By.xpath("//div[@id='gridInsurance']/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
						"div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
				if(firePolicy.isDisplayed())
				{
					firePolicy.click();
					waitForTime(10);
					Verify.verifyTrue(true, MessageUtility.FIREPOLICY_CLICKED);
					isFirePoliciesPageLaunched();
					clickHHPageCustomer();
					setTopFrame();
					break;
				}
				else
					Verify.verifyTrue(false,"Fire policy is not found");	
						
			}
			divCount++;
		}
			}
		}catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}
	}


    /**
     * Verify Auto Policies Page is Launched
     * @throws ScriptException
     */

	public void isAutoPoliciesPageLaunched() throws ScriptException {
			waitForTime(2);
			getWebDriverInstance().switchTo().frame("main");
			waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.ACCTPOLICYHEADER, 10);
			if (CWNonAgentCSObjects.WidgetInfos.ACCTPOLICYHEADER.getText()
					.equalsIgnoreCase("Auto Policy Information")) {
				Verify.verifyTrue(true, "Auto Policies Page launched Successfully");
			} else if (CWNonAgentCSObjects.WidgetInfos.AUTOPOLICY_LBLPOLICYINFO
					.exists()) {
				Verify.verifyTrue(true, MessageUtility.AUTOPOLICY_LAUNCHED);
			} else {
				Verify.verifyTrue(false, MessageUtility.AUTOPOLICY_NOTLAUNCHED);
			}
		}
    /**
     * Closing Auto Policy Screen
     * @throws ScriptException
     */
	public void closeAutoAppScreen() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE, 20);
		try {
			if (widgetExists(CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE)) {
				CWNonAgentCSObjects.WidgetInfos.BUTTON_POLICYCLOSE.click();
			} else {
				clickHHPageCustomer();
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, MessageUtility.AUTOPOLICY_NOTLAUNCHED);

		}
	}
   /**
    * Clicking AddAccPoliciesWithOthers Link
    * @throws ScriptException
    */
	public void clickAddAccPoliciesWithOthersLink() throws ScriptException {
		waitForPageLoad(HouseHoldTestObjects.WidgetInfos.ADDPRODUCTS, 15);
		if (HouseHoldTestObjects.WidgetInfos.ADDPRODUCTS.exists()) {
			click(HouseHoldTestObjects.WidgetInfos.ADDPRODUCTS,
					MessageUtility.LINK_ADDPRODUCTSWITHOTHERS_CLICKED);
			Verify.verifyTrue(true,
					MessageUtility.LINK_ADDPRODUCTSWITHOTHERS_DISPLAYED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_ADDPRODUCTSWITHOTHERS_NOTDISPLAYED);
		}
	}
    /**
     * Clicking Previous Review Date Link
     * @throws ScriptException
     */
	public void clickPreviousReviewLink() throws ScriptException {
		try {
			if (HouseHoldTestObjects.WidgetInfos.PREVIOUSREVIEWDATE.exists()) {
				click(HouseHoldTestObjects.WidgetInfos.PREVIOUSREVIEWDATE,
						MessageUtility.LINK_PREVIOUSREVIEW_CLICKED);
				Verify.verifyTrue(true, MessageUtility.LINK_PREVIOUSREVIEW_DISPLAYED);
				setIFrame();
			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_PREVIOUSREVIEW_NOTDISPLAYED);
			}
		}  catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		}
	}
    /**
     * Setting Previous Review Date in Text box
     * @param sPrevReviewDatefromDB
     */
	public void setPreviousReviewDate(String sPrevReviewDatefromDB) {
		try {
			if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE.exists()) {
				setTextInTextbox(ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE,
						sPrevReviewDatefromDB,
						MessageUtility.LASTREVIEWDATE);
				if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE.getText() != null) {
					String date = getNextReviewDate();
					setTextInTextbox(
							ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE, date,
							MessageUtility.LASTREVIEWDATE);
				}
				if (ReviewDatePopupObjects.WidgetInfos.BUTTON_SAVE.exists()) {
					click(ReviewDatePopupObjects.WidgetInfos.BUTTON_SAVE,
							MessageUtility.BUTTON_SAVE);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.REVIEWDATESPAGE_NOTFOUND);
			}
		}   catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		}
	}
    /**
     * verify Previous Review Date Displayed As Link in HHpage
     * @param previousReviewDateEntered
     */
	public void verifyPreviousReviewDateDisplayedAsLinkinHHpage(
			String previousReviewDateEntered) {
		try {
			if(isHHPageLaunched()){
				Link PREVIOUS_REVIEW_DATE = new Link("text="+previousReviewDateEntered);
				if (PREVIOUS_REVIEW_DATE.exists()) {
					Verify.verifyTrue(true, MessageUtility.LINK_PREVIOUSREVIEWDATE_DISPLAYED);
				} else {
					Verify.verifyTrue(false, MessageUtility.LINK_PREVIOUSREVIEWDATE_NOTDISPLAYED);
				}
			}
		}  catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		}
	}

	/**
     * Clicking Next Review Link
     * @throws ScriptException
     */
	public void clickNextReviewLink() throws ScriptException {
		waitForPageLoad(HouseHoldTestObjects.WidgetInfos.NEXTREVIEWDATE, 5);
		if (HouseHoldTestObjects.WidgetInfos.NEXTREVIEWDATE.exists()) {
			click(HouseHoldTestObjects.WidgetInfos.NEXTREVIEWDATE,
					MessageUtility.LINK_NEXTREVIEW_CLICKED);
			setIFrame();
		}
	}
    /**
     * Setting Next Review Date in Text box
     * @param sPrevReviewDatefromDB
     * @throws ScriptException
     */
	public void setNextReviewDate(String sPrevReviewDatefromDB)
			throws ScriptException {
		try {
			String date = getPreviousReviewDate();
			if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE.exists()) {
				setTextInTextbox(ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE,
						sPrevReviewDatefromDB,
						MessageUtility.NEXTREVIEWDATE);
				if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE.getText()
						.contains("Select")) {
					setTextInTextbox(
							ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE, date,
							MessageUtility.LASTREVIEWDATE);
				}
				if (ReviewDatePopupObjects.WidgetInfos.BUTTON_SAVE.exists()) {
					click(ReviewDatePopupObjects.WidgetInfos.BUTTON_SAVE,
							MessageUtility.BUTTON_SAVE);
				}
			}
		} catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		}

	}
    /**
     * verify Next Review Date Displayed As Link in HHpage
     * @param nextReviewDateEntered
     */
	public void verifyNextReviewDateDisplayedAsLinkinHHpage(
			String nextReviewDateEntered) {
		try {
			if(isHHPageLaunched()){
				Link NEXT_REVIEW_DATE = new Link("text="+nextReviewDateEntered);
				if (NEXT_REVIEW_DATE.exists()) {
					Verify.verifyTrue(true, MessageUtility.LINK_NEXTREVIEWDATE_DISPLAYED);
				}
				else{
				Verify.verifyTrue(false, MessageUtility.LINK_NEXTREVIEWDATE_NOTDISPLAYED);
				}
				}
			}catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		}
	}

	/**
	 * Click on Separate Customer link in Customer Maintenance Page to launch
	 * Search and Select One Customer Page
	 * 
	 * @throws ScriptException
	 */
	public void launchSS1CPageFromCMPage() throws ScriptException {
		waitForPageLoad(CustomerMaintenanceAppObj.WidgetInfos.LINK_SEPARATECUSTOMER, 30);
		if (CustomerMaintenanceAppObj.WidgetInfos.LINK_SEPARATECUSTOMER.exists()) {
			click(CustomerMaintenanceAppObj.WidgetInfos.LINK_SEPARATECUSTOMER,
					MessageUtility.LINK_SEPARATECUSTOMER_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTMAINTAINENCEPAGE_NOTLAUNCHED);
		}
	}
   /**
    * Getting Next Review date as fifth date from current date  
    * @return
    */
	public String getNextReviewDate() {
		java.util.Date date = new java.util.Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		Format sdf = new SimpleDateFormat("MM-dd-yyyy");
		calendar.add(Calendar.DATE, 5);
		return sdf.format(calendar.getTime());
	}
  /**
   * Getting Previous Review date as fifth date behind from current date
   * @return
   */
	public String getPreviousReviewDate() {
		java.util.Date date = new java.util.Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		Format sdf = new SimpleDateFormat("MM-dd-yyyy");
		calendar.add(Calendar.DATE, -5);
		return sdf.format(calendar.getTime());
	}
    /**
     * launching Customer Information Page From HHPage
     */
	public void launchCustomerInfoPageFromHHPage() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HouseHoldTestObjects.WidgetInfos.CUSTOMER_LINK, HouseHoldTestObjects.WidgetInfos.LINK_HHCUSTOMERINFO);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(true, e.getMessage());
		}
	}
    /**
     * verify Conflict And Continue To HHPage
     */
	public void verifyConflictAndContinueToHHPage() {
		if (CreateIndividualCustomer.WidgetInfos.BUTTON_CANCEL.exists()) {
			CreateIndividualCustomer.WidgetInfos.BUTTON_CANCEL.click();
			Verify.verifyTrue(false, MessageUtility.ADDRESS_CONFLICT);

		} else {
			Verify.verifyTrue(false, MessageUtility.SEPARATECUSTOMER_FAIL);
			launchCustomerInfoPageFromHHPage();
		}
	}
    /**
     * Select and Moving Customer to next table
     * @param prop
     * @param button
     * @param customer
     * @return
     * @throws ScriptException
     */
	public boolean moveCustomerDataMoveFunction(WidgetInfo prop, Button button,
			String customer) throws ScriptException {
		boolean selected = false;
		int i = 1;
		setTopFramewithDefaultContent();
		String css = "";
		while (i <= 10) {
			css = "div#householdMembers1>div.tableContainer>table tbody.scrollContent>tr:nth-child("+i + ")";
			if (getWebDriverInstance().findElement(By.cssSelector(css)).isDisplayed()) {
				String text = getWebDriverInstance().findElement(By.cssSelector(css.toString())).getText();
				if (text.contains(customer.toUpperCase())) {
					getWebDriverInstance().findElement(By.cssSelector(css.toString())).click();
					selected = true;
					break;
				}
			}
			i++;
		}
		if (selected) {
			waitForTime(3);
			if (button.exists())
				click(button, " button clicked Successfully");
			waitForTime(3);
		} else if (!selected) {/*
			css.insert(css.length(), 1 + ")");
			if (selenium.isElementPresent(css.toString())) {
				selenium.click(css.toString());
				waitForTime(3);
				if (button.exists())
					click(button, " button clicked Successfully");
			}
		*/}
		return selected;
	}
    /**
     * Select And Add Customer From Search Results MCLB FirstCustomer HHMOVE
     * @throws ScriptException
     */
	public void selectAndAddCustomerFromSearchResultsMCLBFirstCustomerHHMOVE()
			throws ScriptException {
		selectcCustomerFromMclbAndAddToMclb(clientE2ETO
				.getSs2cFirstCustomerHHMOVE());
		waitForTime(5);
		if (CWNonAgentCSObjects.WidgetInfos.BUTTON_ADD.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.BUTTON_ADD,
					MessageUtility.BUTTON_ADD);
		}
	}
    /**
     * Select And Add Customer From Search Results MCLB SecondCustomer HHMOVE
     * @throws ScriptException
     */
	public void selectAndAddCustomerFromSearchResultsMCLBSecondCustomerHHMOVE()
			throws ScriptException {
		waitForPageLoad(SearchSelectCustomerAppObj.WidgetInfos.BUTTON_VIEWCOMBINEADD, 10);
		if (SearchSelectCustomerAppObj.WidgetInfos.BUTTON_VIEWCOMBINEADD.exists()) {
			selectcCustomerFromMclbAndAddToMclb(clientE2ETO
					.getSs2cSecondCustomerHHMOVE());
			if (CWNonAgentCSObjects.WidgetInfos.BUTTON_ADD.exists()) {
				click(CWNonAgentCSObjects.WidgetInfos.BUTTON_ADD,
						MessageUtility.BUTTON_ADD);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
		}
	}
    /**
     * Select Customer From MCLB And Add To MCLB
     * @param customer
     * @throws ScriptException
     */
	public void selectcCustomerFromMclbAndAddToMclb(String customer)
	throws ScriptException {
if (getWebDriverInstance().findElement(By.id("searchResults")).isDisplayed()) {
	boolean selected = searchAndSelectCustomerFromTable(customer);
	if (!selected) {
		Verify.verifyTrue(false, customer
				+ MessageUtility.CUSTOMER_NOTSELECTED);
	} else {
		Verify.verifyTrue(true, customer
				+ MessageUtility.CUSTOMER_FOUND);
	}
} else {
	Verify.verifyTrue(false,
			MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
}
}
    /**
     * Search And Select Customer From Table
     * @param text
     * @return
     * @throws ScriptException
     */
	public boolean searchAndSelectCustomerFromTable(String text)
	throws ScriptException {
waitForTime(10);
boolean selected = false;
int rowCount = 1;
String data = "";
String found = "";
count = 0;
try {
	if (getWebDriverInstance().findElement(By.cssSelector("span.searchResults")).isDisplayed()) {
		String searchResult = getWebDriverInstance().findElement(By.cssSelector("span.searchResults")).getText();
		found = searchResult.substring(6, searchResult.length());
		if (found != "") {
			count = Integer.parseInt(found.trim());
		} else {
			count = 3;
		}
	}
	while (true) {
		String css = "div.tableContainer> table tbody> tr:nth-child("
				+ rowCount + ")> td:nth-child(15)";
		if (getWebDriverInstance().findElement(By.cssSelector(css)).isDisplayed()) {
			data = getWebDriverInstance().findElement(By.cssSelector(css)).getText();
			if (data.contains(text)) {
				getWebDriverInstance().findElement(By.cssSelector(css)).click();
				selected = true;
				break;
			}
		}
		rowCount++;
		if (rowCount > count) {
			break;
		}
	}
} catch (ScriptException scriptException) {
	scriptError(scriptException);
} catch (Exception e) {
	Verify.verifyTrue(true, e.getMessage());
}
return selected;
}
    /**
     * Launching Next Page by clicking next link
     * @throws ScriptException
     */
	public void launchNextPage() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.LINK_NEXT, 10);
		if (CWNonAgentCSObjects.WidgetInfos.LINK_NEXT.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.LINK_NEXT,
					MessageUtility.LINK_NEXT);
		}
	}
    /**
     * Verify PersonalInfo USSSN is Exists
     * @return
     * @throws ScriptException
     */
	public boolean isPersonalInfoUSSSNExists() throws ScriptException {
		waitForPageLoad(SSNSINObjects.WidgetInfos.TEXTFIELD_US_SSN, 15);
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_US_SSN.exists()) {
			return true;
		} else {
			return false;
		}
	}
    /**
     * Verify PersonalInfo CNSIN is Exists
     * @return
     * @throws ScriptException
     */
	public boolean isPersonalInfoCNSINExists() throws ScriptException {
		waitForPageLoad(SSNSINObjects.WidgetInfos.TEXTFIELD_SIN, 15);
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_SIN.exists()) {
			return true;
		} else {
			return false;
		}
	}
    /**
     * Refreshing Household page
     */
	public void refreshHHPage() {
		try {
			if (isHHPageLaunched()) {
				if (HouseHoldPageObjects.WidgetInfos.REFRESH_CLOSE_MENU.exists()) {
					HouseHoldPageObjects.WidgetInfos.REFRESH_CLOSE_MENU.click();
					waitForPageLoad(HouseHoldPageObjects.WidgetInfos.REFRESH);
					HouseHoldPageObjects.WidgetInfos.REFRESH.click();
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		} 
	}
	
    /**
     * Closing Household page
     */
		
	public void closeHHPage() {
		try {
			if (isHHPageLaunched()) {
				if (HouseHoldPageObjects.WidgetInfos.REFRESH_CLOSE_MENU.exists()) {
					HouseHoldPageObjects.WidgetInfos.REFRESH_CLOSE_MENU.click();
					waitForPageLoad(HouseHoldPageObjects.WidgetInfos.CLOSE);
					HouseHoldPageObjects.WidgetInfos.CLOSE.click();
					waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTFIELD_lASTNAME, 5);
					Verify.verifyTrue(true, MessageUtility.HOUSEHOLDPAGE_CLOSED);
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		} 
	}


    /**
     * verify SSN And SIN Labels
     */
	public void verifySSNAndSIN() {
		try {
			WebElement cssTin = getWebDriverInstance().findElement(By.xpath("//label[text()='US SSN:']"));
			waitForTime(3);
			if(cssTin.isDisplayed()){
	
	
				WebElement cssSSN = getWebDriverInstance().findElement(By.cssSelector("label[for=\"person.tin.number\"]"));
	
				String USSSN_TEXT = cssSSN.getText();
				
				WebElement cssSIN = getWebDriverInstance().findElement(By.cssSelector("label[for=\"person.sin.number\"]"));
				
				String CNSIN_TEXT = cssSIN.getText();
				
				
			    if (USSSN_TEXT.contains("US SSN:")
						&& CNSIN_TEXT.contains("CN SIN:")) {
					Verify.verifyTrue(true,
							MessageUtility.SSN_DISPLAY);
				} else {
					Verify.verifyTrue(false,
							MessageUtility.SSN_NOTDISPLAY);
				}
				
	
			}
			
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		}
	}
    /**
     * Filling AgentCode in Create customer page
     */

	public void fillAgentCode() { 

			try {
				 if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_AGENTCODE
						.exists()) {

					enterMandatoryfieldtoEnablebutton(

					CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_AGENTCODE,

					clientE2ETO.getAgentCode());

					Verify.verifyTrue(true, clientE2ETO.getAgentCode()

					+ MessageUtility.AGENTCODE_VALUE);

				}else if (CreateIndividualCustomer.WidgetInfos.LIST_AGENT.exists()) {

					CreateIndividualCustomer.WidgetInfos.LIST_AGENT
							.selectItemAtIndex(1);
				}
 
				 else if (CreateOrganizationCustomerAppObj.WidgetInfos.STATE_AGENT_CODE

				.exists()) {

					enterMandatoryfieldtoEnablebutton(

					CreateOrganizationCustomerAppObj.WidgetInfos.STATE_AGENT_CODE,

					clientE2ETO.getAgentCode());

				}
				
			} catch (Exception e) {

				Verify.verifyTrue(true, e.getMessage());
			}

			}
	
	public void fillAgent() { 
		try {		 
			if (CreateIndividualCustomer.WidgetInfos.LIST_AGENT.exists()) {
				CreateIndividualCustomer.WidgetInfos.LIST_AGENT
						.selectItemAtIndex(1);
			}
		
		} catch (Exception e) {

			Verify.verifyTrue(true, e.getMessage());
		}

		}


    /**
     * Clicking Active customer name link
     * @throws ScriptException
     */
	public void clickHouseholdLink() throws ScriptException {
		Link clientName = new Link("id=lblClientName");
		click(clientName, MessageUtility.ACTIVECUSTOMER_CLICKED);
	}
    /**
     * Selecting HouseHold Member from HHpage
     * @param member
     * @throws ScriptException
     */
	public void selectHouseHoldMemHHpage(String member) throws ScriptException {
		Link isMember = new Link("text=" + member);
		if (isMember.exists())
			isMember.click();

	}

	/**
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * @throws ScriptException
	 */
	public void clickActionsSearchPage() throws ScriptException {
		try {
			Selenium selenium = sel.getCurrentDomain();
			String path = "css=button[name=\"actiondd\"]";
			waitForTime(5);
			selenium.mouseOver(path);
			selenium.highlight(path);
			selenium.mouseDown(path);
			Verify.verifyTrue(true, "Action drop down clicked successfully");
		} catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		} 
	}
    /**
     * Verify Action Drop down is Exists
     * @return
     * @throws ScriptException
     */
	public boolean isActionDropdownExists() throws ScriptException {
		waitForPageLoad(CustomerSeparateAppObj.WidgetInfos.ACTION_DROPDOWN, 15);
		if (CustomerSeparateAppObj.WidgetInfos.ACTION_DROPDOWN.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Added :javascriptExpression � Find an element by evaluating
	 * javascriptExpression. This allows you to traverse the HTML Document
	 * Object Model using JavaScript. Added by:U7KV
	 * 
	 * @throws ScriptException
	 */

	public void clickActionsActivitityList() throws ScriptException {
		try {

			Selenium selenium = sel.getCurrentDomain();
			String activityList = "dom=document.getElementById(\"dijit_MenuItem_3_text\")";
			selenium.click(activityList);
			Verify.verifyTrue(true,
					MessageUtility.LINK_ACTIVITYLIST_CLICKED);

		}  catch(Exception e){
			Verify.verifyTrue(true, e.getMessage());
		} 
	}
    /**
     * Clicking next link to launch conflict page
     * @throws ScriptException
     */
	public void launchConflictInfoPage() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.LINK_NEXT, 15);
		if (CWNonAgentCSObjects.WidgetInfos.LINK_NEXT.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.LINK_NEXT,
					MessageUtility.LINK_NEXT);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
		}
	}
    /**
     * Clicking Previous Review  Link
     * @throws ScriptException
     */
	public void clickPreviuosLink() throws ScriptException {
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.LINK_PREVIUOS, 30);
		if (CWNonAgentCSObjects.WidgetInfos.LINK_PREVIUOS.exists()) {
			click(CWNonAgentCSObjects.WidgetInfos.LINK_PREVIUOS,
					MessageUtility.LINK_PREVIOUSREVIEW_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		}
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
				20);
	}
    /**
     * Entering CNSin for Combine customer page
     * @throws ScriptException
     */
	public void enterInvalidCNSIN_Combine() throws ScriptException {
		if (SSNSINObjects.WidgetInfos.TEXTFIELD_CNSIN_COMBINE.exists())
			setTextInTextbox(SSNSINObjects.WidgetInfos.TEXTFIELD_CNSIN_COMBINE,
					clientE2ETO.getCnSIN_Combine(),
					MessageUtility.SSN1);
	}
   /**
    * Selecting one customer from MCLB
    * @throws ScriptException
    */
	public void selectSS1CCustomerOneFromMCLB() throws ScriptException {
		boolean isExists = true;
		if (isExists) {
			selectcCustomerFromMclbAndAddToMclb(clientE2ETO
					.getSS1CFirstCustomer());
		} else {
			Verify.verifyTrue(false,
					MessageUtility.SEPARATECUSTOMERSPAGE_NOTEXISTS);
		}
	}
    /**
     * Clicking next link to launch Separate customer page
     * @throws ScriptException
     */
	public void launchSeparateCustomerPage() throws ScriptException {
		waitForTime(3);
		if (CustomerSeparateAppObj.WidgetInfos.LINK_NEXT.exists()) {
			click(CustomerSeparateAppObj.WidgetInfos.LINK_NEXT,
					MessageUtility.LINK_NEXT);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_NEXT_NOTCLICKED);
		}
	}
    /**
     * Select and Moving customer to next table for separate 
     * @throws ScriptException
     */
	public void moveCustomerNameOne1_Cpp() throws ScriptException {
		waitForPageLoad(CustomerSeparateAppObj.WidgetInfos.TABLE_MOVECLIENTONEALLNAMES, 20);
		boolean selected = false;
		if (CustomerSeparateAppObj.WidgetInfos.TABLE_MOVECLIENTONEALLNAMES.exists()) {
			selected = moveCustomerData(
					CustomerSeparateAppObj.WidgetInfos.TABLE_MOVECLIENTONEALLNAMES,
					CustomerSeparateAppObj.WidgetInfos.BUTTON_MOVECLIENTONEALLNAME,
					clientE2ETO.getMoveNameData());
		} else {
			Verify.verifyTrue(true, MessageUtility.CUSTNAMES_NOTAVAILABLE);
		}
		if (selected) {
			Verify.verifyTrue(true, clientE2ETO.getMoveNameData()
					+ MessageUtility.NAME_MOVED);
		} else {
			Verify.verifyTrue(false, clientE2ETO.getMoveNameData()
					+ MessageUtility.NAME_NOTMOVED);
		}
	}
	
    /**
     * Select and Moving customer to next table for separate 
     * @param prop
     * @param button
     * @param customer
     * @return
     * @throws ScriptException
     */
	private boolean moveCustomerData(WidgetInfo prop, Button button,
			String customer) throws ScriptException {
		boolean selected = false;
		int i = 1;
		while (i <= 10) {
			if (getWebDriverInstance().findElement(
					By.cssSelector("div#clientOneAllNames>div.tableContainer>table.scrollTable tbody.scrollContent>tr:nth-child("
							+ i + ")>td:nth-child(3)")).isDisplayed()) {
				
				WebElement custOneData = getWebDriverInstance().findElement(
						By.cssSelector("div#clientOneAllNames>div.tableContainer>table.scrollTable tbody.scrollContent>tr:nth-child("
								+ i + ")>td:nth-child(3)"));
				String customerOneData = custOneData.getText();
				if (customer.equalsIgnoreCase(customerOneData)) {
					getWebDriverInstance().findElement(
							By.cssSelector("div#clientOneAllNames>div.tableContainer>table.scrollTable tbody.scrollContent>tr:nth-child("
							+ (i) + ")>td:nth-child(3)")).click();
					selected = true;
					break;
				}
				i++;
			}
		}
		if (selected) {
			if (button.exists()) {
				click(button, "button clicked Successfully");
				waitForTime(1);
			}
		}
		return selected;
	}

    /**
     * Setting SSN To Customer One
     */
	public void setSSNToCustomerOne() {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTSSN.exists()) {
				setTextInTextbox(CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTSSN,
						clientE2ETO.getSSNCustomerOne(),
						MessageUtility.SSN1);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
    /**
     * Setting SSN To Customer Two
     */
	public void setSSNToCustomerTwo() {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.TEXT_NEWCLIENTSSN.exists()) {
				setTextInTextbox(CustomerSeparateAppObj.WidgetInfos.TEXT_NEWCLIENTSSN,
						clientE2ETO.getSSNCustomerTwo(),
						MessageUtility.SSN1);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
    /**
     * Setting SIN To Customer Two
     */
	public void setSINToCustomerOne() {
		try {
			waitForTime(3);
			if (CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTSIN.exists()) {
				setTextInTextbox(CustomerSeparateAppObj.WidgetInfos.TEXT_CURRENTCLIENTSIN,
						clientE2ETO.getSINCustomerOne(),
						MessageUtility.SIN);
			}
		} catch (ScriptException e) {

			scriptError(e);
		}
	}
	
    /**
     * Getting Household Members
     * @throws ScriptException
     */
	public void getHouseholdMembers() throws ScriptException {
		if (isHHPageLaunched()) {
			ArrayList<String> memberNames = new ArrayList<String>();
			int rowCount = 0;
			int count = 1;
			while (true) {
				try {
					
					String xpath = "xpath=//div[@id='gridHHMembers']/div[@class='dojoxGridMasterView']/div[@class='dojoxGridView']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/div/div["
							+ count
							+ "]/table[@class='dojoxGridRowTable']/tbody/tr[1]/td[1]";
					WebElement labelElement = getWebDriverInstance().findElement(
							By.xpath(xpath));
					String memberName = labelElement.getText();
					memberNames.add(memberName);
					rowCount++;
					count++;
				} catch (Exception e) {
					break;
				}
				clientE2ETO.setHouseHoldMemberValues(memberNames);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		}
	}
    /**
     * Verify Selected Two Customers is Exist
     * @return
     * @throws ScriptException
     */
	public boolean isSelectedTwoCustomersExist() throws ScriptException {
		waitForTime(10);
		boolean flag = false;
		if (SearchSelectCustomerAppObj.WidgetInfos.DIV_SELECTED_CUSTOMERS.exists()) {
			String ss2Customers = SearchSelectCustomerAppObj.WidgetInfos.DIV_SELECTED_CUSTOMERS
					.getText();
			System.out.println("Praveen ss2Customers:"+ss2Customers);
			System.out.println("Praveen getCombineCust1Name:"+clientE2ETO.getCombineCust1Name().trim());
			System.out.println("Praveen getCombineCust2Name:"+clientE2ETO.getCombineCust2Name().trim());
			if ((ss2Customers.contains(clientE2ETO.getCombineCust1Name().trim()))
					|| (ss2Customers
							.contains(clientE2ETO.getCombineCust2Name().trim())))
				flag = true;
			else
				flag = false;
		}
		return flag;
	}
	
    /**
     * Verify Conflict Page is Launched
     * @return
     */
	public boolean isConflictPageLaunched() {
		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE, 20);
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_BIRTHDATE.exists()
				|| ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN.exists()
				|| ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_MARITAL_STATUS
						.exists()
				|| ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_CITIZENSHIP
						.exists()
				|| ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_LANGUAGE
						.exists()
				|| ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_TAXID
						.exists()
				|| ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_DEATHDATE
						.exists()
				|| ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_ORGTYPE
						.exists()
				|| ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SELECT_ORGTYPE
						.exists())
			return true;
		else
			return false;
	}
   /**
    * Verify HHMove Selected Two Customers Exist
    * @return
    * @throws ScriptException
    */
	public boolean isHHMoveSelectedTwoCustomersExist() throws ScriptException {
		waitForPageLoad(SearchSelectCustomerAppObj.WidgetInfos.DIV_SELECTED_CUSTOMERS, 30);
		boolean flag = false;
		if (SearchSelectCustomerAppObj.WidgetInfos.DIV_SELECTED_CUSTOMERS.exists()) {
			String ss2Customers = SearchSelectCustomerAppObj.WidgetInfos.DIV_SELECTED_CUSTOMERS
					.getText();
			if ((ss2Customers
					.contains(clientE2ETO.getSs2cFirstCustomerHHMOVE()))
					&& (ss2Customers.contains(clientE2ETO
							.getSs2cSecondCustomerHHMOVE())))
				flag = true;
			else
				flag = false;
		}
		return flag;
	}
	
	public void fillAgentCode_AppQuoteMenu() { 

		try {
				if (CreateIndividualCustomer.WidgetInfos.LIST_AGENT.exists()) {

					CreateIndividualCustomer.WidgetInfos.LIST_AGENT
							.selectItemAtIndex(1);
				}

			 else if (CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_AGENTCODE
					.exists()) {

				enterMandatoryfieldtoEnablebutton(

				CreateOrganizationCustomerAppObj.WidgetInfos.TEXT_AGENTCODE,

				clientE2ETO.getAgentCode());

				Verify.verifyTrue(true, clientE2ETO.getAgentCode()

				+ MessageUtility.AGENTCODE_VALUE);

			} else if (CreateOrganizationCustomerAppObj.WidgetInfos.STATE_AGENT_CODE

			.exists()) {

				enterMandatoryfieldtoEnablebutton(

				CreateOrganizationCustomerAppObj.WidgetInfos.STATE_AGENT_CODE,

				clientE2ETO.getAgentCode());

			}
				KeyboardUtility.sendKeys("{TAB}");
				Button b= new Button("id=btnOK");
				b.click();
				waitForTime(2);

		} catch (Exception e) {

			Verify.verifyTrue(true, e.getMessage());
		}

		}
	
	public void closeHHPage_SW() {
		try {
			waitForTime(5);
			if (isHHPageLaunched()) {
				waitForPageLoad(HouseHoldTestObjects.WidgetInfos.PAGE_ACTIONS_LINK, 10);
				if (HouseHoldTestObjects.WidgetInfos.PAGE_ACTIONS_LINK.exists()) {
					HouseHoldTestObjects.WidgetInfos.PAGE_ACTIONS_LINK.click();
					HouseHoldTestObjects.WidgetInfos.LINK_PAGE_ACTIONS_CLOSE.click();
					Verify.verifyTrue(true, MessageUtility.HOUSEHOLDPAGE_CLOSED);
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		} 
	}
	
	public void refreshHHPage_SW() {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(HouseHoldTestObjects.WidgetInfos.PAGE_ACTIONS_LINK, 10);
				if (HouseHoldTestObjects.WidgetInfos.PAGE_ACTIONS_LINK.exists()) {
					HouseHoldTestObjects.WidgetInfos.PAGE_ACTIONS_LINK.click();
					HouseHoldTestObjects.WidgetInfos.PAGE_ACTIONS_REFRESH.click();
					Verify.verifyTrue(true, MessageUtility.HOUSEHOLDPAGE_CLOSED);
					waitForTime(3);
				}
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch(Exception e){
			Verify.verifyTrue(false, e.getMessage());
		} 
	}
	
	public void isFirePoliciesPageLaunched() throws ScriptException {
		waitForTime(2);
		//getWebDriverInstance().switchTo().frame("main");
		waitForPageLoad(CWNonAgentCSObjects.WidgetInfos.FIRE_POLICY_HEADER, 10);
		if (CWNonAgentCSObjects.WidgetInfos.FIRE_POLICY_HEADER.getText()
				.equalsIgnoreCase("Fire Policy Information")) {
			Verify.verifyTrue(true, MessageUtility.FIREPOLICY_LAUNCHED);
		} else if (CWNonAgentCSObjects.WidgetInfos.FIREPOLICY_LBLPOLICYINFO
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.FIREPOLICY_LAUNCHED);
		} else {
			System.out.println("#######################");
			Verify.verifyTrue(false, MessageUtility.FIREPOLICY_NOTLAUNCHED);
		}
	}
	//CanadaCASL reg
	public void EmessageOnlySendWithCASLFieldY(){
		verifyOnlySendElectronicMessage();
		isExplainTextDisplayed();
		waitForTime(2);
		((JavascriptExecutor) getWebDriverInstance()).executeScript("scroll(150,0);");
		isCASLFieldTextYesDisplayed();
		verifiyhearingImpairedNotScrolling();
	}
	public void doNotsendEmessageWithCASLFieldY(){
		verifyDoNotsentEmessage();
		isExplainTextDisplayed();
		waitForTime(2);
		((JavascriptExecutor) getWebDriverInstance()).executeScript("scroll(150,0);");
		isCASLFieldTextYesDisplayed();
		verifiyhearingImpairedNotScrolling();
	}
	public void verifyOnlySendElectronicMessageForBothClient(){
		waitForTime(3);
		launchCustomerInfoPageFromHHPage();
		verifyOnlySendElectronicMessage();
		getWebDriverInstance().close();
		waitForTime(4);
		Set<String> windowHandles=getWebDriverInstance().getWindowHandles();
		for(String win :windowHandles){
			getWebDriverInstance().switchTo().window(win);
		}		
		launchPortalCustomerSearchPageScondCustomer();
		launchPortalHHPage();
		launchCustomerInfoPageFromHHPage();
		verifyOnlySendElectronicMessage();
		
	}
	public void verifyDoNotSendElectronicMessageForBothClient(){
		waitForTime(3);
		launchCustomerInfoPageFromHHPage();
		verifyDoNotsentEmessage();
		getWebDriverInstance().close();
		waitForTime(4);
		Set<String> windowHandles=getWebDriverInstance().getWindowHandles();
		for(String win :windowHandles){
			getWebDriverInstance().switchTo().window(win);
		}		
		launchPortalCustomerSearchPageScondCustomer();
		launchPortalHHPage();
		launchCustomerInfoPageFromHHPage();
		verifyDoNotsentEmessage();
	}
	public void verifyOnlyAndDoNotSendElectronicMessageForClients(){
		waitForTime(3);
		launchCustomerInfoPageFromHHPage();
		verifyOnlySendElectronicMessage();
		getWebDriverInstance().close();
		waitForTime(4);
		Set<String> windowHandles=getWebDriverInstance().getWindowHandles();
		for(String win :windowHandles){
			getWebDriverInstance().switchTo().window(win);
		}		
		launchPortalCustomerSearchPageScondCustomer();
		launchPortalHHPage();
		launchCustomerInfoPageFromHHPage();
		verifyDoNotsentEmessage();
	}
	public void verifyDoNotAndOnlySendElectronicMessageForClients(){
		waitForTime(3);
		launchCustomerInfoPageFromHHPage();
		verifyDoNotsentEmessage();
		getWebDriverInstance().close();
		waitForTime(4);
		Set<String> windowHandles=getWebDriverInstance().getWindowHandles();
		for(String win :windowHandles){
			getWebDriverInstance().switchTo().window(win);
		}		
		launchPortalCustomerSearchPageScondCustomer();
		launchPortalHHPage();
		launchCustomerInfoPageFromHHPage();
		verifyOnlySendElectronicMessage();	
	}
	public void verifyOnlySendElectronicMessage(){
	waitForTime(4);
	String eMessage= getWebDriverInstance().findElement(By.id("eMessage")).getAttribute("value");
	if(eMessage.equalsIgnoreCase("Only Send Electronic Service Messages")){
		Verify.verifyTrue(true, "Only Send Electronic Service Messages displayed successfully");
	}else{
		Verify.verifyTrue(false, "Only Send Electronic Service Messages is not displayed");
	}
	}
	
	public void verifyEmessageFieldWithCASLFieldN(){
		waitForTime(4);
		((JavascriptExecutor) getWebDriverInstance()).executeScript("scroll(0,150);");
		String privacy= getWebDriverInstance().findElement(By.id("privacy")).getAttribute("value");
		if(privacy.equalsIgnoreCase("Share")){
			Verify.verifyTrue(true, "Retrive E-Message is Not displayed ");
		}else{
			Verify.verifyTrue(true, "Retrive E-Message is displayed ");
		}
		waitForTime(2);
		((JavascriptExecutor) getWebDriverInstance()).executeScript("scroll(150,0);");
		isCASLFieldTextNoDisplayed();
		verifiyhearingImpairedNotScrolling();
	}
	
	public void verifyDoNotsentEmessage(){
		waitForTime(4);
		String eMessage= getWebDriverInstance().findElement(By.id("eMessage")).getAttribute("value");
		if(eMessage.equalsIgnoreCase("Do Not Send Electronic Messages")){
			Verify.verifyTrue(true, "Do Not Send Electronic Messages displayed successfully");
		}else{
			Verify.verifyTrue(false, "Do Not Send Electronic Messages is not displayed");
		}
	}
	
	public void verifyEmessageFieldWithCASLFieldY(){
		waitForTime(4);
		((JavascriptExecutor) getWebDriverInstance()).executeScript("scroll(0,150);");
		String privacy= getWebDriverInstance().findElement(By.id("privacy")).getAttribute("value");
		if(privacy.equalsIgnoreCase("Share")){
			Verify.verifyTrue(true, "Retrive E-Message is Not displayed ");
		}else{
			Verify.verifyTrue(true, "Retrive E-Message is displayed ");
		}
		waitForTime(2);
		((JavascriptExecutor) getWebDriverInstance()).executeScript("scroll(150,0);");
		isCASLFieldTextYesDisplayed();
		verifiyhearingImpairedNotScrolling();
		
	}
	public void changingFromOnlyEmessageToUnsubscribe(){
		waitForTime(2);
		UpdateClick();
		explainTextInsideOfUpdate();
		getWebDriverInstance().findElement(By.id("person.unsubscribeEMessage")).click();
		getWebDriverInstance().findElement(By.id("save")).click();
		isErrorPage("Update Personal Information");
		setTopFramewithDefaultContent();
		clickHHPageCustomer();
		setTopFrame();
		launchCustomerInfoPageFromHHPage();
		verifyDoNotsentEmessage();
		isExplainTextDisplayed();
		UpdateClick();
		if(getWebDriverInstance().findElement(By.id("person.unsubscribeEMessage")).isEnabled()){
			Verify.verifyTrue(false, "unsubscribeEMessage is Enabled");
		}else{
			Verify.verifyTrue(true, "unsubscribeEMessage is disabled");
		}
		getWebDriverInstance().findElement(By.id("cancel")).click();
		setTopFramewithDefaultContent();
		String marketEmailValue= getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_13']/div/div/div/div/table/tbody/tr[1]/td[2]")).getText();
		if(marketEmailValue.equalsIgnoreCase("Yes")){
			Verify.verifyTrue(true, "MarketingEmail value is YES");
		}else{
			Verify.verifyTrue(false, "MarketingEmail value is  "+marketEmailValue);
		}
	}
	public void verifyEmessageafterCombine(){
		waitForTime(2);
		launchCustomerInfoPageFromHHPage();
		verifyDoNotsentEmessage();
	}
	public void isExplainTextDisplayed(){
		getWebDriverInstance().findElement(By.id("eMessagePermissionExplainLink")).click();
		String explainText= getWebDriverInstance().findElement(By.xpath("//div[@id='eMessagePermissionExplainLinkPopup']/p")).getText();
		if(explainText.equalsIgnoreCase("e-Message Permission - Indicates if approved service emails should or should not be sent to the customer. E-Message Permission displays on the customer bar next to email address and should be reviewed prior to sending any electronic messages to a customer. In edit mode, associates with the appropriate access will be able to manually unsubscribe a customer at their request.")){
			Verify.verifyTrue(true, "Explain Text is displayed successfully");
		}else{
			Verify.verifyTrue(true, "Explain Text is  Not displayed ");
		}
	}
	public void UpdateClick(){
		click(Update_Misc_Objects.WidgetInfos.LINK_UPDATEPERSONAL,
				MessageUtility.LINK_UPDATEPERSONALINFO);
		setIFrame();
		WebElement scroll = getWebDriverInstance().findElement(By.id("eMessagePermissionExplainLink"));
		scroll.sendKeys(Keys.PAGE_DOWN);
	}
	public void explainTextInsideOfUpdate(){
		waitForTime(3);
		Link explainLink= new Link("id=eMessagePermissionExplainLink");
		if(explainLink.exists()){
			Verify.verifyTrue(true, "EMessagePermissionExplainLink is displayed followe by unsubscribe-E message permission");
			explainLink.click();
			String ePermissionExpalin= getWebDriverInstance().findElement(By.xpath("//div[@id='eMessagePermissionExplainLinkPopup']/p")).getText();
			if(ePermissionExpalin.equalsIgnoreCase("Unsubscribe e-Message Permission - This checkbox is used to manually mark a customer's choice to no longer receive electronic communications. Once this indicator is set to unsubscribe it cannot be changed.")){
				Verify.verifyTrue(true, "Explain Text is displayed successfully");
			}else{
				Verify.verifyTrue(false, "Explain Text is Not displayed successfully");
			}
		}
	}
	public void isCASLFieldTextNoDisplayed(){
		if(getWebDriverInstance().findElement(By.id("lblCasl")).getText().equalsIgnoreCase("No")){
			Verify.verifyTrue(true, "CASL Field Value No is displayed ");
		}else{
			Verify.verifyTrue(false, "CASL Field Value NO is Not displayed");
		}
	}
	public void isCASLFieldTextYesDisplayed(){
		if(getWebDriverInstance().findElement(By.id("lblCasl")).getText().equalsIgnoreCase("Yes")){
			Verify.verifyTrue(true, "CASL Field Value Yes is displayed ");
		}else{
			Verify.verifyTrue(false, "CASL Field Value Yes is Not displayed");
		}
	}
	public void verifiyhearingImpairedNotScrolling(){
		if(getWebDriverInstance().findElement(By.id("hearingImpaired")).isDisplayed()){
			Verify.verifyTrue(true, "scrolling down below hearing impaired field is Not displayed");
		}else{
			Verify.verifyTrue(false, "scrolling down below hearing impaired field is displayed");
		}
	}
	
	
	 /**
     * Verify Portal Search Page is Launched Or Not
     * @throws ScriptException
     */
	public void isSplunkSearchPageLaunchedOrNot() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.TEXTAREA_SEARCH, 20);
		if (ABSPortalTestObjects.WidgetInfos.TEXTAREA_SEARCH.exists()) {
			Verify.verifyTrue(true, MessageUtility.SPLUNK_SEARCH);
		} else {
			Verify.verifyTrue(false, MessageUtility.SPLUNK_SEARCH_NOTLAUNCHED);
		}
	}
	
	 /**
     * Verify ART Page is Launched Or Not
     * @throws ScriptException
     */
	public void isARTPageLaunchedOrNot() throws ScriptException {
		waitForPageLoad(ABSPortalTestObjects.WidgetInfos.LINK_ART_LOGIN, 20);
		if (ABSPortalTestObjects.WidgetInfos.LINK_ART_LOGIN.exists()) {
			Verify.verifyTrue(true, MessageUtility.ART_TIMESHEET);
		} else {
			Verify.verifyTrue(false, MessageUtility.ART_TIMESHEET_NOTLAUNCHED);
		}
		clickLogin();
	}
		
	public void clickLogin() {
		ABSPortalTestObjects.WidgetInfos.LINK_ART_LOGIN.click();
	}
	
	public void clickARTWSRS(){
		waitForTime(10);
		getWebDriverInstance().findElement(By.xpath("//table[3]/tbody/tr[3]/td[2]/a")).click();
		waitForTime(10);
	}
	
	 /**
	 * Click on Active Customer Bar link to navigate back to HH Page.
	 */
	public void clickPresetsArrowDown() {
		try {
			getWebDriverInstance().switchTo().defaultContent();
			/*WebElement presetArrowDown = getWebDriverInstance()
					.findElement(
							By.xpath("//form[@class='search-form']/table[@class='search-bar']/tbody/tr/td[3]/div[@class='btn-group shared-timerangepicker']/a[@class='splBorder splBorder-nsew splBackground-primary btn']/span[@class='time-label']"));*/
			
			WebElement presetArrowDown = getWebDriverInstance()
			.findElement(
					By.xpath("//form[@class='search-form']/table/tbody/tr/td[3]/div/a"));
			
			//System.out.println("presetArrowDown:"+presetArrowDown);
			
			/*WebElement presetArrowDown = getWebDriverInstance()
			.findElement(
					By.xpath("//div[@class='shared-searchbar-submit']/a[@class='btn']/i[@class='icon-search-thin']"));*/
			
		
			
			
			presetArrowDown.click();
			waitForTime(10);
			WebElement dateRange = getWebDriverInstance()
			.findElement(
					By.xpath("//div[@class='popdown-dialog open']//div[@class='accordion view-new-time-range-picker-dialog shared-timerangepicker-dialog']/div[3]/div/a"));
			
			dateRange.click();
			waitForTime(10);
			getWebDriverInstance()
			.findElement(
					By.xpath("//div[@class='popdown-dialog open']//div[@class='accordion view-new-time-range-picker-dialog shared-timerangepicker-dialog']/div[3]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/span/input")).clear();
					getWebDriverInstance()
					.findElement(
							By.xpath("//div[@class='popdown-dialog open']//div[@class='accordion view-new-time-range-picker-dialog shared-timerangepicker-dialog']/div[3]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/span/input")).sendKeys("03/18/2017");
					getWebDriverInstance()
					.findElement(
							By.xpath("//div[@class='popdown-dialog open']//div[@class='accordion view-new-time-range-picker-dialog shared-timerangepicker-dialog']/div[3]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/span/input")).clear();
			getWebDriverInstance()
			.findElement(
					By.xpath("//div[@class='popdown-dialog open']//div[@class='accordion view-new-time-range-picker-dialog shared-timerangepicker-dialog']/div[3]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/span/input")).sendKeys("03/18/2017");
			getWebDriverInstance()
			.findElement(
					By.xpath("//div[@class='popdown-dialog open']//div[@class='accordion view-new-time-range-picker-dialog shared-timerangepicker-dialog']/div[3]/div[2]/div[1]/div[2]/div[1]/div[1]/div[4]/button")).click();
			waitForTime(30);
			//ABSPortalTestObjects.WidgetInfos.TEXTFIELD_STARTDATE.setText("03/18/2017");
			//ABSPortalTestObjects.WidgetInfos.TEXTFIELD_ENDDATE.setText("03/18/2017");
			getWebDriverInstance()
			.findElement(
					By.xpath("//div[@class='shared-searchbar-submit']/a[@class='btn']/i[@class='icon-search-thin']")).click();
			waitForTime(20);
			
			Verify.verifyTrue(true,
					"Customer name link is clicked successfully");
			
			setTopFrame();
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
}
