package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class Agent_CustInf_USSSN_CNSIN_ErrorValidation42 extends BaseScript  {
	int rowCount=0;
	int count=0;
	String query = "select * from Agent_CustInf_USSSN_CNSIN_Validation";
	
	public void executeSearchScript() throws Exception {
			createCustTasks.clickCustomer();
			createCustTasks.launchPortalCustomerSearchPage();
			createCustTasks.launchPortalHHPage();
			createCustTasks.launchCustInfoPageFromHHPage();
		} 
	
public void executeScript() throws Exception {
		createCustTasks.clickUpdatePersonalInfo();
	try {
		if(createCustTasks.isPersonalInfoUSSSNExists() || createCustTasks.isPersonalInfoCNSINExists()) {
		createCustTasks.appendMessage("**********   Started executing test case:  "
				+ clientE2ETO.getTestCaseName() + "  ********* ");
		createCustTasks.appendMessage("+++++++++++   Started executing test case:  "
				+ clientE2ETO.getTestCaseName() + " +++++++++++");
		createCustTasks.verifyTestCase(clientE2ETO.getTestCaseName());
		createCustTasks.appendMessage("**********  Finished executing test case:  "
				+ clientE2ETO.getTestCaseName() + "  ********* ");
		}else {
			createCustTasks.appendToResultFile(false,"Cannot Proceed with Personal Info US SSN/Canada SIN Validations as US SSN/Canada SIN widgets not found");
			count++;
		}
	} catch (Exception e) {
		createCustTasks.appendToResultFile(
				false,
				"Exception occured while accessing "
						+ transferObject.getTestcaseName()
						+ " And the error message is: " + e.getMessage());
		createCustTasks.setStatus(false, "Exception occured while accessing "
				+ transferObject.getTestcaseName()
				+ " And the error message is: " + e.getMessage());
	}
}

public void scriptMain()  {
	try {
		transferObject=setTestDataObject(transferObject);
		transferObject.setDbQuery(query);
		
		dbresultSet =databaseUtil.getCoreData(transferObject);
		
		while(dbresultSet.next()){
			clientE2ETO = databaseUtil.loadTestDataAgentCustInfUSSSNCNSINErrorValidation42(dbresultSet,clientE2ETO);
			scenarioTasks = new ScenarioTasks(clientE2ETO);
			createCustTasks = new CreateCustomersTasks(clientE2ETO);
						
			if(rowCount==0) {
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				
				executeSearchScript();
				rowCount++;
			}
			
			if (clientE2ETO.getIsTest().equalsIgnoreCase("1") && (count==0)) {
				executeScript();					
			}
		}
	} 
		catch (Exception e) {
		e.printStackTrace();
	}
}
}


