package sf.client.service.healthSuite.testScripts.EndToEnd;

import java.lang.reflect.InvocationTargetException;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;

public class Agent_SeparateCust_USSSN_CNSIN_ErrorValidation42 extends
		BaseScript {
	int rowCount = 0;
	int count = 0;
	String query = "select * from Agent_SeparateCust_USSSN_CNSIN_Validation";
	
	public void executeHouseHoldScript() throws Exception {
		createCustTasks.clickCustomer();
		createCustTasks.launchPortalCustomerSearchPage();
		createCustTasks.launchPortalHHPage();
		separateCustTasks.verifySearchandSelectOneCustomerPage();
	}

	public void separateErrorValidations() throws InvocationTargetException {
		if (createCustTasks.isSelectedOneCustomerExist()) {
			try {
				createCustTasks
						.appendMessage("**********   Started executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ "  ********* ");
				createCustTasks
						.appendMessage("+++++++++++   Started executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ " +++++++++++");
				createCustTasks.verifyTestCase(clientE2ETO.getTestCaseName());
				createCustTasks
						.appendMessage("**********  Finished executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ "  ********* ");
			} catch (Exception e) {
				createCustTasks.appendToResultFile(
						false,
						"Exception occured while accessing "
								+ transferObject.getTestcaseName()
								+ " And the error message is: "
								+ e.getMessage());
				createCustTasks.setStatus(
						false,
						"Exception occured while accessing "
								+ transferObject.getTestcaseName()
								+ " And the error message is: "
								+ e.getMessage());
			}
		} else {
			createCustTasks
					.appendToResultFile(
							false,
							"Cannot proceed with Customer Separate Validations as Searched Customer is not availbale in Search results table");
			count++;
		}
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataAgentSeparateCustUSSSNCNSINValidation(
						dbresultSet, clientE2ETO);

				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);

				if (rowCount == 0) {
					launcher = new LaunchApplication(getWATConfig());
					launcher.launchUser(scriptName());
					createCustTasks.createResultsFile(resultsFileName(),
							scriptName());
					rowCount++;
					executeHouseHoldScript();
				}

				if (clientE2ETO.getIsTest().equalsIgnoreCase("1")
						&& (count == 0)) {
					separateErrorValidations();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
