package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;

public class SW_Individual_Scenario38 extends BaseScript {

	int count = 0;
	String query = "select * from SW_Individual_Scenario38";
	public void executeScript() throws Exception {
		createCustTasks.createCustomerAndAddUpdateSSNAndSIN();
		createCustTasks.setTopFramewithDefaultContent();
		createCustTasks.enterSSNAndSINaddInd();
		combineTasks.combineselectCustOneSSN();
		combineTasks.combineSelectCustTwoSSN();
		combineTasks.combineSelectNewSSN();
		if (clientE2ETO.getType().equalsIgnoreCase("moveSSN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPageABS();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("moveSSN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("moveSIN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPageABS();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("moveSIN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("moveSSNSIN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPageABS();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("moveSSNSIN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("newSSN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPageABS();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("newSSN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("newSIN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPageABS();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("newSIN");
		}
		
		
		if (clientE2ETO.getType().equalsIgnoreCase("newSSNSIN")) {
			separateCustTasks.verifySearchandSelectOneCustomerPageABS();
			separateCustTasks.separateCustomerWithUSSSNCNSINValues("newSSNSIN");
		}
		

	}

	public void scriptMain() {

		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			launcher = new LaunchApplication(getWATConfig());
			launcher.launchUser(this.getClass().getSimpleName());
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataSWIndividualScenario38(dbresultSet, clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				if(count==0){ 
					  createCustTasks.createResultsFile(resultsFileName(), scriptName());
					 createCustTasks.setTopFrame();
					  createCustTasks.handleCimsVersion();
					  createCustTasks.setCustomerSearchTopFrame();
				      createCustTasks.clickCreateIndividual();
					  count++; 
				  }
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
