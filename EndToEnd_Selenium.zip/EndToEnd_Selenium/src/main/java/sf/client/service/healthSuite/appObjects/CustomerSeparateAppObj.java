package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

public class CustomerSeparateAppObj {

	/*public static final Div TABLE_MOVECLIENTONEALLNAMES = new Div(
			"id=clientOneAllNames");
	public static final Button BUTTON_MOVECLIENTONEALLNAME = new Button(
			"id=moveClientOneAllName");
	public static final Button BUTTON_MOVECLIENTONEPHONE = new Button(
			"id=moveClientOnePhone");
	public static final Button BUTTON_COPYCLIENTONEEMAIL = new Button(
			"id=copyClientOneEmail");
	public static final Button BUTTON_MOVECLIENTONEDRIVERSLICENSE = new Button(
			"id=moveClientOneDriversLicense");
	public static final Button BUTTON_MOVECLIENTONEOTHERADDRESS = new Button(
			"id=moveClientOneOtherAddress");
	public static final Button BUTTON_MOVECLIENTONESSN = new Button(
			"id=moveClientOneSSN");
	public static final Button BUTTON_MOVECLIENTTWOSSN = new Button(
			"id=moveClientTwoSSN");
	public static final Button BUTTON_MOVECLIENTONESIN = new Button(
			"id=moveClientOneSIN");
	public static final Button BUTTON_MOVECLIENTTWOSIN = new Button(
			"id=moveClientTwoSIN");
	public static final Button BUTTON_CANCELBUTTON = new Button("id=cancel");
	public static final Link LINK_NEXT = new Link("text=Next >|");
	public static final TextField TEXT_CURRENTCLIENTBIRTHDATE = new TextField(
			"name=currentClientBirthDate");
	public static final TextField TEXT_NEWCLIENTBIRTHDATE = new TextField(
			"name=newClientBirthDate");
	public static final TextField TEXT_NEWCLIENTSIN = new TextField(
			"id=newClientSIN");
	public static final TextField TEXT_CURRENTCLIENTSIN = new TextField(
			"id=currentClientSIN");
	public static final Div DIV_PHONES = new Div("id=clientOnePhones");
	public static final Div DIV_EMAILS = new Div("id=clientOneEmails");
	public static final Div DIV_DRI_LIC = new Div("id=clientOneDriversLicenses");
	public static final Div DIV_NON_POLICY = new Div(
			"id=clientOneOtherAddresses");
	public static final Div TABLE_MOVECLIENTONEALLNAMES2 = new Div(
			"id=clientTwoAllNames");
	public static final Div DIV_PHONES2 = new Div("id=clientTwoPhones");
	public static final Div DIV_EMAILS2 = new Div("id=clientTwoEmails");
	public static final Div DIV_DRI_LIC2 = new Div(
			"id=clientTwoDriversLicenses");
	public static final Div DIV_NON_POLICY2 = new Div(
			"id=clientTwoOtherAddresses");
	public static final String table_emails_Moving = "text=Usage Email Address*"; // GuiTestObject
	public static final String table_NonPolicyAddress_Moving = "text=Addres*";
	public static final String table_phones_Moving = "text=Usage Number*";
	public static final String table_driverLicense_Moving = "text=Type Number*";
	public static final TextField TEXT_CURRENTCLIENTTIN = new TextField(
			"id=currentClientTIN");
	public static final TextField TEXT_NEWCLIENTTIN = new TextField(
			"id=newClientTIN");
	public static final TextField TEXT_CURRENTCLIENTSSN = new TextField(
			"id=currentClientSSN");
	public static final TextField TEXT_NEWCLIENTSSN = new TextField(
			"id=newClientSSN");
	public static final Button ACTION_DROPDOWN = new Button("name=actiondd");
	public static final Span ACCOUNTS_POLICIES_BUTTON = new Span(
			"class=dijitReset dijitInline dijitButtonNode");
	public static final Div ACCOUNT_POLICIES_TITLE = new Div(
			"class=policyDlgTitle");*/

	//	Widget Constants
	public static final String DIV_MOVECLIENTONEALLNAMES_ID ="id=clientOneAllNames";
	public static final String BUTTON_MOVECLIENTONEALLNAME_ID ="id=moveClientOneAllName";
	public static final String BUTTON_MOVECLIENTONEPHONE_ID ="id=moveClientOnePhone";
	public static final String BUTTON_COPYCLIENTONEEMAIL_ID ="id=copyClientOneEmail";
	public static final String BUTTON_MOVECLIENTONEDRIVERSLICENSE_ID ="id=moveClientOneDriversLicense";
	public static final String BUTTON_MOVECLIENTONEOTHERADDRESS_ID ="id=moveClientOneOtherAddress";
	public static final String BUTTON_MOVECLIENTONESSN_ID ="id=moveClientOneSSN";
	public static final String BUTTON_MOVECLIENTTWOSSN_ID ="id=moveClientTwoSSN";
	public static final String BUTTON_MOVECLIENTONESIN_ID ="id=moveClientOneSIN";
	public static final String BUTTON_MOVECLIENTTWOSIN_ID ="id=moveClientTwoSIN";
	public static final String BUTTON_CANCELBUTTON_ID = "id=cancel";
	public static final String LINK_NEXT_TEXT= "text=Next >|";
	public static final String TEXT_CURRENTCLIENTBIRTHDATE_NAME = "name=currentClientBirthDate";
	public static final String TEXT_NEWCLIENTBIRTHDATE_NAME ="name=newClientBirthDate";
	public static final String TEXT_NEWCLIENTSIN_ID ="id=newClientSIN";
	public static final String TEXT_CURRENTCLIENTSIN_ID = "id=currentClientSIN";
	public static final String DIV_PHONES_ID = "id=clientOnePhones";
	public static final String DIV_EMAILS_ID = "id=clientOneEmails";
	public static final String DIV_DRI_LIC_ID = "id=clientOneDriversLicenses";
	public static final String DIV_NON_POLICY_ID = "id=clientOneOtherAddresses";
	public static final String DIV_MOVECLIENTONEALLNAMES2_ID = "id=clientTwoAllNames";
	public static final String DIV_PHONES2_ID = "id=clientTwoPhones";
	public static final String DIV_EMAILS2_ID = "id=clientTwoEmails";
	public static final String DIV_DRI_LIC2_ID = "id=clientTwoDriversLicenses";
	public static final String DIV_NON_POLICY2_ID ="id=clientTwoOtherAddresses";
	public static final String TEXT_CURRENTCLIENTTIN_ID = "id=currentClientTIN";
	public static final String TEXT_NEWCLIENTTIN_ID = "id=newClientTIN";
	public static final String TEXT_CURRENTCLIENTSSN_ID= "id=currentClientSSN";
	public static final String TEXT_NEWCLIENTSSN_ID = "id=newClientSSN";
	public static final String BUTTON_ACTION_DROPDOWN = "name=actiondd";
	public static final String SPAN_ACCOUNTS_POLICIES_BUTTON = "class=dijitReset dijitInline dijitButtonNode";
	public static final String DIV_ACCOUNT_POLICIES_TITLE ="class=policyDlgTitle";
	private static final String CUSTOMERSEPARATE_BUTTON_MOVECLIENTONEEMAIL = "id=moveClientOneEmail";
	public static final String LINK_PREVIOUS_TEXT= "text=< Previous";
	
	public static final String CUST_PROFILE_PRINT = "id=currentClientTIN";
	
	@WidgetIDs
	public static class WidgetInfos {
		
		public static final Div TABLE_MOVECLIENTONEALLNAMES = new Div(DIV_MOVECLIENTONEALLNAMES_ID);
		public static final Button BUTTON_MOVECLIENTONEALLNAME = new Button(BUTTON_MOVECLIENTONEALLNAME_ID);
		public static final Button BUTTON_MOVECLIENTONEPHONE = new Button(BUTTON_MOVECLIENTONEPHONE_ID);
		public static final Button BUTTON_COPYCLIENTONEEMAIL = new Button(BUTTON_COPYCLIENTONEEMAIL_ID);
		public static final Button BUTTON_MOVECLIENTONEDRIVERSLICENSE = new Button(BUTTON_MOVECLIENTONEDRIVERSLICENSE_ID);
		public static final Button BUTTON_MOVECLIENTONEOTHERADDRESS = new Button(BUTTON_MOVECLIENTONEOTHERADDRESS_ID);
		public static final Button BUTTON_MOVECLIENTONESSN = new Button(BUTTON_MOVECLIENTONESSN_ID);
		public static final Button BUTTON_MOVECLIENTTWOSSN = new Button(BUTTON_MOVECLIENTTWOSSN_ID);
		public static final Button BUTTON_MOVECLIENTONESIN = new Button(BUTTON_MOVECLIENTONESIN_ID);
		public static final Button BUTTON_MOVECLIENTTWOSIN = new Button(BUTTON_MOVECLIENTTWOSIN_ID);
		public static final Button BUTTON_CANCELBUTTON = new Button(BUTTON_CANCELBUTTON_ID);
		public static final Link LINK_NEXT = new Link(LINK_NEXT_TEXT);
		public static final TextField TEXT_CURRENTCLIENTBIRTHDATE = new TextField(TEXT_CURRENTCLIENTBIRTHDATE_NAME);
		public static final TextField TEXT_NEWCLIENTBIRTHDATE = new TextField(TEXT_NEWCLIENTBIRTHDATE_NAME);
		public static final TextField TEXT_NEWCLIENTSIN = new TextField(TEXT_NEWCLIENTSIN_ID);
		public static final TextField TEXT_CURRENTCLIENTSIN = new TextField(TEXT_CURRENTCLIENTSIN_ID);
		public static final Div DIV_PHONES = new Div(DIV_PHONES_ID);
		public static final Div DIV_EMAILS = new Div(DIV_EMAILS_ID);
		public static final Div DIV_DRI_LIC = new Div(DIV_DRI_LIC_ID);
		public static final Div DIV_NON_POLICY = new Div(DIV_NON_POLICY_ID);
		public static final Div TABLE_MOVECLIENTONEALLNAMES2 = new Div(DIV_MOVECLIENTONEALLNAMES2_ID);
		public static final Div DIV_PHONES2 = new Div(DIV_PHONES2_ID);
		public static final Div DIV_EMAILS2 = new Div(DIV_EMAILS2_ID);
		public static final Div DIV_DRI_LIC2 = new Div(DIV_DRI_LIC2_ID);
		public static final Div DIV_NON_POLICY2 = new Div(DIV_NON_POLICY2_ID);
		//Need to check the below 4 things
		public static final String table_emails_Moving = "text=Usage Email Address*"; // GuiTestObject
		public static final String table_NonPolicyAddress_Moving = "text=Addres*";
		public static final String table_phones_Moving = "text=Usage Number*";
		public static final String table_driverLicense_Moving = "text=Type Number*";
		public static final TextField TEXT_CURRENTCLIENTTIN = new TextField(TEXT_CURRENTCLIENTTIN_ID);
		public static final TextField TEXT_NEWCLIENTTIN = new TextField(TEXT_NEWCLIENTTIN_ID);
		public static final TextField TEXT_CURRENTCLIENTSSN = new TextField(TEXT_CURRENTCLIENTSSN_ID);
		public static final TextField TEXT_NEWCLIENTSSN = new TextField(TEXT_NEWCLIENTSSN_ID);
		public static final Button ACTION_DROPDOWN = new Button(BUTTON_ACTION_DROPDOWN);
		public static final Span ACCOUNTS_POLICIES_BUTTON = new Span(SPAN_ACCOUNTS_POLICIES_BUTTON);
		public static final Div ACCOUNT_POLICIES_TITLE = new Div(DIV_ACCOUNT_POLICIES_TITLE);
		public static final Button BUTTON_MOVECLIENTONEEMAIL = new Button(
				CUSTOMERSEPARATE_BUTTON_MOVECLIENTONEEMAIL);
		public static final Link LINK_PREVIOUS = new Link(LINK_PREVIOUS_TEXT);
		
		public static final TextField TEXT_CUST_PROFILE_PRINT = new TextField(CUST_PROFILE_PRINT);
	}

}
