package sf.client.service.healthSuite.appObjects;

import statefarm.widget.WidgetInfo;
import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Image;
import statefarm.widget.gui.Link;

public class Update_Misc_Objects {
	/*public static final Link UPDATE_EMAIL = new Link("title=Open the Update Email page");
	public static final Link link_AddAlias = new Link("text=Add Alias");
	public static final Link link_AddAddress = new Link("text=Add Address");
	public static final Link link_AddPhone = new Link("href=javascript:addPhone*");
	public static final Link link_AddEmail = new Link("text=Add Email");
	public static final Link link_AddEvent = new Link("text=Add Event");
	public static final Link ADD_CUSTOMER_INTEREST = new Link("text=Add Interest");
	public static final Link link_AddEmployment = new Link("text=Add Employment");
	public static final Link link_MAILING = new Link("text=Mailing");
	public static final Link link_NOTES = new Link("text=No");
	public static final Link link_updatepersonal = new Link("text=Update");
	public static final Button button_houseHoldButtonsearchPage = new Button("id=viewHouseholdInfo");
	public static WidgetInfo widCusInfoForm = new WidgetInfo("name=custInfoForm");
	public static final Button button_removeEventContinueButton = new Button("id=removeContinueButton|onclick=*removeEvent()*");
	public static final Div div_addd_errMsgSummary = new Div("id=messageSummary");
	public static final Link EmailAddress_ActiveCustomerBar = new Link("id=emailAddress");
	public static final Link SendEmail_Cancel = new Link("value=Cancel");
	public static final Image REMOVE_EMAIL = new Image("title=Remove Email address from list");
	public static final Link LINK_ORG_UPDATE = new Link("text=Update|href=javascript:updateOrganizationInfo()");
	public static final Button isButtonRemoveContinue = new Button("id=removeContinueButton");
	public static final Image REMOVE_PHONE = new Image("title=Remove Phone Number from list");*/
	
	private static final String UPDATE_MISC_LINK_EMAIL = "title=Open the Update Email page";
	private static final String UPDATE_MISC_LINK_ADDALIAS = "text=Add Alias";
	private static final String UPDATE_MISC_LINK_ADDADDRESS = "text=Add Address";
	private static final String UPDATE_MISC_LINK_ADDPHONE = "href=javascript:addPhone*";
	private static final String UPDATE_MISC_LINK_ADDEMAIL = "text=Add Email";
	private static final String UPDATE_MISC_LINK_ADDEVENT = "text=Add Event";
	private static final String UPDATE_MISC_LINK_ADDINTEREST = "text=Add Interest";
	private static final String UPDATE_MISC_LINK_ADDEMPLOYMENT = "text=Add Employment";
	private static final String UPDATE_MISC_LINK_MAILING = "text=Mailing";
	private static final String UPDATE_MISC_LINK_NO = "text=No";
	private static final String UPDATE_MISC_LINK_UPDATEPERSONAL = "href=javascript:updatePersonalInfo*";
	private static final String UPDATE_MISC_BUTTON_HOUSEHOLDBUTTONSEARCHPAGE = "id=viewHouseholdInfo";
	private static final String UPDATE_MISC_WIDGETINFO_CUSTOMERINFOFORM = "name=custInfoForm";
	private static final String UPDATE_MISC_BUTTON_REMOVEEVENTCONTINUE = "id=removeContinueButton";
	private static final String UPDATE_MISC_DIV_MESSAGE_SUMMARY = "id=messageSummary";
	private static final String UPDATE_MISC_LINK_EMAILADDRESS = "id=emailAddress";
	private static final String UPDATE_MISC_LINK_CANCEL = "value=Cancel";
	private static final String UPDATE_MISC_IMAGE_REMOVE_EMAIL = "title=Remove Email address from list";
	private static final String UPDATE_MISC_LINK_UPDATEORGANIZATIONINFO = "text=Update|href=javascript:updateOrganizationInfo()";
	private static final String UPDATE_MISC_BUTTON_REMOVECONTINUE = "id=removeContinueButton";
	private static final String UPDATE_MISC_IMAGE_REMOVE_PHONENUMBER = "title=Remove Phone Number from list";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final Link LINK_EMAIL = new Link(UPDATE_MISC_LINK_EMAIL);
		public static final Link LINK_ADDALIAS = new Link(UPDATE_MISC_LINK_ADDALIAS);
		public static final Link LINK_ADDADDRESS = new Link(UPDATE_MISC_LINK_ADDADDRESS);
		public static final Link LINK_ADDPHONE = new Link(UPDATE_MISC_LINK_ADDPHONE);
		public static final Link LINK_ADDEMAIL = new Link(UPDATE_MISC_LINK_ADDEMAIL);
		public static final Link LINK_ADDEVENT = new Link(UPDATE_MISC_LINK_ADDEVENT);
		public static final Link LINK_ADDINTEREST = new Link(UPDATE_MISC_LINK_ADDINTEREST);
		public static final Link LINK_ADDEMPLOYMENT = new Link(UPDATE_MISC_LINK_ADDEMPLOYMENT);
		public static final Link LINK_MAILING = new Link(UPDATE_MISC_LINK_MAILING);
		public static final Link LINK__NO = new Link(UPDATE_MISC_LINK_NO);
		public static final Link LINK_UPDATEPERSONAL = new Link(UPDATE_MISC_LINK_UPDATEPERSONAL);
		public static final Button BUTTON_HOUSEHOLDBUTTONSEARCHPAGE = new Button(UPDATE_MISC_BUTTON_HOUSEHOLDBUTTONSEARCHPAGE);
		public static final WidgetInfo WIDGETINFO_CUSTOMERINFOFORM = new WidgetInfo(UPDATE_MISC_WIDGETINFO_CUSTOMERINFOFORM);
		public static final Button BUTTON_REMOVEEVENTCONTINUE = new Button(UPDATE_MISC_BUTTON_REMOVEEVENTCONTINUE);
		public static final Div DIV_MESSAGE_SUMMARY = new Div(UPDATE_MISC_DIV_MESSAGE_SUMMARY);
		public static final Link LINK_EMAILADDRESS = new Link(UPDATE_MISC_LINK_EMAILADDRESS);
		public static final Link LINK_CANCEL = new Link(UPDATE_MISC_LINK_CANCEL);
		public static final Image IMAGE_REMOVE_EMAIL = new Image(UPDATE_MISC_IMAGE_REMOVE_EMAIL);
		public static final Link LINK_UPDATEORGANIZATIONINFO = new Link(UPDATE_MISC_LINK_UPDATEORGANIZATIONINFO);
		public static final Button BUTTON_REMOVECONTINUE = new Button(UPDATE_MISC_BUTTON_REMOVECONTINUE);
		public static final Image IMAGE_REMOVE_PHONENUMBER = new Image(UPDATE_MISC_IMAGE_REMOVE_PHONENUMBER);
	}
}

