package sf.client.service.healthSuite.to;


import java.util.ArrayList;

public class ClientE2ETO {

	private static final long serialVersionUID = 1L;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	private String lastNameSearchpage = null;
	private String orgNameSearchpage = null;
	private String firstNameSearchpage = null;
	private String customerSearchpage = null;
	private String zipSearchPage = null;
	private String citySearchPage = null;
	private String stateSearchPage = null;
	private String CustomerTwoData = null;
	private String ss2cFirstCustomer = null;
	private String ss2cSecondCustomer = null;
	private String citizenshipAllowedValues = null;
	private String preferredLanguagesAllowedValues = null;
	private String userAlias = null;
	private String region  = null;
	private String region2  = null;
	private String phoneNumber = null;
	private String phoneNumber1 = null;
	private String policyNumber = null;
	private String zip = null;
	private String city = null;
	private String agentCode = null;
	private String canadaAgentCode = null;
	private String state = null;
	private String lastNameSS2CFirstCust = null;
	private String lastNameSS2CSecondCust = null;
	private String firstNameSS2CFirstCust = null;
	private String firstNameSS2CSecondCust = null;
	private String zipSS2C = null;
	private String citySS2C = null;
	private String stateSS2C = null;
	private String combineCust1LastName = null;
	private String combineCust1FirstName = null;
	private String combineCust1Zip = null;
	private String combineCust1Name = null;
	private String combineCust2LastName = null;
	private String combineCust2FirstName = null;
	private String combineCust2Zip = null;
	private String combineCust2Name = null;
	private String deathDate = null;
	private String birthDate = null;
	private String maritalStatus = null;
	private String ssn = null;
	private String gender = null;
	private String citizenship = null;
	private String linkedClients = null;
	private String clientID = null;
	private String lastName2 = null;
	private String firstName2 = null;
	private String middleName2 = null;
	private String zip2 = null;
	private String firstName = null;
	private String lastName = null;
	private String csLastName = null;
	private String csLastName2 = null;
	private String csOrgName = null;
	private String csOrgName2 = null;
	private String csFirstName = null;
	private String csFirstName2 = null;
	private String policyStateOrProv = null;
	private String movingState = null;
	private String movingCity = null;
	private String csZip = null;
	private String title = null;
	private String mStreet = null;
	private String mCity = null;
	private String mstate = null;
	private String mzip = null;
	private String mSubDivision = null;
	private String mNotes = null;
	private String mAttention = null;
	private String mailingType = null;
	private String mCountry = null;
	private String mProvince = null;
	private String middleName = null;
	private String rCity = null;
	private String livingArrangements = null;
	private String firstYrWithSF = null;
	private String customerCategory = null;
	private String personalInfoAsOfDate = null;
	private String employerName = null;
	private String occupation = null;
	private String occupationStatus = null;
	private String jobTitle = null;
	private String employmentAsOfDate = null;
	private String lifeEvent = null;
	private String lifeEventOther = null;
	private String lifeEvent2AsOfDate = null;
	private String customerInterest = null;
	private String lineOfBusiness = null;
	private String productType = null;
	private String company = null;
	private String emailAddress1 = null;
	private String type = null;
	private String sinOne = null;
	private String sinTwo = null;
	private String usSSN_Combine = null;
	private String cnSIN_Combine = null;
	private String usSSN = null;
	private String cnSIN = null;
	private String errorMessageOne = null;
	private String errorMessageTwo = null;
	private String cellExtn = null;
	private String organizationType = null;
	private String organizationName = null;
	private String isTest = null;
	private String orgBusinessPhoneNum;
	private String orgEmailAddress1;
	private String hearAboutOffice;
	private String mostimportanttoyou;
	private String taxIdNumber;
	private String industry;
	private String numberOfEmployees;
	private String organizationRevenue;
	private String licenceNumber = null;
	private String ssnNum = null;
	private String testCaseName = null;
	private String callingPref = null;
	private String fromTime = null;
	private String toTime = null;
	private String hhOrganizationName = null;
	private String hhFirstName = null;
	private String hhLastName = null;
	private String hhSSN = null;
	private String hhSIN = null;
	private String hhEmailAddress1 = null;
	private String preferredLanguage = null;
	private String hhStreet = null;
	private String hhCity = null;
	private String hhState = null;
	private String hhZip = null;
	private String customerOneData = null;
	private String customerOneData2 = null;
	private String aliasFirstName = null;
	private String aliasLastName = null;
	private String secondAliasFirstName = null;
	private String secondAliasLastName = null;
	private String permissionText = null;
	private String templates = null;
	private String sinNum = null;
	private String additionalCallingPref = null;
	private String updatePhoneNumber = null;
	private String updateEmailAddress = null;
	private String faxCallingPref = null;
	private String faxFromTime = null;
	private String faxToTime = null;
	private String faxSpecificSun = null;
	private String faxSpecificMon = null;
	private String faxSpecificTue = null;
	private String faxSpecificWed = null;
	private String faxSpecificThu = null;
	private String faxSpecificFri = null;
	private String faxSpecificSat = null;
	private String emailMarketing = null;

	private String email = null;
	private String AddOrgName = null;

	private String Indcity = null;
	private String IndZip = null;
	private String IndStreet = null;
	private String Indstate = null;
	private String lastIndName = null;
	private String firstIndName = null;
	private String homeFromTime = null;
	private String homeToTime = null;

	private String callingPrefDayWork = null;
	private String callingPrefDayHome = null;
	private String callingPrefFromTimeWork = null;
	private String callingPrefToTimeWork = null;

	private String SS1CFirstCustomer = null;
	

	private String birthDateCustomerOne = null;
	private String birthDateCustomerTwo = null;
	private String sSNCustomerTwo = null;
	private String sINCustomerTwo = null;
	private String sINCustomerOne = null;
	
	private String lastNameSearchpage_sept = null;
	
	private String firstNameSearchpage_sept = null;
	private String customerSearchpage_sept = null;
	private String zipSearchPage_sept = null;
	private String stateSearchPage_sept = null;
	private String tINCustomerTwo = null;

	private String tINCustomerOne = null;



	private String province = null;
	private String lob = null;
	
	private String xdate = null;
	private String details = null;
	private String nextReviewDate = null;
	private String previousReviewDate = null;

	private ArrayList<String> HouseHoldMemberValues = null;
	private String lastNameHHMOVESearchpage = null;
	private String firstNameHHMOVESearchpage = null;
	private String zipHHMOVESearchPage = null;
	private String cityHHMOVESearchPage = null;
	private String ss2cFirstCustomerHHMOVE = null;
	private String ss2cSecondCustomerHHMOVE = null;
	private String moveCustomerOneHHMOVE = null;
	private String moveCustomerTwoHHMOVE = null;
	private String lastNameHHMOVE2Searchpage = null;

	private String firstNameHHMOVE2Searchpage = null;
	private String zipHHMOVE2SearchPage = null;
	private String cityHHMOVE2SearchPage = null;
	private String OrgName = null;
	private String OtherRegZip = null;



	private String specificDays = null;

	private String CellPhoneNumber = null;

	private String CallingPrefDay = null;

	private String HomePhoneNumber = null;

	private String WorkPhoneNumber = null;

	private String AdditionalPhoneNumber = null;
	
	private String FaxPhoneNumber = null;
	
	private String AdditionalFromTime = null;
	private String AdditionalToTime = null;
	private String AdditionalType = null;
	
	private String State2 = null;
	private String customerForCSPage = null;
	private String City2 = null;
	private String OrgName2 = null;
	
	private String portalTestId = null;
	private String portalDomain = null;
	private String portalPassword = null;
	private String urlPortal = null;

	private String customerType = null;
	private String agentName = null;
	private String street = null;
	
	private String canadaPhone = null;
	private String canadaZip = null;
	private String policyNumber1 = null;

	public String getForeignAddress() {
		return foreignAddress;
	}

	public void setForeignAddress(String foreignAddress) {
		this.foreignAddress = foreignAddress;
	}

	public String getForeignStreet() {
		return foreignStreet;
	}

	public void setForeignStreet(String foreignStreet) {
		this.foreignStreet = foreignStreet;
	}

	public String getForeignCity() {
		return foreignCity;
	}

	public void setForeignCity(String foreignCity) {
		this.foreignCity = foreignCity;
	}

	public String getForeignCountry() {
		return foreignCountry;
	}

	public void setForeignCountry(String foreignCountry) {
		this.foreignCountry = foreignCountry;
	}

	public String getForeignPostal() {
		return foreignPostal;
	}

	public void setForeignPostal(String foreignPostal) {
		this.foreignPostal = foreignPostal;
	}
	private String foreignAddress=null;
	private String foreignStreet=null;
	private String foreignCity=null;
	private String foreignCountry=null;
	private String foreignPostal=null;
	private String mostimportanttoyouOther;

	private String addressUsage = null;
	private String mStreet1 = null;

	private String hhMemberAdd2 = null;
	
	private String SSN = null;
	private String drivingLicense = null;
	private String licensedStateOrProv = null;
	private String movingZip = null;
	private String typeName = null;
	// Accounts and policies fields.
	private String countryType = null;

	private String updateFromTime = null;

	private String updateToTime = null;
	private String updateLastName = null;
	
	private String hhMemberAdd1 = null;
	
	private String presentHHMember = null;
	private String AgentAlias = null;
	private String agentAlias1 = null;
	private String updateCustomerInterest = null;
	private String updateEmployerName = null;
	private String updateOccupation = null;
	private String updateOccupationOther = null;
	private String updateOccupationStatus = null;
	private String updateJobTitle = null;
	private String updateJobTitleOther = null;
	private String updateEmploymentAsOfDate = null;

	private String updateLifeEvent = null;

	private String updateLifeEventOther = null;
	private String occupationOther = null;
	private String jobTitleOther = null;

	private String updateXDate = null;

	private String shareType = null;

	private String phoneUsage = null;
	private String updateCellExtn = null;



	private String IndustryOther = null;
	
	private String moveNameData = null;
	
	private String sSNCustomerOne =null;
	private String customer1Name =null;
	
	private String addAddlIndLastName =null;
	private String addAddlIndFirstName =null;
	private String addAddlOrgName =null;
	
	
	
	public String getAddAddlIndFirstName() {
		return addAddlIndFirstName;
	}

	public String getAddAddlIndLastName() {
		return addAddlIndLastName;
	}

	public String getAddAddlOrgName() {
		return addAddlOrgName;
	}

	public String getAdditionalCallingPref() {
		return additionalCallingPref;
	}

	public String getAdditionalFromTime() {
		return AdditionalFromTime;
	}

	public String getAdditionalPhoneNumber() {
		return AdditionalPhoneNumber;
	}

	public String getAdditionalToTime() {
		return AdditionalToTime;
	}

	public String getAdditionalType() {
		return AdditionalType;
	}
		
	public String getAddOrgName() {
		return AddOrgName;
	}
	
	public String getAddressUsage() {
		return addressUsage;
	}

	public String getAgentAlias() {
		return AgentAlias;
	}
	public String getAgentAlias1() {
		return agentAlias1;
	}
	public String getregion() {
	       return region;
	}
	public String getregion2() {
        return region2;
	}

	public String getAgentCode() {
		return agentCode;
	}
	
	public String getCanadaAgentCode() {
		return canadaAgentCode;
	}

	public String getAgentName() {
		return agentName;
	}

	public String getAliasFirstName() {
		return aliasFirstName;
	}

	public String getAliasLastName() {
		return aliasLastName;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public String getBirthDateCustomerOne() {
		return birthDateCustomerOne;
	}

	public String getBirthDateCustomerTwo() {
		return birthDateCustomerTwo;
	}

	public String getCallingPref() {
		return callingPref;
	}

	public String getCallingPrefDay() {
		return CallingPrefDay;
	}

	public String getCallingPrefDayHome() {
		return callingPrefDayHome;
	}

	public String getCallingPrefDayWork() {
		return callingPrefDayWork;
	}
	public String getCallingPrefFromTimeWork() {
		return 	callingPrefFromTimeWork;
	}
	public String getCallingPrefToTimeWork() {
		return callingPrefToTimeWork;
	}
	public String getCellExtn() {
		return cellExtn;
	}

	public String getCellPhoneNumber() {
		return CellPhoneNumber;
	}

	

	public String getCitizenship() {
		return citizenship;
	}
	

	public String getCitizenshipAllowedValues() {
		return citizenshipAllowedValues;
	}

	public String getCity() {
		return city;
	}

	public String getCity2() {
		return City2;
	}

	public String getCityHHMOVE2SearchPage() {
		return cityHHMOVE2SearchPage;
	}

	public String getCityHHMOVESearchPage() {
		return cityHHMOVESearchPage;
	}

	public String getCitySearchPage() {
		return citySearchPage;
	}

	public String getCitySS2C() {
		return citySS2C;
	}

	public String getClientID() {
		return clientID;
	}

	public String getCnSIN() {
		return cnSIN;
	}

	public String getCnSIN_Combine() {
		return cnSIN_Combine;
	}

	public String getCombineCust1FirstName() {
		return combineCust1FirstName;
	}

	public String getCombineCust1LastName() {
		return combineCust1LastName;
	}

	public String getCombineCust1Name() {
		return combineCust1Name;
	}

	public String getCombineCust1Zip() {
		return combineCust1Zip;
	}

	public String getCombineCust2FirstName() {
		return combineCust2FirstName;
	}

	public String getCombineCust2LastName() {
		return combineCust2LastName;
	}

	public String getCombineCust2Name() {
		return combineCust2Name;
	}

	public String getCombineCust2Zip() {
		return combineCust2Zip;
	}

	public String getCompany() {
		return company;
	}

	public String getCountryType() {
		return countryType;
	}

	public String getCsFirstName() {
		return csFirstName;
	}
	public String getCsFirstName2() {
		return csFirstName2;
	}

	public String getCsLastName() {
		return csLastName;
	}
	public String getCsLastName2() {
		return csLastName2;
	}

	public String getCsOrgName() {
		return csOrgName;
	}
	public String getCsOrgName2() {
		return csOrgName2;
	}

	public String getCsZip() {
		return csZip;
	}

	public String getCustomer1Name() {
		return customer1Name;
	}

	public String getCustomerCategory() {
		return customerCategory;
	}

	public String getCustomerForCSPage() {
		return customerForCSPage;
	}

	public String getCustomerInterest() {
		return customerInterest;
	}

	public String getCustomerOneData() {
		return customerOneData;
	}
	public String getCustomerOneData2() {
		return customerOneData2;
	}

	public String getCustomerSearchpage() {
		return customerSearchpage;
	}

	public String getCustomerSearchpage_sept() {
		return customerSearchpage_sept;
	}

	public String getCustomerTwoData() {
		return CustomerTwoData;
	}

	public String getCustomerType() {
		return customerType;
	}

	public String getDeathDate() {
		return deathDate;
	}

	public String getDetails() {
		return details;
	}

	public String getDrivingLicense() {
		return drivingLicense;
	}

	public String getEmail() {
		return email;
	}

	public String getEmailAddress1() {
		return emailAddress1;
	}

	public String getEmailMarketing() {
		return emailMarketing;
	}

	public String getEmployerName() {
		return employerName;
	}

	public String getEmploymentAsOfDate() {
		return employmentAsOfDate;
	}

	public String getErrorMessageOne() {
		return errorMessageOne;
	}

	public String getErrorMessageTwo() {
		return errorMessageTwo;
	}

	public String getFaxCallingPref() {
		return faxCallingPref;
	}

	public String getFaxFromTime() {
		return faxFromTime;
	}

	public String getFaxPhoneNumber() {
		return FaxPhoneNumber;
	}

	public String getFaxSpecificFri() {
		return faxSpecificFri;
	}

	public String getFaxSpecificMon() {
		return faxSpecificMon;
	}

	public String getFaxSpecificSat() {
		return faxSpecificSat;
	}

	public String getFaxSpecificSun() {
		return faxSpecificSun;
	}

	public String getFaxSpecificThu() {
		return faxSpecificThu;
	}

	public String getFaxSpecificTue() {
		return faxSpecificTue;
	}

	public String getFaxSpecificWed() {
		return faxSpecificWed;
	}

	public String getFaxToTime() {
		return faxToTime;
	}

	public String getFirstIndName() {
		return firstIndName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getFirstName2() {
		return firstName2;
	}
	public String getFirstNameHHMOVE2Searchpage() {
		return firstNameHHMOVE2Searchpage;
	}

	public String getFirstNameHHMOVESearchpage() {
		return firstNameHHMOVESearchpage;
	}

	public String getFirstNameSearchpage() {
		return firstNameSearchpage;
	}

	public String getFirstNameSearchpage_sept() {
		return firstNameSearchpage_sept;
	}

	public String getFirstNameSS2CFirstCust() {
		return firstNameSS2CFirstCust;
	}

	public String getFirstNameSS2CSecondCust() {
		return firstNameSS2CSecondCust;
	}

	public String getFirstYrWithSF() {
		return firstYrWithSF;
	}

	public String getFromTime() {
		return fromTime;
	}

	public String getGender() {
		return gender;
	}

	public String getHearAboutOffice() {
		return hearAboutOffice;
	}

	public String getHhCity() {
		return hhCity;
	}

	public String getHhEmailAddress1() {
		return hhEmailAddress1;
	}

	public String getHhFirstName() {
		return hhFirstName;
	}

	public String getHhLastName() {
		return hhLastName;
	}

	public String getHhMemberAdd1() {
		return hhMemberAdd1;
	}

	public String getHhMemberAdd2() {
		return hhMemberAdd2;
	}

	public String getHhOrganizationName() {
		return hhOrganizationName;
	}

	public String getHhSIN() {
		return hhSIN;
	}

	public String getHhSSN() {
		return hhSSN;
	}

	public String getHhState() {
		return hhState;
	}

	public String getHhStreet() {
		return hhStreet;
	}

	public String getHhZip() {
		return hhZip;
	}

	public String getHomeFromTime() {
		return homeFromTime;
	}

	public String getHomePhoneNumber() {
		return HomePhoneNumber;
	}

	public String getHomeToTime() {
		return homeToTime;
	}
	
	public ArrayList<String> getHouseHoldMemberValues() {
		return HouseHoldMemberValues;
	}

	public String getIndcity() {
		return Indcity;
	}

	public String getIndstate() {
		return Indstate;
	}

	public String getIndStreet() {
		return IndStreet;
	}

	public String getIndustry() {
		return industry;
	}

	public String getIndustryOther() {
		return IndustryOther;
	}

	public String getIndZip() {
		return IndZip;
	}

	public String getIsTest() {
		return isTest;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public String getJobTitleOther() {
		return jobTitleOther;
	}

	public String getLastIndName() {
		return lastIndName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getLastName2() {
		return lastName2;
	}

	public String getLastNameHHMOVE2Searchpage() {
		return lastNameHHMOVE2Searchpage;
	}

	public String getLastNameHHMOVESearchpage() {
		return lastNameHHMOVESearchpage;
	}

	public String getLastNameSearchpage() {
		return lastNameSearchpage;
	}

	public String getLastNameSearchpage_sept() {
		return lastNameSearchpage_sept;
	}

	public String getLastNameSS2CFirstCust() {
		return lastNameSS2CFirstCust;
	}

	public String getLastNameSS2CSecondCust() {
		return lastNameSS2CSecondCust;
	}

	public String getLicenceNumber() {
		return licenceNumber;
	}

	public String getLicensedStateOrProv() {
		return licensedStateOrProv;
	}

	public String getLifeEvent() {
		return lifeEvent;
	}

	public String getLifeEvent2AsOfDate() {
		return lifeEvent2AsOfDate;
	}
	
	public String getLifeEventOther() {
		return lifeEventOther;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public String getLinkedClients() {
		return linkedClients;
	}

	public String getLivingArrangements() {
		return livingArrangements;
	}

	public String getLob() {
		return lob;
	}

	public String getMailingType() {
		return mailingType;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public String getmAttention() {
		return mAttention;
	}

	public String getmCity() {
		return mCity;
	}

	public String getmCountry() {
		return mCountry;
	}

	public String getMiddleName() {
		return middleName;
	}

	public String getMiddleName2() {
		return middleName2;
	}

	public String getmNotes() {
		return mNotes;
	}

	public String getMostimportanttoyou() {
		return mostimportanttoyou;
	}

	public String getMostimportanttoyouOther() {
		return mostimportanttoyouOther;
	}

	public String getMoveCustomerOneHHMOVE() {
		return moveCustomerOneHHMOVE;
	}

	public String getMoveCustomerTwoHHMOVE() {
		return moveCustomerTwoHHMOVE;
	}

	public String getMoveNameData() {
		return moveNameData;
	}

	public String getMovingCity() {
		return movingCity;
	}

	public String getMovingState() {
		return movingState;
	}

	public String getMovingZip() {
		return movingZip;
	}

	public String getmProvince() {
		return mProvince;
	}

	public String getMstate() {
		return mstate;
	}

	public String getmStreet() {
		return mStreet;
	}

	public String getmStreet1() {
		return mStreet1;
	}

	public String getmSubDivision() {
		return mSubDivision;
	}

	public String getMzip() {
		return mzip;
	}

	public String getNextReviewDate() {
		return nextReviewDate;
	}

	public String getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public String getOccupation() {
		return occupation;
	}

	public String getOccupationOther() {
		return occupationOther;
	}

	public String getOccupationStatus() {
		return occupationStatus;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public String getOrganizationRevenue() {
		return organizationRevenue;
	}

	public String getOrganizationType() {
		return organizationType;
	}

	public String getOrgBusinessPhoneNum() {
		return orgBusinessPhoneNum;
	}

	public String getOrgEmailAddress1() {
		return orgEmailAddress1;
	}

	public String getOrgName() {
		return OrgName;
	}

	public String getOrgName2() {
		return OrgName2;
	}

	public String getOrgNameSearchpage() {
		return orgNameSearchpage;
	}


	public String getOtherRegZip() {
		return OtherRegZip;
	}

	public String getPermissionText() {
		return permissionText;
	}

		
	public String getPersonalInfoAsOfDate() {
		return personalInfoAsOfDate;
	}

	public String getSinOne() {
		return sinOne;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public String getPhoneNumber1() {
		return phoneNumber1;
	}


	public String getPhoneUsage() {
		return phoneUsage;
	}


	public String getPolicyNumber() {
		return policyNumber;
	}

	public String getPolicyStateOrProv() {
		return policyStateOrProv;
	}

	
	public String getPreferredLanguage() {
		return preferredLanguage;
	}

	public String getPreferredLanguagesAllowedValues() {
		return preferredLanguagesAllowedValues;
	}

	public String getPresentHHMember() {
		return presentHHMember;
	}

	public String getPreviousReviewDate() {
		return previousReviewDate;
	}
	
	
	public String getProductType() {
		return productType;
	}

	public String getProvince() {
		return province;
	}

	
	public String getrCity() {
		return rCity;
	}


	public String getShareType() {
		return shareType;
	}
	
	public String getSINCustomerOne() {
		return sINCustomerOne;
	}

	
	public String getSINCustomerTwo() {
		return sINCustomerTwo;
	}

	public String getSinNum() {
		return sinNum;
	}

	public String getSinTwo() {
		return sinTwo;
	}

	public String getSpecificDays() {
		return specificDays;
	}
	
	public String getSS1CFirstCustomer() {
		return SS1CFirstCustomer;
	}

	public String getSs2cFirstCustomer() {
		return ss2cFirstCustomer;
	}

	public String getSs2cFirstCustomerHHMOVE() {
		return ss2cFirstCustomerHHMOVE;
	}

	public String getSs2cSecondCustomer() {
		return ss2cSecondCustomer;
	}

	
	public String getSs2cSecondCustomerHHMOVE() {
		return ss2cSecondCustomerHHMOVE;
	}

	
	public String getSsn() {
		return ssn;
	}

	public String getSSN() {
		return SSN;
	}

	public String getSSNCustomerOne() {
		return sSNCustomerOne;
	}


	public String getSSNCustomerTwo() {
		return sSNCustomerTwo;
	}


	public String getSsnNum() {
		return ssnNum;
	}

	public String getState() {
		return state;
	}

	public String getState2() {
		return State2;
	}

	
	public String getStateSearchPage() {
		return stateSearchPage;
	}

	public String getStateSearchPage_sept() {
		return stateSearchPage_sept;
	}

	public String getStateSS2C() {
		return stateSS2C;
	}


	public String getTaxIdNumber() {
		return taxIdNumber;
	}

	public String getTemplates() {
		return templates;
	}

	public String getTestCaseName() {
		return testCaseName;
	}

	public String gettINCustomerOne() {
		return tINCustomerOne;
	}

	public String gettINCustomerTwo() {
		return tINCustomerTwo;
	}

	public String getTitle() {
		return title;
	}


	public String getToTime() {
		return toTime;
	}


	public String getType() {
		return type;
	}

	public String getTypeName() {
		return typeName;
	}


	public String getUpdateCellExtn() {
		return updateCellExtn;
	}

	
	public String getUpdateCustomerInterest() {
		return updateCustomerInterest;
	}

	public String getUpdateEmailAddress() {
		return updateEmailAddress;
	}
	
	public String getUpdateEmployerName() {
		return updateEmployerName;
	}

	public String getUpdateEmploymentAsOfDate() {
		return updateEmploymentAsOfDate;
	}
	
	public String getUpdateFromTime() {
		return updateFromTime;
	}

	public String getUpdateJobTitle() {
		return updateJobTitle;
	}

	public String getUpdateJobTitleOther() {
		return updateJobTitleOther;
	}

	public String getUpdateLastName() {
		return updateLastName;
	}

	public String getUpdateLifeEvent() {
		return updateLifeEvent;
	}

	public String getUpdateLifeEventOther() {
		return updateLifeEventOther;
	}

	
	public String getUpdateOccupation() {
		return updateOccupation;
	}

	public String getUpdateOccupationOther() {
		return updateOccupationOther;
	}

	public String getUpdateOccupationStatus() {
		return updateOccupationStatus;
	}
	
	public String getUpdatePhoneNumber() {
		return updatePhoneNumber;
	}

	public String getUpdateToTime() {
		return updateToTime;
	}

	public String getUpdateXDate() {
		return updateXDate;
	}


	public String getUserAlias() {
		return userAlias;
	}

	public String getUsSSN() {
		return usSSN;
	}

	public String getUsSSN_Combine() {
		return usSSN_Combine;
	}

	public String getWorkPhoneNumber() {
		return WorkPhoneNumber;
	}
	
	public String getXdate() {
		return xdate;
	}

	public String getZip() {
		return zip;
	}

	public String getZip2() {
		return zip2;
	}

	public String getZipHHMOVE2SearchPage() {
		return zipHHMOVE2SearchPage;
	}

	public String getZipHHMOVESearchPage() {
		return zipHHMOVESearchPage;
	}

	public String getZipSearchPage() {
		return zipSearchPage;
	}
	
	public String getZipSearchPage_sept() {
		return zipSearchPage_sept;
	}

	public String getStreet() {
		return street;
	}
	public String getZipSS2C() {
		return zipSS2C;
	}
	
	public void setAddAddlIndFirstName(String addAddlIndFirstName) {
		this.addAddlIndFirstName = addAddlIndFirstName;
	}

	public void setAddAddlIndLastName(String addAddlIndLastName) {
		this.addAddlIndLastName = addAddlIndLastName;
	}

	public void setAddAddlOrgName(String addAddlOrgName) {
		this.addAddlOrgName = addAddlOrgName;
	}
			
	public void setAdditionalCallingPref(String additionalCallingPref) {
		this.additionalCallingPref = additionalCallingPref;
	}

	public void setAdditionalFromTime(String additionalFromTime) {
		AdditionalFromTime = additionalFromTime;
	}

	public void setAdditionalPhoneNumber(String additionalPhoneNumber) {
		AdditionalPhoneNumber = additionalPhoneNumber;
	}
	

	public void setAdditionalToTime(String additionalToTime) {
		AdditionalToTime = additionalToTime;
	}

	public void setAdditionalType(String additionalType) {
		AdditionalType = additionalType;
	}
	
	public void setAddressUsage(String addressUsage) {
		this.addressUsage = addressUsage;
	}

	public void setAgentAlias(String agentAlias) {
		AgentAlias = agentAlias;
	}
	
	public void setAgentAlias1(String agentAlias1) {
		this.agentAlias1 = agentAlias1;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	
	public void setCanadaAgentCode(String agentCode) {
		canadaAgentCode = agentCode;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public void setAliasFirstName(String aliasFirstName) {
		this.aliasFirstName = aliasFirstName;
	}

	public void setAliasLastName(String aliasLastName) {
		this.aliasLastName = aliasLastName;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public void setBirthDateCustomerOne(String birthDateCustomerOne) {
		this.birthDateCustomerOne = birthDateCustomerOne;
	}

	public void setBirthDateCustomerTwo(String birthDateCustomerTwo) {
		this.birthDateCustomerTwo = birthDateCustomerTwo;
	}
	
	public void setCallingPref(String callingPref) {
		this.callingPref = callingPref;
	}

	public void setCallingPrefDay(String callingPrefDay) {
		CallingPrefDay = callingPrefDay;
	}

	public void setCallingPrefDayHome(String callingPrefDayHome) {
		this.callingPrefDayHome = callingPrefDayHome;
	}

	public void setCallingPrefDayWork(String callingPrefDayWork) {
		this.callingPrefDayWork = callingPrefDayWork;
	}

	public void setCallingPrefFromTimeWork(String callingPrefFromTimeWork) {
		this.callingPrefFromTimeWork = callingPrefFromTimeWork;
	}
	
	public void setCallingPrefToTimeWork(String callingPrefToTimeWork) {
		this.callingPrefToTimeWork = callingPrefToTimeWork;
	}

	public void setCellExtn(String cellExtn) {
		this.cellExtn = cellExtn;
	}

	public void setCellPhoneNumber(String cellPhoneNumber) {
		CellPhoneNumber = cellPhoneNumber;
	}

	
	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}

	public void setCitizenshipAllowedValues(String citizenshipAllowedValues) {
		this.citizenshipAllowedValues = citizenshipAllowedValues;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setCity2(String city2) {
		City2 = city2;
	}

	public void setCityHHMOVE2SearchPage(String cityHHMOVE2SearchPage) {
		this.cityHHMOVE2SearchPage = cityHHMOVE2SearchPage;
	}

	public void setCityHHMOVESearchPage(String cityHHMOVESearchPage) {
		this.cityHHMOVESearchPage = cityHHMOVESearchPage;
	}

	public void setCitySearchPage(String citySearchPage) {
		this.citySearchPage = citySearchPage;
	}

	public void setCitySS2C(String citySS2C) {
		this.citySS2C = citySS2C;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	
	public void setCnSIN(String cnSIN) {
		this.cnSIN = cnSIN;
	}

	public void setCnSIN_Combine(String cnSIN_Combine) {
		this.cnSIN_Combine = cnSIN_Combine;
	}

	public void setCombineCust1FirstName(String combineCust1FirstName) {
		this.combineCust1FirstName = combineCust1FirstName;
	}

	public void setCombineCust1LastName(String combineCust1LastName) {
		this.combineCust1LastName = combineCust1LastName;
	}

	public void setCombineCust1Name(String combineCust1Name) {
		this.combineCust1Name = combineCust1Name;
	}

	public void setCombineCust1Zip(String combineCust1Zip) {
		this.combineCust1Zip = combineCust1Zip;
	}

	public void setCombineCust2FirstName(String combineCust2FirstName) {
		this.combineCust2FirstName = combineCust2FirstName;
	}

	public void setCombineCust2LastName(String combineCust2LastName) {
		this.combineCust2LastName = combineCust2LastName;
	}

	public void setCombineCust2Name(String combineCust2Name) {
		this.combineCust2Name = combineCust2Name;
	}

	public void setCombineCust2Zip(String combineCust2Zip) {
		this.combineCust2Zip = combineCust2Zip;
	}

	public void setCompany(String company) {
		this.company = company;
	}
	
	public void setCountryType(String countryType) {
		this.countryType = countryType;
	}

	public void setCsFirstName(String csFirstName) {
		this.csFirstName = csFirstName;
	}

	public void setCsLastName(String csLastName) {
		this.csLastName = csLastName;
	}

	public void setCsOrgName(String csOrgName) {
		this.csOrgName = csOrgName;
	}

	public void setCsZip(String csZip) {
		this.csZip = csZip;
	}

	public void setCustomer1Name(String customer1Name) {
		this.customer1Name = customer1Name;
	}

	public void setCustomerCategory(String customerCategory) {
		this.customerCategory = customerCategory;
	}

	public void setCustomerForCSPage(String customerForCSPage) {
		this.customerForCSPage = customerForCSPage;
	}

	public void setCustomerInterest(String customerInterest) {
		this.customerInterest = customerInterest;
	}
	
	public void setCustomerOneData(String customerOneData) {
		this.customerOneData = customerOneData;
	}

	public void setCustomerSearchpage(String customerSearchpage) {
		this.customerSearchpage = customerSearchpage;
	}

	public void setCustomerTwoData(String customerTwoData) {
		CustomerTwoData = customerTwoData;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public void setDeathDate(String deathDate) {
		this.deathDate = deathDate;
	}
	public void setDetails(String details) {
		this.details = details;
	}

	public void setDrivingLicense(String drivingLicense) {
		this.drivingLicense = drivingLicense;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setEmailAddress1(String emailAddress1) {
		this.emailAddress1 = emailAddress1;
	}

	public void setEmailMarketing(String emailMarketing) {
		this.emailMarketing = emailMarketing;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public void setEmploymentAsOfDate(String employmentAsOfDate) {
		this.employmentAsOfDate = employmentAsOfDate;
	}

	public void setErrorMessageOne(String errorMessageOne) {
		this.errorMessageOne = errorMessageOne;
	}

	public void setErrorMessageTwo(String errorMessageTwo) {
		this.errorMessageTwo = errorMessageTwo;
	}

	public void setFaxCallingPref(String faxCallingPref) {
		this.faxCallingPref = faxCallingPref;
	}

	public void setFaxFromTime(String faxFromTime) {
		this.faxFromTime = faxFromTime;
	}

	public void setFaxPhoneNumber(String faxPhoneNumber) {
		FaxPhoneNumber = faxPhoneNumber;
	}

	public void setFaxSpecificFri(String faxSpecificFri) {
		this.faxSpecificFri = faxSpecificFri;
	}

	public void setFaxSpecificMon(String faxSpecificMon) {
		this.faxSpecificMon = faxSpecificMon;
	}

	public void setFaxSpecificSat(String faxSpecificSat) {
		this.faxSpecificSat = faxSpecificSat;
	}

	public void setFaxSpecificSun(String faxSpecificSun) {
		this.faxSpecificSun = faxSpecificSun;
	}

	public void setFaxSpecificThu(String faxSpecificThu) {
		this.faxSpecificThu = faxSpecificThu;
	}

	public void setFaxSpecificTue(String faxSpecificTue) {
		this.faxSpecificTue = faxSpecificTue;
	}

	public void setFaxSpecificWed(String faxSpecificWed) {
		this.faxSpecificWed = faxSpecificWed;
	}

	public void setFaxToTime(String faxToTime) {
		this.faxToTime = faxToTime;
	}

	public void setFirstIndName(String firstIndName) {
		this.firstIndName = firstIndName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setFirstName2(String firstName2) {
		this.firstName2 = firstName2;
	}

	public void setFirstNameHHMOVE2Searchpage(String firstNameHHMOVE2Searchpage) {
		this.firstNameHHMOVE2Searchpage = firstNameHHMOVE2Searchpage;
	}

	public void setFirstNameHHMOVESearchpage(String firstNameHHMOVESearchpage) {
		this.firstNameHHMOVESearchpage = firstNameHHMOVESearchpage;
	}

	public void setFirstNameSearchpage(String firstNameSearchpage) {
		this.firstNameSearchpage = firstNameSearchpage;
	}


	public void setFirstNameSearchpage_sept(String firstNameSearchpage_sept) {
		this.firstNameSearchpage_sept = firstNameSearchpage_sept;
	}

	public void setFirstNameSS2CFirstCust(String firstNameSS2CFirstCust) {
		this.firstNameSS2CFirstCust = firstNameSS2CFirstCust;
	}

	public void setFirstNameSS2CSecondCust(String firstNameSS2CSecondCust) {
		this.firstNameSS2CSecondCust = firstNameSS2CSecondCust;
	}

	public void setFirstYrWithSF(String firstYrWithSF) {
		this.firstYrWithSF = firstYrWithSF;
	}

	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setHearAboutOffice(String hearAboutOffice) {
		this.hearAboutOffice = hearAboutOffice;
	}

	
	public void setHhCity(String hhCity) {
		this.hhCity = hhCity;
	}

	public void setHhEmailAddress1(String hhEmailAddress1) {
		this.hhEmailAddress1 = hhEmailAddress1;
	}

	public void setHhFirstName(String hhFirstName) {
		this.hhFirstName = hhFirstName;
	}

	public void setHhLastName(String hhLastName) {
		this.hhLastName = hhLastName;
	}

	public void setHhMemberAdd1(String hhMemberAdd1) {
		this.hhMemberAdd1 = hhMemberAdd1;
	}

	public void setHhMemberAdd2(String hhMemberAdd2) {
		this.hhMemberAdd2 = hhMemberAdd2;
	}

	public void setHhOrganizationName(String hhOrganizationName) {
		this.hhOrganizationName = hhOrganizationName;
	}

	public void setHhSIN(String hhSIN) {
		this.hhSIN = hhSIN;
	}

	public void setHhSSN(String hhSSN) {
		this.hhSSN = hhSSN;
	}

	public void setHhState(String hhState) {
		this.hhState = hhState;
	}

	public void setHhStreet(String hhStreet) {
		this.hhStreet = hhStreet;
	}

	public void setHhZip(String hhZip) {
		this.hhZip = hhZip;
	}

	public void setHomeFromTime(String homeFromTime) {
		this.homeFromTime = homeFromTime;
	}

	public void setHomePhoneNumber(String homePhoneNumber) {
		HomePhoneNumber = homePhoneNumber;
	}

	public void setHomeToTime(String homeToTime) {
		this.homeToTime = homeToTime;
	}

	public void setHouseHoldMemberValues(ArrayList<String> houseHoldMemberValues) {
		HouseHoldMemberValues = houseHoldMemberValues;
	}

	public void setIndcity(String indcity) {
		Indcity = indcity;
	}

	public void setIndstate(String indstate) {
		Indstate = indstate;
	}

	public void setIndStreet(String indStreet) {
		IndStreet = indStreet;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public void setIndustryOther(String industryOther) {
		IndustryOther = industryOther;
	}

	public void setIndZip(String indZip) {
		IndZip = indZip;
	}

	public void setIsTest(String isTest) {
		this.isTest = isTest;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public void setJobTitleOther(String jobTitleOther) {
		this.jobTitleOther = jobTitleOther;
	}

	public void setLastIndName(String lastIndName) {
		this.lastIndName = lastIndName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setLastName2(String lastName2) {
		this.lastName2 = lastName2;
	}

	public void setLastNameHHMOVE2Searchpage(String lastNameHHMOVE2Searchpage) {
		this.lastNameHHMOVE2Searchpage = lastNameHHMOVE2Searchpage;
	}

	public void setLastNameHHMOVESearchpage(String lastNameHHMOVESearchpage) {
		this.lastNameHHMOVESearchpage = lastNameHHMOVESearchpage;
	}

	public void setLastNameSearchpage(String lastNameSearchpage) {
		this.lastNameSearchpage = lastNameSearchpage;
	}

	public void setLastNameSearchpage_sept(String lastNameSearchpage_sept) {
		this.lastNameSearchpage_sept = lastNameSearchpage_sept;
	}

	public void setLastNameSS2CFirstCust(String lastNameSS2CFirstCust) {
		this.lastNameSS2CFirstCust = lastNameSS2CFirstCust;
	}

	public void setLastNameSS2CSecondCust(String lastNameSS2CSecondCust) {
		this.lastNameSS2CSecondCust = lastNameSS2CSecondCust;
	}

	public void setLicenceNumber(String licenceNumber) {
		this.licenceNumber = licenceNumber;
	}

	public void setLicensedStateOrProv(String licensedStateOrProv) {
		this.licensedStateOrProv = licensedStateOrProv;
	}

	public void setLifeEvent(String lifeEvent) {
		this.lifeEvent = lifeEvent;
	}

	public void setLifeEvent2AsOfDate(String lifeEvent2AsOfDate) {
		this.lifeEvent2AsOfDate = lifeEvent2AsOfDate;
	}

	public void setLifeEventOther(String lifeEventOther) {
		this.lifeEventOther = lifeEventOther;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public void setLinkedClients(String linkedClients) {
		this.linkedClients = linkedClients;
	}

	public void setLivingArrangements(String livingArrangements) {
		this.livingArrangements = livingArrangements;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public void setMailingType(String mailingType) {
		this.mailingType = mailingType;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public void setmAttention(String mAttention) {
		this.mAttention = mAttention;
	}

	public void setmCity(String mCity) {
		this.mCity = mCity;
	}

	public void setmCountry(String mCountry) {
		this.mCountry = mCountry;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public void setMiddleName2(String middleName2) {
		this.middleName2 = middleName2;
	}
	
	public void setmNotes(String mNotes) {
		this.mNotes = mNotes;
	}

	public void setMostimportanttoyou(String mostimportanttoyou) {
		this.mostimportanttoyou = mostimportanttoyou;
	}

	public void setMostimportanttoyouOther(String mostimportanttoyouOther) {
		this.mostimportanttoyouOther = mostimportanttoyouOther;
	}

	public void setMoveCustomerOneHHMOVE(String moveCustomerOneHHMOVE) {
		this.moveCustomerOneHHMOVE = moveCustomerOneHHMOVE;
	}

	public void setMoveCustomerTwoHHMOVE(String moveCustomerTwoHHMOVE) {
		this.moveCustomerTwoHHMOVE = moveCustomerTwoHHMOVE;
	}

	public void setMoveNameData(String moveNameData) {
		this.moveNameData = moveNameData;
	}

	public void setMovingCity(String movingCity) {
		this.movingCity = movingCity;
	}

	public void setMovingState(String movingState) {
		this.movingState = movingState;
	}

	public void setMovingZip(String movingZip) {
		this.movingZip = movingZip;
	}

	public void setmProvince(String mProvince) {
		this.mProvince = mProvince;
	}

	public void setMstate(String mstate) {
		this.mstate = mstate;
	}

	public void setmStreet(String mStreet) {
		this.mStreet = mStreet;
	}

	public void setmStreet1(String mStreet1) {
		this.mStreet1 = mStreet1;
	}

	public void setmSubDivision(String mSubDivision) {
		this.mSubDivision = mSubDivision;
	}

	public void setMzip(String mzip) {
		this.mzip = mzip;
	}

	public void setNextReviewDate(String nextReviewDate) {
		this.nextReviewDate = nextReviewDate;
	}

	public void setNumberOfEmployees(String numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public void setOccupationOther(String occupationOther) {
		this.occupationOther = occupationOther;
	}

	public void setOccupationStatus(String occupationStatus) {
		this.occupationStatus = occupationStatus;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public void setOrganizationRevenue(String organizationRevenue) {
		this.organizationRevenue = organizationRevenue;
	}

	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}

	public void setOrgBusinessPhoneNum(String orgBusinessPhoneNum) {
		this.orgBusinessPhoneNum = orgBusinessPhoneNum;
	}



	public void setOrgEmailAddress1(String orgEmailAddress1) {
		this.orgEmailAddress1 = orgEmailAddress1;
	}

	public void setOrgName(String orgName) {
		OrgName = orgName;
	}

	public void setOrgName2(String orgName2) {
		OrgName2 = orgName2;
	}

	public void setOrgNameSearchpage(String orgNameSearchpage) {
		this.orgNameSearchpage = orgNameSearchpage;
	}

	


	public void setOtherRegZip(String otherRegZip) {
		OtherRegZip = otherRegZip;
	}

	public void setPermissionText(String permissionText) {
		this.permissionText = permissionText;
	}

	public void setPersonalInfoAsOfDate(String personalInfoAsOfDate) {
		this.personalInfoAsOfDate = personalInfoAsOfDate;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public void setPhoneNumber1(String phoneNumber1) {
		this.phoneNumber1 = phoneNumber1;
	}
	

	public void setPhoneUsage(String phoneUsage) {
		this.phoneUsage = phoneUsage;
	}


	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public void setPolicyStateOrProv(String policyStateOrProv) {
		this.policyStateOrProv = policyStateOrProv;
	}

	
	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}

	public void setPreferredLanguagesAllowedValues(
			String preferredLanguagesAllowedValues) {
		this.preferredLanguagesAllowedValues = preferredLanguagesAllowedValues;
	}

	public void setPresentHHMember(String presentHHMember) {
		this.presentHHMember = presentHHMember;
	}

	public void setPreviousReviewDate(String previousReviewDate) {
		this.previousReviewDate = previousReviewDate;
	}

	
	
	public void setProductType(String productType) {
		this.productType = productType;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	
	

	public void setrCity(String rCity) {
		this.rCity = rCity;
	}


	public void setRegion(String region) {
		this.region = region;
	}

	public void setRegion2(String region2) {
		this.region2 = region2;
	}




	public void setShareType(String shareType) {
		this.shareType = shareType;
	}

	public void setsINCustomerOne(String sINCustomerOne) {
		this.sINCustomerOne = sINCustomerOne;
	}

	public void setSINCustomerOne(String sINCustomerOne) {
		this.sINCustomerOne = sINCustomerOne;
	}

	public void setSINCustomerTwo(String sINCustomerTwo) {
		this.sINCustomerTwo = sINCustomerTwo;
	}

	public void setSinNum(String sinNum) {
		this.sinNum = sinNum;
	}

	public void setSinOne(String sinOne) {
		this.sinOne = sinOne;
	}

	public void setSinTwo(String sinTwo) {
		this.sinTwo = sinTwo;
	}

	public void setSpecificDays(String specificDays) {
		this.specificDays = specificDays;
	}

	public void setSS1CFirstCustomer(String sS1CFirstCustomer) {
		SS1CFirstCustomer = sS1CFirstCustomer;
	}

	public void setSs2cFirstCustomer(String ss2cFirstCustomer) {
		this.ss2cFirstCustomer = ss2cFirstCustomer;
	}

	public void setSs2cFirstCustomerHHMOVE(String ss2cFirstCustomerHHMOVE) {
		this.ss2cFirstCustomerHHMOVE = ss2cFirstCustomerHHMOVE;
	}

	public void setSs2cSecondCustomer(String ss2cSecondCustomer) {
		this.ss2cSecondCustomer = ss2cSecondCustomer;
	}

	public void setSs2cSecondCustomerHHMOVE(String ss2cSecondCustomerHHMOVE) {
		this.ss2cSecondCustomerHHMOVE = ss2cSecondCustomerHHMOVE;
	}

	public void setSSN(String sSN) {
		SSN = sSN;
	}

	public void setSSNCustomerOne(String sSNCustomerOne) {
		this.sSNCustomerOne = sSNCustomerOne;
	}

	public void setSSNCustomerTwo(String sSNCustomerTwo) {
		this.sSNCustomerTwo = sSNCustomerTwo;
	}

	public void setSsnNum(String ssnNum) {
		this.ssnNum = ssnNum;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setState2(String state2) {
		State2 = state2;
	}

	public void setStateSearchPage(String stateSearchPage) {
		this.stateSearchPage = stateSearchPage;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setTaxIdNumber(String taxIdNumber) {
		this.taxIdNumber = taxIdNumber;
	}

	public void setTemplates(String templates) {
		this.templates = templates;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	public void settINCustomerOne(String tINCustomerOne) {
		this.tINCustomerOne = tINCustomerOne;
	}

	public void settINCustomerTwo(String tINCustomerTwo) {
		this.tINCustomerTwo = tINCustomerTwo;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setToTime(String toTime) {
		this.toTime = toTime;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public void setUpdateCustomerInterest(String updateCustomerInterest) {
		this.updateCustomerInterest = updateCustomerInterest;
	}

	public void setUpdateEmailAddress(String updateEmailAddress) {
		this.updateEmailAddress = updateEmailAddress;
	}

	public void setUpdateEmployerName(String updateEmployerName) {
		this.updateEmployerName = updateEmployerName;
	}

	public void setUpdateEmploymentAsOfDate(String updateEmploymentAsOfDate) {
		this.updateEmploymentAsOfDate = updateEmploymentAsOfDate;
	}

	public void setUpdateJobTitle(String updateJobTitle) {
		this.updateJobTitle = updateJobTitle;
	}

	public void setUpdateJobTitleOther(String updateJobTitleOther) {
		this.updateJobTitleOther = updateJobTitleOther;
	}

	public void setUpdateLastName(String updateLastName) {
		this.updateLastName = updateLastName;
	}

	public void setUpdateLifeEvent(String updateLifeEvent) {
		this.updateLifeEvent = updateLifeEvent;
	}

	public void setUpdateLifeEventOther(String updateLifeEventOther) {
		this.updateLifeEventOther = updateLifeEventOther;
	}

	public void setUpdateOccupation(String updateOccupation) {
		this.updateOccupation = updateOccupation;
	}

	public void setUpdateOccupationOther(String updateOccupationOther) {
		this.updateOccupationOther = updateOccupationOther;
	}

	public void setUpdateOccupationStatus(String updateOccupationStatus) {
		this.updateOccupationStatus = updateOccupationStatus;
	}

	public void setUpdatePhoneNumber(String updatePhoneNumber) {
		this.updatePhoneNumber = updatePhoneNumber;
	}

	public void setUpdateXDate(String updateXDate) {
		this.updateXDate = updateXDate;
	}

	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}

	public void setUsSSN(String usSSN) {
		this.usSSN = usSSN;
	}

	public void setUsSSN_Combine(String usSSN_Combine) {
		this.usSSN_Combine = usSSN_Combine;
	}

	public void setWorkPhoneNumber(String workPhoneNumber) {
		WorkPhoneNumber = workPhoneNumber;
	}

	public void setXdate(String xdate) {
		this.xdate = xdate;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public void setZip2(String zip2) {
		this.zip2 = zip2;
	}

	public void setZipHHMOVE2SearchPage(String zipHHMOVE2SearchPage) {
		this.zipHHMOVE2SearchPage = zipHHMOVE2SearchPage;
	}

	public void setZipHHMOVESearchPage(String zipHHMOVESearchPage) {
		this.zipHHMOVESearchPage = zipHHMOVESearchPage;
	}

	public void setZipSearchPage(String zipSearchPage) {
		this.zipSearchPage = zipSearchPage;
	}

	public void setZipSearchPage_sept(String zipSearchPage_sept) {
		this.zipSearchPage_sept = zipSearchPage_sept;
	}

	public void setZipSS2C(String zipSS2C) {
		this.zipSS2C = zipSS2C;
	}

	public String getSecondAliasFirstName() {
		return secondAliasFirstName;
	}

	public void setSecondAliasFirstName(String secondAliasFirstName) {
		this.secondAliasFirstName = secondAliasFirstName;
	}

	public String getSecondAliasLastName() {
		return secondAliasLastName;
	}

	public void setSecondAliasLastName(String secondAliasLastName) {
		this.secondAliasLastName = secondAliasLastName;
	}
	
	public String getCanadaPhone() {
		return canadaPhone;
	}

	public void setCanadaPhone(String canadaPhone) {
		this.canadaPhone = canadaPhone;
	}
	
	public String getCanadaZip() {
		return canadaZip;
	}

	public void setCanadaZip(String canadaZip) {
		this.canadaZip = canadaZip;
	}
	
	public String getPolicyNumber1() {
		return policyNumber1;
	}
	
	public void setPolicyNumber1(String policyNumber1) {
		this.policyNumber1 = policyNumber1;
	}

	public String getPortalTestId() {
		return portalTestId;
	}

	public void setPortalTestId(String portalTestId) {
		this.portalTestId = portalTestId;
	}

	public String getPortalDomain() {
		return portalDomain;
	}

	public void setPortalDomain(String portalDomain) {
		this.portalDomain = portalDomain;
	}

	public String getPortalPassword() {
		return portalPassword;
	}

	public void setPortalPassword(String portalPassword) {
		this.portalPassword = portalPassword;
	}

	public String getUrlPortal() {
		return urlPortal;
	}

	public void setUrlPortal(String urlPortal) {
		this.urlPortal = urlPortal;
	}
}
