package sf.client.service.healthSuite.helpers;

import java.io.BufferedWriter;


public class TransferObject {
	BufferedWriter resultsFile =null;
	private String resultFileName = null;
	private String resultFilePath = null;
	private String userAlias = null;
	public BufferedWriter getResultsFile() {
		return resultsFile;
	}
	public void setResultsFile(BufferedWriter resultsFile) {
		this.resultsFile = resultsFile;
	}
	/**
	 * @return the resultFileName
	 */
	public String getResultFileName() {
		return resultFileName;
	}

	/**
	 * @param resultFileName
	 *            the resultFileName to set
	 */
	public void setResultFileName(String resultFileName) {
		this.resultFileName = resultFileName;
	}
	public String getResultFilePath() {
		return resultFilePath;
	}

	/**
	 * @param resultFilePath
	 *            the resultFilePath to set
	 */
	public void setResultFilePath(String resultFilePath) {
		this.resultFilePath = resultFilePath;
	}
	private String message=null;


	public String getMessage() {
		return message;
	}

	public  void setMessage(String message) {
		this.message = message;
	}
	public String getUserAlias() {
		return userAlias;
	}
	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}

}
