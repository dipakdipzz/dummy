package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;

public class SW_IndCustIntlChar_Scenario13 extends BaseScript {
	int count = 0;
	String query = "select * from SW_IndCustIntlChar_Scenario13";

	public void executeScript() throws Exception

	{
		/**
		 * click on Version URL
		 */
		createCustTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();
		createCustTasks.setCustomerSearchTopFrame();
		/**
		 * Create With International Characters.
		 */
		createCustTasks.createIndividualWithAdditionalMembers();

		/**
		 * Add an Individual
		 *//*
		scenarioTasks.addIndividualinHouseholdPage();
		scenarioTasks.setTopFramewithDefaultContent();

		*//**
		 * Refresh HH page
		 *//*
		scenarioTasks.refreshHHPage_SW();

		*//**
		 * Add an Organization
		 *//*
		scenarioTasks.addOrganizationinHouseholdPage();
		scenarioTasks.setTopFramewithDefaultContent();

		/**
		 * Refresh HH page
		 
		scenarioTasks.refreshHHPage_SW();

		*//**
		 * verifying the added members
		 *//*
		scenarioTasks.verifyAddedIndOrgCustomerInHHPage(clientE2ETO
				.getHhOrganizationName());*/

		/**
		 * Customer Information verifications
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();

		/**
		 * Add alias with International Characters
		 */
		updateTasks.addFirstAlias();

		/**
		 * Add alias with International Characters
		 *//*
		updateTasks.addSecondAlias();*/

		/**
		 * Add US Address
		 */
		updateTasks.addAddressCustomerInfo();

		/**
		 * Update Address
		 */
		updateTasks.updateAddressCustomerInfo();

		/**
		 * Click Change Of Address and Cancel the window
		 */
		scenarioTasks.clickChageAddress();
		scenarioTasks.clickCancelChangeAddress();
		scenarioTasks.setTopFramewithDefaultContent();
		/**
		 * Add Email
		 */
		updateTasks.addEmailCustomerInfo();

		/**
		 * Update Email
		 */
		updateTasks.updateEmail();

		/**
		 * Remove Email
		 */
		updateTasks.removeEmail();
		updateTasks.setTopFramewithDefaultContent();

		/**
		 * Personal Info
		 */
		updateTasks.updatePersonalInfoCustomerInfo();

		/**
		 * Add,Update & Delete Customer Interest
		 * 
		 */
		updateTasks.addCustomerInterestsCustomerInfo();
		updateTasks.updateCustomerInterestUpdate();
		updateTasks.removeInterest();

		/**
		 * Add,Update & Delete Employment
		 * 
		 */
		updateTasks.updateEmploymentAddEmployment();
		updateTasks.updateEmploymentUpdate();
		updateTasks.updateEmploymentRemove();

		/**
		 * Add,Update & Delete Life Events
		 **/
		scenarioTasks.lifeEventsAddEventSC1();
		updateTasks.lifeEventsUpdate();
		updateTasks.lifeEventsRemove();
		/**
		 * Navigate back to HH Page
		 * 
		 */
		scenarioTasks.clickHHPageCustomer();
		scenarioTasks.setTopFrame();
		scenarioTasks.handleCimsVersion();

		/**
		 * *Validate Inactive Policies tab
		 */

		scenarioTasks.clickInactivePolicies();
		scenarioTasks.printInactivePolicies();

		/**
		 * Validate the Payment/Billing History screen
		 * 
		 */
		scenarioTasks.clickPaymentBillingHistory();
		/**
		 * Search and Select Two Customers and Click on Next link.
		 *//*
		combineTasks.verifySearchandSelectTwoCustomersPageABS();
		*//**
		 * Navigate to Customer Combine screen using the CUSTOMER menu option
		 * and combine two customers.
		 *//*
		combineTasks.verifyInfoandClickCombine();
		*//**
		 * Search and Select Customer from Search and Select one Customer Page.
		 *//*
		separateCustTasks.verifySearchandSelectOneCustomerPageABS();
		*//**
		 * Separating a Customer.
		 *//*
		separateCustTasks.separateCustomer();
		*//**
		 * Navigate to Household Maintenance screen and perform Household Move
		 * transaction.
		 *//*

		*//** 
		 *//*
		hhNavigationTasks.verifyHHMovesMoveMemberBetweenTwoHouseholdsABS();
*/
		/**
		 * Navigating to Customer Search Page
		 */
		scenarioTasks.setTopFramewithDefaultContent();
		scenarioTasks.closeHHPage_SW();
		scenarioTasks.setCustomerSearchTopFrame();
		/**
		 * customer search
		 */
		separateCustTasks.launchHHPageFromCustomerSearchPage();
		/**
		 * Customer Information verifications
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();
		/**
		 * Verifying that policies are listed in the �Account/Policy Roles� for
		 * customer in the Customer information screen.
		 */
		scenarioTasks.printAccountsAndPolicesFromCustomerInfoPage();
		/**
		 * Launch & Validate the Customer Profile Print document
		 */
		updateTasks.launchAndValidateCustomerProfilePrint();

	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil
						.loadTestDataSWIndCustIntlCharScenario13(dbresultSet,
								clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);

				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(this.getClass().getSimpleName());

				scenarioTasks
						.createResultsFile(resultsFileName(), scriptName());

				executeScript();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}