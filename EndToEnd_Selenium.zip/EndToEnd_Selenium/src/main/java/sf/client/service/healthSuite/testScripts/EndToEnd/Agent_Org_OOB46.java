package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.OOBOrgnizationTasks;
import sf.client.service.healthSuite.tasks.SSNSINTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class Agent_Org_OOB46 extends BaseScript{
	int count=0;
	String query = "select * from Agent_Org_OOB46";
	public void executeScript() throws Exception{
		/**
		 * OOB_ORG  - 01---> OOB Organization Search - Auto Policy as Verification Data.
		 */
		String policyType = clientE2ETO.getTypeName();
		if(policyType.equalsIgnoreCase("Auto")){
			oobOrgnizationTasks.fetchOrgDataAuto();
		}
		/**
		 * OOB_ORG  - 02---> OOB Organization Search - Fire Policy as Verification Data,
		 * OOB_ORG  - 03---> OOB Organization Search - Organization New Mexico  address
		 */
		if(policyType.equalsIgnoreCase("Fire")){
			oobOrgnizationTasks.fetchOrgDataFire();
		}
		
		/**
		 * OOB_ORG  - 04--->OOB Organization Search - Policy as Verification Data.
		 */
		
		if(policyType.equalsIgnoreCase("AutoP")){
			oobOrgnizationTasks.fetchOrgDataAuto();
		}
		
		/**
		 * OOB_ORG  - 05---> OOB Organization Search - Policy as Verification Data,
		 * OOB_ORG  - 06---> Launch CIA page
		 */
		if(policyType.equalsIgnoreCase("AutoQ")){
			oobOrgnizationTasks.fetchData();
			ssnSINTasks.launchCIA(); 
		}
	
	}
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentOrgOOB46(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				oobOrgnizationTasks = new OOBOrgnizationTasks(clientE2ETO);
				ssnSINTasks = new SSNSINTasks(clientE2ETO);
				if(count==0) {
					launcher = new LaunchApplication(getWATConfig());
					launcher.launchUser(scriptName());
					scenarioTasks.createResultsFile(resultsFileName(),scriptName());
					ssnSINTasks.launchCustomerSeachPage();
				}
				executeScript();
				count++;
			}
		}catch (Exception e){
			e.printStackTrace();
		}
	}
}


