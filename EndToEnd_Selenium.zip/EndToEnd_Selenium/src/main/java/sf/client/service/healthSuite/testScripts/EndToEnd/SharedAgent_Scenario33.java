package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;

public class SharedAgent_Scenario33 extends BaseScript {

	int count = 0;
	String query = "select * from SharedAgent_Scenario33";

	public void executeScript() throws Exception {
		if (createCustTasks.isAgentBusinessSystemExist()) {
			createCustTasks.clickCustomer();
			createCustTasks.verifySearchBookInCSPageSharedAgent();
			createCustTasks.launchPortalCustomerSearchPage();
			createCustTasks.selectPortalCustomerFromSearch();
			createCustTasks.setWindow("Household Information", 30, 2);
			createCustTasks.verifyHouseholdPageLaunched();
		}
	}

	public void scriptMain() {

		try {

			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);

			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {

				clientE2ETO = databaseUtil.loadTestDataSharedAgentScenario33(
						dbresultSet, clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());

				createCustTasks
						.createResultsFile(resultsFileName(), scriptName());
				executeScript();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
