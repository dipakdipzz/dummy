package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.ConnectCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHRelationshipTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;


public class CAAM_Agent_CreateIndCust_SearchCustomer extends BaseScript {
	
	
	String query = "select * from Agent_CreateIndCust_Scenario10";
	public void executeScript() {

		/**Validate Customer Search Page*/
		createCustTasks.launchCustomerSeachPage();
		/**validate Create Individual & Create Organization link Exists in Customer Search page.*/
		scenarioTasks.verifyCreateIndOrg();
		/**Click the 'Create Individual'  link */
		createCustTasks.clickCreateIndividual();
		
		/**Validate the ability to Create Individual customer*/
		createCustTasks.createIndividualCustomer();
		createCustTasks.closeHHPage();
		createCustTasks.setParentWindow();
		createCustTasks.launchNewlyCreatedCustomerSearchPage();
		createCustTasks.launchNewCustomerHHPage();
		createCustTasks.closeHHPage();
		createCustTasks.setParentWindow();
		createCustTasks.launchPortalCustomerSearchPage();
		createCustTasks.launchHouseholdpageFromPortal();
		createCustTasks.launchPortalCustomerSearchPage();
	}
	
	public void scriptMain()  {
		try {
			transferObject=setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet =databaseUtil.getCoreData(transferObject);
			while(dbresultSet.next()){
				clientE2ETO = databaseUtil.loadTestDataAgentCreateIndCustScenario10(dbresultSet,clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks =new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				connectCustTasks = new ConnectCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				hhRelationshipTasks = new HHRelationshipTasks(clientE2ETO);				
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				scenarioTasks.createResultsFile(resultsFileName(),scriptName());
				executeScript();
			}
			
			
		}
			catch (Exception e) {
			e.printStackTrace();
		}
	}
}


