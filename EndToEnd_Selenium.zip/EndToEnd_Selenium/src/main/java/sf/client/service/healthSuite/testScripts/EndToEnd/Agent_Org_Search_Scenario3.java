package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.HHnavigationTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.RemoveFromBookTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.SeparateCustomersTasks;

public class Agent_Org_Search_Scenario3 extends BaseScript {

	private static String QRY = "select * from Agent_Org_Search_Scenario3";

	public void executeScript() throws Exception {
		/** Launching HH Page */
		productTasks.launchHouseholdpageFromPortal();
		/** Add Previous Review date */
		productTasks.verifyPreviousReviewDateFunctionality();
		/** Add Next Review date */
		productTasks.verifyNextReviewDateFunctionality();
		/** Verify Accounts/Policies page */
		productTasks.verifyAccountsPoliciesWithOthers();
		/** Create Auto & Bank Policy */
		productTasks.createAutoBankPolicesWithOthers();
		/** Validate Auto & Bank Policies */
		productTasks.verifyCreatedAutoBankPolicies();
		/** Updating Auto Policy */
		productTasks.updateAutoPoliciesWithOthers();
		/** Remove Bank Policy */
		productTasks.removeBankPoliciesWithOthers();
	/*	*//** Add an Individual *//*
		scenarioTasks.addIndividualinHouseholdPage();*/
		/** Validate Remove from Book */
		removeFromBookTasks.verifyRemoveFromBook();
		/** Validate Active Customer to remove */
		removeFromBookTasks.validateActiveCustomerRemoval();
		/** Search and Select Customer from Search and Select one Customer Page. */
		separateCustTasks.verifySearchandSelectOneCustomerPage();
		/** Separating a Customer *//*
		separateCustTasks.separateCustomer();*/
		/**Closing HH page*/
		removeFromBookTasks.closeHHPage();
		/** Validate Help On this Page */
		productTasks.setWindow(EndToEndConstants.CUSTOMER_SEARCH, 30, 2);
		productTasks.launchHelpOnthisPage_Household();
		productTasks.validateHelpOnthisPageInCustomerSearchPage();
	}

	public void scriptMain() {

		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(QRY);
			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataAgentOrgSearchScenario3(
						dbresultSet, clientE2ETO);
				removeFromBookTasks = new RemoveFromBookTasks(clientE2ETO);
				hhNavigationTasks = new HHnavigationTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				separateCustTasks = new SeparateCustomersTasks(clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				productTasks = new ProductTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				launcher = new LaunchApplication(getWATConfig());
				launcher.launchUser(scriptName());
				createCustTasks.createResultsFile(resultsFileName(),
						scriptName());
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
