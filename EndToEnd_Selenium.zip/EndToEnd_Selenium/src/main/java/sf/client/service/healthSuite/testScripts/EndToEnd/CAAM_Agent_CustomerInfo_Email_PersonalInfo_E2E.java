package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.common.helpers.TestDataObject;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.helpers.DatabaseUtil;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;
import sf.client.service.healthSuite.tasks.UpdateCustomersTasks;
import sf.client.service.healthSuite.to.ClientE2ETO;

public class CAAM_Agent_CustomerInfo_Email_PersonalInfo_E2E extends BaseScript {

	int count = 0;
	String query = "select * from Agent_CreateIndCust_Scenario11";

	public void executeScript() throws Exception {
		/**
		 * Click on the 'View Customer Information' option in the Action drop down button for a Customer in the Household member section. Navigates to Cust Info page. Navigate back to Household page 
		 */
		scenarioTasks.clickActionsViewCustomerInfoABS();
		
		
		/**
		 *  Selecting Update Personal Information Option from the Action Drop Down Menu
		 */
		scenarioTasks.clickActionsUpdatePersonalInformation();
		
		/**
		 * Validate that the new Phone changes/updates are displayed in the Active Customer Bar  
		 */	 
		
		/*scenarioTasks.validateActiveCustomerBar();
		updateTasks.validatePhoneNumbersDisplayedActiveCustomerBar();*/
	
		/**
		 *  Customer Information verifications
		 */
		createCustTasks.launchCustomerInfoPageFromHHPage();

		/**
		 *  Add Email
		 */
		updateTasks.addEmailCustomerInfo();

		/**
		 *  Personal Info
		 */
		updateTasks.updatePersonalInfoCustomerInfo();

		/**
		 *  Customer Interest
		 */
		updateTasks.addCustomerInterestsCustomerInfo();

		/**
		 * Validate Close option displayed under the Refresh/Close Menu in
		 * Household Page
		 */
		scenarioTasks.clickHHPageCustomer();
		updateTasks.closeHHPage();
		updateTasks.setParentWindow();
		//launcher.shutdownServer();
	}

	public void scriptMain() {

		try {
			databaseUtil = new DatabaseUtil();
			clientE2ETO = new ClientE2ETO();
			transferObject = new TestDataObject();
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);

			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil
						.loadTestDataAgentCreateIndCustScenario11(dbresultSet,
								clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				updateTasks = new UpdateCustomersTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				//launcher = new LaunchApplication(getWATConfig());
				//launcher.launchUser(this.getClass().getSimpleName());

				scenarioTasks
						.createResultsFile(resultsFileName(), scriptName());

				executeScript();

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
