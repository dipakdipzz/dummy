package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.TextField;

/**
 * This class contains all the page objects related to CW Agent
 */
public class CWAgentCSObjects {
	
	private static final String RADIO_BUTTON_SEARCHBYTYPE_AGENTNAME = "name=searchByType";
	private static final String TEXT_AGENTNAME_SEARCH_CRITERIAL = "id=agentNameSearchCriteria.lastName";
	private static final String TEXT_AGENTNAME_SEARCH_CRITERIAF = "id=agentNameSearchCriteria.firstName";
	private static final String TEXT_AGENTNAME_SEARCH_CRITERIAZ = "id=agentNameSearchCriteria.zip";
	private static final String BUTTON_SEARCH = "id=agentNameSearch";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final RadioButton RADIOBUTTON_SEARCHBYTYPE_AGENTNAME = new RadioButton(RADIO_BUTTON_SEARCHBYTYPE_AGENTNAME);
		public static final TextField TEXT_AGENTNAME_SEARCH_LASTNAME =new TextField(TEXT_AGENTNAME_SEARCH_CRITERIAL);
		public static final TextField TEXT_AGENTNAME_SEARCH_FIRSTNAME = new TextField(TEXT_AGENTNAME_SEARCH_CRITERIAF);
		public static final TextField TEXT_AGENTNAME_SEARCH_ZIP = new TextField(TEXT_AGENTNAME_SEARCH_CRITERIAZ);
		public static final Button BUTTON_AGENT_SEARCH = new Button(BUTTON_SEARCH);
		
	}
}
