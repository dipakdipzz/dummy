package sf.client.service.common.helpers;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class EncryptAndDecryptUtil {

	/**
	 * This method is used to get the decrypted version of a String depends on
	 * the count
	 * 
	 * @param password
	 * @param count
	 * @return
	 */
	private static final String ALGO = "AES";
	private static final byte[] KEY_VALUE = new byte[] { 'T', 'h', 'e', 'B',
			'e', 's', 't', 'S', 'e', 'c', 'r', 'e', 't', 'K', 'e', 'y' };

	@SuppressWarnings("restriction")
	public static String getEncrypted(String Data, int count) {
		try {
			Cipher cipher = Cipher.getInstance(ALGO);
			cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(KEY_VALUE, ALGO));
			byte[] encVal = cipher.doFinal(Data.getBytes());
			return new sun.misc.BASE64Encoder().encode(encVal);
		} catch (Exception e) {
			return "";
		}
	}

	@SuppressWarnings("restriction")
	public static String getDecrypted(String encryptedData, int count) {
		try {
			Cipher cipher = Cipher.getInstance(ALGO);
			System.out.println("1:");
			cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(KEY_VALUE, ALGO));
			System.out.println("2:"+encryptedData);
			byte[] decryptedValue = new sun.misc.BASE64Decoder()
					.decodeBuffer(encryptedData);
			System.out.println("3:"+decryptedValue);
			byte[] decValue = cipher.doFinal(decryptedValue);
			System.out.println("decValue:"+new String(decValue));
			return new String(decValue);
		} catch (Exception e) {
			System.out.println("String(decValue):");
			return "";
		}
	}
	
	public static void main(String[] args) {
		System.out.println(getEncrypted("Test1hsx", 2));
	}

}