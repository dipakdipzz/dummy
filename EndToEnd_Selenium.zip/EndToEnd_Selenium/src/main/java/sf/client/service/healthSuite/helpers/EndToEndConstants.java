package sf.client.service.healthSuite.helpers;

public class EndToEndConstants {
	
public static final String PROSPECT_NO_APPQUOTES = "Prospect customer with no apps/quotes";
public static final String EXCUSTOMER_NO_APPQUOTES_GREATER_60 ="Ex-customers with no apps/quotes > 60";
public static final String HOUSEHOLD_INFORMATION = "Household Information";
public static final String CUSTOMER_INFORMATION = "Customer Information";
public static final String ADDMEMBERS = "Add Member(s)";
public static final String WORK_PHONE="Work Phone";
public static final String TITLE_AGENT_SELECTION="Agent Selection";
public static final String ADD_ACCOUNTSPOLICIES_WITHOTHERS="Add Accounts/Policies With Others";
public static final String CREATE_ORAGANIZATION="Create Organization";
public static final String CREATE_ORAGANIZATION_AGENT="Create Organization Customer";
public static final String CREATE_INDIVIDUAL_PORTAL="Create Individual Customer";
public static final String PRESENTATION_KIT="Presentation Kit";
public static final String REMOVE_ALL_PHONE="Remove All Phone";
public static final String CIMS_ERROR_PAGE="CIMS Error Page";
public static final String CUSTOMER_PROFILE_PRINT="Customer Profile Print";
public static final String CIMS_VERSION="Select CIMS 2.0 Version";
public static final String AGENT_BUSINESS_SYSTEM="Agents Business System";
public static final String  PRODUCT_SELECTION="Product Selection";
public static final String  PRODUCTION_MANAGER="Production Manager";
public static final String ACTIVITY_LIST="Activity";
public static final String CREATE_FOLLOW_UP="New Activity Follow-up";
public static final String CREATE_NOTE="New Activity Note";
public static final String UPDATE_ACCOUNTSPOLICIES_WITHOTHERS="Update Accounts / Policies With Others";
public static final String UPDATE_PERSONAL_INFORMATION="Update Personal Information ";
public static final String HOUSEHOLD="Household";
public static final String CUSTOMER_SEARCH="ABS Customer Search 1.1";
public static final String xpath = "//div[@class='dijitPopup dijitMenuPopup']/table/tbody/";
public static final String DIRECT_MAIL = "EBR";
public static final String ERROR_MESSAGE = "Please enter a valid SSN/SIN. A valid SSN/SIN cannot begin with 000, cannot contain all 9's with a 0-8 at the end, be all the same number or be in consecutive order (123456789). If entering an SSN/SIN please make sure that the entered number is 9 digits and all numeric.";


}
