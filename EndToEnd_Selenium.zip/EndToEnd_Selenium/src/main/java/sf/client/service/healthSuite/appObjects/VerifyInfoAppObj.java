package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Link;

public class VerifyInfoAppObj {
	/*public static final Button BUTTON_COMBINEBUTTON =  new Button("id=doCombine");
	public static final  Link LINK_Previous = new Link("text=< Previous");*/
	
	private static final String VERIFYINFOAPP_BUTTON_COMBINE =  "id=doCombine";
	private static final  String VERIFYINFOAPP_LINK_PREVIOUS = "text=< Previous";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final Button BUTTON_COMBINE =  new Button(VERIFYINFOAPP_BUTTON_COMBINE);
		public static final  Link LINK_PREVIOUS = new Link(VERIFYINFOAPP_LINK_PREVIOUS);
	}
}
