package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ProductTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class Agent_Ind_MR_Scenario2 extends BaseScript
{
	String query = "select * from Agent_Ind_MR_Scenario2";
	 	public void executeScript() { 
	 		/**Launching HH Page*/
	 		productTasks.launchHouseholdpageFromPortal();
	 		/**Click on the MR icon displayed for all Auto/Fire/Life/Health/SFPP statefarm policies*/
	 		productTasks.validateInsuranceAccountPolicies();
	 		/**Verify that  MR Icon is not displayed for Bank/Mutual Funds/Assurant Health/Policy with Others Policies*/
	 		productTasks.verifyMRIconHHPage();
			/**Launching New Change-PT & Payment Link for Fire Policy*/
	 	  combineTasks.launchNewChangePTFirePolicy();	
	 		/**Launching Payment Links for Fire Policy*/
	 		combineTasks.launchPaymentFirePolicy();
	 		/**Launching  New Change-PT Link for Auto Policy*/
	 		combineTasks.launchNewChangePTAutoPolicy();
	 		/**Launching Add A Vehicle Link for Auto Policy*/
	 		combineTasks.launchAddVechicleAutoPolicy();
			/**Launching New App/Quote from Customer Search Page ACTION dropdown menu*/
			scenarioTasks.launchNewAppQuoteFromActionDropdownSearchPage();
			/**Launching New Production Manager from Customer Search Page ACTION dropdown menu*/
			scenarioTasks.launchProductionManagerFromActionDropdownSearchPage();
			/**Launching New Activity List from Customer Search Page ACTION dropdown menu*/
			scenarioTasks.launchNewActivityFromActionDropdownSearchPage();
			/**Launching New Create Follow-Up from Customer Search Page ACTION dropdown menu*/
			scenarioTasks.launchNewCreateFollowUpFromActionDropdownSearchPage();
			/**Launching New Create Note from Customer Search Page ACTION dropdown menu*/
			scenarioTasks.launchNewCreateNoteFromActionDropdownSearchPage();
			/**Launching New Direct Mail History from Customer Search Page ACTION dropdown menu*/
			scenarioTasks.launchDirectMailHistoryFromActionDropdownSearchPage();
			/**Launching New Marketing Opportunities from Customer Search Page ACTION dropdown menu*/
			scenarioTasks.launchMktngOpprFromActionDropdownSearchPage();
			/**Launching New Customer Profile Print from Customer Search Page ACTION dropdown menu*/
			scenarioTasks.launchCustomerProfilePrintFromActionDropdownSearchPage();
			/**Click ACCOUNTS & POLICIES button.*/
			combineTasks.clickAccountandPoliciesTwisty();
			/**Validate the Action drop down is not displayed in the Accounts & Policies lightbox for Health,Life,Bank,MutualFund*/
	 		productTasks.validateLifeHealthBankMutualFundsActionDropDownNotdisplay();
	 		
	 		launcher.shutdownServer();
	 	}
	 	public void scriptMain() {
				try {
					transferObject=setTestDataObject(transferObject);
					transferObject.setDbQuery(query);
					dbresultSet =databaseUtil.getCoreData(transferObject);
					while(dbresultSet.next()){
						clientE2ETO = databaseUtil.loadTestDataAgentIndMRScenario2(dbresultSet,clientE2ETO);
						createCustTasks=new CreateCustomersTasks(clientE2ETO);
						productTasks =new ProductTasks(clientE2ETO);
						scenarioTasks=new ScenarioTasks(clientE2ETO);
						combineTasks=new CombineCustomersTasks(clientE2ETO);
						launcher = new LaunchApplication(getWATConfig());
						launcher.launchUser(this.getClass().getSimpleName());
						productTasks.createResultsFile(resultsFileName(),scriptName());
						executeScript();
					}
				} 
					catch (Exception e) {
					e.printStackTrace();
				}
				
		}
	 }
