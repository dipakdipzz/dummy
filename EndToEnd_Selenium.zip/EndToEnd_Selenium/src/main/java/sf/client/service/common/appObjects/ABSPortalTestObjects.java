package sf.client.service.common.appObjects;

import java.awt.TextArea;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.RadioButton;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

public class ABSPortalTestObjects {
	
	private static final String ABSPORTAL_AGENTS_BUSINESS_SYSTEM = "title=Agents Business System";
	private static final String ABSPORTAL_LINK_CUSTOMER = "text=Customer";
	private static final String ABSPORTAL_TEXTFIELD_lASTNAME = "name=lastName";
	private static final String ABSPORTAL_TEXTFIELD_FIRSTNAME = "name=firstName";
	private static final String ABSPORTAL_BUTTON_SUBMITSEARCH = "name=submitSearch";
	private static final String ABSPORTAL_BUTTON_CLEAR = "name=submitClear";
	private static final String ABSPORTAL_RADIOBUTTON_SEARCHOPTION = "name=searchOption";
	private static final String ABSPORTAL_TEXTFIELD_CITY = "name=city";
	private static final String ABSPORTAL_TEXTFIELD_POSTALCODE = "name=postalCode";
	private static final String ABSPORTAL_LINK_TESTLINKS ="text=Test Links";
	private static final String ABSPORTAL_LINK_TESTLINKS_COMBINE_SEPARATE ="text=R15363 Combine/Separate";
	private static final String ABSPORTAL_LINK_SERVICES_TAB = "text=Services";
	private static final String ABSPORTAL_LINK_CUSTOMERS_AND_HOUSEHOLD = "text=Customers & Household";
	private static final String ABSPORTAL_LINK_CUSTOMER_COMBINE_AND_SEPARATE = "text=Customer Combine & Separate";
	private static final String ABSPORTAL_TEXTFIELD_ACCOUNTNUMBER = "id=accountNumber";
	private static final String ABSPORTAL_SPAN_CLOSE ="text=Close";
	private static final String ABSPORTAL_LINK_HELPONTHISPAGE = "text=help on this page";
	private static final String ABSPORTAL_TEXTFIELD_AGENTALIAS = "name=simulateUser";
	private static final String  ABSPORTAL_BUTTON_AGENTSEARCH = "name=submitSimulate";
	private static final String ABSPORTAL_RADIOBUTTON_PHONE = "id=P2QX9A00_phoneSearchOption";
	private static final String ABSPORTAL_RADIOBUTTON_ACCTPOLICY = "id=P2QX9A00_policySearchOption";
	private static final String ABSPORTAL_TEXTFIELD_PHONENUMBER = "id=P2QX9A00_phoneNumber";
	private static final String ABSPORTAL_TEXTFIELD_POLICYNUMBER = "id=P2QX9A00_policyNumber";
	
	private static final String SPLUNK_TEXTAREA_SEARCH = "name=q";
	private static final String SPLUNK_TEXTFIELD_STARTDATE = "class=*earliest-date*";
	private static final String SPLUNK_TEXTFIELD_ENDDATE = "class=*latest-date*";
	
	private static final String  ART_LOGIN ="href=login*";
	private static final String ART_LOGIN_ID = "name=TxtLogin";
	private static final String ART_PASSWORD = "name=Txtpassword";
	private static final String ART_SUBMIT = "name=Submit";
	private static final String ART_SUBMIT_OK = "name=submit1";
	private static final String ART_UPDATE_TOTALS = "id=uptot";
	
	private static final String ART_WSRS = "href=mainmen*13";
	private static final String ART_WEEKEND_DATE = "id=txtweekend";
	private static final String ART_TEXT_HOURS_11 = "name=TXTHOURS11";
	private static final String ART_TEXT_HOURS_12 = "name=TXTHOURS12";
	private static final String ART_TEXT_HOURS_13 = "name=TXTHOURS13";
	private static final String ART_TEXT_HOURS_14 = "name=TXTHOURS14";
	private static final String ART_TEXT_HOURS_15 = "name=TXTHOURS15";
	private static final String ART_TEXT_HOURS_16 = "name=TXTHOURS16";
	private static final String ART_TEXT_HOURS_17 = "name=TXTHOURS17";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final String AGENTS_BUSINESS_SYSTEM = ABSPORTAL_AGENTS_BUSINESS_SYSTEM;
		public static final Link LINK_CUSTOMER = new Link(ABSPORTAL_LINK_CUSTOMER);
		public static final TextField TEXTFIELD_lASTNAME = new TextField(ABSPORTAL_TEXTFIELD_lASTNAME);
		public static final TextField TEXTFIELD_FIRSTNAME = new TextField(ABSPORTAL_TEXTFIELD_FIRSTNAME);
		public static final Button BUTTON_SUBMITSEARCH = new Button(ABSPORTAL_BUTTON_SUBMITSEARCH);
		public static final Button BUTTON_CLEAR = new Button(ABSPORTAL_BUTTON_CLEAR);
		public static final RadioButton RADIOBUTTON_SEARCHOPTION = new RadioButton(ABSPORTAL_RADIOBUTTON_SEARCHOPTION);
		public static final TextField TEXTFIELD_CITY = new TextField(ABSPORTAL_TEXTFIELD_CITY);
		public static final TextField TEXTFIELD_POSTALCODE = new TextField(ABSPORTAL_TEXTFIELD_POSTALCODE);
		public static final Link LINK_TESTLINKS =new Link(ABSPORTAL_LINK_TESTLINKS);
		public static final Link LINK_TESTLINKS_COMBINE_SEPARATE =new Link(ABSPORTAL_LINK_TESTLINKS_COMBINE_SEPARATE);
		public static final Link SERVICES_TAB = new Link(ABSPORTAL_LINK_SERVICES_TAB);
		public static final Link LINK_CUSTOMERS_AND_HOUSEHOLD_TAB = new Link(ABSPORTAL_LINK_CUSTOMERS_AND_HOUSEHOLD);
		public static final Link LINK_COMB_SEPARATE = new Link(ABSPORTAL_LINK_CUSTOMER_COMBINE_AND_SEPARATE);
		public static final TextField TEXTFIELD_ACCOUNTNUMBER = new TextField(ABSPORTAL_TEXTFIELD_ACCOUNTNUMBER);
		public static final Span SPAN_CLOSE =new Span(ABSPORTAL_SPAN_CLOSE);
		public static final Link HELPONTHISPAGE = new Link(ABSPORTAL_LINK_HELPONTHISPAGE);
		public static final TextField TEXTFIELD_AGENTALIAS = new TextField(ABSPORTAL_TEXTFIELD_AGENTALIAS);
		public static final Button BUTTON_AGENTSEARCH = new Button(ABSPORTAL_BUTTON_AGENTSEARCH);
		public static final RadioButton RADIOBUTTON_PHONE = new RadioButton(ABSPORTAL_RADIOBUTTON_PHONE);
		public static final RadioButton RADIOBUTTON_ACCTPOLICY = new RadioButton(ABSPORTAL_RADIOBUTTON_ACCTPOLICY);
		public static final TextField TEXTFIELD_PHONENUMBER = new TextField(ABSPORTAL_TEXTFIELD_PHONENUMBER);
		public static final TextField TEXTFIELD_POLICYNUMBER = new TextField(ABSPORTAL_TEXTFIELD_POLICYNUMBER);
		
		public static final TextField TEXTAREA_SEARCH = new TextField(SPLUNK_TEXTAREA_SEARCH);
		public static final TextField TEXTFIELD_STARTDATE = new TextField(SPLUNK_TEXTFIELD_STARTDATE);
		public static final TextField TEXTFIELD_ENDDATE = new TextField(SPLUNK_TEXTFIELD_ENDDATE);
		
		public static final Link LINK_ART_LOGIN = new Link(ART_LOGIN);
		public static final TextField TEXTFIELD_ART_LOGIN_ID = new TextField(ART_LOGIN_ID);
		public static final TextField TEXTFIELD_ART_PASSWORD = new TextField(ART_PASSWORD);
		public static final Button BUTTON_ART_SUBMIT = new Button(ART_SUBMIT);
		public static final Button BUTTON_ART_SUBMIT_OK = new Button(ART_SUBMIT_OK);
		public static final Button BUTTON_ART_UPDATE_TOTALS = new Button(ART_UPDATE_TOTALS);
		public static final Link LINK_ART_WSRS = new Link(ART_WSRS);
		public static final TextField TEXTFIELD_ART_WEEKEND_DATE = new TextField(ART_WEEKEND_DATE);
		public static final TextField TEXTFIELD_ART_TEXT_HOURS_11 = new TextField(ART_TEXT_HOURS_11);
		public static final TextField TEXTFIELD_ART_TEXT_HOURS_12 = new TextField(ART_TEXT_HOURS_12);
		public static final TextField TEXTFIELD_ART_TEXT_HOURS_13 = new TextField(ART_TEXT_HOURS_13);
		public static final TextField TEXTFIELD_ART_TEXT_HOURS_14 = new TextField(ART_TEXT_HOURS_14);
		public static final TextField TEXTFIELD_ART_TEXT_HOURS_15 = new TextField(ART_TEXT_HOURS_15);
		public static final TextField TEXTFIELD_ART_TEXT_HOURS_16 = new TextField(ART_TEXT_HOURS_16);
		public static final TextField TEXTFIELD_ART_TEXT_HOURS_17 = new TextField(ART_TEXT_HOURS_17);
	}
}
