package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Image;
import statefarm.widget.gui.Label;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.TextField;

public class ReviewDatePopupObjects {
	
	// public static final Div REVIEWDATES_LABEL = new Div("id=pageContent");
	// public static final TextField LASTREVIEWDATE_TEXT = new TextField("id=reviewDate.lastReviewDate");
	// public static final TextField NEXTREVIEWDATE_TEXT = new TextField("id=reviewDate.nextReviewDate");
	// public static final Link HELPONTHISPAGE=new Link("text=help on this page");
	// public static final Link FOLLOWUP_LINK=new Link("text=Follow Up");
	// public static final Link NOTES_LINK=new Link("text=Note");
	// public static final Link PRESENTATIONKIT_LINK=new Link("text=Presentation Kit");
	// public static final Button SAVE=new Button("id=save");
	// public static final Button CANCEL=new Button("id=cancel");
	// public static final Image image_displayDatePicker = new Image("alt=Display date picker");
	// public static final Image image_Next_Review = new Image("alt=Display date picker");
	// public static final Label label_create = new Label("text=Create:");
	// public static final Link PREVIOUSREVIEWDATE= new Link("id=lastReviewDate");

	private static final String REVIEWDATEPOPUP_DIV_REVIEWDATES = "id=pageContent";
	private static final String REVIEWDATEPOPUP_TEXTFIELD_LASTREVIEWDATE = "id=reviewDate.lastReviewDate";
	private static final String REVIEWDATEPOPUP_TEXTFIELD_NEXTREVIEWDATE = "id=reviewDate.nextReviewDate";
	private static final String REVIEWDATEPOPUP_LINK_HELPONTHISPAGE = "text=help on this page";
	private static final String REVIEWDATEPOPUP_LINK_FOLLOWUP = "text=Follow Up";
	private static final String REVIEWDATEPOPUP_LINK_NOTES = "text=Note";
	private static final String REVIEWDATEPOPUP_LINK_PRESENTATIONKIT = "text=Presentation Kit";
	private static final String REVIEWDATEPOPUP_BUTTON_SAVE = "id=save";
	private static final String REVIEWDATEPOPUP_BUTTON_CANCEL = "id=cancel";
	private static final String REVIEWDATEPOPUP_IMAGE_DISPLAY_DATEPICKER = "alt=Display date picker";
	private static final String REVIEWDATEPOPUP_LABEL_CREATE = "text=Create:";
	private static final String REVIEWDATEPOPUP_LINK_PREVIOUSREVIEWDATE = "id=lastReviewDate";

	@WidgetIDs
	public static class WidgetInfos {
		public static final Div DIV_REVIEWDATES = new Div(REVIEWDATEPOPUP_DIV_REVIEWDATES);

		public static final TextField TEXTFIELD_LASTREVIEWDATE = new TextField(REVIEWDATEPOPUP_TEXTFIELD_LASTREVIEWDATE);
		public static final TextField TEXTFIELD_NEXTREVIEWDATE = new TextField(REVIEWDATEPOPUP_TEXTFIELD_NEXTREVIEWDATE);

		public static final Link LINK_HELPONTHISPAGE = new Link(REVIEWDATEPOPUP_LINK_HELPONTHISPAGE);
		public static final Link LINK_FOLLOWUP = new Link(REVIEWDATEPOPUP_LINK_FOLLOWUP);
		public static final Link LINK_NOTES = new Link(REVIEWDATEPOPUP_LINK_NOTES);
		public static final Link LINK_PRESENTATIONKIT = new Link(REVIEWDATEPOPUP_LINK_PRESENTATIONKIT);
		public static final Link LINK_PREVIOUSREVIEWDATE = new Link(REVIEWDATEPOPUP_LINK_PREVIOUSREVIEWDATE);

		public static final Button BUTTON_SAVE = new Button(REVIEWDATEPOPUP_BUTTON_SAVE);
		public static final Button BUTTON_CANCEL = new Button(REVIEWDATEPOPUP_BUTTON_CANCEL);

		public static final Image IMAGE_DISPLAY_DATEPICKER = new Image(REVIEWDATEPOPUP_IMAGE_DISPLAY_DATEPICKER);

		public static final Label LABEL_CREATE = new Label(REVIEWDATEPOPUP_LABEL_CREATE);
	}
}
