package sf.client.service.healthSuite.tasks;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.HouseHoldMove_PageObjects;
import sf.client.service.healthSuite.appObjects.OutOfBookConformationPageObjects;
import sf.client.service.healthSuite.appObjects.OutOfBookPoliciesAndAccountsPageObjects;
import sf.client.service.healthSuite.appObjects.OutOfBookSearchPageObjects;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.wat.util.KeyboardUtility;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.manager.Verify;

public class OOBIndividualTasks extends HouseHoldTasks {

	/**
	 * Empty Constructor
	 */
	public OOBIndividualTasks() {

	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param clientE2ETO
	 */
	public OOBIndividualTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}

	/**
	 * Click on OOB Search Radio button in Customer search page if it exists.
	 * 
	 * @throws ScriptException
	 * @throws sf.client.service.common.helpers.ScriptException
	 */
	public void clickSearchOOB() throws ScriptException,
			sf.client.service.common.helpers.ScriptException {
		waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON, 15);
		if (OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.OOB_RADIOBUTTON.click();
			Verify.verifyTrue(true,
					MessageUtility.RADIOBUTTON_OUTOFBOOK_CLICKED);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_OUTOFBOOK_NOTFOUND);
		}
	}

	/**
	 * Click on individual search Radio button in Customer search page.
	 * <p>
	 * If it not exists appropriate error message will be written to result
	 * file.
	 * 
	 * @throws ScriptException
	 */
	public void clickSearchIndividaul() throws ScriptException {
		waitForPageLoad(
				OutOfBookSearchPageObjects.WidgetInfos.RADIOBUTTON_SELECTINDIVIDUAL, 15);
		if (OutOfBookSearchPageObjects.WidgetInfos.RADIOBUTTON_SELECTINDIVIDUAL.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.RADIOBUTTON_SELECTINDIVIDUAL.click();
			Verify.verifyTrue(true,
					MessageUtility.RADIOBUTTON_INDIVIDUAL);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_INDIVIDUAL_NOTFOUND);
		}
	}

	/**
	 * This method is used to do two things
	 * <p>
	 * i)Click on OOB Search Radio button in Customer search page if it exists.
	 * ii)Click on individual search Radio button in Customer search page.
	 * <p>
	 * If it not exists appropriate error message will be written to result
	 * file.
	 */
	public void clickOutOfBookAndIndividualRadioButton() {
		try {
			if (isPortalSearchPageExist()) {
				clickSearchOOB();
				clickSearchIndividaul();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Verify whether OOB Search page exists for Searching.
	 * 
	 * @return returns true if OOB Search page exists.
	 */
	public boolean isOOBIndividualPageExists() {
		
		waitForTime(5);
		if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Enter last name,First name, Postal Code,Province and City in Search page.
	 */
	public void enterNameSectionInOOBIndividualPage() {
		try {
			if (isOOBIndividualPageExists()) {
				enterLastName();
				enterFirstName();
				enterZip(); 
				selectStateOrProvince(); 
				enterCity();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}

		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * If the OOB Search page exists enter the Verification data.this method
	 * will do,
	 * <p>
	 * 1)Select the Line of Business 2)Enter the Account policy number. 3)Select
	 * the Verification state. 4)Enter the SSN number.
	 */
	public void enterVerificationDataInOOBIndividualPage() {
		try {
			if (isOOBIndividualPageExists()) {
				selectLOB();
				enterAccountPolicyNum();
				selectVerificationState();
				enterSSN();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * If the OOB Search page exists enter the Verification data.this method
	 * will do,
	 * <p>
	 * 1)Select the Line of Business 2)Enter the Account policy number. 3)Select
	 * the Verification state. 4)Enter the USSSN number.
	 */
	public void enterVerificationDataOOBIndividualPage() {
		try {
			if (isOOBIndividualPageExists()) {
				selectLOB();
				enterAccountPolicyNum();
				selectVerificationState();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Enter the Moving To data in OOB Search Page.
	 * <p>
	 * 1)Select New State 2)Enter Moving city. 3) Enter Moving Postal.
	 */
	public void enterMovingToDataInOOBIndividualPage() {
		try {
			if (isOOBIndividualPageExists()) {
				selectMoveState();
				enterMoveCity();
				enterMoveZip();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.ABSSEARCHPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * This Method is used to enter the last name in OOB Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterLastName() throws ScriptException {
		
		if (OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT.click();
		}
		if (clientE2ETO.getLastName() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_LASTNAME.setText(clientE2ETO
						.getLastName());
				Verify.verifyTrue(true,  clientE2ETO.getLastName() + MessageUtility.LASTNAME_VALUE);
						
			} else {
				Verify.verifyTrue(false,  MessageUtility.TEXT_LASTNAME);
			}
		}
	}

	/**
	 * This Method is used to enter the First name in OOB Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterFirstName() throws ScriptException {
		if (clientE2ETO.getFirstName() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_FIRSTNAME.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_FIRSTNAME.setText(clientE2ETO
						.getFirstName());
				Verify.verifyTrue(true, "'" + clientE2ETO.getFirstName() + MessageUtility.FIRSTNAME_VALUE);
			} else {
				Verify.verifyTrue(false, MessageUtility.TEXT_FIRSTNAME);
			}
		}
	}

	/**
	 * This Method is used to enter the Postal in OOB Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterZip() throws ScriptException {
		if (clientE2ETO.getZip() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_POSTALCODE.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_POSTALCODE.setText(clientE2ETO
						.getZip());
				Verify.verifyTrue(true,  MessageUtility.ZIP_VALUE);
			} else {
				Verify.verifyTrue(false,  MessageUtility.TEXT_ZIP);
			}
		}
	}

	/**
	 * This method is used to select the LOB In OOB Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void selectLOB() throws ScriptException {
		if (clientE2ETO.getLob() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.LIST_VERIFICATIONLOB.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.LIST_VERIFICATIONLOB
						.selectItem(clientE2ETO.getLob());
				Verify.verifyTrue(
						true,clientE2ETO.getLob() + MessageUtility.LINEOFBUSINESS);

			} else
				Verify.verifyTrue(false, MessageUtility.LINEOFBUSINESS_NOTFOUND);
		}
	}

	/**
	 * This method is used to enter the Account Policy Number In OOB Search
	 * Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterAccountPolicyNum() throws ScriptException {
		if (clientE2ETO.getPolicyNumber() != null) {
			
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_ACCOUNTPOLICYNUMBER.exists()) {
				enterMandatoryfieldtoEnablebutton(
						OutOfBookSearchPageObjects.WidgetInfos.TEXT_ACCOUNTPOLICYNUMBER,
						clientE2ETO.getPolicyNumber());
				Verify.verifyTrue(
						true, clientE2ETO.getPolicyNumber()+ MessageUtility.POLICYNUMBER);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.TEXT_POLICYNUMBER_NOTFOUND);
			}
		}
	}

	/**
	 * This method is used to Check for the particular Customer in the Search
	 * results.
	 * 
	 * @param cName
	 *            customer name to be Checked
	 * @return returns true if the given Customer exists
	 */
	public boolean isCustomerExists(String cName) {

		Link CUSTOMER_NAME_LINK = new Link("text=" + cName);
		waitForPageLoad(CUSTOMER_NAME_LINK, 20);
		if (CUSTOMER_NAME_LINK.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method is used to verify the SSN is disabled
	 * 
	 * @throws ScriptException
	 */
	public void isSSNDisable() throws ScriptException {
		if (!OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBSSN.isEnabled()) {
			Verify.verifyTrue(true, MessageUtility.SSN_DISABLED);
		} else {
			Verify.verifyTrue(false, MessageUtility.SSN_NOTDISABLED);
		}
	}

	/**
	 * Click on Search button in the OOB Search page.
	 * 
	 * @throws ScriptException
	 */
	public void clickSearch() throws ScriptException {
		waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.BUTTON_SEARCHSUBMIT, 10);
		if (OutOfBookSearchPageObjects.WidgetInfos.BUTTON_SEARCHSUBMIT.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.BUTTON_SEARCHSUBMIT.click();
			Verify.verifyTrue(true, MessageUtility.BUTTON_SEARCH);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_SEARCH_NOTFOUND);
		}
	}

	/**
	 * Verify the Searching Customer is Exists.
	 * <p>
	 * If the Search Customer exists write an appropriate message to result
	 * file.
	 * 
	 * @throws ScriptException
	 */
	public void verifySearch() throws ScriptException {

		Link searchResult = new Link("text=" + clientE2ETO.getCustomerOneData());
		waitForPageLoad(searchResult, 25);
		boolean custFlag = isCustomerExists(clientE2ETO.getCustomerOneData());
		if (custFlag) {
			Verify.verifyTrue(true, clientE2ETO.getCustomerOneData() + MessageUtility.CUSTOMER_FOUND);
		} else {
			Verify.verifyTrue(false, clientE2ETO.getCustomerOneData() + MessageUtility.CUSTOMER_NOTFOUND);
		}

	}

	/**
	 * Verify the Searching Customer is Exists in OOB Search Page.
	 * <p>
	 * If the Search Customer exists write an appropriate message to result
	 * file.
	 * 
	 * @throws ScriptException
	 */
	public void verifyOobSearch() throws ScriptException {

		Link searchResult = new Link("text="
				+ clientE2ETO.getCustomerSearchpage());
		waitForPageLoad(searchResult, 25);
		boolean custFlag = isCustomerExists(clientE2ETO.getCustomerSearchpage());
		if (custFlag) {
			Verify.verifyTrue(true, clientE2ETO.getCustomerSearchpage() + MessageUtility.CUSTOMER_FOUND);
		} else {
			Verify.verifyTrue(false, clientE2ETO.getCustomerSearchpage() + MessageUtility.CUSTOMER_NOTFOUND);
		}

	}

	/**
	 * Click on Clear button in the OOB Search page
	 * 
	 * @throws ScriptException
	 */
	public void clearData() throws ScriptException {
		waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT, 15);
		if (OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.BUTTON_CLEARSUBMIT.click();
		}
	}

	/**
	 * Click on the Customer name link if exists in the resultant table.
	 * 
	 * @throws ScriptException
	 */
	public void clickCustomerMCLBTable() throws ScriptException {
		Link link = new Link("text=" + clientE2ETO.getCustomerOneData());
		waitForPageLoad(link, 20);
		if (link.exists()) {
			link.click();
			setWindow("Out of Book Confirmation",20,1);
			
		} else {
			Verify.verifyTrue(false, clientE2ETO.getCustomerOneData() + MessageUtility.CUSTOMER_NOTFOUND); 
		}
	}

	/**
	 * Click on the Customer name link if exists in the resultant OOB Search
	 * table.
	 * 
	 * @throws ScriptException
	 */
	public void clickOobCustomerMCLB_Table() throws ScriptException {
		Link link = new Link("text=" + clientE2ETO.getCustomerSearchpage());
		waitForPageLoad(link, 20);
		if (link.exists()) {
			link.click();
			setWindow("Out of Book Confirmation",30,2);
		} else {
			Verify.verifyTrue(false, clientE2ETO.getCustomerSearchpage() + MessageUtility.CUSTOMER_NOTFOUND);
		}
	}

	/**
	 * verify whether OOB Page launched.
	 * <p>
	 * If the OOB Page launched write an appropriate message to result file.
	 * 
	 * @return returns if OOB Page launched.
	 * @throws ScriptException
	 */
	public boolean isOutOfBookConformationLaunched() throws ScriptException {
		waitForPageLoad(
				OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1,
				10);
		if (OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1
				.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.OUTOFBOOKPAGE_LAUNCHED);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * verify whether OOB Page launched.
	 * <p>
	 * If the OOB Page launched write an appropriate message to result file.
	 * Checking for the Error Page.if the Error page appears it will write the
	 * appropriate error message
	 * 
	 * @throws ScriptException
	 */
	public void outOfBookConformationLaunched() throws ScriptException {
		waitForPageLoad(
				OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1,
				10);
		if (OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1
				.exists()) {
			Verify.verifyTrue(true, MessageUtility.OUTOFBOOKPAGE_LAUNCHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.OUTOFBOOKPAGE_NOTLAUNCHED);
			isErrorPage("Out of Book Confirmation");
		}
	}

	/**
	 * Click on Reason for Transfer radio button.
	 * 
	 * @throws ScriptException
	 */
	public void selectReasonForTransfer() throws ScriptException {
		if (isOutOfBookConformationLaunched()) {
			if (OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1
					.exists()) {
				OutOfBookConformationPageObjects.WidgetInfos.RADIOBUTTON_SELECTEDREASONAGENTINITI_1
						.click();
				Verify.verifyTrue(true, MessageUtility.REASONFORTRANSFER);

			} else {
				Verify.verifyTrue(false, MessageUtility.REASONFORTRANSFER_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(false, MessageUtility.OUTOFBOOKPAGE_NOTLAUNCHED);
		}
	}

	/**
	 * Check the Customer Permission Over 18 Radio button in OOB Page.
	 * 
	 * @throws ScriptException
	 */
	public void selectCustomerPermissionOver18() throws ScriptException {

		if (isOutOfBookConformationLaunched()) {
			if (OutOfBookConformationPageObjects.WidgetInfos.CHECKBOX_SEARCHEDCUSTOMERPERMISSIONOVER18
					.exists()) {
				OutOfBookConformationPageObjects.WidgetInfos.CHECKBOX_SEARCHEDCUSTOMERPERMISSIONOVER18
						.click();
				Verify.verifyTrue(true,
						MessageUtility.SEARCHEDCUSTOMERPERMISSIONOVER18_CLICKED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.SEARCHEDCUSTOMERPERMISSIONOVER18_NOTFOUND);
			}
		} else {
				Verify.verifyTrue(false, MessageUtility.OUTOFBOOKPAGE_NOTLAUNCHED);
		}

	}

	/**
	 * Click on Next link in OOB Page.
	 * 
	 * @throws ScriptException
	 */
	public void clickNextOOC() throws ScriptException {
		if (OutOfBookConformationPageObjects.WidgetInfos.LINK_NEXT.exists()) {
			OutOfBookConformationPageObjects.WidgetInfos.LINK_NEXT.click();
			Verify.verifyTrue(true,
					MessageUtility.LINK_NEXT);

		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_NEXT_NOTCLICKED);

		}
	}

	/**
	 * Click on the Go To HH Page link in the OOB Page.
	 * 
	 * @throws ScriptException
	 */
	public void clickGoToHHPage() throws ScriptException {
		if (isOOBPolicyPageLaunched()) {
			if (OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE
					.exists()) {
				OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE.click();
				KeyboardUtility.sendKeys("{ENTER}");
				Verify.verifyTrue(true,
						MessageUtility.GOTOHHPAGE_CLICKED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.GOTOHHPAGE_NOTFOUND);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.GOTOHHPAGE_NOTFOUND);
		}

	}

	/**
	 * Select the verification state in OOB Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void selectVerificationState() throws ScriptException {
		if (clientE2ETO.getPolicyStateOrProv() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.LIST_VERIFICATIONSTATEPROV.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.LIST_VERIFICATIONSTATEPROV
						.selectItem(clientE2ETO.getPolicyStateOrProv());
				Verify.verifyTrue(true, MessageUtility.VERIFICATIONSTATE);
			} else {
				Verify.verifyTrue(false, MessageUtility.VERIFICATIONSTATE_NOTFOUND);
			}
		}
	}

	/**
	 * Select the Moving To State in OOB Search page.
	 * 
	 * @throws ScriptException
	 */
	public void selectMoveState() throws ScriptException {
		if (clientE2ETO.getMovingState() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.LIST_MOVINGTOSTATEPROV.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.LIST_MOVINGTOSTATEPROV
						.selectItem(clientE2ETO.getMovingState());
				Verify.verifyTrue(true, MessageUtility.MOVINGSTATE);
			} else {
				Verify.verifyTrue(false, MessageUtility.MOVINGSTATE_NOTFOUND);
			}
		}
	}

	/**
	 * Enter the Moving To City in OOB Search page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMoveCity() throws ScriptException {
		if (clientE2ETO.getMovingCity() != null) {
			if ((OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBCITYMOVE).exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBCITYMOVE.setText(clientE2ETO
						.getMovingCity());
				Verify.verifyTrue(true, clientE2ETO.getMovingCity() + MessageUtility.MOVINGCITY);
			} else {
				Verify.verifyTrue(false,  MessageUtility.MOVINGCITY_NOTFOUND);
			}
		}
	}

	/**
	 * Enter the Moving Zip in OOB Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterMoveZip() throws ScriptException {
		if (clientE2ETO.getMovingZip() != null) {
			if ((OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBPOSTALCODEMOVE).exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBPOSTALCODEMOVE
						.setText(clientE2ETO.getMovingZip());
				Verify.verifyTrue(true, clientE2ETO.getMovingZip() + MessageUtility.MOVINGZIP);
			} else {
				Verify.verifyTrue(false, MessageUtility.MOVINGZIP_NOTFOUND);
						
			}
		}
	}

	/**
	 * Check whether the OOb Policy page is launched
	 * 
	 * @return return true if the OOb Policy page is launched
	 * @throws ScriptException
	 */
	public boolean isOOBPolicyPageLaunched() throws ScriptException {
		waitForPageLoad(
				OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE, 10);
		if (OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE.exists()) {
			return true;

		} else {
			return false;
		}
	}

	/**
	 * Check whether the OOB Policy page is launched
	 * <p>
	 * Write an appropriate message in the result file
	 * 
	 * @throws ScriptException
	 */
	public void verifyOOBPolicyPageLaunched() throws ScriptException {
		waitForPageLoad(
				OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE, 10);
		if (OutOfBookPoliciesAndAccountsPageObjects.WidgetInfos.LINK_GOTOHHPAGE.exists()) {
			Verify.verifyTrue(true, MessageUtility.OUTOFBOOKPOLICIESPAGE_LAUCNHED);
		} else {
			Verify.verifyTrue(false, MessageUtility.OUTOFBOOKPOLICIESPAGE_NOTLAUCNHED);
		}
	}

	/**
	 * This method is used to verify the HH Members after launching from the OOB
	 * policies page.
	 * 
	 * @throws ScriptException
	 */
	public void verifyHHMembers() throws ScriptException {
		try {
			clickCustomerMCLBTable();
			setTopFrame();
			outOfBookConfirmationPage();
			waitForTime(4);
			oobPolicyPage();
			oobHHPage();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Verify the OOB Household members after launching from the OOB Search
	 * page.
	 * 
	 * @throws ScriptException
	 */
	public void verifyOobHHMembers() throws ScriptException {
		try {
			clickOobCustomerMCLB_Table();
			waitForTime(30);
			setTopFrame();
			selectAgentInHhMoves();
			outOfBookConfirmationPage();
			oobPolicyPage();
			oobHHPage();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * This method is used to verify whether OOB policies page launched and
	 * select the mandatory field in that page then click on the Next link.
	 * 
	 */
	public void outOfBookConfirmationPage() {
		try {
			outOfBookConformationLaunched();
			selectReasonForTransfer();
			selectCustomerPermissionOver18();
			hhMembersSelection();
			clickNextOOC();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * This method is used to verify the OOB Policies page and click on Go To HH
	 * Page link.
	 */
	public void oobPolicyPage() {
		try {
			verifyOOBPolicyPageLaunched();
			clickGoToHHPage();
			
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * This method is used to verify the HH Page that is launched from the OOB
	 * Policies page.
	 */
	public void oobHHPage() {
		try {
			isHHPageLaunched();
			verifyHHMembersSection();
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * This method is used to select HHMember in OOB Confirmation Page
	 */
	public void hhMembersSelection() {
		if (isOutOfBookConformationLaunched()) {
			if (clientE2ETO.getHhMemberAdd1() != null) {
				selectHouseHoldMemHHpage(clientE2ETO.getHhMemberAdd1());
				Verify.verifyTrue(true, clientE2ETO.getHhMemberAdd1()
						+ MessageUtility.HHMEMBER_SELECTED);
			}

			if (clientE2ETO.getHhMemberAdd2() != null) {
				selectHouseHoldMemHHpage(clientE2ETO.getHhMemberAdd2());
				Verify.verifyTrue(true, clientE2ETO.getHhMemberAdd2()
						+ MessageUtility.HHMEMBER_SELECTED);
			}
		} else {
			Verify.verifyTrue(false,
					MessageUtility.HHMEMBER_NOTSELECTED);
		}
	}

	/**
	 * This method is used to enter SSN number in the OOB Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterSSN() throws ScriptException {
		if (clientE2ETO.getSSN() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBSSN.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBSSN.setText(clientE2ETO
						.getSSN());
				Verify.verifyTrue(true, MessageUtility.SSN1);

			} else {
				Verify.verifyTrue(false, MessageUtility.SSN_NOTDISPLAYED);

			}
		}
	}

	/**
	 * This method is used to enter USSSN number in the OOB Search Page.
	 * 
	 * @throws ScriptException
	 */
	public void enterOobSSN() throws ScriptException {
		if (clientE2ETO.getUsSSN() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBSSN.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_OOBSSN.setText(clientE2ETO
						.getUsSSN());
				Verify.verifyTrue(true, MessageUtility.SSN1);

			} else {
				Verify.verifyTrue(false, MessageUtility.SSN_NOTDISPLAYED);

			}
		}
	}

	/**
	 * This method is used to Select the Province from the OOB Search page.
	 * 
	 * @throws ScriptException
	 */
	public void selectStateOrProvince() throws ScriptException {
		if (clientE2ETO.getState() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.LIST_STATEPROV.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.LIST_STATEPROV
						.selectItem(clientE2ETO.getState());
				Verify.verifyTrue(true, MessageUtility.STATEORPROVINCE);
			} else {
				Verify.verifyTrue(false, MessageUtility.STATEORPROVINCE_NOTFOUND);
						
			}
		}
	}

	/**
	 * Enter the City in Name section of OOB Search page .
	 * 
	 * @throws ScriptException
	 */
	public void enterCity() throws ScriptException {
		if (clientE2ETO.getCity() != null) {
			if (OutOfBookSearchPageObjects.WidgetInfos.TEXT_CITY.exists()) {
				OutOfBookSearchPageObjects.WidgetInfos.TEXT_CITY.setText(clientE2ETO
						.getCity());
				Verify.verifyTrue(true, MessageUtility.MOVINGCITY);
			} else {
				Verify.verifyTrue(false, MessageUtility.MOVINGCITY_NOTFOUND);
			}
		}
	}

	/**
	 * Verify the Household Member section to verify the Customer.
	 * 
	 * @throws ScriptException
	 */
	public void verifyHHMembersSection() throws ScriptException {

		Div hhMembersSection = new Div("id=tempHHMembersGrid");

		if (hhMembersSection.exists()) {
			Verify.verifyTrue(true, MessageUtility.HOUSEHOLDMEMBERS_BEGIN);
			Verify.verifyTrue(true,"======================================================================\n\n");
			Verify.verifyTrue(true,hhMembersSection.getText() + "\n\n");
			Verify.verifyTrue(true,"======================================================================\n");
			Verify.verifyTrue(true, MessageUtility.HOUSEHOLDMEMBERS_END);

			String divText = hhMembersSection.getText();
			if (clientE2ETO.getHhMemberAdd1() != null) {
				if (divText.indexOf((clientE2ETO.getHhMemberAdd1()))>0) {
					Verify.verifyTrue(true, clientE2ETO.getHhMemberAdd1() + MessageUtility.CUSTOMERS_HOUSEHOLDSECTION);
				} else {
					Verify.verifyTrue(false, MessageUtility.HOUSEHOLDMEMBERSSECTION_NOTEXISTS);
				}
			}

			if (clientE2ETO.getHhMemberAdd2() != null) {
				if (divText.indexOf(clientE2ETO.getHhMemberAdd2()) > 0) {
					Verify.verifyTrue(true, MessageUtility.CUSTOMERS_HOUSEHOLDSECTION);
				} else {
					Verify.verifyTrue(false, MessageUtility.HOUSEHOLDMEMBERSSECTION_NOTEXISTS);
				}
			}

		} else {
			Verify.verifyTrue(false, MessageUtility.HOUSEHOLDMEMBERSSECTION_NOTEXISTS);
		}
	}

	/**
	 * This method is used to Fetch appropriate auto data from the MDB to verify
	 * the Search is Success.
	 */
	public void fetchDataAuto() {
		try {
			clickOutOfBookAndIndividualRadioButton();
			clearData();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataInOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			clickSearch();
			verifySearch();
			clearData();
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * This method is used to Fetch appropriate fire data from the MDB to verify
	 * the Search is Success.
	 */
	public void fetchDataFire() {
		try {
			isOOBIndividualPageExists();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataInOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			clickSearch();
			verifySearch();
			clearData();
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * This method is used to Fetch appropriate SSN data from the MDB to verify
	 * search is Success.
	 */
	public void fetchData4SSN() {
		try {
			isOOBIndividualPageExists();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataInOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			clickSearch();
			verifySearch();
			clearData();
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * This method is used to verify SSN field is dis-abled after selection
	 * Canada state / Province in the Name search details
	 */
	public void fetchDataSSNDisable() {
		try {
			isOOBIndividualPageExists();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataInOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			isSSNDisable();
			clearData();
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * This method is used to launch HH Page through OOB Search Page (life data)
	 * and Verify the HH Members
	 */
	public void fetchDataLifeSF() {
		try {
			clickOutOfBookAndIndividualRadioButton();
			isOOBIndividualPageExists();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataInOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			clickSearch();
			verifySearch();
			verifyHHMembers();
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			e.printStackTrace();
			Verify.verifyTrue(false, e.getMessage());
		}

	}

	/**
	 * This method is used to launch HH Page through OOB Search Page and Verify
	 * the HH Members
	 */
	public void fetchDataOob() {
		try {
			clickOutOfBookAndIndividualRadioButton();
			isOOBIndividualPageExists();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			clickSearch();
			verifyOobSearch();
			verifyOobHHMembers();
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	public void fetchOobData() {
		try {
			clickOutOfBookAndIndividualRadioButton();
			isOOBIndividualPageExists();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			clickSearch();
			waitForTime(5);
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}
	
	public void canadaAgentNotAbleToSearchOnUSOob() {
		try {
			clickOutOfBookAndIndividualRadioButton();
			isOOBIndividualPageExists();
			enterNameSectionInOOBIndividualPage();
			enterVerificationDataOOBIndividualPage();
			enterMovingToDataInOOBIndividualPage();
			clickSearch();
			waitForTime(3);
			verifyErrorMessageForScenario3();
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}
	

	/**
	 * this method is Used click on the Customer tab in the Agent Business
	 * System
	 * 
	 * @throws ScriptException
	 */
	public void clickCustomerTab() throws ScriptException {
		waitForPageLoad(OutOfBookSearchPageObjects.WidgetInfos.WP_LINK_CUSTOMERTAB,10);
		if (OutOfBookSearchPageObjects.WidgetInfos.WP_LINK_CUSTOMERTAB.exists()) {
			OutOfBookSearchPageObjects.WidgetInfos.WP_LINK_CUSTOMERTAB.click();
			Verify.verifyTrue(true, MessageUtility.CUSTOMERTAB_CLICKED);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.CUSTOMERTAB_NOTFOUND);

		}
	}

	/**
	 * relationshipToAgent
	 */
	
	public String getRelationshipToAgent(){
		try{
			if(isCustomerInfoPageExists()){
				WebElement relationshipToAgent = getWebDriverInstance()
						.findElement(
								By.cssSelector("input[id=\"relationshipToAgent\"]"));

				if(relationshipToAgent.isDisplayed()){
					String text=relationshipToAgent.getText();
					return text;
				}
			}
		}catch(Exception exception){
			Verify.verifyTrue(false, exception.getMessage());
		}
		return "";
	}
	
	/**
	 * selecting Agent In HhMoves
	 * 
	 * @throws ScriptException
	 */
	public void selectAgentInHhMoves() throws ScriptException {
		try {
			  /*waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.SELECT_AGENTHHMOVES, 15);
			if (HouseHoldMove_PageObjects.WidgetInfos.SELECT_AGENTHHMOVES.exists()) {
				HouseHoldMove_PageObjects.WidgetInfos.SELECT_AGENTHHMOVES.hover();
				HouseHoldMove_PageObjects.WidgetInfos.SELECT_AGENTHHMOVES.click();
				Verify.verifyTrue(true, MessageUtility.AGENT_SELECTED);
			} else {

			}*/
			waitForTime(20);
			System.out.println("Praveen:"+getWebDriverInstance().findElement(
					By.xpath("//div[@class='leftpt7em']/a")).getText());
			getWebDriverInstance().findElement(
					By.xpath("//div[@class='leftpt7em']/a")).click();
			waitForTime(3);
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyRelationshipToAgent(){
		try{
			if(getRelationshipToAgent().equalsIgnoreCase("Prospect")){
				Verify.verifyTrue(true,"Relationship to Agent: Prospect");
			}else{
				Verify.verifyTrue(false,"Relationship to Agent: Customer is not Prospect Customer");
			}
		}catch(Exception exception){
			Verify.verifyTrue(false, exception.getMessage());
		}
	}
	
	public void verifyActivityCreatedForLoggingAgent(){
		try{
			String activityActions="";
			int i=0;			
			if(isHHPageLaunched()){
				while(true){
					WebElement activity = getWebDriverInstance()
							.findElement(By.cssSelector("div#gridActivity div.dojoxGridView div.dojoxGridScrollbox>div>div>div:nth-child("+i+")"));

					if(activity.isDisplayed()){
						activityActions=activity.getText();
					}else{
						break;
					}
					if(activityActions.contains(new SimpleDateFormat("MM/dd/yyyy").format(new Date())) && activityActions.contains("Out of Book Customer Search")){
						Verify.verifyTrue(true, MessageUtility.ACTIVITY);
						break;
					}
					i++;
				}
			}
		}catch(Exception exception){
			Verify.verifyTrue(false, exception.getMessage());
		}
	}

}
