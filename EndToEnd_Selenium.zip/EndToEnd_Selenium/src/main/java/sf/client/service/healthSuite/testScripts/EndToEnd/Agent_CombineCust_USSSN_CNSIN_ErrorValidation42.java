package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CombineCustomersTasks;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class Agent_CombineCust_USSSN_CNSIN_ErrorValidation42 extends
		BaseScript {
	int rowCount = 0;
	int count = 0;
	String query = "select * from Agent_CombineCust_USSSN_CNSIN_Validation";

	public void executeScript() {
		combineTasks.combineSearchandSelectTwoCustomers();
	}

	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil
						.loadTestDataAgentCombineCustUSSSNCNSINErrorValidation42(
								dbresultSet, clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				combineTasks = new CombineCustomersTasks(clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				if (rowCount == 0) {
					launcher = new LaunchApplication(getWATConfig());
					launcher.launchUser(scriptName());
					createCustTasks.createResultsFile(resultsFileName(),
							scriptName());
					executeScript();
					rowCount++;
				}
				if (clientE2ETO.getIsTest().equalsIgnoreCase("1")
						&& (count == 0)) {
					combineErrorValidations();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void combineErrorValidations(){
		if (createCustTasks.isSelectedTwoCustomersExist()) {
			try {
				createCustTasks
						.appendMessage("**********   Started executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ "  ********* ");
				createCustTasks
						.appendMessage("+++++++++++   Started executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ " +++++++++++");
				createCustTasks.verifyTestCase(clientE2ETO.getTestCaseName());
				createCustTasks
						.appendMessage("**********  Finished executing test case:  "
								+ clientE2ETO.getTestCaseName()
								+ "  ********* ");

			} catch (Exception e) {
				createCustTasks.appendToResultFile(
						false,
						"Exception occured while accessing "
								+ transferObject.getTestcaseName()
								+ " And the error message is: "
								+ e.getMessage());
			}
		} else {
			createCustTasks.appendToResultFile(false,
					"Cannot proceed with Customer Combine Validations as Searched Customer is not availbale in Search results table");
			count++;
		}
	}
}
