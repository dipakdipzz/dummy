package sf.client.service.healthSuite.tasks;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.AddIndividualPageObjects;
import sf.client.service.healthSuite.appObjects.CreateIndividualCustomer;
import sf.client.service.healthSuite.appObjects.RelationshipsScreenTestObjects;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.manager.Verify;

public class HHRelationshipTasks extends HouseHoldTasks {
	public String cellsData = null;

	public HHRelationshipTasks() {
	}

	public HHRelationshipTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}
    /**
     * Adding Individual to Household Relationships
     */
	public void addIndHHRelationship() {
		try {
			waitForPageLoad(RelationshipsScreenTestObjects.WidgetInfos.LINK_ADD_INDIVIDUAL, 15);
			if (RelationshipsScreenTestObjects.WidgetInfos.LINK_ADD_INDIVIDUAL.exists()) {
				click(RelationshipsScreenTestObjects.WidgetInfos.LINK_ADD_INDIVIDUAL,
						MessageUtility.LINK_ADDINDIVIDUAL);
				waitForPageLoad(AddIndividualPageObjects.WidgetInfos.BUTTON_HHADDADDRESS,
						20);
				if (AddIndividualPageObjects.WidgetInfos.BUTTON_HHADDADDRESS.exists()) {
					setTextInTextbox(AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME,
							clientE2ETO.getFirstIndName(),
							clientE2ETO.getFirstIndName()
									+ MessageUtility.FIRSTNAME_VALUE);
					setTextInTextbox(AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME,
							clientE2ETO.getLastIndName(),
							clientE2ETO.getLastIndName() + MessageUtility.LASTNAME_VALUE);
					clickAndChooseSelectAddress();
					AddIndividualPageObjects.WidgetInfos.TEXT_LASTNAME.click();
					AddIndividualPageObjects.WidgetInfos.TEXT_FIRSTNAME.click();
					if (AddIndividualPageObjects.WidgetInfos.BUTTON_CREATEMEMBERSAVE
							.exists()) {
						click(AddIndividualPageObjects.WidgetInfos.BUTTON_CREATEMEMBERSAVE,
								MessageUtility.BUTTON_CREATEMEMBER);
					}
				}
				waitForPageLoad(RelationshipsScreenTestObjects.WidgetInfos.LINK_ADD_INDIVIDUAL,
						10);
				if (RelationshipsScreenTestObjects.WidgetInfos.LINK_ADD_INDIVIDUAL.exists()) {
					String css = "div#householdRelationships";
					if (getWebDriverInstance().findElement(By.cssSelector(css)).isDisplayed()) {
						String Text = getWebDriverInstance().findElement(By.cssSelector(css)).getText();
						if (Text.contains(clientE2ETO.getFirstIndName()
								.toUpperCase()
								+ " "
								+ clientE2ETO.getLastIndName().toUpperCase())) {
							Verify.verifyTrue(true,
									MessageUtility.ADDINDIVIDUAL_SUCCESS);
						} else {
							Verify.verifyTrue(false,
									MessageUtility.ADDINDIVIDUAL_FAIL);
						}
					}

				}

				else {
					Verify.verifyTrue(false,
							MessageUtility.RELATIONSHIPS_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_ADDINDIVIDUAL_NOTFOUND);
			}
		} catch (ScriptException e) {
			Verify.verifyTrue(false, e.getMessage());
		}

	}
    /**
     * Adding Individual to Non-Household Relationships
     */
	public void addIndNonHHRelationship() {
		try {
			Verify.verifyTrue(true, "********Executing steps for adding new individual customer into Relationships (Members Outside the Household) ********");
			String css = "div#pageContent>form[name=\"retrievePartyPartyRelationshipForm\"] div:nth-child(9)>div>div:nth-child(2)>a";
			waitForPageLoad(RelationshipsScreenTestObjects.WidgetInfos.LINK_ADD_INDIVIDUAL, 15);
			if (getWebDriverInstance().findElement(By.cssSelector(css)).isDisplayed()) {
				getWebDriverInstance().findElement(By.cssSelector(css)).click();
				waitForPageLoad(CreateIndividualCustomer.WidgetInfos.TEXT_FIRSTNAME, 10);
				if (CreateIndividualCustomer.WidgetInfos.TEXT_FIRSTNAME.exists()) {
					fillAgentCode();
					setTextInTextbox(
							CreateIndividualCustomer.WidgetInfos.TEXT_FIRSTNAME,
							clientE2ETO.getFirstName2(),
							clientE2ETO.getFirstName2()
									+ MessageUtility.FIRSTNAME_VALUE);
					setTextInTextbox(CreateIndividualCustomer.WidgetInfos.TEXT_LASTNAME,
							clientE2ETO.getLastName2(),
							clientE2ETO.getLastName2()
									+ MessageUtility.LASTNAME_VALUE);
					setTextInTextbox(
							CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_STREET,
							clientE2ETO.getIndStreet(),
							clientE2ETO.getIndStreet()
									+ MessageUtility.STREET_VALUE);
					setTextInTextbox(
							CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_CITY,
							clientE2ETO.getIndcity(), clientE2ETO.getIndcity()
									+ MessageUtility.CITY_VALUE);
					CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_STATE
							.setText(clientE2ETO.getIndstate());
					setTextInTextbox(CreateIndividualCustomer.WidgetInfos.TEXT_MAILING_ZIP,
							clientE2ETO.getIndZip(), clientE2ETO.getIndZip()
									+MessageUtility.ZIP);
					click(AddIndividualPageObjects.WidgetInfos.BUTTON_CREATEMEMBERSAVE,
							MessageUtility.BUTTON_CREATEMEMBER);
					verifyAddressStandzation();
					waitForPageLoad(RelationshipsScreenTestObjects.WidgetInfos.LISTBOX_RELATIONSHIP_CODE);
					if (RelationshipsScreenTestObjects.WidgetInfos.LISTBOX_RELATIONSHIP_CODE.exists()) {
						selectFromListbox(
								RelationshipsScreenTestObjects.WidgetInfos.LISTBOX_RELATIONSHIP_CODE,
								RelationshipsScreenTestObjects.WidgetInfos.LISTBOX_RELATIONSHIP_CODE
										.selectItemAtIndex(1),
								MessageUtility.RELATIONSHIP_SELECTED);
						click(RelationshipsScreenTestObjects.WidgetInfos.BUTTON_SAVE,
								MessageUtility.BUTTON_SAVE);
					}
					waitForPageLoad(
							RelationshipsScreenTestObjects.WidgetInfos.LINK_ADD_INDIVIDUAL, 10);
					if (RelationshipsScreenTestObjects.WidgetInfos.LINK_ADD_INDIVIDUAL.exists()) {
						css = "div#nonHouseholdRelationships";
						if (getWebDriverInstance().findElement(By.cssSelector(css)).isDisplayed()){
							String Text = getWebDriverInstance().findElement(By.cssSelector(css)).getText();
							if (Text.contains(clientE2ETO.getFirstName2()
									.toUpperCase()
									+ " "
									+ clientE2ETO.getLastName2().toUpperCase())) {
								Verify.verifyTrue(true,
										MessageUtility.ADDINDIVIDUAL_SUCCESS);
							} else {
								Verify.verifyTrue(false,
										MessageUtility.ADDINDIVIDUAL_FAIL);
							}
						}

					}
				} else {
					Verify.verifyTrue(false, MessageUtility.ADDINDIVIDUAL_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(false, MessageUtility.LINK_ADDINDIVIDUAL_NOTFOUND);
			}
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
    /**
     * Verifying Household MCLB in Relationships Page
     * @throws ScriptException
     */
	public void verifyHouseholdMCLB() throws ScriptException {
		try {
			String header = "";
			String row = "";
			String formatter = "                                 || ";
			String border = "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

			String borderHeader = "==========================================================================================================================================================================================================================================================================================================================";

			int rowCount;
			int count = 1;

			String table = getTableXPathFromDivId("householdRelationships");
			rowCount = getRowCountFromXpathDivId("householdRelationships");
			if (rowCount >= 1) {
				String[] s = { "Name", "", "Relationship to Customer", "" };
				for (int i = 0; i < s.length; i++) {
					header += s[i].trim() + formatter.substring(s[i].length());
				}
				resultsFile
						.write("\r\n  *  Verify info Relationships (Members Inside the Household) Table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile.write(borderHeader.substring(0, header.length())
						+ "\r\n");
				while (count <= rowCount) {
					for (int i = 1; i <= s.length; i++) {

						WebElement cellData = getWebDriverInstance().findElement(By.xpath(table + "/tr[" + count+ "]/td[" + i + "]"));
						cellsData = cellData.getText();
						if (cellsData.length() <= (formatter.length() - 4)) {
							row += cellsData
									+ formatter.substring(cellsData.length());
						} else {
							row += cellsData.substring(0,
									formatter.length() - 3) + "|| ";
						}
					}
					row = "";
					count += 1;
				}
				count = 0;
				Verify.verifyTrue(true,
						MessageUtility.HOUSEHOLDMEMBERSTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.HOUSEHOLDMEMBERS_EMPTY);
			}
			header = "";
			row = "";

		} catch (IOException i) {
			Verify.verifyTrue(false, MessageUtility.HOUSEHOLDMEMBERSTABLE_NOTDISPLAYED);
		}
	}
    /**
     * Verifying Household MCLB in Relationships Page for AHQB
     * @throws ScriptException
     */
	public void verifyAHQBHouseholdMCLB() throws ScriptException {
		try {
			String header = "";
			String row = "";
			String formatter = "                                 || ";
			String border = "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

			String borderHeader = "==========================================================================================================================================================================================================================================================================================================================";

			int rowCount = 0;
			int count = 1;

			String table = getTableXPathFromDivId("householdRelationships");
			rowCount = getRowCountFromXpathDivId("householdRelationships");
			if (rowCount >= 1) {
				String[] s = { "Name", "Relationship to Customer" };
				for (int i = 0; i < s.length; i++) {
					header += s[i].trim() + formatter.substring(s[i].length());
				}
				resultsFile
						.write("\r\n  *  Verify info Relationships (Members Inside the Household) Table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile.write(borderHeader.substring(0, header.length())
						+ "\r\n");
				while (count <= rowCount) {
					for (int i = 1; i <= s.length; i++) {
						cellsData = getWebDriverInstance().findElement(By.xpath(table + "/tr[" + count
								+ "]/td[" + i + "]")).getText();
						if (cellsData.length() <= (formatter.length() - 4)) {
							row += cellsData
									+ formatter.substring(cellsData.length());
						} else {
							row += cellsData.substring(0,
									formatter.length() - 3) + "|| ";
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				Verify.verifyTrue(true,
						MessageUtility.HOUSEHOLDMEMBERSTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.HOUSEHOLDMEMBERS_EMPTY);
			}
			header = "";
			row = "";

		} catch (IOException i) {
			Verify.verifyTrue(false, MessageUtility.HOUSEHOLDMEMBERSTABLE_DISPLAYED);
		}
	}
    /**
     * Verifying Non-Household MCLB in Relationships Page 
     * @throws ScriptException
     */
	public void verifyNonHouseholdMCLB() throws ScriptException {

		try {
			String header = "";
			String row = "";
			String formatter = "                                 || ";
			String border = "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

			String borderHeader = "==========================================================================================================================================================================================================================================================================================================================";

			int rowCount = 0;
			int count = 1;

			String table = getTableXPathFromDivId("nonHouseholdRelationships");
			rowCount = getRowCountFromXpathDivId("nonHouseholdRelationships");
			if (rowCount >= 1) {
				String[] s = { "Name", "Relationship to Customer", "" };
				for (int i = 0; i < s.length; i++) {
					header += s[i].trim() + formatter.substring(s[i].length());
				}
				resultsFile
						.write("\r\n  *  Verify info Relationships (Members Outside the Household) Table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile.write(borderHeader.substring(0, header.length())
						+ "\r\n");
				while (count <= rowCount) {
					for (int i = 1; i < s.length; i++) {
						
						WebElement cellData = getWebDriverInstance()
						.findElement(
								By.xpath(table + "/tr[" + count
										+ "]/td[" + i + "]"));
						
						cellsData = cellData.getText();
						if (cellsData.length() <= (formatter.length() - 4)) {
							row += cellsData
									+ formatter.substring(cellsData.length());
						} else {
							row += cellsData.substring(0,
									formatter.length() - 3) + "|| ";
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.NONHOUSEHOLDMEMBERSTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
						MessageUtility.NONHOUSEHOLDMEMBERS_EMPTY);
			}
			header = "";
			row = "";

		} catch (IOException i) {
			Verify.verifyTrue(false, MessageUtility.NONHOUSEHOLDMEMBERSTABLE_NOTDISPLAYED);
		}
	}
    /**
     * Verifying Non-Household MCLB in Relationships Page for AHQB
     * @throws ScriptException
     */
	public void verifyAHQBNonHouseholdMCLB() throws ScriptException {
		try {
			String header = "";
			String row = "";
			String formatter = "                                 || ";
			String border = "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";
			String borderHeader = "==========================================================================================================================================================================================================================================================================================================================";
			int rowCount = 0;
			int count = 1;
			String table = getTableXPathFromDivId("nonHouseholdRelationships");
			rowCount = getRowCountFromXpathDivId("nonHouseholdRelationships");
			if (rowCount >= 1) {
				String[] s = { "Name", "Relationship to Customer" };
				for (int i = 0; i < s.length; i++) {
					header += s[i].trim() + formatter.substring(s[i].length());
				}

				resultsFile
						.write("\r\n  *  Verify info Relationships (Members Outside the Household) Table  \r\n");
				resultsFile.write(border.substring(0, header.length())
						+ " \r\n");
				resultsFile.write(header + "\r\n");
				resultsFile.write(borderHeader.substring(0, header.length())
						+ "\r\n");
				while (count <= rowCount) {
					for (int i = 1; i < s.length; i++) {
						cellsData = getWebDriverInstance().findElement(By.xpath(table + "/tr[" + count	+ "]/td[" + i + "]")).getText();
						if (cellsData.length() <= (formatter.length() - 4)) {
							row += cellsData
									+ formatter.substring(cellsData.length());
						} else {
							row += cellsData.substring(0,
									formatter.length() - 3) + "|| ";
						}
					}
					resultsFile.write(row + "\r\n");
					row = "";
					count += 1;
				}
				count = 0;
				resultsFile.write(border.substring(0, header.length())
						+ "\r\n\r\n");
				Verify.verifyTrue(true,
						MessageUtility.NONHOUSEHOLDMEMBERSTABLE_DISPLAYED);
			}

			if (rowCount < 1) {
				Verify.verifyTrue(true,
				MessageUtility.NONHOUSEHOLDMEMBERS_EMPTY);
			}
			header = "";
			row = "";

		} catch (IOException i) {
			Verify.verifyTrue(false, MessageUtility.NONHOUSEHOLDMEMBERSTABLE_NOTDISPLAYED);
		}
	}
    /**
     * Clicking Close button in Relationship page
     * @throws ScriptException
     */
	public void closeRelationshipsPage() throws ScriptException {
		
		waitForPageLoad(RelationshipsScreenTestObjects.WidgetInfos.BUTTON_CANCEL, 10);
		if (RelationshipsScreenTestObjects.WidgetInfos.BUTTON_CANCEL.exists()) {
			click(RelationshipsScreenTestObjects.WidgetInfos.BUTTON_CANCEL,
					MessageUtility.BUTTON_CLOSE);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_CLOSE_NOTFOUND);
		}

	}
	
   /**
    * Verify Relationship Page is Launched
    * @return
    */
	public boolean isRelationshipPageLaunched() {
		waitForPageLoad(
				RelationshipsScreenTestObjects.WidgetInfos.DIV_MEMBERS_INSIDE_HOUSEHOLD,
				20);
		if (RelationshipsScreenTestObjects.WidgetInfos.DIV_MEMBERS_INSIDE_HOUSEHOLD
				.exists()) {
			return true;
		} else {
			return false;
		}
	}
    /**
     * validating Relationship Page 
     * @throws ScriptException
     */
	public void validateRelationshipPage() throws ScriptException {
		try {
			if (isRelationshipPageLaunched()) {
				verifyHouseholdMCLB();
				verifyNonHouseholdMCLB();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
    /**
     * closing Relationship Page
     * @throws ScriptException
     */
	public void closeRelationshipPage() throws ScriptException {
		try {
			if (isRelationshipPageLaunched()) {
				closeRelationshipsPage();
				setWindow("Household Information", 5, 2);
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
   /**
    * verify And Add Household And NonHousehold Individuals In RelationshipPage
    */
	public void verifyAndAddHouseholdAndNonHouseholdIndInRelationshipPage() {
		try {
			if (isRelationshipPageLaunched()) {
				validateRelationshipPage();
				addIndHHRelationship();
				isErrorPage("Relationships (Members Inside the Household)");
				addIndNonHHRelationship();
				isErrorPage("Relationships (Members Outside the Household)");
				closeRelationshipPage();
			} else {
				Verify.verifyTrue(false, MessageUtility.RELATIONSHIPSPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Verify the Relationship Page Exists and Add Individual in Member Inside
	 * and Member Outside the Household
	 */
	public void verifyAHQBAddHouseholdAndNonHouseholdIndInRelationshipPage() {
		try {
			if (isHHPageLaunched()) {
				validateRelationshipsLinkDisplayed();
				if (isRelationshipPageLaunched()) {
					verifyAHQBHouseholdMCLB();
					verifyAHQBNonHouseholdMCLB();
					closeRelationshipsPage();
					setWindow("Contact Center Online", 5, 2);
					setCRCDefaultFrame();
					clickContinueButtonIfExists();
				} else {
					Verify.verifyTrue(false, MessageUtility.RELATIONSHIPSPAGE_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

}
