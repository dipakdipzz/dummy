package sf.client.service.healthSuite.tasks;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.ConflictCustomerInfoAppObj;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.OutOfBookConformationPageObjects;
import sf.client.service.healthSuite.appObjects.SSNSINObjects;
import sf.client.service.healthSuite.appObjects.Update_IND_CustomerInfo_PageObjects;
import sf.client.service.healthSuite.appObjects.VerifyInfoAppObj;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.TableEx;
import statefarm.widget.manager.Verify;


public class SSNSINTasks extends HouseHoldTasks {
	CombineCustomersTasks combineTasks = new CombineCustomersTasks();
	List<String> list = new ArrayList<String>();
	public SSNSINTasks() {
		super();
	}

	public SSNSINTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}
	/**
	 * Launching CIA page clicking CIA Link
	 * @throws ScriptException
	 */
	public void launchCIA() throws ScriptException {
		
		if (OutOfBookConformationPageObjects.WidgetInfos.CIA.exists()) {
			OutOfBookConformationPageObjects.WidgetInfos.CIA.click();
			Verify.verifyTrue(true, MessageUtility.CIAPAGE_LAUNCHED);
		} else {
			Verify.verifyTrue(false,  MessageUtility.CIAPAGE_NOTFOUND);
		}
	}
	/**
	 * Adding Conflicting CustomerInformation SSN to List 
	 * @return
	 * @throws ScriptException
	 */
	public List<String> validateConflictingCustomerInfo()
	throws ScriptException {

int rowCount = 0;
String SSN = null;
int d = 1;
while (true) {
	try {
		WebElement SSNText = getWebDriverInstance().findElement(By.xpath("//div[@class='combineConflictRadio']/div["
						+ d + "]"));
		SSN = SSNText.getText();
		list.add(SSN);
		rowCount++;
		d++;
	} catch (Exception e) {
		break;
	}
}

return list;
}
    /**
     * Launching Conflict Info Page From Verify Info Page 
     */
	public void launchConflictInfoPageFromVerifyInfoPage() {
		waitForPageLoad(VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE, 30);
		if (VerifyInfoAppObj.WidgetInfos.LINK_PREVIOUS.exists()) {

			click(VerifyInfoAppObj.WidgetInfos.LINK_PREVIOUS,
					MessageUtility.LINK_PREVIOUSREVIEW_CLICKED);

		} else {
			Verify.verifyTrue(false, MessageUtility.VERIFYINFOPAGE_NOTEXISTS);

		}
	}
     /**
      * Select FirstCustomer Radio button And Validating SSN For FirstCustomer 
      */
	public void selectAndValidateSSNForFirstCustomer() {
		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN, 20);
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN.exists()) {
			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN1.exists())
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN1,
						MessageUtility.SSN_CUSTONE);

			else
				Verify.verifyTrue(true, MessageUtility.SSN_NOCONFLICT);
			combineTasks.selectDOBMaritalStatusRadioButton();
			List<String> list2 = validateConflictingCustomerInfo();

			String firstSSN = list2.get(0).substring(0, 11);
			combineTasks.launchVerifyInfoPage();
			waitForPageLoad(VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE, 30);
			WebElement verifySSN = getWebDriverInstance().findElement(By.xpath("//form[@name='combineClientVerifyForm']/fieldset[5]/div[5]/div[2]/div[1]/div[2]/label"));
			String ssn = verifySSN.getText();
			if (firstSSN.equals(ssn))
				Verify.verifyTrue(
						true, MessageUtility.CUSTONESSN_DISPLAYED);
			else
				Verify.verifyTrue(false,
						MessageUtility.CUSTONESSN_NOTDISPLAYED);

		} else
			Verify.verifyTrue(false, MessageUtility.SSN_NOCONFLICT);
	}
    /**
     * Select SecondCustomer Radio button And Validating SSN For SecondCustomer
     */
	public void selectAndValidateSSNForSecondCustomer() {
		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN, 20);
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN.exists()) {

			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2.exists())
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN2,
						MessageUtility.SSN_CUSTTWO);

			else
				Verify.verifyTrue(true, MessageUtility.SSN_NOCONFLICT);
			combineTasks.selectDOBMaritalStatusRadioButton();
			List<String> list2 = validateConflictingCustomerInfo();
			String secondSSN = list2.get(1).substring(0, 11);
			combineTasks.launchVerifyInfoPage();
			waitForPageLoad(VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE, 30);
			WebElement verifySSN = getWebDriverInstance().findElement(By.xpath("//form[@name='combineClientVerifyForm']/fieldset[5]/div[5]/div[2]/div[1]/div[2]/label"));
			String ssn = verifySSN.getText();
			if (secondSSN.equals(ssn))
				Verify.verifyTrue(
						true, MessageUtility.CUSTTWOSSN_DISPLAYED);
			else
				Verify.verifyTrue(false,
						MessageUtility.CUSTTWOSSN_NOTDISPLAYED);

		} else
			Verify.verifyTrue(false, MessageUtility.SSN_NOCONFLICT);
	}
    /**
     * Selecting new value Radio button and Entering New SSN to Validate NewSSN in verifyInformation Page
     */
	public void enterAndValidateNewSSNinConflictInfoPage() {

		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN, 20);
		waitForTime(3);
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN.exists()) {
			if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN_OTHER.exists())
				selectRadioButton(
						ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_SIN_OTHER,
						MessageUtility.SSN_CUSTTWO);
			enterMandatoryfieldtoEnablebutton(
					ConflictCustomerInfoAppObj.WidgetInfos.TEXT_SSN_SIN_OTHER,
					clientE2ETO.getSsnNum());
			combineTasks.launchVerifyInfoPage();
			waitForPageLoad(VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE, 30);
			WebElement verifySSN = getWebDriverInstance().findElement(By.xpath("//form[@name='combineClientVerifyForm']/fieldset[5]/div[5]/div[2]/div[1]/div[2]/label"));
			String ssn = verifySSN.getText();
			String unMasked = clientE2ETO.getSsnNum().substring(0, 3) + "-"
					+ clientE2ETO.getSsnNum().substring(3, 5) + "-"
					+ clientE2ETO.getSsnNum().substring(5);
			if (unMasked.equals(ssn))
				Verify.verifyTrue(true, MessageUtility.NEWSSN_DISPLAYED);
			else
				Verify.verifyTrue(false,
						MessageUtility.NEWSSN_NOTDISPLAYED);
		} else
			Verify.verifyTrue(false, MessageUtility.SSN_NOCONFLICT);
	}
    /**
     * Selecting No value Radio button  to Validate SSN in verifyInformation Page
     */
	public void validateSSNNoValueRadioButton() {
		waitForPageLoad(ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_NOVALUE, 10);
		if (ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_NOVALUE.exists()) {
			selectRadioButton(ConflictCustomerInfoAppObj.WidgetInfos.RADIOBUTTON_SSN_NOVALUE,
					MessageUtility.RADIOBUTTON_NO);
			combineTasks.launchVerifyInfoPage();
			waitForTime(5);
			WebElement textSSN = getWebDriverInstance().findElement(By.xpath("//div[@class='readOnlyFloatLeft']/div[2]/div[@class='fieldToAlign']/label"));
			String verifySSN = textSSN.getText();
			if (verifySSN.isEmpty())
				Verify.verifyTrue(true,
						MessageUtility.SSN_EMPTY);
			else
				Verify.verifyTrue(false,
						MessageUtility.SSN_NOTEMPTY);
		} else
			Verify.verifyTrue(false,
					MessageUtility.RADIOBUTTON_NO_NOTFOUND);
	}

	/**
	 * Customer Combine - Display of US SSN information in the Verify
	 * information- conflict page and ability to select US SSN number of
	 * Customer1 and 2 in the verify information conflict page
	 * 
	 * @throws Exception
	 */
	public void validateSSNForTwoCustomers() {
		try {
			if (combineTasks.isSearchandSelectTwoCustomerPage()) {
				combineTasks.launchConflictInfoPage();
				selectAndValidateSSNForFirstCustomer();
				launchConflictInfoPageFromVerifyInfoPage();
				selectAndValidateSSNForSecondCustomer();
			} else
				Verify.verifyTrue(false,
						MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Customer Combine - Ability to enter new US SSN number in the verify
	 * information- conflict page
	 * 
	 * @throws Exception
	 */
	public void validateNewSSNinConflictInfoPage() {
		try {
			if (VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE.exists()) {
				launchConflictInfoPageFromVerifyInfoPage();
				enterAndValidateNewSSNinConflictInfoPage();
			} else
				Verify.verifyTrue(false,
						MessageUtility.VERIFYINFOPAGE_NOTEXISTS);
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Customer Combine - Ability to select the No value radio button in the
	 * verify information- conflict page.
	 */
	public void selectAndValidateNoValueRadioButtonForSSN() {
		try {
			if (VerifyInfoAppObj.WidgetInfos.BUTTON_COMBINE.exists()) {
				launchConflictInfoPageFromVerifyInfoPage();
				validateSSNNoValueRadioButton();
			} else
				Verify.verifyTrue(false,
						MessageUtility.VERIFYINFOPAGE_NOTEXISTS);
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	
	/**
	 * To Verify that the user is able to view the Account & Policies twisty  is NOT present in the ABS Search result page successfully.
	 */
	public void validateAccountandPoliciesTwistyNotPresent() {
		try {
			waitForPageLoad(SSNSINObjects.WidgetInfos.BUTTON_POLICIES_TWISTY, 30);
			if (!SSNSINObjects.WidgetInfos.BUTTON_POLICIES_TWISTY.exists())
				Verify.verifyTrue(true,
						MessageUtility.ACCOUNTSANDPOLICIESTWISTY_NOTDISPLAYED);
			else
				Verify.verifyTrue(false,
						MessageUtility.ACCOUNTSANDPOLICIESTWISTY_DISPLAYED);
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
	
    /**
     * Clicking Account and Policies Twisty in the ABS Search result page
     */
	public void clickAccountandPoliciesTwisty() {
		try {
			
				WebElement accountPolicies = getWebDriverInstance().findElement(By.xpath("//div[@id='gridNode']/div/div/div/div/div/div/table/tbody/tr/td[1]/span/span"));
				if (accountPolicies.isDisplayed()) {
					accountPolicies.click();
					waitForTime(5);
					Verify.verifyTrue(true,
							MessageUtility.ACCOUNTSANDPOLICIESTWISTY_CLICKED);
				} else
					Verify.verifyTrue(false,
							MessageUtility.ACCOUNTSANDPOLICIESTWISTY_NOTDISPLAYED);
			
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
   
	/**
	 * Validate that, all the policies associated are displayed in Order on the Account & Policies Light box
	 * SFPP,Auto,Fire,Life,Health,Bank and Mutual Funds
	 */

	public void validateDisplayOrderOfPolicies() {
		try {
			if (SSNSINObjects.WidgetInfos.DIV_POLICIES_TABLE.exists()) {
				String policyDetails = SSNSINObjects.WidgetInfos.DIV_POLICIES_TABLE.getText();

				int auto, fire, life, sfpp = 0;
				auto = policyDetails.indexOf("Auto");
				fire = policyDetails.indexOf("Fire");
				life = policyDetails.indexOf("Life");
				sfpp = policyDetails.indexOf("SFPP");

				if (sfpp < auto && auto < fire && fire < life) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : sfpp, auto, fire followed by life.");
				} else if (sfpp != -1 && sfpp < auto && auto < fire) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : sfpp, auto followed by fire.");
				} else if (sfpp < fire && fire < life) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : sfpp, fire followed by life.");
				} else if (sfpp == -1 && auto < fire && fire < life) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : auto, fire followed by life.");
				} else if (sfpp != -1 && sfpp < auto) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : sfpp followed by auto.");
				} else if (sfpp != -1 && sfpp < fire) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : sfpp followed by fire.");
				} else if (sfpp != -1 && sfpp < life) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : sfpp followed by life.");
				} else if (auto != -1 && auto < fire) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : auto followed by fire.");
				} else if (auto != -1 && auto < life) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : auto followed by life.");
				} else if (fire != -1 && fire < life) {
					Verify.verifyTrue(true,
							"The order of policies are displayed as : fire followed by life.");
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1) {
					Verify.verifyTrue(true,
							"There are only  sfpp policy in MCLB.");
				} else if (sfpp == -1 && auto != -1 && fire == -1 && life == -1) {
					Verify.verifyTrue(true,
							"There are only  auto policy in MCLB.");
				} else if (sfpp == -1 && auto == -1 && fire != -1 && life == -1) {
					Verify.verifyTrue(true,
							"There are only  fire policy in MCLB.");
				} else if (sfpp == -1 && auto == -1 && fire == -1 && life != -1) {
					Verify.verifyTrue(true,
							"There are only  life policy in MCLB.");
				} else {
					Verify.verifyTrue(true, "There are no  policy in MCLB.");
				}

				Verify.verifyTrue(true,"\n\n============ACCOUNTS & POLICIES TABLE================\n\n");
				Verify.verifyTrue(true,policyDetails.substring(0, 38));
				Verify.verifyTrue(true,policyDetails.substring(39,
						policyDetails.length()));
				Verify.verifyTrue(true,"\n\n============END OF TABLE================\n\n");

			} else
				Verify.verifyTrue(false,
						MessageUtility.ACCOUNTSANDPOLICIESLIGHTBOX_NOTFOUND);
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Validate the policy status in Status column. Valid Status are: 
       o Active � all LOBs
       o Not Active/inactive � all LOBs
       o Pended � SFPP only
       o Transferred � SFPP only
       o Issued � F, L, H, B, MF
	 * @author ux14
	 * 
	 */
	public void validatePolicyStatusinStatusColumn() {
		try {
			if (SSNSINObjects.WidgetInfos.DIV_POLICIES_TABLE.exists()) {
				String policyDetails = SSNSINObjects.WidgetInfos.DIV_POLICIES_TABLE.getText();

				int auto, fire, life, sfpp, health, bank, MutualFunds = 0;

				sfpp = policyDetails.indexOf("SFPP");
				auto = policyDetails.indexOf("Auto");
				fire = policyDetails.indexOf("Fire");
				life = policyDetails.indexOf("Life");
				health = policyDetails.indexOf("Health");
				bank = policyDetails.indexOf("Bank");
				MutualFunds = policyDetails.indexOf("Mutual Funds");

				String SFPPStatus = null;
				String autoStatus = null;
				String fireStatus = null;
				String lifeStatus = null;
				String healthStatus = null;
				String bankStatus = null;
				String mutualFundStatus = null;

				if (sfpp != -1 && auto != -1) {

					SFPPStatus = policyDetails.substring(sfpp, auto);
				} else if (sfpp != -1 && auto == -1 && fire != -1) {
					SFPPStatus = policyDetails.substring(sfpp, fire);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life != -1) {
					SFPPStatus = policyDetails.substring(sfpp, life);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1
						&& health != -1) {
					SFPPStatus = policyDetails.substring(sfpp, health);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1
						&& health == -1 && bank != -1) {
					SFPPStatus = policyDetails.substring(sfpp, bank);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1
						&& health == -1 && bank == -1 && MutualFunds != -1) {
					SFPPStatus = policyDetails.substring(sfpp, MutualFunds);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1
						&& health == -1 && bank == -1 && MutualFunds == -1) {
					SFPPStatus = policyDetails.substring(sfpp,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.SFPPPOLICY_NOTFOUND);
				}

				if (auto != -1 && fire != -1) {

					autoStatus = policyDetails.substring(auto, fire);
				} else if (auto != -1 && fire == -1 && life != -1) {
					autoStatus = policyDetails.substring(auto, life);
				} else if (auto != -1 && fire == -1 && life == -1
						&& health != -1) {
					autoStatus = policyDetails.substring(auto, health);
				} else if (auto != -1 && fire == -1 && life == -1
						&& health == -1 && bank != -1) {
					autoStatus = policyDetails.substring(auto, bank);
				} else if (auto != -1 && fire == -1 && life == -1
						&& health == -1 && bank == -1 && MutualFunds != -1) {
					autoStatus = policyDetails.substring(auto, MutualFunds);
				} else if (auto != -1 && fire == -1 && life == -1
						&& health == -1 && bank == -1 && MutualFunds == -1) {
					autoStatus = policyDetails.substring(auto,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.AUTOPOLICY_NOTFOUND);
				}

				if (fire != -1 && life != -1) {
					fireStatus = policyDetails.substring(fire, life);
				} else if (fire != -1 && life == -1 && health != -1) {
					fireStatus = policyDetails.substring(fire, health);
				} else if (fire != -1 && life == -1 && health == -1
						&& bank != -1) {
					fireStatus = policyDetails.substring(fire, bank);
				} else if (fire != -1 && life == -1 && health == -1
						&& bank == -1 && MutualFunds != -1) {
					fireStatus = policyDetails.substring(fire, MutualFunds);
				} else if (fire != -1 && life == -1 && health == -1
						&& bank == -1 && MutualFunds == -1) {
					fireStatus = policyDetails.substring(fire,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.FIREPOLICY_NOTFOUND);
				}

				if (life != -1 && health != -1) {
					lifeStatus = policyDetails.substring(life, health);
				} else if (life != -1 && health == -1 && bank != -1) {
					lifeStatus = policyDetails.substring(life, bank);
				} else if (life != -1 && health == -1 && bank == -1
						&& MutualFunds != -1) {
					lifeStatus = policyDetails.substring(life, MutualFunds);
				} else if (life != -1 && health == -1 && bank == -1
						&& MutualFunds == -1) {
					lifeStatus = policyDetails.substring(life,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.LIFEPOLICY_NOTFOUND);
				}

				if (health != -1 && bank != -1) {
					healthStatus = policyDetails.substring(health, bank);
				} else if (health != -1 && bank == -1 && MutualFunds != -1) {
					healthStatus = policyDetails.substring(health, MutualFunds);
				} else if (health != -1 && bank == -1 && MutualFunds == -1) {
					healthStatus = policyDetails.substring(health,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.HEALTHPOLICY_NOTFOUND);
				}

				if (bank != -1 && MutualFunds != -1) {
					bankStatus = policyDetails.substring(bank, MutualFunds);
				} else if (bank != -1 && MutualFunds == -1) {
					bankStatus = policyDetails.substring(bank,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.BANKPOLICY_NOTFOUND);
				}

				if (MutualFunds != -1) {
					mutualFundStatus = policyDetails.substring(MutualFunds,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.LINK_MUTUALFUNDSPOLICY_NOTFOUND);
				}

				if (SFPPStatus != null) {
					if (SFPPStatus.contains("Active")
							|| SFPPStatus.contains("Not Active")
							|| SFPPStatus.contains("Transferred")
							|| SFPPStatus.contains("Pended")
							|| SFPPStatus.contains("inactive"))

						Verify.verifyTrue(true,
								MessageUtility.SFPPPOLICYSTATUS_DISPLAYED);

					else
						Verify.verifyTrue(false,
								MessageUtility.SFPPPOLICYSTATUS_NOTDISPLAYED);
				}

				if (autoStatus != null) {
					if (autoStatus.contains("Active")
							|| autoStatus.contains("Not Active")
							|| autoStatus.contains("inactive"))

						Verify.verifyTrue(true,
								MessageUtility.AUTOPOLICYSTATUS_DISPLAYED);

					else
						Verify.verifyTrue(false,
								MessageUtility.AUTOPOLICYSTATUS_NOTDISPLAYED);

				}

				if (fireStatus != null) {
					if (fireStatus.contains("Active")
							|| fireStatus.contains("Not Active")
							|| fireStatus.contains("inactive")
							|| fireStatus.contains("Issued"))

						Verify.verifyTrue(true,
								MessageUtility.FIREPOLICYSTATUS_DISPLAYED);

					else
						Verify.verifyTrue(false,
								MessageUtility.FIREPOLICYSTATUS_NOTDISPLAYED);
				}

				if (lifeStatus != null) {
					if (lifeStatus.contains("Active")
							|| lifeStatus.contains("Not Active")
							|| lifeStatus.contains("inactive")
							|| lifeStatus.contains("Issued"))

						Verify.verifyTrue(true,
								MessageUtility.LIFEPOLICYSTATUS_DISPLAYED);

					else
						Verify.verifyTrue(false,
								MessageUtility.LIFEPOLICYSTATUS_NOTDISPLAYED);
				}

				if (healthStatus != null) {
					if (healthStatus.contains("Active")
							|| healthStatus.contains("Not Active")
							|| healthStatus.contains("inactive")
							|| healthStatus.contains("Issued"))

						Verify.verifyTrue(true,
								MessageUtility.HEALTHPOLICYSTATUS_DISPLAYED);

					else
						Verify.verifyTrue(false,
								MessageUtility.HEALTHPOLICYSTATUS_NOTDISPLAYED);
				}

				if (bankStatus != null) {
					if (bankStatus.contains("Active")
							|| bankStatus.contains("Not Active")
							|| bankStatus.contains("inactive")
							|| bankStatus.contains("Issued"))

						Verify.verifyTrue(true,
								MessageUtility.BANKPOLICYSTATUS_DISPLAYED);

					else
						Verify.verifyTrue(false,
								MessageUtility.BANKPOLICYSTATUS_NOTDISPLAYED);
				}

				if (mutualFundStatus != null) {
					if (mutualFundStatus.contains("Active")
							|| mutualFundStatus.contains("Not Active")
							|| mutualFundStatus.contains("inactive")
							|| mutualFundStatus.contains("Issued"))

						Verify.verifyTrue(true,
								MessageUtility.MUTUALFUNDSPOLICYSTATUS_DISPLAYED);

					else
						Verify.verifyTrue(false,
								MessageUtility.MUTUALFUNDSPOLICYSTATUS_NOTDISPLAYED);
				}

			} else
				Verify.verifyTrue(false,
						MessageUtility.ACCOUNTSANDPOLICIESLIGHTBOX_NOTFOUND);
		}

		catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * Validate the list of Actions for each LOB in the Account and Policy Lightbox: 

        � SFPP must only allow Payment Action.
        � Auto must only allow:
          o Payment
          o Report A Loss
          o New Change � PT
          o Add a Vehicle
        � Fire must only allow: 
          o Payment
          o Report a Loss 
          o New Change - PT
        � Life, Health, Bank, Mutual Funds should have no actions associated with any accounts/policies. 
	 * @author ux14
	 * 
	 */
	public void validateActionDropdownForPolicies() {
		try {
			
			Div policiesTable = new Div("class=policyDiv");
			int customerCount = 0;
			TableEx names = new TableEx("id=gridNode");
			int rowCount = names.getBodyRowCount();
			for(int i=0;i<rowCount;i++)
			{
				String custName = names.getBodyCellText(i, 8);
				if(custName.equalsIgnoreCase(clientE2ETO.getCustomerOneData()))
					 customerCount = rowCount;
			}
			if (policiesTable.exists()) {
				
				int divCount = 1;
				while(true)
				{
					try {
						WebElement policyType = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
								"div/div["+divCount+"]/table/tbody/tr[1]/td/strong"));
						if (policyType.getText().equalsIgnoreCase("SFPP")) {
							divCount++;
							WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
											"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
							actionMenu.click();
							waitForTime(2);
							
							WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
							if (actionTypes.getText().contains("Payment"))
								Verify.verifyTrue(true,
										MessageUtility.PAYMENT_DISPLAYED);
							else
								Verify.verifyTrue(false,
										MessageUtility.PAYMENT_NOTDISPLAYED);
						}

						if (policyType.getText().equalsIgnoreCase("Auto")) {
							divCount++;
							WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
									"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
							actionMenu.click();
							waitForTime(2);
							WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));
							if (actionTypes.getText().contains("Payment")
									|| actionTypes.getText().contains("Report a Loss")
									|| actionTypes.getText().contains("New Change - PT")
									|| actionTypes.getText().contains("Add a Vehicle"))
								Verify.verifyTrue(
										true,
										MessageUtility.OPTIONS_AUTO);

							else
								Verify.verifyTrue(false,
										MessageUtility.ACTIONMENUOPTIONS_NOTDISPLAYED);
						}
						if (policyType.getText().equalsIgnoreCase("Fire")) {
							divCount++;
							WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
									"div/div["+divCount+"]/table/tbody/tr[2]/td[2]/span/span/span"));
							actionMenu.click();
							waitForTime(2);
							WebElement actionTypes = getWebDriverInstance().findElement(By.xpath("//div[@class='dijitPopup dijitMenuPopup']/table"));

							if (actionTypes.getText().contains("Payment")
									|| actionTypes.getText().contains("Report a Loss")
									|| actionTypes.getText().contains("New Change - PT"))
								Verify.verifyTrue(
										true,
										MessageUtility.OPTIONS_FIRE);

							else
								Verify.verifyTrue(false,
										MessageUtility.ACTIONMENUOPTIONSFIRE_NOTDISPLAYED);
						}

						if (policyType.getText().equalsIgnoreCase("Life")) {
							divCount++;
							WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
									"div/div["+divCount+"]/table/tbody/tr[2]/td[2]"));	
							if (!actionMenu.getText().contains("Action"))
							Verify.verifyTrue(true,
										MessageUtility.ACTIONMENU_LIFEPOLICY_NOTDISPLAYED);

							else
								Verify.verifyTrue(false,
										MessageUtility.ACTIONMENU_LIFEPOLICY_DISPLAYED);
						}

						if (policyType.getText().equalsIgnoreCase("Health")) {
							divCount++;
							WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
									"div/div["+divCount+"]/table/tbody/tr[2]/td[2]"));
							if (!actionMenu.getText().contains("Action"))
								Verify.verifyTrue(true,
										MessageUtility.ACTIONMENU_HEALTHPOLICY_NOTDISPLAYED);

							else
								Verify.verifyTrue(false,
										MessageUtility.ACTIONMENU_HEALTHPOLICY_DISPLAYED);
						}

						if (policyType.getText().equalsIgnoreCase("Bank")) {
							divCount++;
							WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
									"div/div["+divCount+"]/table/tbody/tr[2]/td[2]"));
							if (!actionMenu.getText().contains("Action"))
								Verify.verifyTrue(true,
										MessageUtility.ACTIONMENU_BANKPOLICY_NOTDISPLAYED);

							else
								Verify.verifyTrue(false,
										MessageUtility.ACTIONMENU_BANKPOLICY_DISPLAYED);
						}

						if (policyType.getText().equalsIgnoreCase("MFund")) {
							divCount++;
							WebElement actionMenu = getWebDriverInstance().findElement(By.xpath("//div[@id='pgrid|"+customerCount+"'"+"]/div/div/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']/" +
									"div/div["+divCount+"]/table/tbody/tr[2]/td[2]"));
							if (!actionMenu.getText().contains("Action"))
							
								Verify.verifyTrue(true,
										MessageUtility.ACTIONMENU_MUTUALFUNDSPOLICY_NOTDISPLAYED);
							else
								Verify.verifyTrue(false,
										MessageUtility.ACTIONMENU_MUTUALFUNDSPOLICY_DISPLAYED);
						}

						divCount++;
					} catch (Exception e) {
						break;
					}
				
			} //while
				
			}else
				Verify.verifyTrue(false,
						MessageUtility.ACCOUNTSANDPOLICIESLIGHTBOX_NOTFOUND);
		} catch (ScriptException e) {
		}
	}

	/**
	 * Validate the Policy numbers displayed in Number column
	 * @author ux14
	 * 
	 */
	public void validateCountofAllPoliciesWithStateFarm() {
		try {
			if (SSNSINObjects.WidgetInfos.DIV_POLICIES_TABLE.exists()) {
				int sfppCount = 0;
				int autoCount = 0;
				int fireCount = 0;
				int bankCount = 0;
				int healthCount = 0;
				int lifeCount = 0;
				int mutualFundCount = 0;

				String policyDetails = SSNSINObjects.WidgetInfos.DIV_POLICIES_TABLE.getText();

				int auto, fire, life, sfpp, health, bank, MutualFunds = 0;

				sfpp = policyDetails.indexOf("SFPP");
				auto = policyDetails.indexOf("Auto");
				fire = policyDetails.indexOf("Fire");
				life = policyDetails.indexOf("Life");
				health = policyDetails.indexOf("Health");
				bank = policyDetails.indexOf("Bank");
				MutualFunds = policyDetails.indexOf("Mutual Funds");

				String SFPPStatus = null;
				String autoStatus = null;
				String fireStatus = null;
				String lifeStatus = null;
				String healthStatus = null;
				String bankStatus = null;
				String mutualFundStatus = null;

				if (sfpp != -1 && auto != -1) {

					SFPPStatus = policyDetails.substring(sfpp, auto);
				} else if (sfpp != -1 && auto == -1 && fire != -1) {
					SFPPStatus = policyDetails.substring(sfpp, fire);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life != -1) {
					SFPPStatus = policyDetails.substring(sfpp, life);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1
						&& health != -1) {
					SFPPStatus = policyDetails.substring(sfpp, health);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1
						&& health == -1 && bank != -1) {
					SFPPStatus = policyDetails.substring(sfpp, bank);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1
						&& health == -1 && bank == -1 && MutualFunds != -1) {
					SFPPStatus = policyDetails.substring(sfpp, MutualFunds);
				} else if (sfpp != -1 && auto == -1 && fire == -1 && life == -1
						&& health == -1 && bank == -1 && MutualFunds == -1) {
					SFPPStatus = policyDetails.substring(sfpp,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.SFPPPOLICY_NOTFOUND);
				}

				if (auto != -1 && fire != -1) {

					autoStatus = policyDetails.substring(auto, fire);
				} else if (auto != -1 && fire == -1 && life != -1) {
					autoStatus = policyDetails.substring(auto, life);
				} else if (auto != -1 && fire == -1 && life == -1
						&& health != -1) {
					autoStatus = policyDetails.substring(auto, health);
				} else if (auto != -1 && fire == -1 && life == -1
						&& health == -1 && bank != -1) {
					autoStatus = policyDetails.substring(auto, bank);
				} else if (auto != -1 && fire == -1 && life == -1
						&& health == -1 && bank == -1 && MutualFunds != -1) {
					autoStatus = policyDetails.substring(auto, MutualFunds);
				} else if (auto != -1 && fire == -1 && life == -1
						&& health == -1 && bank == -1 && MutualFunds == -1) {
					autoStatus = policyDetails.substring(auto,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.AUTOPOLICY_NOTFOUND);
				}

				if (fire != -1 && life != -1) {
					fireStatus = policyDetails.substring(fire, life);
				} else if (fire != -1 && life == -1 && health != -1) {
					fireStatus = policyDetails.substring(fire, health);
				} else if (fire != -1 && life == -1 && health == -1
						&& bank != -1) {
					fireStatus = policyDetails.substring(fire, bank);
				} else if (fire != -1 && life == -1 && health == -1
						&& bank == -1 && MutualFunds != -1) {
					fireStatus = policyDetails.substring(fire, MutualFunds);
				} else if (fire != -1 && life == -1 && health == -1
						&& bank == -1 && MutualFunds == -1) {
					fireStatus = policyDetails.substring(fire,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.FIREPOLICY_NOTFOUND);
				}

				if (life != -1 && health != -1) {
					lifeStatus = policyDetails.substring(life, health);
				} else if (life != -1 && health == -1 && bank != -1) {
					lifeStatus = policyDetails.substring(life, bank);
				} else if (life != -1 && health == -1 && bank == -1
						&& MutualFunds != -1) {
					lifeStatus = policyDetails.substring(life, MutualFunds);
				} else if (life != -1 && health == -1 && bank == -1
						&& MutualFunds == -1) {
					lifeStatus = policyDetails.substring(life,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.LIFEPOLICY_NOTFOUND);
				}

				if (health != -1 && bank != -1) {
					healthStatus = policyDetails.substring(health, bank);
				} else if (health != -1 && bank == -1 && MutualFunds != -1) {
					healthStatus = policyDetails.substring(health, MutualFunds);
				} else if (health != -1 && bank == -1 && MutualFunds == -1) {
					healthStatus = policyDetails.substring(health,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.HEALTHPOLICY_NOTFOUND);
				}

				if (bank != -1 && MutualFunds != -1) {
					bankStatus = policyDetails.substring(bank, MutualFunds);
				} else if (bank != -1 && MutualFunds == -1) {
					bankStatus = policyDetails.substring(bank,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.BANKPOLICY_NOTFOUND);
				}

				if (MutualFunds != -1) {
					mutualFundStatus = policyDetails.substring(MutualFunds,
							policyDetails.length());
				} else {
					Verify.verifyTrue(true,
							MessageUtility.LINK_MUTUALFUNDSPOLICY_NOTFOUND);
				}

				if (SFPPStatus != null)
					sfppCount = countPolicy(SFPPStatus, "Active")
							+ countPolicy(SFPPStatus, "Not Active")
							+ countPolicy(SFPPStatus, "Transferred")
							+ countPolicy(SFPPStatus, "Pended")
							+ countPolicy(SFPPStatus, "inactive");
				if (autoStatus != null)
					autoCount = countPolicy(autoStatus, "Active")
							+ countPolicy(autoStatus, "Not Active")
							+ countPolicy(autoStatus, "inactive");
				if (fireStatus != null)
					fireCount = countPolicy(fireStatus, "Active")
							+ countPolicy(fireStatus, "Not Active")
							+ countPolicy(fireStatus, "inactive")
							+ countPolicy(fireStatus, "Issued");
				if (lifeStatus != null)
					lifeCount = countPolicy(lifeStatus, "Active")
							+ countPolicy(lifeStatus, "Not Active")
							+ countPolicy(lifeStatus, "inactive")
							+ countPolicy(lifeStatus, "Issued");
				if (healthStatus != null)
					healthCount = countPolicy(healthStatus, "Active")
							+ countPolicy(healthStatus, "Not Active")
							+ countPolicy(healthStatus, "inactive")
							+ countPolicy(healthStatus, "Issued");
				if (bankStatus != null)
					bankCount = countPolicy(bankStatus, "Active")
							+ countPolicy(bankStatus, "Not Active")
							+ countPolicy(bankStatus, "inactive")
							+ countPolicy(bankStatus, "Issued");
				if (mutualFundStatus != null)
					mutualFundCount = countPolicy(mutualFundStatus, "Active")
							+ countPolicy(mutualFundStatus, "Not Active")
							+ countPolicy(mutualFundStatus, "inactive")
							+ countPolicy(mutualFundStatus, "Issued");

				String millionDollarBar = SSNSINObjects.WidgetInfos.DIV_POLICYSTATUS.getText();
				int millionDollarBarSFPPCount = Integer
						.parseInt(millionDollarBar.substring(22, 23));
				int millionDollarBarAutoCount = Integer
						.parseInt(millionDollarBar.substring(30, 31));
				int millionDollarBarFireCount = Integer
						.parseInt(millionDollarBar.substring(38, 39));
				int millionDollarBarLifeCount = Integer
						.parseInt(millionDollarBar.substring(46, 47));
				int millionDollarBarHealthCount = Integer
						.parseInt(millionDollarBar.substring(56, 57));
				int millionDollarBarBankCount = Integer
						.parseInt(millionDollarBar.substring(64, 65));
				int millionDollarBarMutualFundCount = Integer
						.parseInt(millionDollarBar.substring(73, 74));

				if (sfppCount == millionDollarBarSFPPCount)
					Verify.verifyTrue(true,
							MessageUtility.SFPPPOLICYCOUNT_EQUAL);

				else
					Verify.verifyTrue(false,
							MessageUtility.SFPPPOLICYCOUNT_NOTEQUAL);

				if (autoCount == millionDollarBarAutoCount)
					Verify.verifyTrue(true,
							MessageUtility.AUTOPOLICYCOUNT_EQUAL);

				else
					Verify.verifyTrue(false,
							MessageUtility.AUTOPOLICYCOUNT_NOTEQUAL);

				if (fireCount == millionDollarBarFireCount)
					Verify.verifyTrue(true,
							MessageUtility.FIREPOLICYCOUNT_EQUAL);

				else
					Verify.verifyTrue(false,
							MessageUtility.FIREPOLICYCOUNT_NOTEQUAL);

				if (bankCount == millionDollarBarBankCount)
					Verify.verifyTrue(true,
							MessageUtility.BANKPOLICYCOUNT_EQUAL);

				else
					Verify.verifyTrue(false,
							MessageUtility.BANKPOLICYCOUNT_NOTEQUAL);

				if (healthCount == millionDollarBarHealthCount)
					Verify.verifyTrue(true,
							MessageUtility.HEALTHPOLICYCOUNT_EQUAL);

				else
					Verify.verifyTrue(false,
							MessageUtility.HEALTHPOLICYCOUNT_NOTEQUAL);

				if (lifeCount == millionDollarBarLifeCount)
					Verify.verifyTrue(true,
							MessageUtility.LIFEPOLICYCOUNT_EQUAL);

				else
					Verify.verifyTrue(false,
							MessageUtility.LIFEPOLICYCOUNT_NOTEQUAL);

				if (mutualFundCount == millionDollarBarMutualFundCount)
					Verify.verifyTrue(
							true,
							MessageUtility.MUTUALFUNDSPOLICYCOUNT_EQUAL);

				else
					Verify.verifyTrue(
							false,
							MessageUtility.MUTUALFUNDSPOLICYCOUNT_NOTEQUAL);
			} else
				Verify.verifyTrue(false,
						"ACCOUNTS & POLICIES Light box not Opened");
		} catch (ScriptException e) {
			scriptError(e);
		}

	}
    /**
     * Counting Policy by Status
     * @param policyDetails
     * @param status
     * @return
     */
	public int countPolicy(String policyDetails, String status) {
		int length = 0;
		String[] arr = policyDetails.split(status);
		length = arr.length;

		return length - 1;
	}

	/**
	 * All active policies of P1(where P1 is named on the policy) in IL will be displayed in Accounts/Policies section and policies are hyper linked. Agent field will be blank.
	 * 
	 * All active policies of P1 in IN will be displayed in Accounts/Policies section but not hyper linked. Agent field will have IN Agent's name displayed.
	 * @author ux14
	 * 
	 */
	public void validatePoliciesInInsuranceTabForSharedAgent() {

		try {
			int divCount = 1;
			String agentName = null;
			String policyNumber = null;
			int d = 1;
			while (true) {
				try {
					
					WebElement policyText = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']" +
							"/div/div["+divCount+"]/table/tbody/tr[2]/td[3]/a"));
					policyNumber = policyText.getText(); 
					WebElement agentText = getWebDriverInstance().findElement(By.xpath("//div[@id='dojox_grid__View_1']/div[@class='dojoxGridScrollbox']/div[@class='dojoxGridContent']" +
							"/div/div["+divCount+"]/table/tbody/tr[2]/td[4]"));
					agentName = agentText.getText();
					
					Link policyNumberLink = new Link("text=" + policyNumber);
					Link agentNameLink = new Link("text=" + agentName);

					if (policyNumberLink.exists()) {
						Verify.verifyTrue(
								true, MessageUtility.POLICYNUMBER_DISPLAYED);
								
						if (!agentNameLink.exists())
							Verify.verifyTrue(
									true, MessageUtility.AGENTNAME_NOTHYPERLINK);
									
					} else if (agentNameLink.exists()) {

						Verify.verifyTrue(
								true, MessageUtility.AGENTNAME_HYPERLINK);

						if (!policyNumberLink.exists())

							Verify.verifyTrue(
									true, MessageUtility.POLICYNUMBER_NOTDISPLAYED);
					} else if (policyNumberLink.exists()
							&& agentNameLink.exists())

						Verify.verifyTrue(
								false,
								MessageUtility.POLICYNUMBERANDAGENTNAME);

					divCount++;
					d++;
				} catch (Exception e) {
					break;
				}
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
    /**
     * 
     * Select And Validate Second Agent From Multiple Households
     * @throws ScriptException
     */
	public void selectAndValidateSecondAgentFromMultipleHouseholds()
			throws ScriptException {
		Link cusHH = new Link("text=Customer Households");
		Link link = new Link("id=11");

		if (cusHH.exists()) {
			cusHH.hover();
			link.click();
			Verify.verifyTrue(true,
					MessageUtility.SECONDAGENT_SELECTED);
			validatePoliciesInInsuranceTabForSharedAgent();
			Verify.verifyTrue(true, MessageUtility.POLICYDETAILS_SECONDAGENT);
			Verify.verifyTrue(true,SSNSINObjects.WidgetInfos.DIV_GRIDINSURANCE.getText());
			Verify.verifyTrue(true, MessageUtility.TABLEEND);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.SECONDAGENT_NOTSELECTED);

		}
		waitForPageLoad(HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD, 30);
	}

	
   /**
    * Verify SSN in PersonalInfo section 
    * @throws ScriptException
    */
	public void verifySSNPersonalInfo() throws ScriptException {
		if (isCustomerInfoPageExists()) {
			setIFrame();
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SSN.exists()
					|| Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSSN
							.exists())
				Verify.verifyTrue(true,
						MessageUtility.SSN_DISPLAYED);
			else
				Verify.verifyTrue(false,
						MessageUtility.SSN_NOTDISPLAYED);

		} else
			Verify.verifyTrue(
					false,
					MessageUtility.CUSTINFOPAGE_LAUNCHED);

	}
    /**
     * Verify SIN in PersonalInfo section 
     * @throws ScriptException
     */
	public void verifySINPersonalInfo() throws ScriptException {
		setTopFramewithDefaultContent();
		if (isCustomerInfoPageExists()) {
			setIFrame();
			if (Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_SIN.exists()
					|| Update_IND_CustomerInfo_PageObjects.WidgetInfos.TEXT_MASKSIN
							.exists())
				Verify.verifyTrue(true,
						MessageUtility.SIN_DISPLAYED);
			else
				Verify.verifyTrue(false,
						MessageUtility.SIN_NOTDISPLAYED);
			click(Update_IND_CustomerInfo_PageObjects.WidgetInfos.BUTTON_CANCEL,
					MessageUtility.BUTTON_CANCEL);
		} else
			Verify.verifyTrue(
					false,
					MessageUtility.CUSTINFOPAGE_LAUNCHED);

	}

	/**
     * Validating Policies In Insurance Tab for Shared Agent 
     * 
     */
	public void validatePoliciesInInsuranceTab() {
		try {
			if (isHHPageLaunched()) {
				if (SSNSINObjects.WidgetInfos.DIV_GRIDINSURANCE.exists()) {
					validatePoliciesInInsuranceTabForSharedAgent();
					Verify.verifyTrue(true,MessageUtility.POLICYDETAILS_FIRSTAGENT);
					Verify.verifyTrue(true,SSNSINObjects.WidgetInfos.DIV_GRIDINSURANCE
							.getText());
					Verify.verifyTrue(true, MessageUtility.TABLEEND);
					selectAndValidateSecondAgentFromMultipleHouseholds();
				} else
					Verify.verifyTrue(false,
							MessageUtility.INSURANCEPOLICIES_NOTFOUND);
			} else
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
		} catch (ScriptException e) {
			scriptError(e);
		}
	}
}
