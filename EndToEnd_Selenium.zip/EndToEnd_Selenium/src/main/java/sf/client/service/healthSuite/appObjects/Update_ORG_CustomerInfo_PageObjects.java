package sf.client.service.healthSuite.appObjects;


import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.CheckBox;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.TextField;

public class Update_ORG_CustomerInfo_PageObjects {
				
		/*public static final ListBox list_hearAboutOffice =  new ListBox("id=organization.agent.hearAboutOfficeCode"); 
		public static final ListBox list_mostimportanttoyou =   new ListBox("id=organization.agent.agentMarketingInfo.importanceFactorCode"); 
		public static final TextField text_other_mostimportanttoyou =  new TextField("id=organization.agent.agentMarketingInfo.importanceFactorOther");
		public static final Link link_updateOrgInfo = new Link("text=Update");
		public static final ListBox list_OrgType =  new ListBox("id=organization.orgType");
		public static final ListBox list_Industry =   new ListBox("id=organization.enterpriseMarketingInfo.industryValue"); 
		public static final TextField text_IndustryOther =   new TextField("id=organization.enterpriseMarketingInfo.industryText");
		public static final TextField text_numberofEmployees =  new TextField("id=organization.enterpriseMarketingInfo.employeeCount");
		public static final TextField text_organizationRevenue =  new TextField("id=organization.agent.agentMarketingInfo.organizationRevenue");
		public static final TextField text_firstYearWithSF =  new TextField("id=organization.enterpriseMarketingInfo.firstYearWithSF");
		public static final TextField text_customerCategory =  new TextField("id=organization.agent.agentMarketingInfo.customerCategory");
		public static final ListBox list_assignedstaff =   new ListBox("id=organization.agent.staffAssociateId");
		public static final CheckBox checkbox_primaryMarketingContact =  new CheckBox("id=organization.enterpriseMarketingInfo.marketingMailingRecipientIndicator");
		public static final TextField text_emailAddress1 = new TextField("name=email.address");
		public static final Link CUSTOMERPROFILEPRINT=new Link("id=customerProfilePrint");
		public static final TextField TEXT_TIN_NUMBER = new TextField("id=organization.tin.maskedNumber");
		public static final Div MARKETING_OPPORTUNITIES=new Div("id=divBody");*/
	
	private static final String UPDATE_ORG_LISTBOX_HEARABOUTOFFICE = "id=organization.agent.hearAboutOfficeCode";
	private static final String UPDATE_ORG_LISTBOX_MOSTIMPORTANTTOYOU = "id=organization.agent.agentMarketingInfo.importanceFactorCode";
	private static final String UPDATE_ORG_TEXTFIELD_OTHER_MOSTIMPORTANTTOYOU =  "id=organization.agent.agentMarketingInfo.importanceFactorOther";
	private static final String UPDATE_ORG_LINK_UPDATEORGINFO = "text=Update";
	private static final String UPDATE_ORG_LISTBOX_ORGTYPE =  "id=organization.orgType";
	private static final String UPDATE_ORG_LISTBOX_INDUSTRY =   "id=organization.enterpriseMarketingInfo.industryValue";
	private static final String UPDATE_ORG_TEXTFIELD_INDUSTRYOTHER =   "id=organization.enterpriseMarketingInfo.industryText";
	private static final String UPDATE_ORG_TEXTFIELD_NUMBEROFEMPLOYEES = "id=organization.enterpriseMarketingInfo.employeeCount";
	private static final String UPDATE_ORG_TEXTFIELD_ORGANIZATIONREVENUE =  "id=organization.agent.agentMarketingInfo.organizationRevenue";
	private static final String UPDATE_ORG_TEXTFIELD_FIRSTYEARWITHSF =  "id=organization.enterpriseMarketingInfo.firstYearWithSF";
	private static final String UPDATE_ORG_TEXTFIELD_CUSTOMERCATEGORY =  "id=organization.agent.agentMarketingInfo.customerCategory";
	private static final String UPDATE_ORG_LISTBOX_ASSIGNEDSTAFF =  "id=organization.agent.staffAssociateId";
	private static final String UPDATE_ORG_CHECKBOX_PRIMARYMARKETINGCONTACT = "id=organization.enterpriseMarketingInfo.marketingMailingRecipientIndicator";
	private static final String UPDATE_ORG_TEXTFIELD_EMAILADDRESS1 = "id=email.address";
	private static final String UPDATE_ORG_LINK_CUSTOMERPROFILEPRINT="id=customerProfilePrint";
	private static final String UPDATE_ORG_TEXTFIELD_TIN_NUMBER = "id=organization.tin.maskedNumber";
	private static final String UPDATE_ORG_DIV_MARKETING_OPPORTUNITIES="id=divBody";
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final ListBox LISTBOX_HEARABOUTOFFICE =  new ListBox(UPDATE_ORG_LISTBOX_HEARABOUTOFFICE);
		public static final ListBox LISTBOX_MOSTIMPORTANTTOYOU =   new ListBox(UPDATE_ORG_LISTBOX_MOSTIMPORTANTTOYOU);
		public static final TextField TEXTFIELD_OTHER_MOSTIMPORTANTTOYOU =  new TextField(UPDATE_ORG_TEXTFIELD_OTHER_MOSTIMPORTANTTOYOU);
		public static final Link LINK_UPDATEORGINFO = new Link(UPDATE_ORG_LINK_UPDATEORGINFO);
		public static final ListBox LISTBOX_ORGTYPE =  new ListBox(UPDATE_ORG_LISTBOX_ORGTYPE);
		public static final ListBox LISTBOX_INDUSTRY =   new ListBox(UPDATE_ORG_LISTBOX_INDUSTRY);
		public static final TextField TEXTFIELD_INDUSTRYOTHER =   new TextField(UPDATE_ORG_TEXTFIELD_INDUSTRYOTHER);
		public static final TextField TEXTFIELD_NUMBEROFEMPLOYEES =  new TextField(UPDATE_ORG_TEXTFIELD_NUMBEROFEMPLOYEES);
		public static final TextField TEXTFIELD_ORGANIZATIONREVENUE =  new TextField(UPDATE_ORG_TEXTFIELD_ORGANIZATIONREVENUE);
		public static final TextField TEXTFIELD_FIRSTYEARWITHSF =  new TextField(UPDATE_ORG_TEXTFIELD_FIRSTYEARWITHSF);
		public static final TextField TEXTFIELD_CUSTOMERCATEGORY =  new TextField(UPDATE_ORG_TEXTFIELD_CUSTOMERCATEGORY);
		public static final ListBox LISTBOX_ASSIGNEDSTAFF =   new ListBox(UPDATE_ORG_LISTBOX_ASSIGNEDSTAFF);
		public static final CheckBox CHECKBOX_PRIMARYMARKETINGCONTACT =  new CheckBox(UPDATE_ORG_CHECKBOX_PRIMARYMARKETINGCONTACT);
		public static final TextField TEXTFIELD_EMAILADDRESS1 = new TextField(UPDATE_ORG_TEXTFIELD_EMAILADDRESS1);
		public static final Link LINK_CUSTOMERPROFILEPRINT=new Link(UPDATE_ORG_LINK_CUSTOMERPROFILEPRINT);
		public static final TextField TEXTFIELD_TIN_NUMBER = new TextField(UPDATE_ORG_TEXTFIELD_TIN_NUMBER);
		public static final Div DIV_MARKETING_OPPORTUNITIES=new Div(UPDATE_ORG_DIV_MARKETING_OPPORTUNITIES);
	}
}

