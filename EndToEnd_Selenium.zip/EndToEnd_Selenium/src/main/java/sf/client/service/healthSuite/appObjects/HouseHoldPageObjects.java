package sf.client.service.healthSuite.appObjects;

import statefarm.widget.automater.WidgetIDs;
import statefarm.widget.gui.Button;
import statefarm.widget.gui.Div;
import statefarm.widget.gui.Label;
import statefarm.widget.gui.Link;
import statefarm.widget.gui.ListBox;
import statefarm.widget.gui.Span;
import statefarm.widget.gui.TextField;

public class HouseHoldPageObjects {
	
	public static final String HOUSEHOLD_ICSSPAGE = "id=launchCustomerRegistrationForm:buttonGroup";
	public static final String HOUSEHOLD_ICSSPAGE_CLOSE_BUTTON= "id=launchCustomerRegistrationForm:closeButton";
	public static final String USER_ID= "name=userId";
	public static final String HOUSEHOLD_MR_ICON_HHPAGE =  "class=icon_MasterRecord";
	public static final String HOUSEHOLD_INSURANCEPOLICIES =  "id=policyTabContainer_tablist_tempGrid";
	public static final	String HOUSEHOLD_IACTIVECUSTOMERBAR =  "id=divClientBar";
	public static final String HOUSEHOLD_ACTIVE_CUSTOMER_BAR =  "id=lblClientName";
	public static final String HOUSEHOLD_ACTIVECLIENT_LBLCLIENTNAME =  "id=activeClient_lblClientName";
	public static final String HOUSEHOLD_LINK_HELPONTHISPAGE =  "text=help on this page";
	public static final String HOUSEHOLD_LINK_HOUSEHOLD =  "text=Household";
	public static final String HOUSEHOLD_LINK_UPDATEFIREOTHERS =  "text=FIRETEST"; 
	public static final String HOUSEHOLD_LINK_ADDINDIVIDUAL = "text=Individual";
	public static final String HOUSEHOLD_HTML_NONDISCLOSE =  "id=footer"; 
	public static final String HOUSEHOLD_LINK_ADDORGANIZATION = "text=Organization";
	public static final String HOUSEHOLD_TEXTFIELD_ADDUPDATECOMMENTS = "id=hhCommentTextArea";
	public static final String HOUSEHOLD_BUTTON_HHCOMMENTSAVE_LABEL= "id=hhCommentSave_label";
	public static final String HOUSEHOLD_TEXTAREA_HHCOMMENTS_LATEST =  "id=hhCommentEditor"; 
	public static final String HOUSEHOLD_LINK_ADDOTHERS =  "text=Add Products with Others";
	public static final String HOUSEHOLD_LABEL_POLICYCOUNT_WITHOTHERS =  "id=otherMillionDollarLine";
	public static final	String HOUSEHOLD_INACTIVEPOLICIES =  "id=policyTabContainer_tablist_tempInactiveProductGrid";
	public static final String HOUSEHOLD_AHQBLOGO =  "id=qblogo";
	public static final String HOUSEHOLD_REFRESH_CLOSE_MENU= "class=refreshCloseMenu";
	public static final String HOUSEHOLD_REFRESH= "text=Refresh";
	public static final String HOUSEHOLD_CLOSE= "text=Close";
	public static final String HOUSEHOLD_PHONE_NUMBERS= "id=phoneNumber";

	public static final String HOUSEHOLD_LINK_UPDATEBANKOTHERS =  "text=AMA"; 
	public static final String HOUSEHOLD_LINK_UPDATEAUTOOTHERS =  "text=AIG"; 
	
	
	@WidgetIDs
	public static class WidgetInfos {
		public static final Span ICSSPAGE=new Span(HOUSEHOLD_ICSSPAGE);
		public static final Span ICSSPAGE_CLOSE_BUTTON=new Span(HOUSEHOLD_ICSSPAGE_CLOSE_BUTTON);
		public static final TextField USER_ID_TEXTFIELD=new TextField(USER_ID);
		public static final Span MR_ICON_HHPAGE = new Span(HOUSEHOLD_MR_ICON_HHPAGE);
		public static final Div INSURANCEPOLICIES = new Div(HOUSEHOLD_INSURANCEPOLICIES);
		public static final	Div ACTIVECUSTOMERBAR = new Div(HOUSEHOLD_IACTIVECUSTOMERBAR);
		public static final Link HH_ACTIVE_CUSTOMER_BAR = new Link(HOUSEHOLD_ACTIVE_CUSTOMER_BAR);
		public static final Link LINK_HELPONTHISPAGE = new Link(HOUSEHOLD_LINK_HELPONTHISPAGE);
		public static final Link LINK_UPDATEBANKOTHERS = new Link(HOUSEHOLD_LINK_UPDATEBANKOTHERS); 
		public static final Link LINK_UPDATEFIREOTHERS = new Link(HOUSEHOLD_LINK_UPDATEFIREOTHERS); 
		public static final Link LINK_UPDATEAUTOOTHERS = new Link(HOUSEHOLD_LINK_UPDATEAUTOOTHERS); 
		public static final Link LINK_ADDINDIVIDUAL =new Link(HOUSEHOLD_LINK_ADDINDIVIDUAL);
		public static final Div HTML_NONDISCLOSE = new Div(HOUSEHOLD_HTML_NONDISCLOSE); 
		public static final Link LINK_ADDORGANIZATION =new Link(HOUSEHOLD_LINK_ADDORGANIZATION);
		public static final TextField TEXTFIELD_ADDUPDATECOMMENTS =new TextField(HOUSEHOLD_TEXTFIELD_ADDUPDATECOMMENTS);
		public static final Button  BUTTON_HHCOMMENTSAVE_LABEL=new Button(HOUSEHOLD_BUTTON_HHCOMMENTSAVE_LABEL);
		public static final TextField TEXTAREA_HHCOMMENTS_LATEST = new TextField(HOUSEHOLD_TEXTAREA_HHCOMMENTS_LATEST); 
		public static final Label LABEL_POLICYCOUNT_WithOthers = new Label(HOUSEHOLD_LABEL_POLICYCOUNT_WITHOTHERS);
		public static final	Div INACTIVEPOLICIES = new Div(HOUSEHOLD_INACTIVEPOLICIES);
		public static final Link AHQBLOGO = new Link(HOUSEHOLD_AHQBLOGO);
		public static final Link REFRESH_CLOSE_MENU=new Link(HOUSEHOLD_REFRESH_CLOSE_MENU);
		public static final Link REFRESH=new Link(HOUSEHOLD_REFRESH);
		public static final Link CLOSE=new Link(HOUSEHOLD_CLOSE);
		public static final ListBox PHONE_NUMBERS=new ListBox(HOUSEHOLD_PHONE_NUMBERS);
		public static final Link LINK_ADDOTHERS = new Link(HOUSEHOLD_LINK_ADDOTHERS);
		public static final Link ACTIVECLIENT_LBLCLIENTNAME = new Link(HOUSEHOLD_ACTIVECLIENT_LBLCLIENTNAME);
		public static final Link REFRESH_OR_CLOSE=new Link("Refresh/Close");

	}
}

