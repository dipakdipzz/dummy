package sf.client.service.healthSuite.tasks;

import org.openqa.selenium.By;
import sf.client.service.common.appObjects.ABSCustomerSearchTestObjects;
import sf.client.service.common.helpers.ScriptException;
import sf.client.service.healthSuite.appObjects.AddAccountsandPoliciesPopupObjects;
import sf.client.service.healthSuite.appObjects.HHRewriteObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldMove_PageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldPageObjects;
import sf.client.service.healthSuite.appObjects.HouseHoldTestObjects;
import sf.client.service.healthSuite.appObjects.ReviewDatePopupObjects;
import sf.client.service.healthSuite.appObjects.SearchSelectCustomerAppObj;
import sf.client.service.healthSuite.helpers.EndToEndConstants;
import sf.client.service.healthSuite.helpers.MessageUtility;
import sf.client.service.healthSuite.to.ClientE2ETO;
import statefarm.widget.manager.Verify;

public class HHnavigationTasks extends HouseHoldTasks {

	public HHnavigationTasks() {
		super();

	}

	public HHnavigationTasks(ClientE2ETO clientE2ETO) {
		super(clientE2ETO);
	}

	/**
	 * Click Save Button
	 * 
	 * @throws ScriptException
	 */
	public void clickSaveButton() throws ScriptException {
		try {
			waitForPageLoad(
					AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_SAVE,
					10);
			click(AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_SAVE,
					MessageUtility.BUTTON_SAVE);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Select Line of Business from Add Accounts and Policies Page
	 * 
	 * @param sLOB
	 * @throws ScriptException
	 */
	public void selectLineOfBusiness(String sLOB) throws ScriptException {
		waitForPageLoad(
				AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS,
				20);
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS
				.exists()) {
			selectFromListbox(
					AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS,
					sLOB, sLOB + MessageUtility.LINEOFBUSINESS);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINEOFBUSINESS_NOTFOUND);
		}
	}

	/**
	 * Select State from Add Accounts and Policies Page
	 * 
	 * @param sState
	 * @throws ScriptException
	 */
	public void selectStateProv(String sState) throws ScriptException {
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_STATE_PROV
				.exists()) {
			selectFromListbox(
					AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_STATE_PROV,
					sState, sState + MessageUtility.STATEORPROVINCE);
		} else {
			Verify.verifyTrue(false, MessageUtility.STATEORPROVINCE_NOTFOUND);
		}
	}

	/**
	 * Select ProductType from Add Accounts and Policies Page
	 * 
	 * @param sProductType
	 * @throws ScriptException
	 */
	public void selectProductType(String sProductType) throws ScriptException {
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_PRODUCT_TYPE
				.exists()) {
			selectFromListbox(
					AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_PRODUCT_TYPE,
					sProductType, sProductType + MessageUtility.PRODUCTTYPE);
			waitForTime(2);
		} else {
			Verify.verifyTrue(false, MessageUtility.PRODUCTTYPE_NOTFOUND);
		}
	}

	/**
	 * Select Company from Add Accounts and Policies Page
	 * 
	 * @param sCompany
	 * @throws ScriptException
	 */
	public void selectCompany(String sCompany) throws ScriptException {
		waitForPageLoad(
				AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY, 20);
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY
				.exists()) {
			selectFromListbox(
					AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_COMPANY,
					sCompany, sCompany + MessageUtility.COMPANY);
		} else {
			Verify.verifyTrue(false, MessageUtility.COMPANY_NOTFOUND);
		}
	}

	/**
	 * Select XDate from Add Accounts and Policies Page
	 * 
	 * @param sXdate
	 * @throws ScriptException
	 */
	public void enterXDate(String sXdate) throws ScriptException {
		waitForPageLoad(
				AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_TERM_DATE,
				20);
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_TERM_DATE
				.exists()) {
			setTextInTextbox(
					AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_TERM_DATE,
					sXdate, sXdate + MessageUtility.EXDATE);
		} else {
			Verify.verifyTrue(false, MessageUtility.EXDATE_NOTFOUND);
		}
	}

	/**
	 * Select Details from Add Accounts and Policies Page
	 * 
	 * @param sDetails
	 * @throws ScriptException
	 */
	public void enterDetails(String sDetails) throws ScriptException {
		waitForPageLoad(
				AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_ACCOUNT_DETAILS,
				20);
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_ACCOUNT_DETAILS
				.exists()) {
			setTextInTextbox(
					AddAccountsandPoliciesPopupObjects.WidgetInfos.TEXT_ACCOUNT_DETAILS,
					sDetails, sDetails + MessageUtility.DETAILS);
		} else {
			Verify.verifyTrue(false, MessageUtility.DETAILS_NOTFOUND);
		}
	}

	/**
	 * Click Move Members Between TwoHouseholds Link
	 * 
	 * @throws ScriptException
	 */
	public void clickMoveMembersBetweenTwoHouseholds() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_BETWEEN_TWOHOUSEHOLDS);
		if (HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_BETWEEN_TWOHOUSEHOLDS
				.exists()) {
			click(HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_BETWEEN_TWOHOUSEHOLDS,
					MessageUtility.LINK_MOVEMEMBERSBETWEENTWOHOUSEHOLDS);
			Verify.verifyTrue(true,
					MessageUtility.LINK_MOVEMEMBERSBETWEENTWOHOUSEHOLDS);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_MOVEMEMBERSBETWEENTWOHOUSEHOLDS_NOTDISPLAYED);
		}
	}

	/**
	 * Click Save Button From Household Moves page
	 * 
	 * @throws ScriptException
	 */
	public void clickSaveButtonFromMOVE() throws ScriptException {
		if (HouseHoldMove_PageObjects.WidgetInfos.BUTTON_SAVEMOVE.exists()) {
			click(HouseHoldMove_PageObjects.WidgetInfos.BUTTON_SAVEMOVE,
					MessageUtility.BUTTON_SAVE);

		} else {
			Verify.verifyTrue(false,
					MessageUtility.BUTTON_SAVE_NOTFOUND);
		}
	}

	/**
	 * Click on the 'Add Products with Others' option in the PRODUCT ACTIONS
	 * drop down menu and Add policies others
	 */
	public void validateAddProductsWithOthersfromHHPage() {
		try {
			if (isHHPageLaunched()) {
				clickMenuBar(HHRewriteObjects.WidgetInfos.PRODUCT_ACTIONS, HHRewriteObjects.WidgetInfos.ADD_PRODUCT_WITH_OTHERS);
				setWindow(EndToEndConstants.ADD_ACCOUNTSPOLICIES_WITHOTHERS,
						30, 2);
				isErrorPage("Add Products with Others");
				if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS
						.exists()) {
					addAcctPolicy(clientE2ETO);
					clickSaveButton();
					isErrorPage("Save in Add Products with Others");
					closeAddAccountPolicies();
				}
				setWindow(EndToEndConstants.HOUSEHOLD_INFORMATION, 30, 2);
				setTopFramewithDefaultContent();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click Close Button from Add Accounts and Policies Page
	 * 
	 * @throws ScriptException
	 */
	public void closeAddAccountPolicies() throws ScriptException {
		waitForPageLoad(
				AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_CLOSE, 20);
		if (AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_CLOSE
				.exists()) {
			click(AddAccountsandPoliciesPopupObjects.WidgetInfos.BUTTON_CLOSE,
					MessageUtility.BUTTON_CLOSE);
		} else {
			Verify.verifyTrue(false, MessageUtility.BUTTON_CLOSE_NOTFOUND);
		}
	}

	/**
	 * Selecting all products in Add Accounts and Policies Page
	 * 
	 * @param clientE2ETO
	 * @throws ScriptException
	 */
	public void addAcctPolicy(ClientE2ETO clientE2ETO) throws ScriptException {
		try {
			selectLineOfBusiness(clientE2ETO.getLineOfBusiness());
			waitForPageLoad(AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_PRODUCT_TYPE,10);
			selectProductType(clientE2ETO.getProductType());
			selectCompany(clientE2ETO.getCompany());
			enterXDate(clientE2ETO.getXdate());
			enterDetails(clientE2ETO.getDetails());
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Click on the 'Add Products with Others' in the HH Page
	 */
	public void addProductsWithOthersfromHHPage() {
		try {
			if (isHHPageLaunched()) {
				if (HouseHoldPageObjects.WidgetInfos.LINK_ADDOTHERS.exists()) {
					HouseHoldPageObjects.WidgetInfos.LINK_ADDOTHERS.click();
				}
				setWindow("Add Accounts/Policies With Others", 30, 2);
				isErrorPage("Add Accounts/Policies With Others");
				if (AddAccountsandPoliciesPopupObjects.WidgetInfos.LIST_LINE_OF_BUSINESS
						.exists()) {
					addAcctPolicy(clientE2ETO);
					clickSaveButton();
					isErrorPage("Save in Add Accounts/Policies With Others");
					closeAddAccountPolicies();
				}
				setParentWindow();

			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * verify HouseholdMoves Link for CRC
	 * 
	 * @throws ScriptException
	 */
	public void verifyQBHouseholdMovesLink() throws ScriptException {
		HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLD.click();
		if (!HouseHoldTestObjects.WidgetInfos.LINK_HOUSEHOLDMOVES_CRC.exists()) {
			Verify.verifyTrue(true, MessageUtility.LINK_HOUSEHOLDMOVES_NOTFOUND);
		} else {
			Verify.verifyTrue(false, MessageUtility.LINK_HOUSEHOLDMOVES_FOUND);
		}
	}

	/**
	 * verify Combine/Separate Link for CRC
	 * 
	 * @throws ScriptException
	 */
	public void verifyQBCombineSeparateLink() throws ScriptException {
		HouseHoldTestObjects.WidgetInfos.CUSTOMER_LINK.click();
		if (!HouseHoldTestObjects.WidgetInfos.LINK_CUSTOMER_UNDERCOMBINESEPARATE_CRC
				.exists()) {
			Verify.verifyTrue(true,
					MessageUtility.LINK_COMBINESEPARATE_NOTFOUND);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_COMBINESEPARATE_FOUND);
		}
	}

	/**
	 * Accessing Agent One Customer FOR HHMOVE Page
	 * 
	 * @throws ScriptException
	 */
	public void accessAgentOneCustomerFORHHMOVEPage() throws ScriptException {
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
				20);
		if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
				.exists()) {
			SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
					.click();
		}

		if (clientE2ETO.getLastNameHHMOVESearchpage() != null) {
			enterMandatoryfieldtoEnablebutton(
					HouseHoldMove_PageObjects.WidgetInfos.TEXT_AGENTNAMESEARCHCRITERIAL,
					clientE2ETO.getLastNameHHMOVESearchpage());
			Verify.verifyTrue(true, MessageUtility.LASTNAME_VALUE);
		}

		if (clientE2ETO.getFirstNameHHMOVESearchpage() != null) {
			setTextInTextbox(
					HouseHoldMove_PageObjects.WidgetInfos.TEXT_AGENTNAMESEARCHCRITERIAF,
					clientE2ETO.getFirstNameHHMOVESearchpage(),
					clientE2ETO.getFirstNameHHMOVESearchpage()
							+ MessageUtility.FIRSTNAME_VALUE);

		}
		if (clientE2ETO.getZipHHMOVESearchPage() != null) {
			setTextInTextbox(
					HouseHoldMove_PageObjects.WidgetInfos.TEXT_AGENTNAMESEARCHCRITERIAZ,
					clientE2ETO.getZipHHMOVESearchPage(),
					clientE2ETO.getZipHHMOVESearchPage()
							+ MessageUtility.ZIP_VALUE);
		} else {
			if (clientE2ETO.getCityHHMOVESearchPage() != null)
				setTextInTextbox(
						HouseHoldMove_PageObjects.WidgetInfos.TEXT_AGENTNAMESEARCHCRITERIAC,
						clientE2ETO.getCityHHMOVESearchPage(),
						clientE2ETO.getCityHHMOVESearchPage()
								+ MessageUtility.CITY_VALUE);
		}

		click(HouseHoldMove_PageObjects.WidgetInfos.BUTTON_SEARCHBUTTON,
				MessageUtility.BUTTON_SEARCH);
	}

	/**
	 * Accessing Agent One Customer FOR HHMOVE for ABS page
	 * 
	 * @throws ScriptException
	 */
	public void accessAgentOneCustomerFORHHMOVEPageAbs() throws ScriptException {
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
				20);
		if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
				.exists()) {
			SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
					.click();
		}

		if (clientE2ETO.getLastNameHHMOVESearchpage() != null) {
			enterMandatoryfieldtoEnablebutton(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME,
					clientE2ETO.getLastNameHHMOVESearchpage());
			Verify.verifyTrue(true,MessageUtility.LASTNAME_VALUE);
		}

		if (clientE2ETO.getFirstNameHHMOVESearchpage() != null) {
			setTextInTextbox(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_FIRSTNAME,
					clientE2ETO.getFirstNameHHMOVESearchpage(),
					clientE2ETO.getFirstNameHHMOVESearchpage()
							+ MessageUtility.FIRSTNAME_VALUE);

		}
		if (clientE2ETO.getZipHHMOVESearchPage() != null) {
			setTextInTextbox(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_ZIP,
					clientE2ETO.getZipHHMOVESearchPage(),
					clientE2ETO.getZipHHMOVESearchPage()
							+ MessageUtility.ZIP_VALUE);
		} else {
			if (clientE2ETO.getCityHHMOVESearchPage() != null)
				setTextInTextbox(
						ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_CITY,
						clientE2ETO.getCityHHMOVESearchPage(),
						clientE2ETO.getCityHHMOVESearchPage()
								+ MessageUtility.CITY_VALUE);
		}

		click(ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_SUBMIT,
				MessageUtility.BUTTON_SEARCH);
	}

	/**
	 * Accessing Agent Two Customer FOR HHMOVE for Portal page
	 * 
	 * @throws ScriptException
	 */
	public void accessAgentTWOCustomerFORHHMOVEPage() throws ScriptException {
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
				20);
		if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
				.exists()) {
			SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
					.click();
		}
		if (clientE2ETO.getLastNameHHMOVE2Searchpage() != null)

			enterMandatoryfieldtoEnablebutton(
					HouseHoldMove_PageObjects.WidgetInfos.TEXT_AGENTNAMESEARCHCRITERIAL,
					clientE2ETO.getLastNameHHMOVE2Searchpage());
		Verify.verifyTrue(true,MessageUtility.LASTNAME_VALUE);

		if (clientE2ETO.getFirstNameHHMOVE2Searchpage() != null)

			setTextInTextbox(

			HouseHoldMove_PageObjects.WidgetInfos.TEXT_AGENTNAMESEARCHCRITERIAF,

			clientE2ETO.getFirstNameHHMOVE2Searchpage(),
			MessageUtility.FIRSTNAME_VALUE);

		if (clientE2ETO.getZipHHMOVE2SearchPage() != null) {
			setTextInTextbox(HouseHoldMove_PageObjects.WidgetInfos.TEXT_AGENTNAMESEARCHCRITERIAZ,clientE2ETO.getZipHHMOVE2SearchPage(),MessageUtility.ZIP_VALUE);
		}

		click(HouseHoldMove_PageObjects.WidgetInfos.BUTTON_SEARCHBUTTON,MessageUtility.BUTTON_SEARCH);
	}

	/**
	 * Accessing Agent Two Customer FOR HHMOVE for ABS page
	 * 
	 * @throws ScriptException
	 */
	public void accessAgentTWOCustomerFORHHMOVEPageAbs() throws ScriptException {
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
				20);
		if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
				.exists()) {
			SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
					.click();
		}
		if (clientE2ETO.getLastNameHHMOVE2Searchpage() != null)

			enterMandatoryfieldtoEnablebutton(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_LASTNAME,
					clientE2ETO.getLastNameHHMOVE2Searchpage());
		Verify.verifyTrue(true,MessageUtility.LASTNAME_VALUE);

		if (clientE2ETO.getFirstNameHHMOVE2Searchpage() != null)

			setTextInTextbox(
					ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_FIRSTNAME,
					clientE2ETO.getFirstNameHHMOVE2Searchpage(),
					MessageUtility.FIRSTNAME_VALUE);

		if (clientE2ETO.getZipHHMOVE2SearchPage() != null) {
			setTextInTextbox(ABSCustomerSearchTestObjects.WidgetInfos.TEXT_ENTERPRISE_SEARCH_ZIP, clientE2ETO.getZipHHMOVE2SearchPage(),MessageUtility.ZIP_VALUE);
		}

		click(ABSCustomerSearchTestObjects.WidgetInfos.BUTTON_SUBMIT, MessageUtility.BUTTON_SEARCH);
	}

	public void validateHouseholdNonHouseholdLinks() {
		try {
			if (isHHPageLaunched()) {
				//validateHouseHoldLinkNotDisplayed();
				validateNonHouseHoldLinkNotDisplayed();
			} else {
				Verify.verifyTrue(
						false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	/**
	 * validate And Launch RelationshipPage
	 */
	public void validateAndLaunchRelationshipPage() {
		try {
			if (isHHPageLaunched()) {
				 clickMenuBar(HHRewriteObjects.WidgetInfos.HHHOUSEHOLDTAB, HHRewriteObjects.WidgetInfos.HHHOUSEHOLDRELATIONSHIPS);
				setWindow("Relationships", 5, 2);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/** Validate Product Inactive page */
	public void validateInactivePoliciesTabInHHPage() {
		try {
			if (isHHPageLaunched()) {
				clickInactivePolicies();
				displayInactivePolicies();
				validatePhoenixLinkNotDisplayedInProductsInactivePage();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}
	
	/**
	 * Launch Auto Policies from the Household Info section (Select a Customer
	 * having all LOB policies)
	 */
	public void validateAutoPolicyInHHPage() {
		try {
			if (isHHPageLaunched()) {
				clickInsurancePolicies();
				launchAutoAppfromHHPage();
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * Adding Review Dates
	 * 
	 * @throws ScriptException
	 */
	public void addReviewDates() throws ScriptException {
		try {
			if (isHHPageLaunched()) {
				waitForPageLoad(
						ReviewDatePopupObjects.WidgetInfos.LINK_PREVIOUSREVIEWDATE,
						10);
				if (ReviewDatePopupObjects.WidgetInfos.LINK_PREVIOUSREVIEWDATE
						.exists()) {
					clickPreviousReviewLink();
					waitForPageLoad(
							ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE,
							10);
					if (ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE
							.exists()
							&& ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE
									.exists()) {
						setTextInTextbox(
								ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_LASTREVIEWDATE,
								getPreviousReviewDate(),
								MessageUtility.LASTREVIEWDATE);
						setTextInTextbox(
								ReviewDatePopupObjects.WidgetInfos.TEXTFIELD_NEXTREVIEWDATE,
								getNextReviewDate(),
								MessageUtility.NEXTREVIEWDATE);
						if (ReviewDatePopupObjects.WidgetInfos.BUTTON_SAVE
								.exists()) {
							click(ReviewDatePopupObjects.WidgetInfos.BUTTON_SAVE,
									MessageUtility.BUTTON_SAVE);
							setTopFramewithDefaultContent();
						}
					} else {
						isErrorPage("Review Dates");
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.LINK_REVIEWDATES_NOTFOUND);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/**
	 * verify HHMoves -Move Members Between Two Households
	 */
	public void verifyHHMovesMoveMemberBetweenTwoHouseholds() {
		try {
			if (isHHPageLaunched()) {
				launchCMPageFromHHPage("text=Household",
						"text=Household Moves");
				
				if (isHouseholdMaintenancePageLaunched()) {
					clickMoveMembersBetweenTwoHouseholds();
					if (isSearchandSelectTwoCustomersExists()) {
						accessAgentOneCustomerFORHHMOVEPage();
						selectAndAddCustomerFromSearchResultsMCLBFirstCustomerHHMOVE();
						accessAgentTWOCustomerFORHHMOVEPage();
						selectAndAddCustomerFromSearchResultsMCLBSecondCustomerHHMOVE();
						if (isHHMoveSelectedTwoCustomersExist()) {
							launchNextPage();
							isErrorPage("Move Member Between Two Households");
							if (isMoveMembersBetweenTwoHouseholdsExists()) {
								moveCustomerNameOneForHHMove();
								moveCustomerNameTwoForHHMove();
								clickSaveButtonFromMOVE();
								isErrorPage("HH Moves-Move Member Between Two Households ");
								setTopFramewithDefaultContent();
								clickHHPageCustomer();
							} else {
								Verify.verifyTrue(false,
										MessageUtility.MOVEMEMBERSBETWEENTWOHOUSEHOLDSPAGE_NOTLAUNCHED);
								clickHHPageCustomer();
							}
						} else {
							Verify.verifyTrue(
									false,
									MessageUtility.SELECTEDCUSTOMERS_NOTADDED);
						}
					} else {
						Verify.verifyTrue(false,
								MessageUtility.COMBINECUSTOMERSPAGE_NOTEXISTS);
					}
				} else {
					Verify.verifyTrue(false,
							MessageUtility.HOUSEHOLDMAINTAINENCEPAGE_NOTLAUNCHED);
				}
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		}
	}

	/** verify HHMoves -Move Members to New Households for ABS Page
	 */
	public void verifyHHMovesMoveMembersToNewHousehold() {
		try {
			if (isHHPageLaunched()) {
				launchCMPageFromHHPage("innerText=Household",
						"innerText=Household Moves");
				waitForPageLoad(
						HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_TO_NEW_HOUSEHOLD,
						10);
				if (HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_TO_NEW_HOUSEHOLD
						.exists()) {
					clickMovememberstonewhousehold();
					selectAgentInHhMoves();
					selectNameToMove();
					selectMoveButton();
					clickSaveButton();
				} else
					Verify.verifyTrue(false,
							MessageUtility.HOUSEHOLDMAINTAINENCEPAGE_NOTLAUNCHED);
			} else {
				Verify.verifyTrue(false,
						MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		} catch (Exception e) {
			Verify.verifyTrue(false, e.getMessage());
		} finally {
			if (isErrorPage("Move Members To NewHousehold")) {
				clickHHPageCustomer();
				handleCimsVersion();
			}
		}
	}

	/**
	 * verify Household Maintenance Page is Launched
	 * 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isHouseholdMaintenancePageLaunched() throws ScriptException {
		waitForPageLoad(
				HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_BETWEEN_TWOHOUSEHOLDS,
				10);
		if (HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_BETWEEN_TWOHOUSEHOLDS
				.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * verify Search and Select Two Customers page is Exists
	 * 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isSearchandSelectTwoCustomersExists() throws ScriptException {
		waitForPageLoad(
				SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME,
				10);
		if (SearchSelectCustomerAppObj.WidgetInfos.RADIOBUTTON_SEARCHBYTYPEAGENTNAME
				.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * verify Move Members Between Two Households Page is Exists
	 * 
	 * @return
	 * @throws ScriptException
	 */
	public boolean isMoveMembersBetweenTwoHouseholdsExists()
			throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.TABLE_MOVECUSTTWONAMES, 15);
		if (HouseHoldMove_PageObjects.WidgetInfos.TABLE_MOVECUSTTWONAMES.exists()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Moving one customer from CustomerOne table to CustomerTwo table
	 * 
	 * @throws ScriptException
	 */
	public void moveCustomerNameOneForHHMove() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.BUTTON_MOVECUSTONENAME, 15);
		boolean selected = false;
		if (HouseHoldMove_PageObjects.WidgetInfos.TABLE_MOVECUSTTWONAMES.exists()) {
			if (HouseHoldMove_PageObjects.WidgetInfos.TABLE_MOVECUSTTWONAMES.exists())
				selected = moveCustomerDataMoveFunction(
						HouseHoldMove_PageObjects.WidgetInfos.TABLE_MOVECUSTTWONAMES,
						HouseHoldMove_PageObjects.WidgetInfos.BUTTON_MOVECUSTONENAME,
						clientE2ETO.getMoveCustomerOneHHMOVE());
			else {
				Verify.verifyTrue(true, MessageUtility.CUSTNAMES_NOTAVAILABLE);
			}
			if (selected) {
				Verify.verifyTrue(true, clientE2ETO.getMoveCustomerTwoHHMOVE()+ MessageUtility.NAME_MOVED);
			} else {
				Verify.verifyTrue(false, clientE2ETO.getMoveCustomerTwoHHMOVE()+ MessageUtility.NAME_NOTMOVED);
			}
		}

	}

	/**
	 * Moving one customer from CustomerTwo table to CustomerOne table
	 * 
	 * @throws ScriptException
	 */
	public void moveCustomerNameTwoForHHMove() throws ScriptException {
		boolean selected = false;
		if (HouseHoldMove_PageObjects.WidgetInfos.TABLE_MOVECUSTTWONAMES2.exists()) {
			if (HouseHoldMove_PageObjects.WidgetInfos.TABLE_MOVECUSTTWONAMES2.exists())
				selected = moveCustomer2DataMoveFunction(
						HouseHoldMove_PageObjects.WidgetInfos.TABLE_MOVECUSTTWONAMES2,
						HouseHoldMove_PageObjects.WidgetInfos.BUTTON_MOVECUSTTWONAME,
						clientE2ETO.getMoveCustomerTwoHHMOVE());
			else {
				Verify.verifyTrue(true, MessageUtility.CUSTNAMES_NOTAVAILABLE);
			}
			if (selected) {
				Verify.verifyTrue(true, clientE2ETO.getMoveCustomerTwoHHMOVE()+ MessageUtility.NAME_MOVED);
			} else {
				Verify.verifyTrue(false, clientE2ETO.getMoveCustomerTwoHHMOVE()+ MessageUtility.NAME_NOTMOVED);
			}
		}

	}

	/**
	 * Click Move button for Move members to New household
	 * 
	 * @throws ScriptException
	 */
	public void clickMovememberstonewhousehold() throws ScriptException {
		if (HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_TO_NEW_HOUSEHOLD
				.exists()) {
			click(HouseHoldMove_PageObjects.WidgetInfos.LINK_MOVEMEMBERS_TO_NEW_HOUSEHOLD,
					MessageUtility.LINK_MOVEMEMBERSTOANEWHOUSEHOLD);
		} else {
			Verify.verifyTrue(false,
					MessageUtility.LINK_MOVEMEMBERSTOANEWHOUSEHOLD_NOTDISPLAYED);
		}
	}

	/**
	 * Selecting One Customer to move
	 * 
	 * @throws ScriptException
	 */
	public void selectNameToMove() throws ScriptException {
		waitForPageLoad(HouseHoldMove_PageObjects.WidgetInfos.BUTTON_MOVECUSTONENAME, 10);
		if (HouseHoldMove_PageObjects.WidgetInfos.BUTTON_MOVECUSTONENAME.exists()) {
			getWebDriverInstance()
					.findElement(By.xpath("//div[@class='threeColumnPage1']/div[@id='householdMembers1']/div[@class='tableContainer']/table[@class='scrollTable']/tbody[@class='scrollContent']/tr[1]/td[1]")).click();
		}
	}



	/**
	 * Click move button
	 * 
	 * @throws ScriptException
	 */
	public void selectMoveButton() throws ScriptException {
		click(HouseHoldMove_PageObjects.WidgetInfos.BUTTON_MOVECUSTONENAME,
				MessageUtility.BUTTON_MOVE);
	}

	/**
	 * Verify Customer Combine/Separate & Household Moves hyper links are not
	 * available
	 */
	public void validateHHMovesAndCustomerCombineInHHPage() {
		try {
			if (isHHPageLaunched()) {
				verifyQBHouseholdMovesLink();
				verifyQBCombineSeparateLink();
			} else {
				Verify.verifyTrue(false, MessageUtility.HOUSEHOLDPAGE_NOTLAUNCHED);
			}
		} catch (ScriptException e) {
			scriptError(e);
		}
	}

	/**
	 * selecting Agent In HhMoves
	 * 
	 * @throws ScriptException
	 */
	public void selectAgentInHhMoves() throws ScriptException {
		try {
			if (HouseHoldMove_PageObjects.WidgetInfos.SELECT_AGENTHHMOVES.exists()) {
				HouseHoldMove_PageObjects.WidgetInfos.SELECT_AGENTHHMOVES.hover();
				HouseHoldMove_PageObjects.WidgetInfos.SELECT_AGENTHHMOVES.click();
				Verify.verifyTrue(true, MessageUtility.AGENT_SELECTED);
			} else {

			}
		} catch (ScriptException scriptException) {
			scriptError(scriptException);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
