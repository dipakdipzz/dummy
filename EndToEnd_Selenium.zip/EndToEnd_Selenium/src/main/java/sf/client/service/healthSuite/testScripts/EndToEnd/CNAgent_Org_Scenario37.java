package sf.client.service.healthSuite.testScripts.EndToEnd;

import sf.client.service.common.helpers.LaunchApplication;
import sf.client.service.healthSuite.baseScripts.BaseScript;
import sf.client.service.healthSuite.tasks.CreateCustomersTasks;
import sf.client.service.healthSuite.tasks.ScenarioTasks;

public class CNAgent_Org_Scenario37 extends BaseScript {


	int count = 0;
	String query = "select * from CNAgent_Org_Scenario37";
	public void executeScript() throws Exception {

		if (clientE2ETO.getType().equalsIgnoreCase("createOrgCanada")) {
			createCustTasks.accessCreateOrgPageWithTIN("createOrgCanada");
			scenarioTasks.launchCustInfoPageFromHHPage();
			scenarioTasks.verifyTinInOrgCustInfo("verifyTIN");
			scenarioTasks.verifyTinInOrgCustInfo("partiallyMasked");
		}
		
		if (clientE2ETO.getType().equalsIgnoreCase("updateTIN")) {
			scenarioTasks.updateTINNumInOrganizationInfoPage("updateTIN");
		}
		
		if(clientE2ETO.getType().equalsIgnoreCase("updateTINToNull")){
			scenarioTasks.updateTinNumToNull("updateTINToNull");
		}
		
		if(clientE2ETO.getType().equalsIgnoreCase("updateNullToTIN")){
			scenarioTasks.updateTINNumInOrganizationInfoPage("updateNullToTIN");
		}
		
		if(clientE2ETO.getType().equalsIgnoreCase("addOrgInHH")){
			scenarioTasks.launchHHPageFromCustInfo();
			scenarioTasks.addOrganizationWithTininHouseholdPage();
		}
	}
	
	public void scriptMain() {
		try {
			transferObject = setTestDataObject(transferObject);
			transferObject.setDbQuery(query);
			dbresultSet = databaseUtil.getCoreData(transferObject);
			launcher = new LaunchApplication(getWATConfig());
			launcher.launchUser(this.getClass().getSimpleName());
			while (dbresultSet.next()) {
				clientE2ETO = databaseUtil.loadTestDataCNAgentOrgScenario37(dbresultSet, clientE2ETO);
				scenarioTasks = new ScenarioTasks(clientE2ETO);
				createCustTasks = new CreateCustomersTasks(clientE2ETO);
				if(count==0){ 
					 createCustTasks.createResultsFile(resultsFileName(), scriptName());
					 createCustTasks.launchCustomerSeachPage();
					 createCustTasks.clickCreateOrganization();
					 count++;
				  }
				executeScript();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
